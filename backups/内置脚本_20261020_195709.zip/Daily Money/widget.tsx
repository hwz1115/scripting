import { isThisMonth } from "./common/date"
import { loadRecordData } from "./common/record_data"
import { stringToCategory } from "./category"
import { getI18n } from "./i18n"
import { VStack, Text, Divider, Chart, Widget, Bar1DChart } from "scripting"
import { RecordInfo } from "./common/types"

async function loadThisMonthRecords() {
  const records = await loadRecordData()
  if (records == null) {
    return null
  }

  return records.filter(record => {
    return isThisMonth(record.time)
  })
}

export function WidgetView({
  records
}: {
  records: RecordInfo[] | null
}) {
  const i18n = getI18n()

  let total = 0
  let map: Record<string, {
    category: string
    total: number
  }> = {}
  let list: {
    category: string
    total: number
  }[] = []

  records?.forEach(item => {
    if (item.isIncome) {
      return
    }
    total += item.amount

    const {
      category
    } = stringToCategory(item.category)

    if (map[category] == null) {
      let m = map[category] = {
        category,
        total: 0,
      }
      list.push(
        m
      )
    }
    map[category].total += item.amount
  })

  list.sort((a, b) => b.total - a.total)

  if (Widget.family === "accessoryCircular") {
    return (
      <VStack
        frame={Widget.displaySize}
      >
        <Text>
          💰
        </Text>
        <Text
          font="footnote"
          lineLimit={1}
        >
          {total.toFixed(2)}
        </Text>
      </VStack>
    )
  }


  return (
    <VStack
      background="systemBackground"
      frame={Widget.displaySize}
    >
      <VStack
        padding
      >
        <Text
          foregroundStyle="secondaryLabel"
          font={12}
          fontWeight="light"
        >
          {i18n.expensesForTheMonth}
        </Text>
        <Text
          fontWeight="bold"
          foregroundStyle="systemGreen"
        >
          {total.toFixed(2)}
        </Text>
        <Divider />
        <Chart
        >
          <Bar1DChart
            marks={
              list.map(item => ({
                category: item.category,
                value: item.total,
              }))
            }
          />
          {/* <DonutChart
            marks={
              list.map(item => ({
                category: item.category,
                value: item.total,
                innerRadius: {
                  type: "ratio",
                  value: 0.5
                },
                outerRadius: {
                  type: "inset",
                  value: 10
                },
                angularInset: 1,
                cornerRadius: 4,
              }))
            }
          /> */}
        </Chart>
      </VStack>
    </VStack>
  )
}


async function run() {
  let records = await loadThisMonthRecords()

  Widget.present(
    <WidgetView
      records={records}
    />
  )
}

run()
