import { categoryToString, loadCategories } from "../category"
import { getI18n } from "../i18n"
import { Category, RecordInfo } from "./types"

type RecognizedResult = Omit<
  RecordInfo,
  "id" | "time"
>

export async function voiceRecording(
  onRecognized: (details: {
    text: string
    result: RecognizedResult | null
  }) => void
  // listenFor?: number
) {
  const data = await loadCategories()
  if (!data) {
    return
  }

  const categoryData = data!
  const i18n = getI18n()

  // let result: RecognizedResult | null = null

  await SpeechRecognition.start({
    // listenFor: listenFor,
    onResult: ({
      text
    }) => {
      const result = textRecognition(
        text
      )
      onRecognized({
        text,
        result,
      })
      // if (res != null) {
      //   result = res
      // }
    },
    // localeId: Device.systemLocale,
    locale: "zh-CN"
  })

  // return result

  function textRecognition(
    text: string
  ) {
    let amount = text.match(/\d+\.?\d*/)?.[0]
    if (!amount) {
      return null
    }

    let expense = matchCategories(
      text,
      categoryData.expenses,
      false,
    )

    let income = matchCategories(
      text,
      categoryData.income,
      true
    )

    let notes = matchNotes(text)

    let result: RecognizedResult | null = null

    if (expense && income) {
      if (isIncome(text)) {
        result = {
          amount: Number(amount),
          category: categoryToString(
            income.category,
            income.subCategory,
          ),
          isIncome: true,
          notes: notes ?? ""
        }
      } else {
        result = {
          amount: Number(amount),
          category: categoryToString(
            expense.category,
            expense.subCategory,
          ),
          isIncome: false,
          notes: notes ?? ""
        }
      }
    } else if (expense || income) {
      let a = (expense ?? income)!
      result = {
        amount: Number(amount),
        category: categoryToString(
          a.category,
          a.subCategory,
        ),
        isIncome: a.isIncome,
        notes: notes ?? ""
      }
    }


    return result
  }

  function matchCategories(
    text: string,
    categories: Category[],
    isIncome: boolean
  ) {

    for (const category of categories) {
      for (const subCategory of category.items) {
        if (text.includes(subCategory.name)) {
          return {
            category,
            subCategory,
            isIncome,
          }
        }
      }
    }
  }

  function matchNotes(text: string) {
    let index = text.indexOf(i18n.notes)
    if (index === -1) {
      return null
    }
    return text.slice(
      index + i18n.notes.length
    )
  }

  function isIncome(text: string) {
    return text.includes(i18n.income)
  }

}