import { stringToCategory } from "../category"
import {
  RecordInfo,
  RecordsOfDate,
  RecordsOfMonth,
  RecordsOfYear,
  CategoryDetails,
} from "./types"

export function countYearTotal(
  record: RecordsOfYear,
  isIncome: boolean,
) {
  return record.records.reduce(
    (sum, item) =>
      sum + countMonthTotal(item, isIncome),
    0,
  )
}

export function countMonthTotal(
  record: RecordsOfMonth,
  isIncome: boolean,
) {
  return record.records.reduce(
    (sum, item) =>
      sum + countDateTotal(item, isIncome),
    0,
  )
}

export function countDateTotal(
  record: RecordsOfDate,
  isIncome: boolean,
) {
  return record.records
    .filter((e) => !!e.isIncome === isIncome)
    .reduce((sum, item) => {
      return sum + item.amount
    }, 0)
}

export function calcCategoryDetails(
  forEach: (
    callback: (item: RecordInfo) => void,
  ) => void,
) {
  let totalIncome = 0
  let totalExpenses = 0

  const income: CategoryDetails[] = []
  const expenses: CategoryDetails[] = []

  const incomePrimaryMap: {
    [name: string]: CategoryDetails
  } = {}
  const incomeSecondaryMap: {
    [name: string]: CategoryDetails
  } = {}
  const expensesPrimaryMap: {
    [name: string]: CategoryDetails
  } = {}
  const expensesSecondaryMap: {
    [name: string]: CategoryDetails
  } = {}

  forEach((item) => {
    const {
      category,
      subCategory,
    } = stringToCategory(
      item.category,
    )
    if (item.isIncome) {
      if (incomePrimaryMap[category] == null) {
        incomePrimaryMap[category] = {
          category: category,
          categoryFullName: category,
          total: 0,
          percent: 0,
          items: [],
          records: []
        }
        income.push(
          incomePrimaryMap[category]
        )
      }
      if (incomeSecondaryMap[item.category] == null) {
        incomeSecondaryMap[item.category] = {
          category: subCategory,
          categoryFullName: item.category,
          total: 0,
          items: [],
          records: [],
          percent: 0,
        }
        incomePrimaryMap[category]
          .items.push(
            incomeSecondaryMap[
            item.category
            ],
          )
      }
      totalIncome += item.amount
      incomePrimaryMap[category]
        .records.push(
          item
        )
      incomeSecondaryMap[item.category]
        .records.push(
          item
        )
      incomePrimaryMap[category]
        .total += item.amount
      incomeSecondaryMap[item.category]
        .total +=
        item.amount
    } else {
      if (expensesPrimaryMap[category] == null) {
        expensesPrimaryMap[category] = {
          category: category,
          categoryFullName: category,
          total: 0,
          percent: 0,
          items: [],
          records: []
        }
        expenses.push(
          expensesPrimaryMap[category]
        )
      }
      if (
        expensesSecondaryMap[item.category] == null
      ) {
        expensesSecondaryMap[item.category] = {
          category: subCategory,
          categoryFullName: item.category,
          total: 0,
          percent: 0,
          items: [],
          records: []
        }
        expensesPrimaryMap[category]
          .items.push(
            expensesSecondaryMap[
            item.category
            ],
          )
      }
      totalExpenses += item.amount
      expensesPrimaryMap[category]
        .total += item.amount
      expensesSecondaryMap[item.category]
        .total += item.amount
      expensesPrimaryMap[category]
        .records.push(item)
      expensesSecondaryMap[item.category]
        .records.push(item)
    }
  })

  function countPercent(
    list: CategoryDetails[],
    total: number,
  ) {
    for (const item of list) {
      item.percent =
        total === 0
          ? 0 :
          (100 * item.total) / total
      if (item.items.length > 0) {
        countPercent(item.items, total)
        item.items.sort((a, b) =>
          b.total - a.total
        )
      }
    }
    list.sort((a, b) => b.total - a.total)
  }

  countPercent(income, totalIncome)
  countPercent(expenses, totalExpenses)

  return {
    income,
    expenses,
    totalExpenses,
    totalIncome,
  }
}

export function calcCategoryDetailsOfMonth(
  record: RecordsOfMonth,
) {
  return calcCategoryDetails((callback) => {
    for (const date of record.records) {
      for (const item of date.records) {
        callback(item)
      }
    }
  })
}

export function calcCategoryDetailsOfDate(
  record: RecordsOfDate,
) {
  return calcCategoryDetails((callback) => {
    for (const item of record.records) {
      callback(item)
    }
  })
}

export function calcCategoryDetailsOfYear(
  record: RecordsOfYear,
) {
  return calcCategoryDetails((callback) => {
    for (const month of record.records) {
      for (const date of month.records) {
        for (const item of date.records) {
          callback(item)
        }
      }
    }
  })
}

export function calcAllCategoryDetails(
  records: RecordsOfYear[],
) {
  return calcCategoryDetails((callback) => {
    for (const year of records) {
      for (const month of year.records) {
        for (const date of month.records) {
          for (const item of date.records) {
            callback(item)
          }
        }
      }
    }
  })
}
