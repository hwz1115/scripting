export function toNumber(text: string) {
  const result = parseFloat(text)
  return isNaN(result) ? null : result
}

export function getSecondsSinceDayStart(date: Date) {
  const hours = date.getHours()
  const minutes = date.getMinutes()

  return getSeconds(hours, minutes)
}

export function getDateTimeFromSeconds(
  seconds: number,
) {
  const date = new Date()
  date.setHours(0)
  date.setMinutes(0)
  date.setSeconds(0)
  return date.getTime() + seconds * 1000
}

export function getSeconds(
  hours: number,
  minutes: number,
) {
  return (hours * 60 + minutes) * 60
}

export function padLeft(
  str: string,
  len: number,
  padString = " ",
) {
  if (str.length >= len) {
    return str
  }
  return padString.repeat(len - str.length) + str
}

export function formatAsTimeString(date: Date) {
  const hours = date.getHours().toString()
  const mins = date.getMinutes().toString()
  return (
    padLeft(hours, 2, "0") +
    ":" +
    padLeft(mins, 2, "0")
  )
}

export function formatAsDateAndTimeString(
  time: number,
) {
  const date = new Date(time)
  const dateString = date.toLocaleDateString()
  const timeString = formatAsTimeString(date)

  return dateString + " " + timeString
}

export function isStringASingleEmoji(str: string) {
  // return /^\p{Emoji}$/u.test(str)
  return /^\p{Extended_Pictographic}/u.test(str)
}

