import { getI18n } from "../i18n"
import { padLeft } from "./utils"

export function isToday(time: number) {
  const date = new Date(time)
  const now = new Date()
  return (
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate()
  )
}

export function isThisMonth(time: number) {
  const date = new Date(time)
  const now = new Date()
  return (
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth()
  )
}

export function isThisYear(time: number) {
  const date = new Date(time)
  const now = new Date()
  return date.getFullYear() === now.getFullYear()
}

export function isSameYear(
  time1: number,
  time2: number,
) {
  return (
    new Date(time1).getFullYear() ===
    new Date(time2).getFullYear()
  )
}

export function isSameMonth(
  time1: number,
  time2: number,
) {
  const date = new Date(time1)
  const date2 = new Date(time2)
  return (
    date.getFullYear() === date2.getFullYear() &&
    date.getMonth() === date2.getMonth()
  )
}

export function isSameDate(
  time1: number,
  time2: number,
) {
  const date = new Date(time1)
  const date2 = new Date(time2)
  return (
    date.getFullYear() === date2.getFullYear() &&
    date.getMonth() === date2.getMonth() &&
    date.getDate() === date2.getDate()
  )
}

export function getYYYY(time: number) {
  return new Date(time).getFullYear().toString()
}

export function getYYYYMM(time: number) {
  const date = new Date(time)
  return (
    date.getFullYear() +
    "/" +
    padLeft((date.getMonth() + 1).toString(), 2, "0")
  )
}

export function getYYYYMMDD(time: number) {
  const date = new Date(time)
  // return date.toLocaleDateString()
  return (
    date.getFullYear() +
    "/" +
    padLeft((date.getMonth() + 1).toString(), 2, "0") +
    "/" +
    padLeft(date.getDate().toString(), 2, "0")
  )
}

const i18n = getI18n()

const weeks = [
  i18n.sunday,
  i18n.monday,
  i18n.tuesday,
  i18n.wednesday,
  i18n.thursday,
  i18n.friday,
  i18n.satuaday,
]
export function getDateLabel(time: number) {
  if (isToday(time)) {
    return `${i18n.today}, ${getMMDD(time)}`
  }
  const date = new Date(time)
  const weekLabel = weeks[date.getDay()]
  return `${weekLabel}, ${getMMDD(time)}`
}

export function getMMDD(time: number) {
  const date = new Date(time)
  return (
    padLeft((date.getMonth() + 1).toString(), 2, "0") +
    "/" +
    padLeft(date.getDate().toString(), 2, "0")
  )
}

export function getHHmm(time: number) {
  const date = new Date(time)
  return (
    padLeft(date.getHours().toString(), 2, "0") +
    ":" +
    padLeft(date.getMinutes().toString(), 2, "0")
  )
}

const monthList: string[] = [
  i18n.january,
  i18n.february,
  i18n.march,
  i18n.april,
  i18n.may,
  i18n.june,
  i18n.july,
  i18n.august,
  i18n.september,
  i18n.october,
  i18n.november,
  i18n.december,
]

export function getMonthLabel(month: number) {
  return monthList[month]
}
