import { RecordInfo } from "./types"
import { loadData, copyFileFromDocumentsIfExists, saveData } from "./data"

const recordsFilePath =
  "daily-expenses-and-income-data.json"

export async function restoreRecordData() {
  await copyFileFromDocumentsIfExists(recordsFilePath)
}

export async function loadRecordData() {
  const records = await loadData<RecordInfo[]>(
    recordsFilePath,
  )

  return records
}

export async function saveRecordData(
  newRecords: RecordInfo[],
) {
  await saveData(
    recordsFilePath,
    newRecords
  )
}