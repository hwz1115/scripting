export type Category = {
  name: string
  icon: string
  items: SubCategory[]
}

export type SubCategory = {
  name: string
  icon: string
  recommendTimeRange?: RecommendTimeRange
}

export type RecommendTimeRange = {
  from: number
  to: number
}

export type RecordInfo = {
  id: string
  isIncome: boolean
  amount: number
  category: string
  time: number
  notes: string
}

export type RecordsOfDate = {
  date: Date
  records: RecordInfo[]
}

export type RecordsOfMonth = {
  date: Date
  records: RecordsOfDate[]
}

export type RecordsOfYear = {
  date: Date
  records: RecordsOfMonth[]
}

export type CategoryDetails = {
  category: string
  categoryFullName: string
  percent: number
  total: number
  items: CategoryDetails[]
  records: RecordInfo[]
}
