import { Intent, Navigation, Script } from "scripting"
import { getI18n } from "./i18n"
import { matchCategory } from "./category"
import { NewRecordPage } from "./pages/new_record"
import type { RecordInfo } from "./common/types"


function matchAmount(
  text: string
) {
  return text.match(/[+-]?[0-9]+\.[0-9]{1,3}/g)
}

async function run() {
  const i18n = getI18n()

  if (Intent.shortcutParameter == null) {
    Dialog.alert({
      message: i18n.noShortcutParameterFound,
    })

    Script.exit()
    return
  }

  if (Intent.shortcutParameter.type !== "text") {
    Dialog.alert({
      message: i18n.shortcutTextParamOnly,
    })
    Script.exit()
    return
  }

  const text = Intent.shortcutParameter.value
  const matchList = matchAmount(text)?.map(
    item => ({
      value: Number(item),
      str: item
    })
  ).filter(
    item => !isNaN(item.value)
  )

  if (matchList == null || matchList.length === 0) {
    Dialog.alert({
      message: i18n.noAmountDetected,
    })
    Script.exit()
    return
  }

  let selected: {
    value: number
    str: string
  }

  if (matchList.length > 1) {
    let index = await Dialog.actionSheet({
      title: i18n.multipleAmountRecognized,
      actions: matchList.map(item =>
      ({
        label: item.str
      }))
    })

    if (index == null) {
      return
    }

    selected = matchList[index]
  } else {
    selected = matchList[0]
  }

  const isIncome = selected.str.startsWith("+")
  const matchCategoryResult = await matchCategory(text)

  const newRecord = await Navigation.present<RecordInfo>({
    element: <NewRecordPage
      amount={Math.abs(selected.value)}
      category={
        matchCategoryResult != null
          && matchCategoryResult.isIncome == isIncome
          ? matchCategoryResult.category
          : undefined
      }
      isIncome={isIncome}
    />
  })

  if (newRecord != null) {
    await Dialog.alert({
      message: i18n.recordSuccessful(
        newRecord.category,
        newRecord.amount,
        newRecord.isIncome
      )
    })
  }

  Script.exit()
}

run()