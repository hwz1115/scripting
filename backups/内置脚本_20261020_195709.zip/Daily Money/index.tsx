import { Navigation, Script } from "scripting"
import { initCategory, restoreCategoryData } from "./category"
import { MainPage } from "./pages/main"
import { restoreRecordData } from "./common/record_data"

async function run() {
  await Promise.all([
    restoreCategoryData(),
    restoreRecordData(),
  ])
  await initCategory()

  await Navigation.present({
    element: <MainPage />
  })

  // Exit the script and return result
  Script.exit()
}

run()
