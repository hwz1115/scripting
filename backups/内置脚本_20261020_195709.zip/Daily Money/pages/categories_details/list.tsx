import { Button, Group, HStack, Label, List, Navigation, NavigationLink, Section, Spacer, Text, VStack, useContext, useMemo, useState } from "scripting"
import { CategoryDetails, RecordInfo } from "../../common/types"
import { RecordDataContext } from "../main/store"
import { stringToCategory } from "../../category"
import { getHHmm, getMMDD, getYYYYMMDD, isThisYear } from "../../common/date"
import { EditRecordPage } from "../edit_record"
import { useI18n } from "../../i18n"

export function CategoriesDetailsList({
  list, isIncome, title,
}: {
  title: string
  list: CategoryDetails[]
  isIncome: boolean
}) {
  const i18n = useI18n()
  const {
    getPrimaryIcon,
    getIcon,
  } = useContext(RecordDataContext)

  return <Group>
    {list.map(item =>
      <Section
        header={
          <HStack>
            <Text>
              {getPrimaryIcon(
                item.category,
                isIncome
              )}
            </Text>
            <Text>{item.category}</Text>
            <Spacer />
          </HStack>
        }
      >
        <NavigationLink
          destination={
            <CategoryList
              title={
                item.category
              }
              details={item}
            />
          }
        >
          <Text
            badge={item.total.toLocaleString()}
          >
            {i18n.total}
          </Text>
        </NavigationLink>
        {item.items.map(subItem =>
          <NavigationLink
            destination={
              <CategoryList
                title={item.category}
                details={subItem}
              />
            }
          >
            <HStack>
              <Text>{getIcon(
                subItem.categoryFullName,
                isIncome
              )}</Text>
              <Text>{subItem.category}</Text>
              <Spacer />
              <Text
                font="subheadline"
                foregroundStyle="secondaryLabel"
              >{subItem.total.toLocaleString()}</Text>
            </HStack>
          </NavigationLink>
        )}
      </Section>
    )}
  </Group>

}

function CategoryList({
  title,
  details
}: {
  title: string
  details: CategoryDetails
}) {
  const i18n = useI18n()
  const [
    sortByTime,
    setSortByTime
  ] = useState(true)

  const {
    getIcon,
    updateRecord,
    removeRecord,
  } = useContext(RecordDataContext)

  async function editRecord(
    record: RecordInfo
  ) {
    const result = await Navigation.present<
      RecordInfo
    >({
      element: <EditRecordPage
        record={record}
      />,
      modalPresentationStyle: "pageSheet"
    })
    if (result != null) {
      updateRecord(result)
    }
  }

  const list = useMemo(() => {
    if (sortByTime) {
      return details.records
        .slice()
        .sort((a, b) =>
          b.time - a.time
        )
    }
    return details.records
      .slice()
      .sort((a, b) =>
        b.amount - a.amount
      )
  }, [details, sortByTime])

  return <List
    navigationTitle={title}
    navigationBarTitleDisplayMode="inline"
  >
    <Section
      header={
        <HStack>
          <Spacer />
          <Button
            font="subheadline"
            action={() => {
              setSortByTime(!sortByTime)
            }}
          >
            <Label
              title={
                sortByTime
                  ? i18n.sortByAmount
                  : i18n.sortByTime
              }
              systemImage="arrow.up.arrow.down"
            />
          </Button>
        </HStack>
      }
    >
      {list.map(record =>
        <HStack
          contentShape="rect"
          onTapGesture={async () => {
            editRecord(record)
          }}
          trailingSwipeActions={{
            allowsFullSwipe: false,
            actions: [
              <Button
                title={i18n.delete}
                role="destructive"
                action={() => {
                  removeRecord(record.id)
                }}
              />
            ]
          }}
        >
          <Text>
            {getIcon(
              record.category,
              record.isIncome,
            )}
          </Text>

          <VStack
            alignment="leading"
          >
            <Text>
              {
                stringToCategory(
                  record.category
                ).subCategory
              }
            </Text>
            <HStack font="footnote">
              <Text
                foregroundStyle={"systemBlue"}>
                {(isThisYear(record.time) ? getMMDD(record.time) : getYYYYMMDD(record.time)) + " " + getHHmm(record.time)}
              </Text>
              <Text
                foregroundStyle="secondaryLabel"
              >
                {record.notes}
              </Text>
            </HStack>
          </VStack>
          <Spacer />
          <Text foregroundStyle={
            "secondaryLabel"
          }>
            {record.amount.toLocaleString()}
          </Text>
        </HStack>
      )}
    </Section>
  </List>
}