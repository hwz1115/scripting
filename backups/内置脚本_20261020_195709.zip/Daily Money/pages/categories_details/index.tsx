import { EmptyView, List, Picker, Section, Text, useMemo, useState } from "scripting"
import { RecordsOfDate, RecordsOfMonth, RecordsOfYear } from "../../common/types"
import { calcAllCategoryDetails, calcCategoryDetailsOfDate, calcCategoryDetailsOfMonth, calcCategoryDetailsOfYear } from "../../common/calc"
import { useI18n } from "../../i18n"
import { CategoriesDetailsCharts } from "./charts"
import { CategoriesDetailsList } from "./list"

export function CategoriesDetailsPage({
  type, records, title
}: ({
  type: "all"
  records: RecordsOfYear[]
} | {
  type: "date"
  records: RecordsOfDate
} | {
  type: "month"
  records: RecordsOfMonth
} | {
  type: "year"
  records: RecordsOfYear
}) & {
  title: string
}) {
  const i18n = useI18n()
  const {
    income,
    expenses,
    totalExpenses,
    totalIncome,
  } = useMemo(() => {
    switch (type) {
      case "date":
        return calcCategoryDetailsOfDate(records)
      case "month":
        return calcCategoryDetailsOfMonth(records)
      case "year":
        return calcCategoryDetailsOfYear(records)
      case "all":
        return calcAllCategoryDetails(records)
    }
  }, [type, records])

  const [
    tabIndex,
    setTabIndex
  ] = useState(0)
  const isIncome = tabIndex === 1

  const total = !isIncome
    ? totalExpenses
    : totalIncome

  const list = isIncome
    ? income
    : expenses

  return <List
    navigationTitle={title}
    navigationBarTitleDisplayMode="inline"
    contentMargins={{
      edges: "top",
      insets: 0
    }}
  >
    <Section
      listRowBackground={
        <EmptyView />
      }>
      <Picker
        title="Record Type"
        pickerStyle="segmented"
        value={tabIndex}
        onChanged={setTabIndex}
      >
        <Text
          tag={0}
        >{i18n.expenses}
        </Text>
        <Text
          tag={1}
        >{i18n.income}
        </Text>
      </Picker>
    </Section>
    <CategoriesDetailsCharts
      total={total}
      list={list}
    />
    <CategoriesDetailsList
      title={title}
      list={list}
      isIncome={isIncome}
    />
  </List>
}