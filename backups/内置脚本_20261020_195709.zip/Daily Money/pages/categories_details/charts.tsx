import { Chart, DonutChart, Section, Text, VStack } from "scripting"
import { CategoryDetails } from "../../common/types"
import { useI18n } from "../../i18n"

export function CategoriesDetailsCharts({
  total,
  list,
}: {
  total: number
  list: CategoryDetails[]
}) {
  const i18n = useI18n()

  return <Section>
    {list.length
      ? <VStack
        frame={{
          maxWidth: "infinity"
        }}
      >
        <Chart
          scaleToFit
          frame={{
            width: 250
          }}
          chartLegend={{
            position: "trailing",
            alignment: "center"
          }}
        >
          <DonutChart
            marks={
              list.map(item => ({
                category: item.category + " " + item.percent.toFixed(2) + "%",
                value: item.total,
                angularInset: 2,
                innerRadius: {
                  type: "ratio",
                  value: 0.6
                },
                cornerRadius: 4,
              }))
            }
          />
        </Chart>
      </VStack>
      : null}
    <Text
      badge={total.toLocaleString()}>
      {i18n.total}
    </Text>
  </Section>
}