
import { Button, DatePicker, Form, Group, Navigation, NavigationStack, Picker, Section, Text, TextField, Toggle, useContext, useState } from "scripting"
import { useI18n } from "../../i18n"
import { Category } from "../../common/types"
import { getSecondsSinceDayStart, isStringASingleEmoji } from "../../common/utils"
import { RecordDataContext } from "../main/store"

export function NewSubCategoryPage({
  categories,
}: {
  categories: Category[]
}) {
  const i18n = useI18n()
  const dismiss = Navigation.useDismiss()
  const [
    category,
    setCategory
  ] = useState(categories[0]?.name ?? "")
  const [
    icon,
    setIcon
  ] = useState("")
  const [
    name,
    setName
  ] = useState("")
  const [
    from,
    setFrom
  ] = useState<number>()
  const [
    to,
    setTo
  ] = useState<number>()
  const [
    timeRangeEnabled,
    setTimeRangeEnabled
  ] = useState(false)
  const {
    addSubCategory
  } = useContext(RecordDataContext)

  const isReady = category.length > 0
    && name.length > 0
    && isStringASingleEmoji(icon)
    && (!timeRangeEnabled
      || (
        from != null
        && to != null
        && from < to
      )
    )

  async function add() {
    let cate = categories.find(
      item => item.name === category
    )

    if (cate == null) {
      return
    }

    await addSubCategory(
      cate,
      {
        name,
        icon,
        recommendTimeRange: timeRangeEnabled
          && from != null && to != null
          ? {
            from: getSecondsSinceDayStart(new Date(from)),
            to: getSecondsSinceDayStart(new Date(to))
          }
          : undefined
      }
    )

    dismiss()
  }

  return <NavigationStack>
    <Form
      navigationTitle={i18n.subcategoryInfo}
      navigationBarTitleDisplayMode="inline"
      toolbar={{
        topBarLeading: <Button
          title={i18n.cancel}
          action={dismiss}
        />,
        topBarTrailing: <Button
          title={i18n.add}
          action={add}
          disabled={!isReady}
          fontWeight="medium"
        />
      }}
    >
      <Section
        header={
          <Text>{i18n.icon}</Text>
        }>
        <TextField
          title={i18n.categoryIconPlaceholder}
          value={icon}
          onChanged={setIcon}
        />
      </Section>
      <Section
        header={
          <Text>{i18n.name}</Text>
        }>
        <TextField
          title={i18n.categoryNamePlaceholder}
          value={name}
          onChanged={setName}
        />
      </Section>

      <Section>
        <Picker
          title={i18n.category}
          value={category}
          onChanged={setCategory}
        >
          {categories.map(item =>
            <Text tag={item.name}
            >{
                item.icon + "  " + item.name
              }</Text>
          )}
        </Picker>
      </Section>

      <Section
        footer={
          <Text>{i18n.recommendTimeRangeSubtitle}
          </Text>
        }
      >
        <Toggle
          title={i18n.recommendTimeRange}
          value={timeRangeEnabled}
          onChanged={value => {
            setTimeRangeEnabled(value)
            if (value && !from && !to) {
              setFrom(Date.now())
              setTo(Date.now() + 1000 * 60 * 30)
            }
          }}
        />
        {timeRangeEnabled ?
          <Group>
            <DatePicker
              title={i18n.timeFrom}
              value={from ?? Date.now()}
              onChanged={setFrom}
              endDate={to ?? undefined}
              displayedComponents={["hourAndMinute"]}
            />
            <DatePicker
              title={i18n.timeTo}
              value={to ?? Date.now()}
              onChanged={setTo}
              startDate={from ?? undefined}
              displayedComponents={["hourAndMinute"]}
            />
          </Group>
          : null}
      </Section>
    </Form>
  </NavigationStack>
}