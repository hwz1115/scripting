import { Button, Form, Navigation, NavigationStack, Section, TextField, useContext, useState } from "scripting"
import { Category } from "../../common/types"
import { useI18n } from "../../i18n"
import { RecordDataContext } from "../main/store"
import { isStringASingleEmoji } from "../../common/utils"

export function EditCategoryPage({
  info,
  categories,
}: {
  info: Category
  categories: Category[]
}) {
  const dismiss = Navigation.useDismiss()
  const i18n = useI18n()
  const [
    icon,
    setIcon
  ] = useState(info.icon)
  const [
    name,
    setName
  ] = useState(info.name)
  const {
    updateCategory
  } = useContext(
    RecordDataContext
  )
  const isReady = (icon != info.icon
    && isStringASingleEmoji(icon))
    || (name != info.name && name.length > 0
      && categories.some(
        item => item.name !== name
      ))

  async function save() {
    await updateCategory(info,
      {
        name, icon, items: info.items,
      }
    )
    dismiss()
  }

  return <NavigationStack>
    <Form
      navigationTitle={i18n.editCategory}
      navigationBarTitleDisplayMode="inline"
      toolbar={{
        topBarLeading: <Button
          title={i18n.cancel}
          action={dismiss}
        />,
        topBarTrailing: <Button
          title={i18n.save}
          action={save}
          fontWeight="medium"
          disabled={!isReady}
        />
      }}
    >
      <Section>
        <TextField
          title={i18n.categoryIconPlaceholder}
          value={icon}
          onChanged={setIcon}
        />
      </Section>
      <Section>
        <TextField
          title={i18n.categoryNamePlaceholder}
          value={name}
          onChanged={setName}
        />
      </Section>
    </Form>
  </NavigationStack>
}