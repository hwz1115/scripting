import { Button, EmptyView, Form, Navigation, NavigationStack, Picker, Section, Text, TextField, useContext, useSelector, useState } from "scripting"
import { useI18n } from "../../i18n"
import { isStringASingleEmoji } from "../../common/utils"
import { Category } from "../../common/types"
import { RecordDataContext } from "../main/store"

export function NewCategoryPage() {
  const i18n = useI18n()
  const dismiss = Navigation.useDismiss()
  const [
    icon,
    setIcon
  ] = useState("")
  const [
    name,
    setName
  ] = useState("")
  const [
    tabIndex,
    setTabIndex
  ] = useState(0)
  const isIncome = tabIndex === 1

  const {
    addCategory,
    categoryData,
  } = useContext(RecordDataContext)

  const categories = isIncome
    ? categoryData.income
    : categoryData.expenses

  const isReady = isStringASingleEmoji(icon)
    && name.length > 0
    && categories.some(
      item => item.name !== name
    )

  async function add() {
    const category: Category = {
      icon,
      name,
      items: []
    }
    await addCategory(
      categories,
      category
    )
    dismiss()
  }


  return <NavigationStack>
    <Form
      navigationTitle={i18n.categoryInfo}
      navigationBarTitleDisplayMode="inline"
      toolbar={{
        topBarLeading: <Button
          title={i18n.cancel}
          action={dismiss}
        />,
        topBarTrailing: <Button
          title={i18n.add}
          disabled={!isReady}
          action={add}
        />
      }}
      contentMargins={{
        edges: "top",
        insets: 0
      }}
    >
      <Picker
        title={i18n.type}
        value={tabIndex}
        onChanged={setTabIndex}
        pickerStyle="segmented"
        listRowBackground={
          <EmptyView />
        }
      >
        <Text tag={0}>{i18n.expenses}</Text>
        <Text tag={1}>{i18n.income}</Text>
      </Picker>
      <Section
        header={
          <Text>{i18n.icon}</Text>
        }
      >
        <TextField
          title={i18n.categoryIconPlaceholder}
          value={icon}
          onChanged={setIcon}
        />
      </Section>

      <Section
        header={
          <Text>{i18n.name}</Text>
        }
      >
        <TextField
          title={i18n.categoryNamePlaceholder}
          value={name}
          onChanged={setName}
        />
      </Section>
    </Form>
  </NavigationStack>
}