import { Button, DatePicker, Form, Group, Navigation, Picker, Section, Text, TextField, Toggle, useContext, useState } from "scripting"
import { useI18n } from "../../i18n"
import { Category, SubCategory } from "../../common/types"
import { getDateTimeFromSeconds, getSecondsSinceDayStart, isStringASingleEmoji } from "../../common/utils"
import { RecordDataContext } from "../main/store"

export function EditSubCategoryPage({
  info,
  category: initialCategory,
  categories,
}: {
  info: SubCategory,
  category: string
  categories: Category[]
}) {
  const i18n = useI18n()
  const dismiss = Navigation.useDismiss()
  const {
    updateSubCategory
  } = useContext(
    RecordDataContext
  )
  const [
    category,
    setCategory
  ] = useState(initialCategory)
  const [
    icon,
    setIcon
  ] = useState(info.icon)
  const [
    name,
    setName
  ] = useState(info.name)
  const [
    from,
    setFrom
  ] = useState(() => {
    let seconds = info.recommendTimeRange?.from
    if (seconds == null) {
      return Date.now()
    }
    return getDateTimeFromSeconds(seconds)
  })
  const [
    to,
    setTo
  ] = useState(() => {
    let seconds = info.recommendTimeRange?.to
    if (seconds == null) {
      return Date.now() + 1000 * 60 * 30
    }
    return getDateTimeFromSeconds(seconds)
  })
  const [
    timeRangeEnabled,
    setTimeRangeEnabled
  ] = useState(info.recommendTimeRange != null)

  const isReady = (
    icon != info.icon
    && isStringASingleEmoji(icon)
  ) || (
      name != info.name
      && name.length
    ) || (
      info.recommendTimeRange != null
        ? !timeRangeEnabled
        || from != getDateTimeFromSeconds(
          info.recommendTimeRange.from
        )
        || to != getDateTimeFromSeconds(
          info.recommendTimeRange.to
        )
        : timeRangeEnabled
    )

  async function save() {
    let newRecord: SubCategory = {
      name,
      icon,
      recommendTimeRange: timeRangeEnabled
        ? {
          from: getSecondsSinceDayStart(new Date(from!)),
          to: getSecondsSinceDayStart(new Date(to!))
        } : undefined
    }

    await updateSubCategory(
      info, newRecord
    )

    dismiss()
  }

  return <Form
    navigationTitle={i18n.subcategoryInfo}
    navigationBarTitleDisplayMode="inline"
    toolbar={{
      topBarTrailing: <Button
        title={i18n.save}
        disabled={!isReady}
        action={save}
      />
    }}
  >
    <Section>
      <TextField
        title={i18n.categoryIconPlaceholder}
        value={icon}
        onChanged={setIcon}
      />
    </Section>
    <Section>
      <TextField
        title={i18n.categoryNamePlaceholder}
        value={name}
        onChanged={setName}
      />
    </Section>

    <Section>
      <Picker
        title={i18n.category}
        value={category}
        onChanged={setCategory}
      >
        {categories.map(item =>
          <Text tag={item.name}
          >{
              item.icon + "  " + item.name
            }</Text>
        )}
      </Picker>
    </Section>

    <Section
      footer={
        <Text>{i18n.recommendTimeRangeSubtitle}
        </Text>
      }
    >
      <Toggle
        title={i18n.recommendTimeRange}
        value={timeRangeEnabled}
        onChanged={value => {
          setTimeRangeEnabled(value)
          if (value && !from && !to) {
            setFrom(Date.now())
            setTo(Date.now() + 1000 * 60)
          }
        }}
      />
      {timeRangeEnabled ?
        <Group>
          <DatePicker
            title={i18n.timeFrom}
            value={from ?? Date.now()}
            onChanged={setFrom}
            endDate={to ?? undefined}
            displayedComponents={["hourAndMinute"]}
          />
          <DatePicker
            title={i18n.timeTo}
            value={to ?? Date.now()}
            onChanged={setTo}
            startDate={from ?? undefined}
            displayedComponents={["hourAndMinute"]}
          />
        </Group>
        : null}
    </Section>
  </Form>
}