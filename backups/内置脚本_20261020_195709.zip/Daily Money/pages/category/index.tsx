import { Button, DisclosureGroup, EmptyView, HStack, List, Navigation, NavigationLink, NavigationStack, Picker, ProgressView, Section, Spacer, Text, useContext, useState } from "scripting"
import { useI18n } from "../../i18n"
import { EditSubCategoryPage } from "./edit_sub_category"
import { NewCategoryPage } from "./new_category"
import { NewSubCategoryPage } from "./new_sub_category"
import { RecordDataContext } from "../main/store"
import { EditCategoryPage } from "./edit_category"
import { Category } from "../../common/types"

export function CategoryPage() {
  const i18n = useI18n()
  const dismiss = Navigation.useDismiss()

  const [
    isNewCategoryPresented,
    setIsNewCategoryPresented
  ] = useState(false)
  const [
    isNewSubcategoryPresented,
    setIsNewSubcategoryPresented
  ] = useState(false)
  const [
    isEditCategoryPresented,
    setIsEditCategoryPresented
  ] = useState(false)

  const [
    editingCategory,
    setEditingCategory
  ] = useState<Category>()

  const {
    categoryData,
    removeCategory,
    removeSubCategory,
  } = useContext(RecordDataContext)

  const [
    tabIndex,
    setTabIndex
  ] = useState(0)

  const categories = tabIndex === 0
    ? categoryData.expenses
    : categoryData.income

  return <NavigationStack>
    <List
      navigationTitle={i18n.category}
      navigationBarTitleDisplayMode="inline"
      toolbar={{
        topBarLeading: <Button
          title={i18n.done}
          action={dismiss}
        />,
        bottomBar: <HStack>
          <Button
            title={i18n.newSubcategory}
            fontWeight="medium"
            action={() => {
              setIsNewSubcategoryPresented(true)
            }}
          />
          <Spacer />
          <Button
            title={i18n.addCategory}
            action={() => {
              setIsNewCategoryPresented(true)
            }}
          />
        </HStack>
      }}
      contentMargins={{
        edges: "top",
        insets: 0
      }}
      sheet={[
        {
          isPresented: isNewCategoryPresented,
          onChanged: setIsNewCategoryPresented,
          content: <NewCategoryPage />
        },
        {
          isPresented: isEditCategoryPresented,
          onChanged: setIsEditCategoryPresented,
          content: editingCategory
            ? <EditCategoryPage
              info={editingCategory}
              categories={categories}
            />
            : <ProgressView />
        },
        {
          isPresented: isNewSubcategoryPresented,
          onChanged: setIsNewSubcategoryPresented,
          content: <NewSubCategoryPage
            categories={categories}
          />
        }
      ]}
    >
      <Picker
        title="Type"
        value={tabIndex}
        onChanged={setTabIndex}
        pickerStyle="segmented"
        listRowBackground={
          <EmptyView />
        }
      >
        <Text tag={0}>{i18n.expenses}</Text>
        <Text tag={1}>{i18n.income}</Text>
      </Picker>

      <Section>
        {categories.map(category =>
          <DisclosureGroup
            label={
              <HStack
                leadingSwipeActions={{
                  actions: [
                    <Button
                      title={i18n.edit}
                      action={() => {
                        setIsEditCategoryPresented(true)
                        setEditingCategory(category)
                      }}
                      tint="systemBlue"
                    />
                  ]
                }}
                trailingSwipeActions={{
                  allowsFullSwipe: false,
                  actions: [
                    <Button
                      title={i18n.delete}
                      role="destructive"
                      action={() => {
                        removeCategory(
                          categories,
                          category,
                        )
                      }}
                    />
                  ]
                }}
              >
                <Text>{category.icon}</Text>
                <Text>{category.name}</Text>
                <Spacer />
              </HStack>
            }
          >
            {category.items.map(item =>
              <NavigationLink
                destination={
                  <EditSubCategoryPage
                    categories={categories}
                    category={category.name}
                    info={item}
                  />
                }
                trailingSwipeActions={{
                  allowsFullSwipe: false,
                  actions: [
                    <Button
                      title={i18n.delete}
                      role="destructive"
                      action={() => {
                        removeSubCategory(
                          category,
                          item
                        )
                      }}
                    />
                  ]
                }}
              >
                <HStack>
                  <Text>{item.icon}</Text>
                  <Text>{item.name}</Text>
                  <Spacer />
                </HStack>
              </NavigationLink>
            )}
          </DisclosureGroup>
        )}
      </Section>
    </List>
  </NavigationStack >
}