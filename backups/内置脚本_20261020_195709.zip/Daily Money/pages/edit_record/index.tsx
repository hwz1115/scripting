import { RecordEditorStoreContext, RecordEditorStoreProvider } from "../new_record/store"
import { Navigation, Button, Form, DatePicker, NavigationLink, HStack, NavigationStack, useContext, VStack, Picker, Text, Section, TextField, Spacer, EmptyView } from "scripting"
import { useI18n } from "../../i18n"
import { RecordInfo } from "../../common/types"
import { CategoryPicker } from "../new_record/category_picker"

export function EditRecordPage({
  record
}: {
  record: RecordInfo
}) {

  return <RecordEditorStoreProvider
    initialRecord={record}
  >
    <NavigationStack>
      <BodyView />
    </NavigationStack>
  </RecordEditorStoreProvider>
}

function BodyView() {
  const dismiss = Navigation.useDismiss()
  const i18n = useI18n()
  const {
    id,
    amount,
    amountValue,
    setAmount,
    notes,
    setNotes,
    category,
    time,
    setTime,
    setIsIncome,
    isIncome,
    isReady,
  } = useContext(RecordEditorStoreContext)

  async function save() {
    const newRecord: RecordInfo = {
      id: id!,
      amount: amountValue!,
      notes,
      time,
      category,
      isIncome,
    }

    dismiss(newRecord)
  }

  return <VStack
    navigationTitle={i18n.editRecord}
    navigationBarTitleDisplayMode="inline"
    toolbar={{
      topBarLeading: <Button
        title={i18n.cancel}
        action={dismiss}
      />,
      topBarTrailing: <Button
        title={i18n.save}
        action={save}
        fontWeight="medium"
        disabled={!isReady}
      />,
    }}
  >
    <Form
      contentMargins={{
        edges: "top",
        insets: 0
      }}>
      <Picker
        title={i18n.type}
        value={isIncome ? 1 : 0}
        onChanged={(value: number) => {
          setIsIncome(value === 1)
        }}
        pickerStyle="segmented"
        listRowBackground={
          <EmptyView />
        }
      >
        <Text
          tag={0}
        >{i18n.expenses}</Text>
        <Text
          tag={1}
        >{i18n.income}</Text>
      </Picker>
      <Section>
        <TextField
          autofocus
          title={i18n.amount}
          value={amount}
          onChanged={setAmount}
          keyboardType="decimalPad"
        />
        <TextField
          title={i18n.notes}
          value={notes}
          onChanged={setNotes}
          axis="vertical"
          lineLimit={{
            max: 3,
            reservesSpace: true
          }}
        />
      </Section>

      <Section>
        <DatePicker
          title={i18n.time}
          value={time}
          onChanged={setTime}
          displayedComponents={[
            "date", "hourAndMinute"
          ]}
        />
      </Section>

      <NavigationLink
        destination={
          <CategoryPicker />
        }
      >
        <HStack>
          <Text>{i18n.category}</Text>
          <Spacer />
          <Text
            font="callout"
            foregroundStyle="secondaryLabel"
          >{category}</Text>
        </HStack>
      </NavigationLink>
    </Form>
  </VStack>
}