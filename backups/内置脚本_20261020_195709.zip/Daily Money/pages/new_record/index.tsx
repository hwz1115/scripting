import { Button, DatePicker, EmptyView, Form, HStack, Navigation, NavigationLink, NavigationStack, Picker, Section, Spacer, Text, TextField, VStack, Widget, useContext } from "scripting"
import { RecordEditorStoreContext, RecordEditorStoreProvider } from "./store"
import { useI18n } from "../../i18n"
import { loadRecordData } from "../../common/record_data"
import { RecordInfo } from "../../common/types"
import { saveRecordData } from "../../common/record_data"
import { CategoryPicker } from "./category_picker"

export function NewRecordPage({
  amount,
  category,
  notes,
  isIncome,
}: {
  amount?: number
  category?: string
  notes?: string
  isIncome?: boolean
}) {

  return <RecordEditorStoreProvider
    initialRecord={{
      amount: amount ?? 0,
      category: category ?? "",
      time: Date.now(),
      notes: notes ?? "",
      isIncome: isIncome ?? false,
    }}
  >
    <NavigationStack>
      <BodyView />
    </NavigationStack>
  </RecordEditorStoreProvider>
}

function BodyView() {
  const dismiss = Navigation.useDismiss()
  const i18n = useI18n()
  const {
    amount,
    amountValue,
    setAmount,
    notes,
    setNotes,
    category,
    time,
    setTime,
    setIsIncome,
    isIncome,
    isReady,
  } = useContext(RecordEditorStoreContext)

  async function save() {
    let records = await loadRecordData()
    records ??= []

    const record: RecordInfo = {
      id: UUID.string(),
      amount: amountValue!,
      notes,
      time,
      category,
      isIncome,
    }

    const newRecords: RecordInfo[] = [
      record,
      ...records,
    ]

    await saveRecordData(newRecords)
    Widget.reloadAll()
    dismiss(record)
  }

  return <VStack
    navigationTitle={i18n.newRecord}
    navigationBarTitleDisplayMode="inline"
    toolbar={{
      topBarLeading: <Button
        title={i18n.cancel}
        action={dismiss}
      />,
      topBarTrailing: <Button
        title={i18n.add}
        action={save}
        fontWeight="medium"
        disabled={!isReady}
      />,
    }}
  >
    <Form
      contentMargins={{
        edges: "top",
        insets: 0
      }}
    >
      <Section>
        <Picker
          title={i18n.type}
          value={isIncome ? 1 : 0}
          onChanged={(value: number) => {
            setIsIncome(value === 1)
          }}
          pickerStyle="segmented"
          //frame={{ width: 200 }}
          listRowBackground={
            <EmptyView />
          }
        >
          <Text
            tag={0}
          >{i18n.expenses}</Text>
          <Text
            tag={1}
          >{i18n.income}</Text>
        </Picker>
      </Section>
      <Section>
        <TextField
          autofocus
          title={i18n.amount}
          value={amount}
          onChanged={setAmount}
          keyboardType="decimalPad"
        />
        <TextField
          title={i18n.notes}
          value={notes}
          onChanged={setNotes}
          axis="vertical"
          lineLimit={{
            max: 4,
            reservesSpace: true
          }}
        />
      </Section>

      <Section>
        <DatePicker
          title={i18n.time}
          value={time}
          onChanged={setTime}
          displayedComponents={[
            "date", "hourAndMinute"
          ]}
        />
      </Section>

      <NavigationLink
        destination={
          <CategoryPicker />
        }
      >
        <HStack>
          <Text>{i18n.category}</Text>
          <Spacer />
          <Text
            font="callout"
            foregroundStyle="secondaryLabel"
          >{category}</Text>
        </HStack>
      </NavigationLink>
    </Form>
  </VStack>
}