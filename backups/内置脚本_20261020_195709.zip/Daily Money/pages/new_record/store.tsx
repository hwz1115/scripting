import {
  useMemo,
  useState,
  useEffect,
  createContext,
} from "scripting"

import {
  RecordInfo,
  Category,
} from "../../common/types"
import { toNumber } from "../../common/utils"

import {
  loadCategories,
  getRecommendCategories,
  getCategoryIconMap,
} from "../../category"

function useRecordEditor(
  initialRecord: Omit<
    RecordInfo,
    "category" | "id"
  > & {
    category?: string
    id?: string
  },
) {
  const [
    expenseCategoryGroups,
    setExpensesCategoryGroups,
  ] = useState<Category[]>([])
  const expenseCategoryIconMap = useMemo(() => {
    return getCategoryIconMap(
      expenseCategoryGroups
    )
  }, [expenseCategoryGroups])

  const [
    incomeCategoryGroups,
    setIncomeCategoryGroups,
  ] = useState<Category[]>([])
  const incomeCategoryIconMap = useMemo(() => {
    return getCategoryIconMap(
      incomeCategoryGroups
    )
  }, [incomeCategoryGroups])

  const [
    recommendExpensesCategories,
    setRecommendExpensesCategories,
  ] = useState<string[]>([])
  const [
    recommendIncomeCategories,
    setRecommendIncomeCategories,
  ] = useState<string[]>([])

  const [
    expensesCategory,
    setExpensesCategory
  ] = useState(
    () =>
      (!initialRecord.isIncome ?
        initialRecord.category
        : null) ||
      recommendExpensesCategories[0] ||
      "",
  )
  const [
    incomeCategory,
    setIncomeCategory
  ] = useState(
    () =>
      (initialRecord.isIncome ?
        initialRecord.category
        : null) ||
      recommendIncomeCategories[0] ||
      "",
  )

  useEffect(() => {
    async function load() {
      const categories = await loadCategories()
      if (categories == null) {
        return
      }
      const {
        income,
        expenses
      } = categories
      const recommendExpenses =
        getRecommendCategories(expenses)
      const recommendIncome =
        getRecommendCategories(income)
      const initialExpenses =
        (!initialRecord.isIncome ?
          initialRecord.category
          : null) ||
        recommendExpenses[0] ||
        ""
      const initialIncome =
        (initialRecord.isIncome ?
          initialRecord.category
          : null) ||
        recommendIncome[0] ||
        ""

      setExpensesCategoryGroups(expenses)
      setIncomeCategoryGroups(income)
      setExpensesCategory(initialExpenses)
      setIncomeCategory(initialIncome)
      setRecommendIncomeCategories(
        recommendIncome
      )
      setRecommendExpensesCategories(
        recommendExpenses
      )
    }

    load()
  }, [])

  const [isIncome, setIsIncome] = useState(
    () => initialRecord.isIncome,
  )
  const [amount, setAmount] = useState(() =>
    initialRecord.amount === 0 ?
      ""
      : initialRecord.amount.toString(),
  )
  const [time, setTime] = useState(
    () => initialRecord.time,
  )
  const [notes, setNotes] = useState(
    () => initialRecord.notes,
  )
  const [id] = useState(() => initialRecord.id)
  const amountValue = toNumber(amount)
  const category =
    isIncome ? incomeCategory : expensesCategory
  const isReady =
    amountValue != null && category.length > 0

  return {
    id,
    expensesCategory,
    expenseCategoryGroups,
    expenseCategoryIconMap,
    recommendExpensesCategories,
    incomeCategory,
    incomeCategoryGroups,
    incomeCategoryIconMap,
    recommendIncomeCategories,
    isIncome,
    amount,
    amountValue,
    time,
    category,
    notes,
    setIsIncome,
    setAmount,
    setTime,
    setNotes,
    setExpensesCategory,
    setIncomeCategory,
    isReady,
  }
}

export const RecordEditorStoreContext =
  createContext<
    ReturnType<typeof useRecordEditor>
  >()

export function RecordEditorStoreProvider({
  initialRecord,
  children,
}: {
  children: JSX.Element
  initialRecord: Omit<RecordInfo, "id"> & {
    id?: string
  }
}) {
  const store = useRecordEditor(initialRecord)
  return (
    <RecordEditorStoreContext.Provider
      value={store}
    >
      {children}
    </RecordEditorStoreContext.Provider>
  )
}
