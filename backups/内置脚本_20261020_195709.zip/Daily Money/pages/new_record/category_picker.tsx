import { DisclosureGroup, HStack, Image, List, Navigation, Section, Spacer, Text, useContext, useMemo, useState } from "scripting"
import { useI18n } from "../../i18n"
import { RecordEditorStoreContext } from "./store"
import { Category } from "../../common/types"

export function CategoryPicker() {
  const i18n = useI18n()
  const dismiss = Navigation.useDismiss()
  const {
    category,
    expenseCategoryGroups,
    incomeCategoryGroups,
    expenseCategoryIconMap,
    incomeCategoryIconMap,
    recommendIncomeCategories,
    recommendExpensesCategories,
    isIncome,
    setIncomeCategory,
    setExpensesCategory,
  } = useContext(RecordEditorStoreContext)

  const groups = isIncome
    ? incomeCategoryGroups
    : expenseCategoryGroups

  const recommends = isIncome
    ? recommendIncomeCategories
    : recommendExpensesCategories

  const iconMap = isIncome
    ? incomeCategoryIconMap
    : expenseCategoryIconMap

  const [
    search,
    setSearch
  ] = useState("")

  const filteredGroups: Category[] = useMemo(() => {
    if (!search.length) {
      return groups
    }

    const keyword = search.toLowerCase()

    const list = groups.map(group => {
      const items = group.items.filter(item =>
        item.name.toLowerCase().includes(keyword)
      )

      if (items.length || group.name.toLowerCase().includes(keyword)) {
        return {
          ...group,
          items: items.length
            ? items
            : group.items
        }
      }
      return null
    })

    return list.filter(group => group != null) as Category[]
  }, [groups, search])

  return <List
    navigationTitle={i18n.category}
    searchable={{
      value: search,
      onChanged: setSearch,
    }}
  >
    {
      recommends.length && !search.length
        ? <Section
          header={
            <Text>{i18n.recommend}</Text>
          }
        >
          {recommends.map(item =>
            <CategoryRow
              icon={iconMap[item]}
              name={item}
              selected={category === item}
              onTapGesture={() => {
                (isIncome
                  ? setIncomeCategory
                  : setExpensesCategory)(item)
                dismiss()
              }}
            />
          )}
        </Section>
        : null}
    {filteredGroups.map(group =>
      <DisclosureGroup
        label={
          <Text>
            {group.icon} {group.name}
          </Text>
        }
      >
        {group.items.map(item =>
          <CategoryRow
            icon={item.icon}
            name={item.name}
            selected={category === `${group.name}-${item.name}`}
            onTapGesture={() => {
              const category = `${group.name}-${item.name}`;

              (isIncome
                ? setIncomeCategory
                : setExpensesCategory)(category)
              dismiss()
            }}
          />
        )}
      </DisclosureGroup>
    )}
  </List>
}

function CategoryRow({
  icon,
  name,
  selected,
}: {
  icon: string
  name: string
  selected: boolean
}) {

  return <HStack
    contentShape="rect"
  >
    <Text>{icon}</Text>
    <Text>{name}</Text>
    <Spacer />
    {selected
      ? <Image
        systemName="checkmark"
        foregroundStyle="systemBlue"
      /> : null}
  </HStack>
}