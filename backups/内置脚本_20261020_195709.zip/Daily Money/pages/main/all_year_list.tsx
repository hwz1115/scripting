import { useMemo, Section, Text, Spacer, VStack, useSelector, NavigationLink, Group, Chart, BarStackChart, HStack, EmptyView, } from "scripting"
import { useI18n } from "../../i18n"
import { RecordDataContext } from "./store"
import { countYearTotal } from "../../common/calc"
import { RecordsOfYear } from "../../common/types"
import { RecordsOfMonth } from "../../common/types"
import { countMonthTotal } from "../../common/calc"
import { getMonthLabel } from "../../common/date"
import { ListOfMonthView } from "./list_of_month_view"
import { CategoriesDetailsPage } from "../categories_details"

export function AllRecordsListView() {
  const i18n = useI18n()

  const list = useSelector(
    RecordDataContext,
    (store) => store.recordsOfAllYear,
  )
    .slice()
    .sort(
      (a, b) => b.date.getTime() - a.date.getTime(),
    )

  const totalIncome = list.reduce(
    (sum, item) => sum + countYearTotal(item, true),
    0,
  )
  const totalExpenses = list.reduce(
    (sum, item) => sum + countYearTotal(item, false),
    0,
  )
  const chartDataExpensesList = list
    .map((item) => countYearTotal(item, false))
    .reverse()
  const chartDataIncomeList = list
    .map((item) => countYearTotal(item, true))
    .reverse()
  const domainLabels = list
    .map((item) => item
      .date
      .getFullYear()
      .toString()
    )
    .reverse()

  if (list.length === 0) {
    return <EmptyView />
  }

  return <Group>
    <Section>
      <VStack
        alignment="leading"
        listRowSeparator="hidden"
      >
        <Text
          font="subheadline"
          foregroundStyle="secondaryLabel"
        >{i18n.total}</Text>
        <HStack
          font="headline"
        >
          <Text
            foregroundStyle="systemBlue"
          >-{totalExpenses.toLocaleString()}</Text>
          <Text
            foregroundStyle="systemGreen"
          >+{totalIncome.toLocaleString()}</Text>
        </HStack>
      </VStack>
      <Chart
        chartScrollableAxes="horizontal"
        chartXVisibleDomain={7}
        chartScrollPositionX={
          domainLabels.length
            > 7
            ? domainLabels[domainLabels.length - 7]
            : undefined

        }
      >
        <BarStackChart
          marks={
            chartDataExpensesList
              .map((total, index) => ({
                category: i18n.expenses,
                value: total,
                label: domainLabels[index]
              }))
              .concat(chartDataIncomeList
                .map((total, index) => ({
                  category: i18n.income,
                  value: total,
                  label: domainLabels[index]
                })))
          }
        />
      </Chart>
      <NavigationLink
        title={i18n.viewCatrgories}
        destination={
          <CategoriesDetailsPage
            title={i18n.all}
            type="all"
            records={list}
          />
        }
      />
    </Section>
    {list.map(data =>
      <YearSection
        record={data}
      />
    )}
  </Group>
}

function YearSection({
  record,
}: {
  record: RecordsOfYear
}) {
  const i18n = useI18n()
  const totalIncome = countYearTotal(
    record,
    true
  )
  const totalExpenses = countYearTotal(
    record,
    false
  )
  const records = useMemo(
    () =>
      record.records.sort(
        (a, b) => b.date.getTime()
          - a.date.getTime(),
      ),
    [record],
  )

  return <Section
    header={
      <HStack
      >
        <Text>{
          record.date.getFullYear()
        }</Text>
        <Spacer />
      </HStack>
    }
  >
    <NavigationLink
      destination={
        <CategoriesDetailsPage
          title={record.date.getFullYear().toString()}
          type="year"
          records={record}
        />
      }
    >
      <HStack
      >
        <Text>{i18n.total}</Text>
        <Spacer />
        <VStack
          font="subheadline"
          alignment="trailing"
        >
          <Text
            foregroundStyle="systemBlue"
          >-{totalExpenses.toLocaleString()}
          </Text>
          <Text
            foregroundStyle="systemGreen"
          >
            +{totalIncome.toLocaleString()}
          </Text>
        </VStack>
      </HStack>
    </NavigationLink>
    {records.map((record) => (
      <MonthTile record={record} />
    ))}
  </Section>
}

function MonthTile({
  record,
}: {
  record: RecordsOfMonth
}) {
  const totalIncome = countMonthTotal(
    record,
    true
  )
  const totalExpenses = countMonthTotal(
    record,
    false
  )

  return <NavigationLink
    destination={
      <ListOfMonthView
        record={record}
      />
    }
  >
    <HStack>
      <Text>
        {getMonthLabel(
          record.date.getMonth()
        )}
      </Text>
      <Spacer />

      <VStack
        font="subheadline"
        alignment="trailing"
        foregroundStyle="secondaryLabel"
      >
        <Text >
          -{totalExpenses.toLocaleString()}
        </Text>
        <Text >
          +{totalIncome.toLocaleString()}
        </Text>
      </VStack>
    </HStack>
  </NavigationLink>

}
