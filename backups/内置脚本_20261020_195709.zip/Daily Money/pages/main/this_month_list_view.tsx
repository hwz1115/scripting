import { useI18n } from "../../i18n"
import { BarStackChart, Chart, EmptyView, Group, HStack, NavigationLink, Section, Text, VStack, useSelector } from "scripting"
import { RecordDataContext } from "./store"
import { countDateTotal, countMonthTotal } from "../../common/calc"
import { DateGroupView } from "./date_group_view"
import { CategoriesDetailsPage } from "../categories_details"

export function ThisMonthListView() {

  const i18n = useI18n()
  const record = useSelector(
    RecordDataContext,
    (store) => store.recordsOfThisMonth,
  )
  const list = record.records
    .slice()
    .sort(
      (a, b) => b.date.getTime() - a.date.getTime(),
    )

  const totalIncome = countMonthTotal(record, true)
  const totalExpenses = countMonthTotal(record, false)

  const chartDataExpensesList = list
    .map((item) => countDateTotal(item, false))
    .reverse()

  const chartDataIncomeList = list
    .map((item) => countDateTotal(item, true))
    .reverse()

  const domainLabels = list
    .map((item) => item.date.getDate().toString())
    .reverse()

  if (list.length === 0) {
    return <EmptyView />
  }

  return <Group>
    <Section>
      <VStack
        alignment="leading"
        listRowSeparator="hidden"
      >
        <Text
          font="subheadline"
          foregroundStyle="secondaryLabel"
        >{i18n.total}</Text>
        <HStack
          font="headline"
        >
          <Text
            foregroundStyle="systemBlue"
          >-{totalExpenses.toLocaleString()}</Text>
          <Text
            foregroundStyle="systemGreen"
          >+{totalIncome.toLocaleString()}</Text>
        </HStack>
      </VStack>
      <Chart
        chartScrollableAxes="horizontal"
        chartXVisibleDomain={15}
        chartScrollPositionX={domainLabels.length
          > 15
          ? domainLabels[domainLabels.length - 15]
          : undefined
        }
      >
        <BarStackChart
          marks={
            chartDataExpensesList
              .map((total, index) => ({
                category: i18n.expenses,
                value: total,
                label: domainLabels[index]
              }))
              .concat(chartDataIncomeList
                .map((total, index) => ({
                  category: i18n.income,
                  value: total,
                  label: domainLabels[index]
                })))
          }
        />
      </Chart>
      <NavigationLink
        title={i18n.viewCatrgories}
        destination={
          <CategoriesDetailsPage
            title={i18n.thisMonth}
            type="month"
            records={record}
          />
        }
      />
    </Section>

    {list.map(dateGroup =>
      <DateGroupView
        dateGroup={dateGroup}
      />
    )}
  </Group>
}
