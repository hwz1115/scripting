import { Button, ContentUnavailableView, EmptyView, HStack, List, Navigation, NavigationStack, Picker, Section, Spacer, Text, useContext, useEffect, useState, Widget } from "scripting"
import { useI18n } from "../../i18n"
import { RecordDataContext, RecordDataProvider } from "./store"
import { NewRecordPage } from "../new_record"
import { ThisMonthListView } from "./this_month_list_view"
import { AllRecordsListView } from "./all_year_list"
import { CategoryPage } from "../category"

export function MainPage() {
  return <RecordDataProvider>
    <NavigationStack>
      <ContentView />
    </NavigationStack>
  </RecordDataProvider>
}

function ContentView() {
  const i18n = useI18n()
  const dismiss = Navigation.useDismiss()
  const {
    load,
    tabIndex,
    setTabIndex,
    recordsOfThisMonth,
    recordsOfAllYear,
  } = useContext(RecordDataContext)
  const [
    isCategoryPresented,
    setIsCategoryPresented
  ] = useState(false)

  useEffect(() => {
    // Check if this script is started from a widget with a "New Record" parameter.
    if (Widget.parameter.toLowerCase() === "new record") {
      Navigation.present({
        element: <NewRecordPage />,
        modalPresentationStyle: "pageSheet"
      }).then(newRecord => {
        if (newRecord != null) {
          load()
        }
      })
    }
  }, [])

  const hasNoRecords = tabIndex === 0
    ? recordsOfThisMonth.records.length === 0
    : recordsOfAllYear.length === 0

  return <List
    navigationTitle={i18n.title}
    navigationBarTitleDisplayMode="inline"
    toolbar={{
      cancellationAction: <Button
        title={i18n.done}
        action={dismiss}
      />,
      bottomBar: <HStack>
        <Button
          title={i18n.newRecord}
          fontWeight="medium"
          action={async () => {
            const newRecord = await Navigation.present({
              element: <NewRecordPage />,
              modalPresentationStyle: "pageSheet"
            })

            if (newRecord != null) {
              load()
            }
          }}
        />
        <Spacer />
        <Button
          title={i18n.category}
          action={async () => {
            setIsCategoryPresented(true)
          }}
        />
      </HStack>
    }}
    contentMargins={{
      edges: "top",
      insets: 0
    }}
    sheet={{
      isPresented: isCategoryPresented,
      onChanged: setIsCategoryPresented,
      content: <CategoryPage />
    }}
    overlay={
      hasNoRecords
        ? <ContentUnavailableView
          title={"No Record"}
          systemImage={"creditcard.fill"}
          description={"Please add a record."}
        />
        : <EmptyView />
    }
  >
    <Section
      listRowBackground={
        <EmptyView />
      }
    >
      <Picker
        title="Record Type"
        value={tabIndex}
        onChanged={setTabIndex}
        pickerStyle="segmented"
      >
        <Text tag={0}>
          {i18n.thisMonth}
        </Text>
        <Text tag={1}>
          {i18n.all}
        </Text>
      </Picker>
    </Section>

    {
      tabIndex === 0 ?
        <ThisMonthListView />
        : <AllRecordsListView />
    }

  </List >
}