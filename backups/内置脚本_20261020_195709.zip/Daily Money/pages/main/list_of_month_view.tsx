import { RecordsOfMonth } from "../../common/types"
import { useI18n } from "../../i18n"
import { countDateTotal, countMonthTotal } from "../../common/calc"
import { HStack, Chart, List, Section, VStack, Text, NavigationLink, BarStackChart } from "scripting"
import { DateGroupView } from "./date_group_view"
import { getYYYYMM } from "../../common/date"
import { CategoriesDetailsPage } from "../categories_details"


export function ListOfMonthView({
  record,
}: {
  record: RecordsOfMonth
}) {
  const i18n = useI18n()

  const list = record.records
    .slice()
    .sort(
      (a, b) => b.date.getTime() - a.date.getTime(),
    )
  const totalIncome = countMonthTotal(
    record,
    true
  )
  const totalExpenses = countMonthTotal(
    record,
    false
  )
  const chartDataExpensesList = list
    .map((item) => countDateTotal(
      item,
      false
    ))
    .reverse()
  const chartDataIncomeList = list
    .map((item) => countDateTotal(item, true))
    .reverse()
  const domainLabels = list
    .map((item) => item
      .date.getDate().toString()
    )
    .reverse()

  return <List
    navigationTitle={getYYYYMM(
      record.date.getTime()
    )}
    navigationBarTitleDisplayMode="inline"
  >
    <Section
    >
      <VStack
        alignment="leading"
        listRowSeparator="hidden"
      >
        <Text
          font="subheadline"
          foregroundStyle="secondaryLabel"
        >{i18n.total}</Text>
        <HStack
          font="headline"
        >
          <Text
            foregroundStyle="systemBlue"
          >-{totalExpenses.toLocaleString()}</Text>
          <Text
            foregroundStyle="systemGreen"
          >+{totalIncome.toLocaleString()}</Text>
        </HStack>
      </VStack>
      <Chart
        chartScrollableAxes="horizontal"
        chartXVisibleDomain={15}
        chartScrollPositionX={domainLabels.length
          > 15
          ? domainLabels[domainLabels.length - 15]
          : undefined
        }
      >
        <BarStackChart
          marks={
            chartDataExpensesList
              .map((total, index) => ({
                category: i18n.expenses,
                value: total,
                label: domainLabels[index]
              }))
              .concat(chartDataIncomeList
                .map((total, index) => ({
                  category: i18n.income,
                  value: total,
                  label: domainLabels[index]
                })))
          }
        />
      </Chart>
      <NavigationLink
        title={i18n.viewCatrgories}
        destination={
          <CategoriesDetailsPage
            title={i18n.categories}
            type="month"
            records={record}
          />
        }
      />
    </Section>
    {list.map(item =>
      <DateGroupView
        dateGroup={item}
      />
    )}
  </List>
}
