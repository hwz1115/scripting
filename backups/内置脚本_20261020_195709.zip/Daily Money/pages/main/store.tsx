import {
  Widget,
  createContext,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "scripting"
import {
  Category,
  RecordInfo,
  RecordsOfDate,
  RecordsOfMonth,
  RecordsOfYear,
  SubCategory,
} from "../../common/types"
import {
  CategoryData,
  getCategoryIconMap,
  getPrimaryIconMap,
  loadCategories,
  saveCategories,
} from "../../category"
import {
  getYYYY,
  getYYYYMM,
  getYYYYMMDD,
  isThisMonth,
  isThisYear,
} from "../../common/date"
import { loadRecordData, saveRecordData } from "../../common/record_data"

function useRecordData() {
  const [tabIndex, setTabIndex] = useState(0)
  const [records, setRecords] = useState<RecordInfo[]>(
    [],
  )
  const [categoryData, setCategoryData] =
    useState<CategoryData>({
      income: [],
      expenses: [],
    })

  const iconMap = useMemo(
    () => ({
      income: getCategoryIconMap(
        categoryData.income
      ),
      expenses: getCategoryIconMap(
        categoryData.expenses,
      ),
    }),
    [categoryData],
  )

  const primaryIconMap = useMemo(
    () => ({
      income: getPrimaryIconMap(
        categoryData.income
      ),
      expenses: getPrimaryIconMap(
        categoryData.expenses,
      )
    })
    , [categoryData])

  const recordsGroups = useMemo(() => {
    let recordsOfThisMonth: RecordsOfMonth = {
      date: new Date(),
      records: [],
    }
    let recordsOfThisYear: RecordsOfYear = {
      date: new Date(),
      records: [],
    }
    const recordsOfAllYear: RecordsOfYear[] = []
    const recordsByDate: {
      [date: string]: RecordsOfDate
    } = {}
    const recordsByMonth: {
      [month: string]: RecordsOfMonth
    } = {}
    const recordsByYear: {
      [year: string]: RecordsOfYear
    } = {}

    for (const record of records) {
      const d = new Date(record.time)
      const year = getYYYY(record.time)
      const month = getYYYYMM(record.time)
      const date = getYYYYMMDD(record.time)

      if (recordsByYear[year] == null) {
        const y = (recordsByYear[year] = {
          date: d,
          records: [],
        })
        recordsOfAllYear.push(y)
        if (isThisYear(record.time)) {
          recordsOfThisYear = y
        }
      }
      if (recordsByMonth[month] == null) {
        const m = (recordsByMonth[month] = {
          date: d,
          records: [],
        })
        recordsByYear[year].records.push(m)
        if (isThisMonth(record.time)) {
          recordsOfThisMonth = m
        }
      }
      if (recordsByDate[date] == null) {
        const r = (recordsByDate[date] = {
          date: d,
          records: [],
        })
        recordsByMonth[month].records.push(r)
      }

      recordsByDate[date].records.push(record)
    }

    return {
      recordsOfThisMonth,
      recordsOfThisYear,
      recordsOfAllYear,
    }
  }, [records])

  const getIcon = useCallback(
    (name: string, isIncome: boolean) => {
      return isIncome
        ? iconMap.income[name]
        : iconMap.expenses[name]
    },
    [iconMap],
  )
  const getPrimaryIcon = useCallback(
    (name: string, isIncome: boolean) => {
      return isIncome
        ? primaryIconMap.income[name]
        : primaryIconMap.expenses[name]
    }
    , [primaryIconMap])

  const load = useCallback(async () => {
    const [records, categoryData] =
      await Promise.all([
        loadRecordData(),
        loadCategories(),
      ])
    if (records != null) {
      setRecords(records)
    }
    if (categoryData != null) {
      setCategoryData(categoryData)
    }
  }, [])

  useEffect(() => {
    load()
  }, [])

  async function addRecord(
    record: Omit<RecordInfo, "id">,
  ) {
    const newRecords: RecordInfo[] = [
      {
        ...record,
        id: UUID.string(),
      },
      ...records,
    ]

    await saveRecordData(newRecords)

    setRecords(newRecords)

    Widget.reloadAll()
  }

  async function updateRecord(record: RecordInfo) {
    const newRecords = records.map(
      (item) =>
        record.id === item.id
          ? record
          : item,
    )

    await saveRecordData(newRecords)
    setRecords(newRecords)

    Widget.reloadAll()
  }

  async function removeRecord(id: string) {
    const newRecords = records.filter(
      (item) => item.id !== id,
    )

    await saveRecordData(newRecords)

    setRecords(newRecords)

    Widget.reloadAll()
  }

  async function addCategory(
    categories: Category[],
    newCategory: Category
  ) {


    if (categories.find(item => item.name === newCategory.name)) {
      return false
    }
    categories.unshift(newCategory)
    setCategoryData({
      ...categoryData
    })
    await saveCategories(categoryData)
    return true
  }

  async function removeCategory(
    categories: Category[],
    category: Category,
  ) {
    let index = categories.indexOf(category)
    if (index < 0) {
      return
    }
    categories.splice(index, 1)
    setCategoryData({
      ...categoryData
    })
    await saveCategories(categoryData)
  }

  async function updateCategory(
    category: Category,
    newCategory: Category,
  ) {
    category.icon = newCategory.icon
    category.name = newCategory.name
    setCategoryData({
      ...categoryData
    })
    await saveCategories(categoryData)
    return true
  }

  async function addSubCategory(
    category: Category,
    subCategory: SubCategory
  ) {
    if (category.items.find(item =>
      item.name === subCategory.name
    )) {
      return false
    }
    category.items.unshift(subCategory)
    setCategoryData({
      ...categoryData
    })
    await saveCategories(categoryData)
    return true
  }

  async function removeSubCategory(
    category: Category,
    subCategory: SubCategory
  ) {
    category.items = category.items.filter(
      item => item.name !== subCategory.name
        && item.icon !== subCategory.icon
    )
    setCategoryData({
      ...categoryData
    })
    await saveCategories(categoryData)
  }

  async function updateSubCategory(
    subCategory: SubCategory,
    newSubcategory: SubCategory
  ) {
    subCategory.icon = newSubcategory.icon
    subCategory.name = newSubcategory.name
    subCategory.recommendTimeRange = newSubcategory.recommendTimeRange
    setCategoryData({
      ...categoryData
    })
    await saveCategories(categoryData)
  }

  return {
    tabIndex,
    setTabIndex,
    records,
    getIcon,
    getPrimaryIcon,
    categoryData,
    setCategoryData,
    addRecord,
    updateRecord,
    removeRecord,
    load,
    addCategory,
    removeCategory,
    updateCategory,
    addSubCategory,
    removeSubCategory,
    updateSubCategory,
    ...recordsGroups,
  }
}

export type RecordDataStore = ReturnType<
  typeof useRecordData
>

export const RecordDataContext =
  createContext<RecordDataStore>()

export function RecordDataProvider({
  children,
}: {
  children: JSX.Element
}) {
  const store = useRecordData()

  return (
    <RecordDataContext.Provider value={store}>
      {children}
    </RecordDataContext.Provider>
  )
}
