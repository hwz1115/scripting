import { Button, Navigation, useContext } from "scripting"
import { useMemo } from "scripting"
import { Section } from "scripting"
import { HStack } from "scripting"
import { Text } from "scripting"
import { getDateLabel } from "../../common/date"
import { Spacer } from "scripting"
import { VStack } from "scripting"
import { stringToCategory } from "../../category"
import { getHHmm } from "../../common/date"
import { RecordInfo, RecordsOfDate } from "../../common/types"
import { RecordDataContext } from "./store"
import { EditRecordPage } from "../edit_record"

export function DateGroupView({
  dateGroup,
}: {
  dateGroup: RecordsOfDate
}) {

  const {
    getIcon,
    updateRecord,
    removeRecord,
  } = useContext(RecordDataContext)


  const totleIncome = useMemo(
    () =>
      dateGroup.records
        .filter((e) => e.isIncome)
        .reduce((sum, c) =>
          sum + c.amount,
          0
        ),
    [dateGroup],
  )
  const totalExpenses = useMemo(
    () =>
      dateGroup.records
        .filter((e) => !e.isIncome)
        .reduce((sum, c) =>
          sum + c.amount,
          0
        ),
    [dateGroup],
  )

  async function editRecord(
    record: RecordInfo
  ) {
    const result = await Navigation.present<
      RecordInfo
    >({
      element: <EditRecordPage
        record={record}
      />,
      modalPresentationStyle: "pageSheet"
    })
    if (result != null) {
      updateRecord(result)
    }
  }

  return <Section
    header={
      <HStack
      >
        <Text>
          {getDateLabel(
            dateGroup.date.getTime()
          )}
        </Text>
        <Spacer />
        <Text
          foregroundStyle="systemBlue"
        >
          -{totalExpenses
            .toLocaleString()}
        </Text>
        <Text
          foregroundStyle="systemGreen"
        >
          +{totleIncome.toLocaleString()}
        </Text>

      </HStack>
    }
  >
    {dateGroup.records.map((record) => (
      <HStack
        contentShape="rect"
        onTapGesture={async () => {
          editRecord(record)
        }}
        trailingSwipeActions={{
          allowsFullSwipe: false,
          actions: [
            <Button
              title="Delete"
              role="destructive"
              action={() => {
                removeRecord(record.id)
              }}
            />
          ]
        }}
      >
        <Text>
          {getIcon(
            record.category,
            record.isIncome,
          )}
        </Text>

        <VStack
          alignment="leading"
        >
          <Text>
            {
              stringToCategory(
                record.category
              ).subCategory
            }
          </Text>
          <HStack font="footnote">
            <Text
              foregroundStyle={"systemBlue"}>
              {getHHmm(record.time)}
            </Text>
            <Text
              foregroundStyle="secondaryLabel"
            >
              {record.notes}
            </Text>
          </HStack>
        </VStack>
        <Spacer />
        <Text foregroundStyle={
          "secondaryLabel"
        }>
          {record.isIncome ? "+" : "-"}{record.amount.toLocaleString()}
        </Text>
      </HStack>
    ))}
  </Section>
}
