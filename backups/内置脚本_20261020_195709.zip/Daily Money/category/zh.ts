import { Category } from "../common/types"

import { getSeconds } from "../common/utils"

export const ExpensesCategoriesZH: Category[] = [
  {
    name: "餐饮",
    icon: "🍽️",
    items: [
      {
        name: "早餐",
        icon: "🍳",
        recommendTimeRange: {
          from: getSeconds(5, 0),
          to: getSeconds(11, 0),
        },
      },
      {
        name: "午餐",
        icon: "🍲",
        recommendTimeRange: {
          from: getSeconds(11, 0),
          to: getSeconds(14, 0),
        },
      },
      {
        name: "晚餐",
        icon: "🥗",
        recommendTimeRange: {
          from: getSeconds(17, 0),
          to: getSeconds(22, 0),
        },
      },
      {
        name: "下午茶",
        icon: "☕️",
        recommendTimeRange: {
          from: getSeconds(14, 0),
          to: getSeconds(17, 0),
        },
      },
      { name: "水果", icon: "🍓" },
    ],
  },
  {
    name: "交通",
    icon: "🚘",
    items: [
      { name: "停车费", icon: "🅿️" },
      { name: "过路费", icon: "🛣️" },
      { name: "加油充电", icon: "⛽️" },
      { name: "打车", icon: "🚕" },
      { name: "保险", icon: "👩‍💼" },
    ],
  },
  {
    name: "购物",
    icon: "🛒",
    items: [
      { name: "衣服", icon: "👔" },
      { name: "家具", icon: "🛋️" },
      { name: "软件付费", icon: "📱" },
      { name: "电子数码", icon: "📷" },
      { name: "书籍", icon: "📚" },
    ],
  },
  {
    name: "旅行",
    icon: "🏖️",
    items: [
      { name: "住宿", icon: "🛏️" },
      { name: "餐饮", icon: "🍻" },
      { name: "购物", icon: "🛍️" },
      { name: "交通", icon: "🛫" },
      { name: "门票", icon: "🎫" },
    ],
  },
]

export const IncomeCategoriesZH: Category[] = [
  {
    name: "工作",
    icon: "🗂️",
    items: [
      {
        name: "薪水",
        icon: "💵",
      },
      {
        name: "奖金",
        icon: "🎉",
      },
      {
        name: "其他",
        icon: "❔",
      },
    ],
  },
  {
    name: "生意",
    icon: "🤝",
    items: [
      {
        name: "销售款",
        icon: "💴",
      },
      {
        name: "工程款",
        icon: "⛑️",
      },
      {
        name: "兼职",
        icon: "👨‍🎨",
      },
      {
        name: "其他",
        icon: "❔",
      },
    ],
  },
  {
    name: "投资",
    icon: "💰",
    items: [
      {
        name: "利息",
        icon: "💲",
      },
      {
        name: "股票",
        icon: "📈",
      },
      {
        name: "分红",
        icon: "🏧",
      },
      {
        name: "房租",
        icon: "🏘️",
      },
      {
        name: "其他",
        icon: "❔",
      },
    ],
  },
  {
    name: "其他",
    icon: "❓",
    items: [
      {
        name: "退款",
        icon: "🔙",
      },
      {
        name: "还款",
        icon: "↩️",
      },
      {
        name: "赔付款",
        icon: "🔁",
      },
    ],
  },
]
