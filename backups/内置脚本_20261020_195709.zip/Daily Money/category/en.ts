import { Category } from "../common/types"

import { getSeconds } from "../common/utils"

export const ExpensesCategoriesEN: Category[] = [
  {
    name: "Food & Dining",
    icon: "🍽️",
    items: [
      {
        name: "Groceries",
        icon: "🥩",
      },
      {
        name: "Restaurants",
        icon: "🥂",
        recommendTimeRange: {
          from: getSeconds(11, 0),
          to: getSeconds(14, 0),
        },
      },
      {
        name: "Coffee Shops",
        icon: "☕️",
        recommendTimeRange: {
          from: getSeconds(14, 0),
          to: getSeconds(17, 0),
        },
      },
    ],
  },
  {
    name: "Transportation",
    icon: "🚘",
    items: [
      { name: "Parking", icon: "🅿️" },
      { name: "Gas", icon: "⛽️" },
      { name: "Public Transport", icon: "🚃" },
    ],
  },
  {
    name: "Housing",
    icon: "🏠",
    items: [
      { name: "Rent/Mortgage", icon: "💵" },
      { name: "Utilities", icon: "🛠️" },
      { name: "Maintenance", icon: "🪚" },
    ],
  },
  {
    name: "Shopping",
    icon: "🛒",
    items: [
      { name: "Clothing", icon: "👔" },
      { name: "Home Goods", icon: "🛋️" },
      { name: "Electronics", icon: "📷" },
      { name: "Books", icon: "📚" },
    ],
  },
  {
    name: "Travel",
    icon: "🏖️",
    items: [
      { name: "Lodging", icon: "🛏️" },
      { name: "Food & Dinning", icon: "🍻" },
      { name: "Shopping", icon: "🛍️" },
      { name: "Transportation", icon: "🛫" },
      { name: "Ticket", icon: "🎫" },
    ],
  },
]

export const IncomeCategoriesEN: Category[] = [
  {
    name: "Salary",
    icon: "💼",
    items: [
      {
        name: "Base Salary",
        icon: "💵",
      },
      {
        name: "Bonuses",
        icon: "🎉",
      },
      {
        name: "Overtime Pay",
        icon: "👨‍💻",
      },
    ],
  },
  {
    name: "Business Income",
    icon: "🤝",
    items: [
      {
        name: "Product Sales",
        icon: "💴",
      },
      {
        name: "Service Revenue",
        icon: "🧮",
      },
      {
        name: "Commissions",
        icon: "👩‍💼",
      },
    ],
  },
  {
    name: "Investments",
    icon: "💰",
    items: [
      {
        name: "Interest Income",
        icon: "💲",
      },
      {
        name: "Capital Gains",
        icon: "📈",
      },
      {
        name: "Dividends",
        icon: "🏧",
      },
    ],
  },
]
