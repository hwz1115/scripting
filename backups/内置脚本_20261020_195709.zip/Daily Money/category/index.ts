import { Device } from "scripting"

import {
  Category,
  SubCategory,
} from "../common/types"
import {
  ExpensesCategoriesZH,
  IncomeCategoriesZH,
} from "./zh"
import {
  ExpensesCategoriesEN,
  IncomeCategoriesEN,
} from "./en"
import { getSecondsSinceDayStart } from "../common/utils"
import { loadData, copyFileFromDocumentsIfExists, saveData } from "../common/data"

export type CategoryData = {
  income: Category[]
  expenses: Category[]
}

export function getInitialExpensesCategories() {
  const locale = Device.systemLocale
  return locale.includes("zh") ?
    ExpensesCategoriesZH
    : ExpensesCategoriesEN
}

export function getInitialIncomeCategories() {
  const locale = Device.systemLocale
  return locale.includes("zh") ?
    IncomeCategoriesZH
    : IncomeCategoriesEN
}

export function categoryToString(
  category: Category,
  subCategory: SubCategory,
) {
  return category.name
    + "-"
    + subCategory.name
}

export function stringToCategory(categoryName: string) {
  const [category, subCategory] = categoryName.split("-")

  return {
    category,
    subCategory,
  }
}

export function getRecommendCategories(
  categories: Category[],
): string[] {
  const result: string[] = []
  const currentTime = getSecondsSinceDayStart(
    new Date(),
  )

  for (const primary of categories) {
    for (const secondary of primary.items) {
      if (secondary.recommendTimeRange
        != null
      ) {
        if (
          secondary
            .recommendTimeRange
            .from <= currentTime
          &&
          secondary
            .recommendTimeRange
            .to >= currentTime
        ) {
          result.push(
            categoryToString(
              primary,
              secondary
            ),
          )
        }
      }
    }
  }

  return result
}

export function getCategoryIconMap(
  categories: Category[],
) {
  const iconMap: {
    [name: string]: string
  } = {}
  for (const category of categories) {
    for (const sub of category.items) {
      iconMap[
        categoryToString(
          category,
          sub
        )
      ] = sub.icon
    }
  }
  return iconMap
}

export function getPrimaryIconMap(
  categories: Category[]
) {
  const iconMap: {
    [name: string]: string
  } = {}
  for (const category of categories) {
    iconMap[
      category.name
    ] = category.icon
  }
  return iconMap
}

const categoryFilePath =
  "daily-money-category.json"

export async function restoreCategoryData() {
  await copyFileFromDocumentsIfExists(categoryFilePath)
}

export async function initCategory() {
  let data = await loadData<CategoryData>(
    categoryFilePath,
  )
  if (data != null) {
    return
  }

  const initialExpensesCatrgories =
    getInitialExpensesCategories()

  const initialIncomeCategories =
    getInitialIncomeCategories()

  data = {
    income: initialIncomeCategories,
    expenses: initialExpensesCatrgories,
  }

  await saveCategories(data)
}

export async function loadCategories() {
  return loadData<CategoryData>(categoryFilePath)
}

export async function saveCategories(
  data: CategoryData,
) {
  await saveData(categoryFilePath, data)
}

export async function matchCategory(text: string) {
  const categoryData = await loadCategories()
  if (categoryData == null) {
    return null
  }

  const lowerCasedText = text.toLowerCase()

  const scan = (categories: Category[]) => {
    for (const category of categories) {
      for (const subCategory of category.items) {
        if (lowerCasedText.includes(subCategory.icon.toLowerCase())) {
          return categoryToString(category, subCategory)
        }
      }
    }
    return null
  }

  const expenseResult = scan(categoryData.expenses)

  if (expenseResult != null) {
    return {
      category: expenseResult,
      isIncome: false,
    }
  }

  const incomeResult = scan(categoryData.income)

  if (incomeResult != null) {
    return {
      category: incomeResult,
      isIncome: true,
    }
  }

  return null
}