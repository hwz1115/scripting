import { Script } from 'scripting'

console.present().then(() => Script.exit())
console.log('[Fetch Web Pages] This tool allows you to fetch and convert webpages into markdown format by providing specific URLs.')