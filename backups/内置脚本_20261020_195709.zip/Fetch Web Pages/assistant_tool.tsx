import { fetch } from "scripting"

// The tool's input parameters.
type FetchWebPagesParams = {
  urls: string[]
}

async function wait(seconds: number) {
  await new Promise<void>(resolve => {
    setTimeout(resolve, 1000 * seconds)
  })
}

async function loadUrlContent(url: string, turndownCode: string): Promise<string> {
  let ctrl = new WebViewController()
  let result = "Failed to load content"

  try {
    console.log("Start loading", url)
    if (!await ctrl.loadURL(url)) {
      console.error("Failed to load", url)
    } else {
      console.log("Scraping content...")

      await wait(2)

      result = await ctrl.evaluateJavaScript(`(function () {
        ${turndownCode}

        Array.from(
          document.querySelectorAll("script, style, nav, footer, header, img, iframe, video, audio")
        ).map(item => item.parentNode.removeChild(item))

        let service = TurndownService()
        return service.turndown(document.body.innerHTML)
      })()`)
    }

  } catch (e) {
    console.error("Error load content", e)
  }

  ctrl.dispose()

  return result
}

// The function to execute the tool.
const fetchWebPages: AssistantToolExecuteFn<FetchWebPagesParams> = async ({
  urls
}) => {
  try {

    if (!urls.length) {
      return {
        success: false,
        message: "You must provide at least one URL."
      }
    }

    AssistantTool.report("Start loading turndown.js...")

    let turndownCode = await fetch(
      "https://unpkg.com/turndown@7.2.0/dist/turndown.js"
    ).then(res => res.text())

    console.log("Turndown code loaded")

    let count = 0

    let reportCrawled = () => {
      AssistantTool.report(`Fetched: ${count}/${urls.length}`)
    }

    reportCrawled()

    let results: string[] = []

    for (const url of urls) {
      let content = await loadUrlContent(url, turndownCode)
      count += 1
      reportCrawled()
      results.push(
        `<webpage_result url="${url}">\n${content}\n</webpage_result>`
      )
    }

    // let results = await Promise.all(
    //   resouces.map(async (item) => {
    //     let content = await loadUrlContent(item.url, turndownCode)
    //     count += 1
    //     reportCrawled()
    //     return `<search_result title="${item.title}">\n${content}\n</search_result>`
    //   })
    // )

    return {
      success: true,
      message: results.join("\n\n")
    }
  } catch (e) {
    console.error(e)
    return {
      success: false,
      message: "Failed to load webpages, an erorr occurred: " + String(e),
    }
  }
}

// Register the function
const testFetchWebPages = AssistantTool.registerExecuteTool(
  fetchWebPages
)

// Test the function here
testFetchWebPages({
  urls: [
    "https://scripting.fun/doc/"
  ]
})