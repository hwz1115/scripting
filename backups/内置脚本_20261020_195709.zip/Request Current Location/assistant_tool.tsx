
type RequestCurrentLocationParams = {}

const locationApprovalRequest: AssistantToolApprovalRequestFn<RequestCurrentLocationParams> = async () => {
  return {
    message: "The assistant wants to request your current location.",
    primaryButtonLabel: "Allow",
  }
}

const requestCurrentLocation: AssistantToolExecuteWithApprovalFn<RequestCurrentLocationParams> = async () => {
  try {
    const location = await Location.requestCurrent()

    if (location) {
      return {
        success: true,
        message: [
          "The user's current location info:",
          `<latitude>${location.latitude}</latitude>`,
          `<longitude>${location.longitude}</longitude>`
        ].join("\n")
      }
    }
    return {
      success: false,
      message: "Failed to request user's current location, ask user to check the device's location permission."
    }
  } catch (e) {
    return {
      success: false,
      message: "Failed to request user's current location, ask user to check the device's location permission."
    }
  }
}

// Register the approval request
const testRequestLocationApprovalFn = AssistantTool.registerApprovalRequest(
  locationApprovalRequest
)

// Register the execute function
const testRequestLocationExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  requestCurrentLocation
)

// Test the approval request function
testRequestLocationApprovalFn({
})

// Test the execute function
testRequestLocationExecuteFn({
}, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})