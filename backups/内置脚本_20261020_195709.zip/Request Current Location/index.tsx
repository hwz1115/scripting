import { Script } from "scripting"

console.present().then(() => Script.exit())

console.log("[Request Current Location] This tool allows you to request the one-time delivery of the latitude and longitude of the user’s current location.")