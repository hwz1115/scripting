import { DuckDuckGoSearch } from "./duckduckgo_search"

// The tool's input parameters.
type DuckDuckGoSearchParams = {
  keyword: string
}

// The function to execute the tool.
const execute: AssistantToolExecuteFn<DuckDuckGoSearchParams> = async ({
  keyword
}) => {

  const results: string[] = []

  const searchAPI = new DuckDuckGoSearch({
    log: (message) => {
      AssistantTool.report(message)
    },
    error: (message) => {
      AssistantTool.report(message)
    }
  })

  try {

    AssistantTool.report(`Searching DuckDuckGo for "${keyword}"...`)

    for await (const result of searchAPI.text(keyword)) {
      const { title, href, body } = result

      AssistantTool.report(`Received search result: ${title}`)

      results.push(`Title: ${title}\nLink: ${href}\nContent: ${body}`)
    }

    const content = results.join("\n\n---\n\n")

    return {
      success: true,
      message: `DuckDuckGo search result for "${keyword}":\n${content}`
    }
  } catch (e) {
    AssistantTool.report(`Error: ${String(e)}`)
    if (results.length > 0) {
      const content = results.join("\n\n---\n\n")
      return {
        success: true,
        message: `DuckDuckGo search result for "${keyword}":\n${content}`
      }
    }
    return {
      success: false,
      message: "Failed to peform DuckDuckGo Search, an erorr occurred: " + String(e),
    }
  }
}

// Register the function
const testExecute = AssistantTool.registerExecuteTool(
  execute
)

// Test the function here
testExecute({
  keyword: "Tesla stock drop reasons car sales Musk Fed policy"
})