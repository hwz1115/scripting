import { fetch } from "scripting"
import { decode } from "./html_entities"

// Simulating the sleep function
function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms))
}

// Simulating the httpx._exceptions.HTTPError class
class HTTPError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "HTTPError"
  }
}

// Simulating the unescape function
function unescape(text: string) {
  // Replace &quot; with "
  return text.replace(/&quot;/g, '"')
}

// Simulating the re.sub function
function sub(pattern: RegExp, replacement: string, text: string) {
  return text.replace(pattern, replacement)
}

// Simulating the unquote function
function unquote(url: string) {
  return url // Simulating unquoting
}

const REGEX_STRIP_TAGS = /<[^>]*>/g

// Simulating the main class
export class DuckDuckGoSearch {

  constructor(public logger: {
    log: (message: string) => void,
    error: (message: string) => void,
  } = console) {
    this.logger = logger
  }

  async *images(
    keywords: string,
    region = "wt-wt",
    safesearch = "moderate",
    timelimit: string | null = null,
    size: string | null = null,
    color: string | null = null,
    type_image: string | null = null,
    layout: string | null = null,
    license_image: string | null = null
  ) {
    if (!keywords) {
      throw new Error("Keywords are mandatory")
    }

    const vqd = await this._getVqd(keywords)
    if (!vqd) {
      throw new Error("Error in getting vqd")
    }

    const safesearchBase: Record<string, number> = { on: 1, moderate: 1, off: -1 }
    timelimit = timelimit ? `time:${timelimit}` : ""
    size = size ? `size:${size}` : ""
    color = color ? `color:${color}` : ""
    type_image = type_image ? `type:${type_image}` : ""
    layout = layout ? `layout:${layout}` : ""
    license_image = license_image ? `license:${license_image}` : ""

    const payload = {
      l: region,
      o: "json",
      s: 0,
      q: keywords,
      vqd: vqd,
      f: `${timelimit},${size},${color},${type_image},${layout},${license_image}`,
      p: safesearchBase[safesearch.toLowerCase()],
    }

    const cache = new Set()
    for (let _ = 0; _ < 10; _++) {
      const resp = await this._getUrl(
        "GET",
        "https://duckduckgo.com/i.js",
        payload
      )

      if (!resp) {
        break
      }

      try {
        const respJson = await resp.json()
        const pageData = respJson.results
        if (!pageData) {
          break
        }

        let resultExists = false
        for (const row of pageData) {
          const image_url = row.image
          if (image_url && !cache.has(image_url)) {
            cache.add(image_url)
            resultExists = true
            yield {
              title: decode(row.title),
              image: this._normalizeUrl(image_url),
              thumbnail: this._normalizeUrl(row.thumbnail),
              url: this._normalizeUrl(row.url),
              height: row.height,
              width: row.width,
              source: row.source,
            }
          }
        }

        const next = respJson.next
        if (next) {
          payload.s = next.split("s=")[1].split("&")[0]
        }

        if (!next || !resultExists) {
          break
        }
      } catch (error) {
        break
      }
    }
  }

  async *text(
    keywords: string,
    region = "wt-wt",
    safesearch: "moderate" | "on" | "off" = "moderate",
    timelimit: string | null = null
  ) {
    if (!keywords) {
      throw new Error("Keywords are mandatory")
    }

    const vqd = await this._getVqd(keywords)
    if (!vqd) {
      throw new Error("Error in getting vqd")
    }

    const payload: Record<string, any> = {
      q: keywords,
      kl: region,
      l: region,
      s: 0,
      df: timelimit,
      vqd: vqd,
      o: "json",
      sp: "0",
    }

    if (safesearch === "moderate") {
      payload.ex = "-1"
    } else if (safesearch === "off") {
      payload.ex = "-2"
    } else if (safesearch === "on") {
      payload.p = "1"
    }

    const cache = new Set()
    const searchPositions = ["0", "20", "70", "120"]

    for (const s of searchPositions) {
      payload.s = s
      const resp = await this._getUrl(
        "GET",
        "https://links.duckduckgo.com/d.js",
        payload
      )

      if (!resp) {
        break
      }

      try {
        const data = await resp.json()
        const pageData = data.results
        if (!pageData) {
          break
        }

        let resultExists = false
        for (const row of pageData) {
          const href = row.u
          if (
            href &&
            !cache.has(href) &&
            href !== `http://www.google.com/search?q=${keywords}`
          ) {
            cache.add(href)
            const body = this._normalize(decode(row.a))
            if (body) {
              resultExists = true
              yield {
                title: this._normalize(decode(row.t)),
                href: this._normalizeUrl(href),
                body: body,
              }
            }
          }
        }

        if (!resultExists) {
          break
        }
      } catch (error) {
        break
      }
    }
  }

  _queryObjectToString(query: Record<string, any>) {
    const queryString = Object.entries(query)
      .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
      .join("&")
    return queryString
  }

  async _getUrl(method: string, url: string, params: Record<string, any>) {
    for (let i = 0; i < 3; i++) {
      try {
        const requestUrl = method === "GET" ? `${url}?${this._queryObjectToString(params)}` : url
        const resp = await fetch(requestUrl, {
          method,
          body: method === "POST" ? JSON.stringify(params) : undefined,
        })
        if (this._is500InUrl(resp.url) || resp.status === 202) {
          throw new HTTPError("You are being rate limited")
        }
        if (resp.status === 200) {
          return resp
        }
      } catch (ex: any) {
        this.logger.error(`Error requesting ${url} ${ex}`)
        if (i >= 2 || (typeof ex.message === 'string' && ex.message.includes("418"))) {
          throw ex
        }
      }
      this.logger.error(`Retrying ${i + 1} time(s)`)
      await sleep(3000)
    }
    return null
  }

  async _getVqd(keywords: string) {
    try {
      const resp = await this._getUrl("GET", "https://duckduckgo.com", {
        q: keywords,
      })
      if (resp) {
        const data = await resp.text()
        for (const [c1, c2] of [
          ['vqd="', '"'],
          ["vqd=", "&"],
          ["vqd='", "'"],
        ]) {
          try {
            const start = data.indexOf(c1) + c1.length
            const end = data.indexOf(c2, start)
            return data.substring(start, end)
          } catch (error) {
            this.logger.error(`keywords=${keywords} vqd not found`)
          }
        }
      }
    } catch (error) {
      console.error("eyyy", error)
      // Handle error
    }
    return null
  }

  _is500InUrl(url: string) {
    return url.includes("500")
  }

  _normalize(rawHtml: string) {
    if (rawHtml) {
      return unescape(sub(REGEX_STRIP_TAGS, "", rawHtml))
    }
    return ""
  }

  _normalizeUrl(url: string) {
    if (url) {
      return unquote(url).replace(" ", "+")
    }
    return ""
  }
}