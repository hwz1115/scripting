import { Script } from "scripting"

console.present()
  .then(() => {
    Script.exit()
  })

console.log("Hello, this is an Assistant Tool for executing DuckDuckGo Search!")