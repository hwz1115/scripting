import { Script } from "scripting"

console.present().then(() => Script.exit())

console.log("This tool performs deep research on a given topic by generating search keywords, collecting information, and iteratively refining the search until sufficient information is gathered.")