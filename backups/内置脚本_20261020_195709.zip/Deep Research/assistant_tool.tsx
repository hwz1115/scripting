import { analyzeFirstSearchResult } from "./analyze_search_result"
import { performSearch } from "./perform_search"
import { analyzeFurtherResearch } from "./analyze_further_research"
import { waitFor } from "./util"
import { FurtherSearch } from "./types"
import { loadWebContent } from "./load_web_content"

type DeepResearchParams = {
  research_topic: string
}

const MAX_SEARCH_ROUNDS = 8
const MAX_SEARCH_RETRY_COUNT = 3
const SEARCH_RETRY_DELAY = 3000

const deepResearch: AssistantToolExecuteFn<DeepResearchParams> = async (params) => {
  const { research_topic } = params
  let furtherSearches: FurtherSearch[] = []
  let searchResults: string[] = []
  let summary = ""
  let round = 0

  let firstSearchResult = ""

  for (let attempt = 0; attempt < MAX_SEARCH_RETRY_COUNT; attempt++) {
    const result = await performSearch(research_topic)
    if (result == null) {
      AssistantTool.report(`Failed to search topic (attempt ${attempt + 1})`)
      if (attempt < MAX_SEARCH_RETRY_COUNT - 1) {
        AssistantTool.report(`Retrying in ${SEARCH_RETRY_DELAY / 1000} seconds...`)
        await waitFor(SEARCH_RETRY_DELAY)
      }
    } else {
      firstSearchResult = result.text
      break
    }
  }

  AssistantTool.report(`Analyzing search results...`)
  furtherSearches = await analyzeFirstSearchResult(research_topic, firstSearchResult)

  function createResultMessage() {
    const finalSummary = [
      "Deep research completed.",
      summary ? `Summary: ${summary}` : firstSearchResult,
      searchResults.length ? `Search Results:\n${searchResults.join("\n")}` : ""
    ].join("\n\n")
    return {
      success: true,
      message: finalSummary
    }
  }

  while (round < MAX_SEARCH_ROUNDS) {
    round++

    if (!furtherSearches.length) {
      return createResultMessage()
    }

    AssistantTool.report(`Fetching search results...`)
    const currentSearchResults: string[] = []

    for (const furtherSearch of furtherSearches) {
      switch (furtherSearch.type) {
        case "search":
          const searchResult = await performSearch(furtherSearch.value)
          if (searchResult) {
            currentSearchResults.push(searchResult.text)
          }
          break
        case "url":
          const content = await loadWebContent(furtherSearch.value)
          if (content) {
            currentSearchResults.push(content)
          }
          break
      }
    }

    if (currentSearchResults.length === 0) {
      AssistantTool.report(`Failed to search more information.`)
      return createResultMessage()
    }

    searchResults.push(...currentSearchResults)

    const analysisResult = await analyzeFurtherResearch(
      research_topic,
      summary,
      currentSearchResults
    )

    if (!analysisResult) {
      return createResultMessage()
    }

    summary = analysisResult.summary

    if (!analysisResult.needSearch || !analysisResult.furtherSearches || round >= MAX_SEARCH_ROUNDS) {
      AssistantTool.report(`No further search needed.`)
      return createResultMessage()
    } else {
      furtherSearches = analysisResult.furtherSearches ?? []
      AssistantTool.report(`Further search needed:\n${furtherSearches.map(e => `  - ${e.value}`).join("\n")}`)
    }
  }

  return createResultMessage()
}

const testDeepResearch = AssistantTool.registerExecuteTool<DeepResearchParams>(deepResearch)

// Test the tool in the script editor:
testDeepResearch({ research_topic: "The impact of AI on education" })
