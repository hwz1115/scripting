export type FurtherSearch = {
  type: "search" | "url"
  value: string
}

export type AnalysisResult = {
  needSearch: boolean
  furtherSearches?: FurtherSearch[]
  summary: string
}