import { AnalysisResult } from "./types"
import { waitFor } from "./util"


const MAX_RETRY_ATTEMPTS = 3
const RETRY_DELAY = 5000 // 5 seconds

export const analyzeFurtherResearch = async (topic: string, existingSummary: string, searchResults: string[]): Promise<AnalysisResult> => {
  const schema: JSONSchemaObject = {
    type: "object",
    properties: {
      needSearch: {
        type: "boolean",
        required: true,
        description: "Whether further search is needed."
      },
      keywords: {
        type: "array",
        items: {
          type: "object",
          properties: {
            type: {
              type: "string",
              description: "\"keyword\" or \"url\"",
              required: true,
            },
            value: {
              type: "string",
              description: "A new search keyword or a link to explore further.",
              required: true,
            }
          },
          description: "An object with search value and type.",
          required: false,
        },
        description: "An array of further search item."
      },
      summary: {
        type: "string",
        required: true,
        description: "A summary of the research topic."
      }
    },
    description: `JSON object with 'needSearch', 'keywords', and 'summary'.`
  }

  const prompt = `You are an expert research assistant. Based on the research topic "${topic}", the existing summary "${existingSummary}", and the following search results:\n${searchResults.join("\n")}\n\nAnalyze whether further search is needed to gather more information. Return a JSON object with 'needSearch' (boolean), 'keywords' (string array, only if needSearch is true), and 'summary' (string). If there are search results that are not relevant to the topic, discard this information in the summary.`

  for (let attempt = 0; attempt < MAX_RETRY_ATTEMPTS; attempt++) {
    AssistantTool.report(`Analyzing search results...`)

    try {
      const result = await Assistant.requestStructuredData<AnalysisResult>(prompt, schema, {
        provider: "pollinations",
        modelId: "deepseek-reasoning"
      })
      return result
    } catch (error) {
      AssistantTool.report(`Failed to analyze search results (attempt ${attempt + 1}): ${error}`)
      if (attempt < MAX_RETRY_ATTEMPTS - 1) {
        AssistantTool.report(`Retrying in ${RETRY_DELAY / 1000} seconds...`)
        await waitFor(RETRY_DELAY)
      }
    }
  }

  AssistantTool.report("Failed to analyze search results after multiple retries.")
  return {
    needSearch: false,
    furtherSearches: [],
    summary: "Failed to analyze search results after multiple retries."
  }
}