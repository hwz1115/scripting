import { fetch } from "scripting"

type SearchResultText = {
  text: string
}

export const performSearch = async (keyword: string): Promise<SearchResultText | null> => {
  AssistantTool.report(`Searching for keyword: ${keyword}`)

  try {
    const encodedSearchKeywords = encodeURIComponent(keyword)
    const url = `https://text.pollinations.ai/${encodedSearchKeywords}?model=searchgpt`
    const response = await fetch(url)
    if (!response.ok) {
      AssistantTool.report(`HTTP error! status: ${response.status}`)
      return null
    }
    const text = await response.text()
    return { text }
  } catch (error) {
    AssistantTool.report(`Failed to search for keyword "${keyword}": ${error}`)
    return null
  }
}