import { fetch } from "scripting"
import { waitFor } from "./util"

let turndownCode: string | undefined

const loadTurndownCode = async () => {
  try {
    turndownCode = await fetch(
      "https://unpkg.com/turndown@7.2.0/dist/turndown.js"
    ).then(res => res.text())
    return true
  } catch (e) {
    AssistantTool.report(`Failed to load turndown.js: ${e}`)
    return false
  }
}

export const loadWebContent = async (url: string): Promise<string | null> => {

  if (turndownCode == null) {
    if (!await loadTurndownCode()) {
      return null
    }
  }

  AssistantTool.report(`Loading web content: ${url}`)

  let ctrl = new WebViewController()
  let result: string | null = null

  try {
    console.log("Start loading", url)
    if (!await ctrl.loadURL(url)) {
      AssistantTool.report(`Failed to load web content: ${url}`)
    } else {
      console.log("Scraping content...")

      await waitFor(2000)

      result = await ctrl.evaluateJavaScript(`(function () {
        ${turndownCode}

        Array.from(
          document.querySelectorAll("script, style, nav, footer, header, img, iframe, video, audio")
        ).map(item => item.parentNode.removeChild(item))

        let service = TurndownService()
        return service.turndown(document.body.innerHTML)
      })()`)
    }

  } catch (e) {
    AssistantTool.report(`Failed to load web content: ${e}`)
  }

  ctrl.dispose()

  return result
}