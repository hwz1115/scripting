import { FurtherSearch } from "./types"

export const analyzeFirstSearchResult = async (researchTopic: string, firstSearchResult: string) => {
  const schema: JSONSchemaArray = {
    type: "array",
    items: {
      type: "object",
      properties: {
        type: {
          type: "string",
          description: "\"keyword\" or \"url\"",
          required: true,
        },
        value: {
          type: "string",
          description: "A new search keyword or a link to explore further.",
          required: true,
        }
      },
      description: "The object with search value and type.",
      required: true,
    },
    description: `The json array of the result.`,
  }

  const prompt = `You are an expert research assistant. Here are the search results related to the research topic "${researchTopic}":
${firstSearchResult}

Analyze the information and identify content that is relevant to the topic. Based on this, generate up to 5 follow-up search suggestions to help deepen the research.

Return the result as a **JSON array**. Each item in the array should be an object with the following structure:

* \`"type"\`: either \`"keyword"\` (for a new search keyword) or \`"url"\` (for a link to explore further)
* \`"value"\`: the search keyword or URL

### Example Output:

\`\`\`json
[
  { "type": "keyword", "value": "advanced techniques in topic modeling" },
  { "type": "url", "value": "https://example.com/research-paper" }
]
\`\`\`

Only include items that are highly relevant for further investigation of the topic.
`

  try {
    const result = await Assistant.requestStructuredData<FurtherSearch[]>(prompt, schema, {
      provider: "pollinations",
      modelId: "deepseek-reasoning"
    })
    return result
  } catch (error) {
    AssistantTool.report(`Failed to generate search keywords: ${error}`)
    return []
  }
}