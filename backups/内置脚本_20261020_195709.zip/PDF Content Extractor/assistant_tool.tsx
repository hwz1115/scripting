import { fetch } from "scripting"

type PdfExtractorParams = {
  pdf_url: string
}

const pdfApprovalRequest: AssistantToolApprovalRequestFn<PdfExtractorParams> = async (params) => {
  return {
    message: `Will download PDF from:\n${params.pdf_url}`,
    primaryButtonLabel: "Continue"
  }
}

const pdfContentExtractor: AssistantToolExecuteWithApprovalFn<PdfExtractorParams> = async (
  params,
  { primaryConfirmed }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "User canceled PDF download"
    }
  }

  try {
    AssistantTool.report("Starting PDF download...")
    const response = await fetch(params.pdf_url)
    if (!response.ok) throw new Error(`HTTP error ${response.status}`)

    const pdfData = await response.data()

    AssistantTool.report("PDF download completed")

    AssistantTool.report("Parsing PDF content...")
    const pdfDoc = PDFDocument.fromData(pdfData)
    if (!pdfDoc) throw new Error("Invalid PDF format")

    let fullText = ""
    for (let i = 0; i < pdfDoc.pageCount; i++) {
      const page = pdfDoc.pageAt(i)
      const text = await page?.string
      if (text) fullText += text + "\n"
    }
    AssistantTool.report(`Parsed ${pdfDoc.pageCount} pages successfully`)

    return {
      success: true,
      message: `Extracted content (first 5000 chars):\n\n${fullText.slice(0, 5000)}...`
    }
  } catch (error) {
    AssistantTool.report("Error during PDF processing")
    return {
      success: false,
      message: `PDF processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`
    }
  }
}

const testApprovalFn = AssistantTool.registerApprovalRequest(pdfApprovalRequest)
const testExecuteFn = AssistantTool.registerExecuteToolWithApproval(pdfContentExtractor)

testApprovalFn({ pdf_url: "https://file.finance.sina.com.cn/211.154.219.97:9494/MRGG/CNSESZ_STOCK/2025/2025-3/2025-03-27/10811879.PDF" })
testExecuteFn(
  { pdf_url: "https://file.finance.sina.com.cn/211.154.219.97:9494/MRGG/CNSESZ_STOCK/2025/2025-3/2025-03-27/10811879.PDF" },
  { primaryConfirmed: true, secondaryConfirmed: false }
)