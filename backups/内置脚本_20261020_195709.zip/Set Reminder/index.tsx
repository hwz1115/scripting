import { Script } from 'scripting'

console.present().then(() => Script.exit())
console.log('[Set Reminder] This tool allows the assistant to set a reminder with a specified title, due date, and notes. The user will be prompted for approval before the reminder is created.')