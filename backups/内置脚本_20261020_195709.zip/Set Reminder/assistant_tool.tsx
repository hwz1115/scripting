type SetReminderParams = {
  title: string
  due_date: string
  notes?: string
}

const testSetReminderParams: SetReminderParams = {
  title: "Meeting with John",
  due_date: "2025/03/28 09:12:19",
  notes: "Discuss project progress"
}

const setReminderApporvalRequest: AssistantToolApprovalRequestFn<SetReminderParams> = async ({
  title, due_date, notes
}) => {
  const list = [
    "Would you like to set a reminder with the following details?",
    `Title: ${title}`,
    `Due Date: ${due_date}`,
  ]
  if (notes) {
    list.push(`Notes: ${notes}`)
  }
  const message = list.join("\n\n")

  return {
    title: "Set Reminder",
    message,
    primaryButtonLabel: "Set Reminder",
  }
}

const setReminder: AssistantToolExecuteWithApprovalFn<SetReminderParams> = async (
  { title, due_date, notes },
  { primaryConfirmed }
) => {
  if (primaryConfirmed) {
    try {
      const reminder = new Reminder()

      reminder.title = title
      reminder.dueDate = new Date(due_date)
      reminder.notes = notes

      await reminder.save()

      return {
        success: true,
        message: `Reminder "${title}" set successfully for ${due_date}.`,
      }
    } catch (error: any) {
      return {
        success: false,
        message: `Failed to create reminder: ${error.message || error}`,
      }
    }
  }
  return {
    success: false,
    message: "Reminder creation cancelled by user.",
  }
}

// Register the approval request
const testRequestSetReminderApproval = AssistantTool.registerApprovalRequest(
  setReminderApporvalRequest
)

// Test the approval request function
testRequestSetReminderApproval(
  testSetReminderParams
)

// Register the execute function
const testSetReminder = AssistantTool.registerExecuteToolWithApproval(
  setReminder
)

// Test set reminder function
testSetReminder(
  testSetReminderParams,
  {
    primaryConfirmed: true,
    secondaryConfirmed: false
  }
)