import { storageKey } from "./data"
import { Button, List, Navigation, NavigationStack, Script, Section, Text, TextField, useEffect, useState, Widget } from "scripting"

function MainView() {
  const dismiss = Navigation.useDismiss()

  const [stepCountGoal, setStepCountGoal] = useState(() => {
    return (Storage.get<number>(storageKey) ?? 6000).toString()
  })

  const stepCountGoalValue = parseInt(stepCountGoal, 10)

  useEffect(() => {
    if (isNaN(stepCountGoalValue) || stepCountGoalValue <= 0) {
      return
    }
    Storage.set(storageKey, stepCountGoalValue)
  }, [stepCountGoalValue])

  return <NavigationStack>
    <List
      navigationTitle={"Today's Step Count"}
      navigationBarTitleDisplayMode={"inline"}
      toolbar={{
        cancellationAction: <Button
          title={"Close"}
          action={dismiss}
        />
      }}
    >
      <Section
        header={
          <Text>Goal</Text>
        }
        footer={
          <Text>You can set a daily goal.</Text>
        }
      >
        <TextField
          title={"Step Count Goal"}
          value={stepCountGoal}
          onChanged={setStepCountGoal}
          keyboardType={"numberPad"}
        />
      </Section>

      <Section
        footer={
          <Text>
            You can add this widget to your home screen or lock screen to see your step count.
          </Text>
        }
      >
        <Button
          title={"Preview Widget"}
          action={() => {
            Widget.preview()
          }}
        />
      </Section>
    </List>
  </NavigationStack>
}

async function run() {
  await Navigation.present(<MainView />)
  Script.exit()
}

run()