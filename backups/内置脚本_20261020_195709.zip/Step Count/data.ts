export const storageKey = "stepCountGoal"

export async function readData() {
  const startDate = new Date
  startDate.setHours(0, 0, 0, 0)

  const todayStartTime = startDate.getTime()
  const oneHour = 1000 * 60 * 60

  const endDate = new Date(
    todayStartTime + oneHour * 24
  )

  const records: number[] = []

  for (let i = 0; i < 24; i++) {
    records.push(0)
  }

  const unit = HealthUnit.count()

  var totalStepCount = 0

  const statistics = await Health.queryStatistics("stepCount", {
    startDate: startDate,
    endDate: endDate,
    strictStartDate: true,
    strictEndDate: false,
    statisticsOptions: ["cumulativeSum", "separateBySource"]
  })

  if (statistics != null) {
    if (statistics.sources != null && statistics.sources.length > 0) {
      statistics.sources.forEach((source) => {
        const count = statistics.sumQuantity(unit, source) ?? 0

        if (count > totalStepCount) {
          totalStepCount = count
        }
      })
    } else {
      totalStepCount = (statistics.sumQuantity(unit) ?? 0) | 0
    }
  }

  const statisticsCollection = await Health.queryStatisticsCollection("stepCount", {
    startDate: startDate,
    endDate: endDate,
    strictStartDate: true,
    strictEndDate: false,
    statisticsOptions: ["cumulativeSum", "separateBySource"],
    intervalComponents: new DateComponents({ hour: 1 }),
    anchorDate: startDate
  })

  statisticsCollection.statistics().forEach((statistic) => {
    const hour = statistic.startDate.getHours()
    const count = (statistic.sumQuantity(unit) ?? 0) | 0

    records[hour] = count
  })

  return {
    records,
    total: totalStepCount
  }
}
