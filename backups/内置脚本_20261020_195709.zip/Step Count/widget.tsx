import { Text, Widget } from "scripting"
import { WidgetView } from "./components/widget_view"
import { readData } from "./data"

async function runWidget() {
  try {
    const { total, records } = await readData()
    const stepCountGoal = Storage.get<number>("stepCountGoal") ?? 6000

    Widget.present(
      <WidgetView
        records={records}
        stepCount={total}
        stepCountGoal={stepCountGoal}
      />
    )
  } catch (e) {
    console.error("Error running widget:", e)
    Widget.present(
      <Text
        font={"footnote"}
        foregroundStyle={"systemRed"}
      >Error running widget: {String(e)}</Text>
    )
  }
}

runWidget()