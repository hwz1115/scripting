import { HStack, RoundedRectangle, Spacer, Text, VStack, Widget } from "scripting"

export function RecordsBarChart({
  records,
  horizeontalPadding,
  showTimeLabels,
}: {
  records: number[]
  horizeontalPadding: number
  showTimeLabels: boolean
}) {

  const maxValue = Math.max(...records)
  const minValue = Math.min(...records)
  const delta = maxValue - minValue

  const minHeight = 4
  const maxHeight = ["systemSmall", "systemMedium"].includes(Widget.family)
    ? 32 : Widget.family === "accessoryRectangular"
      ? 20
      : 180

  const heightPerValue = maxValue === 0 ? 0 : (maxHeight - minHeight) / delta
  const cornerRadius = Widget.family === "systemSmall" ? 2 : 6

  const itemSpacing = Widget.family === "systemSmall" ? 2 : 4
  const itemWidth = (Widget.displaySize.width - horizeontalPadding * 2 - itemSpacing * (records.length - 1)) / records.length

  return <VStack
  >
    <HStack
      alignment={"bottom"}
      spacing={itemSpacing}
    >
      {
        records.map((value, index) => {
          const height = minHeight + (value - minValue) * heightPerValue
          return <RoundedRectangle
            key={index}
            frame={{
              width: itemWidth,
              height: height,
            }}
            cornerRadius={cornerRadius}
            fill={
              value === 0
                ? "placeholderText"
                : "systemGreen"
            }
            widgetAccentable={value > 0}
          />
        })
      }
    </HStack>
    {showTimeLabels
      ? <HStack
        font={10}
        fontWeight={"bold"}
        fontDesign={"rounded"}
        foregroundStyle={"placeholderText"}
      >
        <Text>0:00</Text>
        <Spacer />
        <Text>12:00</Text>
        <Spacer />
        <Text>24:00</Text>
      </HStack>
      : null
    }
  </VStack>
}