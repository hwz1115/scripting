import { Group, HStack, Image, Spacer, Text } from "scripting"

export function CountViewForAccessoryRectangular({
  stepCount,
  stepCountGoal,
}: {
  stepCount: number
  stepCountGoal: number
}) {
  return <HStack>
    <Image
      systemName="figure.walk.circle.fill"
      foregroundStyle="systemGreen"
      widgetAccentable
      font={20}
    />
    <Text
      foregroundStyle="systemGreen"
      font={14}
      fontWeight="bold"
      fontDesign="rounded"
    >
      {stepCount}/{stepCountGoal}
    </Text>
  </HStack>
}

export function CountViewForCommonSizeFamily({
  stepCount,
  stepCountGoal,
}: {
  stepCount: number
  stepCountGoal: number
}) {
  return <Group>
    <HStack>
      <Image
        systemName="figure.walk.circle.fill"
        foregroundStyle="systemGreen"
        widgetAccentable
        font={32}
      />
      <Spacer />
    </HStack>
    <Group
      fontDesign="rounded"
      fontWeight="bold"
    >
      <Text
        foregroundStyle="systemGreen"
        font={20}
        widgetAccentable
      >
        {stepCount}
      </Text>
      <Text
        foregroundStyle="secondaryLabel"
        font={14}
      >
        of {stepCountGoal} steps
      </Text>
    </Group>
  </Group>
}