import { AccessoryWidgetBackground, Group, HStack, Image, Spacer, Text, VStack, Widget, ZStack } from "scripting"
import { RecordsBarChart } from "./records_bar_chart"
import { CountViewForAccessoryRectangular, CountViewForCommonSizeFamily } from "./count_view"

export function WidgetView({
  stepCount,
  stepCountGoal,
  records,
}: {
  stepCount: number
  stepCountGoal: number
  records: number[]
}) {

  if (Widget.family === "accessoryCircular") {
    return <ZStack>
      <AccessoryWidgetBackground />
      <VStack>
        <Image
          systemName="figure.walk.circle.fill"
          foregroundStyle="systemGreen"
          widgetAccentable
          font={24}
        />
        <Text
          foregroundStyle="systemGreen"
          font={13}
          fontWeight="bold"
          fontDesign="rounded"
        >
          {stepCount}
        </Text>
      </VStack>
    </ZStack>
  }

  if (Widget.family === "accessoryInline") {
    return <HStack>
      <Image
        systemName="figure.walk.circle.fill"
        foregroundStyle="systemGreen"
        widgetAccentable
        font={20}
      />
      <Text
        foregroundStyle="systemGreen"
        font={14}
        fontWeight="bold"
        fontDesign="rounded"
      >
        {stepCount}
      </Text>
      <Text
        foregroundStyle="placeholderText"
        font={14}
        fontWeight="bold"
        fontDesign="rounded"
      >of</Text>
      <Text
        foregroundStyle="placeholderText"
        font={14}
        fontWeight="bold"
        fontDesign="rounded"
      >{stepCountGoal} steps</Text>
    </HStack>
  }

  const padding = 12

  return <VStack
    padding={padding}
    frame={Widget.displaySize}
    alignment="leading"
  >
    {Widget.family === "accessoryRectangular"
      ? <CountViewForAccessoryRectangular
        stepCount={stepCount}
        stepCountGoal={stepCountGoal}
      />
      : <CountViewForCommonSizeFamily
        stepCount={stepCount}
        stepCountGoal={stepCountGoal}
      />}
    <Spacer />
    <RecordsBarChart
      records={records}
      horizeontalPadding={padding}
      showTimeLabels={Widget.family !== "accessoryRectangular"}
    />
  </VStack>
}