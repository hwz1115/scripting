type DeleteCalendarEventsParams = {
  identifiers: string[]
}

const deleteCalendarEventsApprovalRequest: AssistantToolApprovalRequestFn<DeleteCalendarEventsParams> = async (
  params
) => {
  const { identifiers } = params
  const events: CalendarEvent[] = []
  const notFoundIdentifiers: string[] = []

  if (!identifiers || identifiers.length === 0) {
    return {
      message: "No event identifiers provided. Please provide identifiers of the events you want to delete.",
    }
  }

  const now = new Date()
  const future = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000) // One year into the future

  try {
    const allEvents = await CalendarEvent.getAll(now, future)

    identifiers.forEach(identifier => {
      const event = allEvents.find(event => event.identifier === identifier)
      if (event) {
        events.push(event)
      } else {
        notFoundIdentifiers.push(identifier)
      }
    })

    if (events.length === 0 && notFoundIdentifiers.length === 0) {
      return {
        message: "No events found with the provided identifiers.",
      }
    }

    const eventList = events.map(event => `"${event.title}"`).join(", ")
    const notFoundList = notFoundIdentifiers.join(", ")

    let message = `Are you sure you want to delete the following events: ${eventList}?`

    if (notFoundIdentifiers.length > 0) {
      message += `\nThe following event identifiers were not found and will be ignored: ${notFoundList}.`
    }

    return {
      message,
      primaryButtonLabel: "Delete",
      secondaryButtonLabel: "Cancel",
    }
  } catch (error: any) {
    return {
      message: `Failed to retrieve calendar events. Error: ${error.message || error}`,
    }
  }
}

const deleteCalendarEvents: AssistantToolExecuteWithApprovalFn<DeleteCalendarEventsParams> = async (
  params,
  { primaryConfirmed }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "Event deletion cancelled by user.",
    }
  }

  const { identifiers } = params
  const deletedEvents: string[] = []
  const failedToDeleteEvents: string[] = []
  const notFoundEvents: string[] = []

  if (!identifiers || identifiers.length === 0) {
    return {
      success: false,
      message: "No event identifiers provided.",
    }
  }

  const now = new Date()
  const future = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)

  try {
    const allEvents = await CalendarEvent.getAll(now, future)

    for (const identifier of identifiers) {
      const event = allEvents.find(event => event.identifier === identifier)

      if (event) {
        try {
          await event.remove()
          deletedEvents.push(event.title)
        } catch (error: any) {
          failedToDeleteEvents.push(identifier)
        }
      } else {
        notFoundEvents.push(identifier)
      }
    }

    let message = ""
    if (deletedEvents.length > 0) {
      message += `Successfully deleted the following events: ${deletedEvents.join(", ")}.\n`
    }
    if (failedToDeleteEvents.length > 0) {
      message += `Failed to delete events with the following identifiers: ${failedToDeleteEvents.join(", ")}.\n`
    }
    if (notFoundEvents.length > 0) {
      message += `The following event identifiers were not found: ${notFoundEvents.join(", ")}.\n`
    }

    if (message === "") {
      message = "No events were found with the provided identifiers."
    }

    return {
      success: true,
      message,
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to delete calendar events. Error: ${error.message || error}`,
    }
  }
}

const testDeleteCalendarEventsApprovalRequest = AssistantTool.registerApprovalRequest(
  deleteCalendarEventsApprovalRequest
)

const testDeleteCalendarEvents = AssistantTool.registerExecuteToolWithApproval(
  deleteCalendarEvents
)

// Test the tool in the script editor:
testDeleteCalendarEventsApprovalRequest({ identifiers: ["test"] })
testDeleteCalendarEvents({ identifiers: ["test"] }, { primaryConfirmed: true, secondaryConfirmed: false })