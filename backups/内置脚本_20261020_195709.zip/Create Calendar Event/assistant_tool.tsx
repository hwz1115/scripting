type CreateCalendarEventParams = {
  title: string
  start_date: string
  end_date: string
  location?: string
  notes?: string
  is_all_day?: boolean
  calendar?: string
}

const calendarEventApprovalRequest: AssistantToolApprovalRequestFn<CreateCalendarEventParams> = async (
  params,
) => {
  return {
    message: `The assistant wants to create a calendar event with the following details:
Title: ${params.title}
Start Date: ${params.start_date}
End Date: ${params.end_date}
Location: ${params.location || "N/A"}
Notes: ${params.notes || "N/A"}`,
    primaryButtonLabel: "Allow"
  }
}

const createCalendarEvent: AssistantToolExecuteWithApprovalFn<CreateCalendarEventParams> = async (
  params,
  {
    primaryConfirmed,
    secondaryConfirmed,
  }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "User cancelled the event creation."
    }
  }

  try {
    const defaultCalendar = await Calendar.defaultForEvents()
    let calendar: Calendar | null = defaultCalendar

    if (params.calendar) {
      const calendars = await Calendar.forEvents()
      calendar = calendars.find(c => c.identifier === params.calendar) || defaultCalendar
      if (!calendar) {
        return {
          success: false,
          message: `Calendar with identifier "${params.calendar}" not found. Using default calendar.`
        }
      }
    }

    const event = new CalendarEvent()
    event.title = params.title
    event.calendar = calendar
    event.startDate = new Date(params.start_date)
    event.endDate = new Date(params.end_date)
    event.location = params.location
    event.notes = params.notes
    event.isAllDay = params.is_all_day || false

    await event.save()

    return {
      success: true,
      message: `Event "${event.title}" created successfully in calendar "${calendar?.title}".`
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to create event: ${error.message || error.toString()}`
    }
  }
}

const testCalendarEventApprovalFn = AssistantTool.registerApprovalRequest(
  calendarEventApprovalRequest
)

const testCalendarEventExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  createCalendarEvent
)

// Test the tool in the script editor:
testCalendarEventApprovalFn({
  title: "Test Meeting",
  start_date: "2024/01/20 10:00:00",
  end_date: "2024/01/20 11:00:00",
  location: "Test Room",
  notes: "Testing the calendar event creation tool"
})
testCalendarEventExecuteFn({
  title: "Test Meeting",
  start_date: "2024/01/20 10:00:00",
  end_date: "2024/01/20 11:00:00",
  location: "Test Room",
  notes: "Testing the calendar event creation tool"
}, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})