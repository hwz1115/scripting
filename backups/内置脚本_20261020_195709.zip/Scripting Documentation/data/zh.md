`Data` 类用于表示二进制数据，并提供多种格式之间的转换方法，如字符串、文件、Base64、Hex 编码、`ArrayBuffer` 等。它还支持数据拼接与低层级字节访问。

---

## 概述

`Data` 对象常用于：

* 字符串和二进制数据之间的转换
* 读取或保存文件数据
* 图片转为二进制（JPEG/PNG）
* Base64、Hex、`ArrayBuffer` 等格式互转
* 多段二进制数据的合并操作

---

## 静态方法

### `Data.fromString(string: string, encoding?: string): Data | null`

从字符串创建 `Data` 对象。

* **参数：**

  * `string`: 要编码的字符串
  * `encoding`（可选）：编码方式，默认为 `"utf-8"`

* **返回值：** 返回新的 `Data` 实例，或在失败时返回 `null`

* **示例：**

  ```ts
  const data = Data.fromString("Hello, world!")
  ```

---

### `Data.fromFile(filePath: string): Data | null`

从指定路径读取文件内容并生成 `Data`。

* **参数：**

  * `filePath`: 文件的绝对路径

* **返回值：** 如果读取成功返回 `Data` 实例，否则返回 `null`

* **示例：**

  ```ts
  const fileData = Data.fromFile("/private/tmp/sample.txt")
  ```

---

### `Data.fromArrayBuffer(arrayBuffer: ArrayBuffer): Data | null`

用已有的 `ArrayBuffer` 创建 `Data` 对象。

* **参数：**

  * `arrayBuffer`: 有效的 `ArrayBuffer` 对象

* **返回值：** 返回 `Data` 实例或 `null`

* **示例：**

  ```ts
  const buffer = new Uint8Array([1, 2, 3]).buffer
  const data = Data.fromArrayBuffer(buffer)
  ```

---

### `Data.fromBase64String(base64Encoded: string): Data | null`

从 Base64 编码字符串中解析二进制数据。

* **参数：**

  * `base64Encoded`: Base64 编码的字符串

* **返回值：** `Data` 对象，若解析失败则返回 `null`

* **示例：**

  ```ts
  const data = Data.fromBase64String("SGVsbG8=")
  ```

---

### `Data.fromHexString(hexEncoded: string): Data | null`

从十六进制编码的字符串中解析数据。

* **参数：**

  * `hexEncoded`: 如 `"48656c6c6f"` 这样的十六进制字符串

* **返回值：** 返回 `Data` 实例或 `null`

* **示例：**

  ```ts
  const data = Data.fromHexString("48656c6c6f")
  ```

---

### `Data.fromJPEG(image: UIImage, compressionQuality?: number): Data | null`

将 `UIImage` 编码为 JPEG 格式的 `Data`。

* **参数：**

  * `image`: 要编码的图片
  * `compressionQuality`（可选）：压缩质量（0.0\~1.0），默认 1.0

* **返回值：** 返回 `Data` 或失败时返回 `null`

---

### `Data.fromPNG(image: UIImage): Data | null`

将 `UIImage` 编码为 PNG 格式的 `Data`。

* **参数：**

  * `image`: 要编码的图片

* **返回值：** 返回 `Data` 或失败时返回 `null`

---

### `Data.combine(dataList: Data[]): Data`

将多个 `Data` 对象合并为一个。

* **参数：**

  * `dataList`: `Data` 实例数组

* **返回值：** 合并后的新 `Data` 对象，若列表为空返回空数据

* **示例：**

  ```ts
  const d1 = Data.fromString("Hello, ")
  const d2 = Data.fromString("world!")
  const combined = Data.combine([d1, d2])
  console.log(combined.toRawString())
  ```

---

## 实例方法

### `getBytes(): Uint8Array | null`

获取底层字节数据，作为 `Uint8Array`。

* **返回值：** 字节数组，若转换失败返回 `null`

* **示例：**

  ```ts
  const data = Data.fromString("abc")
  const bytes = data?.getBytes()
  ```

---

### `toArrayBuffer(): ArrayBuffer`

将数据转换为 `ArrayBuffer`。

* **返回值：** 一个有效的 `ArrayBuffer` 对象（即使为空也返回）

* **示例：**

  ```ts
  const buffer = data.toArrayBuffer()
  ```

---

### `toBase64String(): string`

返回数据的 Base64 编码字符串。

* **返回值：** 编码后的字符串

* **示例：**

  ```ts
  const base64 = data.toBase64String()
  ```

---

### `toHexString(): string`

返回数据的十六进制字符串。

* **返回值：** 字符串，如 `"48656c6c6f"`

* **示例：**

  ```ts
  const hex = data.toHexString()
  ```

---

### `toRawString(encoding?: string): string | null`

使用指定编码将二进制数据转换为字符串。

* **参数：**

  * `encoding`（可选）：如 `"utf-8"`，默认使用 UTF-8

* **返回值：** 转换后的字符串，失败返回 `null`

* **示例：**

  ```ts
  const data = Data.fromHexString("e4b8ad")
  const str = data?.toRawString("utf-8")
  ```

---

## 综合示例

### 文本转十六进制再还原为原文

```ts
const original = "SecureMessage"
const data = Data.fromString(original)
const hex = data?.toHexString()
const restored = Data.fromHexString(hex!).toRawString()
console.log(restored)
```

---

### 从文件读取数据并转为Base64字符串

```ts
const fileData = Data.fromFile("/path/to/file.bin")
const base64 = fileData?.toBase64String()
```

---

### 合并多个 Data 实例

```ts
const part1 = Data.fromString("Hello, ")
const part2 = Data.fromString("world!")
const combined = Data.combine([part1, part2])
console.log(combined.toRawString())
```

---

## 总结

`Data` 类是处理二进制数据的核心工具，适用于编码解码、文件读写、数据拼接、字符串转换、图片转码等多种场景。它在 Scripting 脚本开发中提供了高效而统一的底层数据操作能力。