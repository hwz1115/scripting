type QueryCalendarParams = {
  identifiers?: string[]
  entity_type: "event" | "reminder"
}

const calendarApprovalRequest: AssistantToolApprovalRequestFn<QueryCalendarParams> = async (
  params,
) => {
  if (params.identifiers && params.identifiers.length > 0) {
    try {
      const allCalendars = params.entity_type === "event" ? await Calendar.forEvents() : await Calendar.forReminders()
      const calendarTitles = params.identifiers.map(identifier => {
        const calendar = allCalendars.find((calendar: Calendar) => calendar.identifier === identifier)
        return calendar ? calendar.title : `Calendar with ID ${identifier}`
      })
      const message = `The assistant wants to access the following ${params.entity_type} calendars: ${calendarTitles.join(', ')}.`
      return {
        message: message,
        primaryButtonLabel: "Allow"
      }
    } catch (error: any) {
      return {
        message: `Failed to retrieve calendar titles. The assistant wants to access ${params.entity_type} calendars with identifiers: ${params.identifiers.join(', ')}.`,
        primaryButtonLabel: "Allow"
      }
    }
  } else {
    return {
      message: `The assistant wants to access all your ${params.entity_type} calendars.`,
      primaryButtonLabel: "Allow"
    }
  }
}

const queryCalendar: AssistantToolExecuteWithApprovalFn<QueryCalendarParams> = async (
  params,
  {
    primaryConfirmed,
    secondaryConfirmed,
  }
) => {
  try {
    let calendars: Calendar[] = []
    const calendarFetcher = params.entity_type === "event" ? Calendar.forEvents : Calendar.forReminders
    if (params.identifiers && params.identifiers.length > 0) {
      const allCalendars = await calendarFetcher()
      if (allCalendars) {
        for (const identifier of params.identifiers) {
          const calendar = allCalendars.find((calendar: Calendar) => calendar.identifier === identifier)
          if (calendar) {
            calendars.push(calendar)
          }
        }
      }
    } else {
      calendars = await calendarFetcher()
    }

    if (calendars.length > 0) {
      let message = "Calendar information:\n"
      for (const calendar of calendars) {
        message += `Identifier: ${calendar.identifier}\n`
        message += `Title: ${calendar.title}\n`
        message += `Color: ${calendar.color}\n`
        message += `Type: ${calendar.type}\n`
        message += `Source: ${calendar.source.title}\n`
        message += `Allowed Entity Types: ${calendar.allowedEntityTypes}\n`
        message += `Is For Events: ${calendar.isForEvents}\n`
        message += `Is For Reminders: ${calendar.isForReminders}\n`
        message += `Allows Content Modifications: ${calendar.allowsContentModifications}\n`
        message += `Is Subscribed: ${calendar.isSubscribed}\n`
        message += `Supported Event Availabilities: ${calendar.supportedEventAvailabilities}\n`
        message += "\n"
      }
      return {
        success: true,
        message: message
      }
    } else {
      return {
        success: false,
        message: "No calendars found."
      }
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to query calendars: ${error.message}`
    }
  }
}

const testCalendarApprovalFn = AssistantTool.registerApprovalRequest(
  calendarApprovalRequest
)

const testCalendarExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  queryCalendar
)

// Test the tool in the script editor:
testCalendarApprovalFn({ entity_type: "event" })
testCalendarExecuteFn({ entity_type: "event" }, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})