import { Notification } from "scripting"

type GetAllNotificationsParams = {
  type: "pending" | "delivered"
}

/**
 * Formats a timestamp (number of milliseconds since the Unix epoch) to a string in the format "YYYY/MM/DD HH:mm:ss".
 * @param timestamp - The timestamp in milliseconds.
 * @returns The formatted date string in local time.
 * @throws {Error} If the timestamp is invalid.
 */
function formatTimestamp(timestamp: number): string {
  const date = new Date(timestamp)
  if (isNaN(date.getTime())) {
    throw new Error(`Invalid timestamp: ${timestamp}`)
  }

  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  const seconds = String(date.getSeconds()).padStart(2, '0')

  return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`
}

async function getAllPendingNotifications(): Promise<{ success: boolean; message: string }> {
  try {
    const notifications = await Notification.getAllPendings()
    if (notifications && notifications.length > 0) {
      const notificationList = notifications.map(notification => {
        let deliveryTime = 0
        if (notification.trigger instanceof LocationNotificationTrigger) {
          deliveryTime = new Date().getTime() // LocationNotificationTrigger doesn't have nextTriggerDate
        } else {
          deliveryTime = notification.trigger?.nextTriggerDate()?.getTime() || 0
        }
        return `- Identifier: ${notification.identifier}\n- Title: ${notification.content.title}\n- Body: ${notification.content.body}\n- Delivery Time: ${formatTimestamp(deliveryTime)}`
      }).join("\n\n---\n\n")

      return {
        success: true,
        message: `All pending Notifications:\n${notificationList}`
      }
    } else {
      return {
        success: true,
        message: `No pending notifications found.`
      }
    }
  } catch (error) {
    return {
      success: false,
      message: `Failed to get pending notifications: ${error}`
    }
  }
}

async function getAllDeliveredNotifications(): Promise<{ success: boolean; message: string }> {
  try {
    const notifications = await Notification.getAllDelivereds()
    if (notifications && notifications.length > 0) {
      const notificationList = notifications.map(notification => {
        let deliveryTime = 0
        if (notification.request.trigger instanceof LocationNotificationTrigger) {
          deliveryTime = notification.date.getTime()
        } else {
          deliveryTime = notification.request.trigger?.nextTriggerDate()?.getTime() || 0
        }
        return `- Identifier: ${notification.request.identifier}\n- Title: ${notification.request.content.title}\n- Body: ${notification.request.content.body}\n- Delivery Time: ${formatTimestamp(deliveryTime)}`
      }).join("\n\n---\n\n")

      return {
        success: true,
        message: `All delivered Notifications:\n${notificationList}`
      }
    } else {
      return {
        success: true,
        message: `No delivered notifications found.`
      }
    }
  } catch (error) {
    return {
      success: false,
      message: `Failed to get delivered notifications: ${error}`
    }
  }
}

const getAllNotifications: AssistantToolExecuteFn<GetAllNotificationsParams> = async (
  params
) => {
  const { type } = params
  if (type === "pending") {
    return getAllPendingNotifications()
  } else {
    return getAllDeliveredNotifications()
  }
}

const testGetAllNotifications = AssistantTool.registerExecuteTool(
  getAllNotifications
)

// Test the tool in the script editor:
testGetAllNotifications({
  type: "delivered"
})