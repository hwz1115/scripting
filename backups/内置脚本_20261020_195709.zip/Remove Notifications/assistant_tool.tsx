import { Notification } from 'scripting'

type NotificationType = "pending" | "delivered"

type RemoveNotificationsParams = {
  identifiers: string[]
  type: NotificationType
}

const removeNotificationsApprovalRequest: AssistantToolApprovalRequestFn<RemoveNotificationsParams> = async (
  params,
) => {
  return {
    message: `The assistant wants to remove ${params.type} notifications with the following identifiers.`,
    primaryButtonLabel: "Allow",
    secondaryButtonLabel: "Deny"
  }
}

async function removePendingNotifications(identifiers: string[]): Promise<{ success: boolean; message: string }> {
  try {
    const allPendingNotifications = await Notification.getAllPendings()
    const notificationsToRemove = allPendingNotifications.filter(notification =>
      identifiers.includes(notification.identifier)
    )
    const notFoundIdentifiers = identifiers.filter(identifier =>
      !allPendingNotifications.find(notification => notification.identifier === identifier)
    )

    if (notFoundIdentifiers.length > 0) {
      AssistantTool.report(`Warning: The following identifiers were not found in pending notifications: ${notFoundIdentifiers.join(', ')}`)
    }

    const identifiersToRemove = notificationsToRemove.map(notification => notification.identifier)
    await Notification.removePendings(identifiersToRemove)

    let message = "Successfully removed the following pending notifications:\n"
    message += notificationsToRemove.map(notification => `- ${notification.content.title}`).join("\n")

    if (notFoundIdentifiers.length > 0) {
      message += `\nBut the following identifiers were not found: ${notFoundIdentifiers.join(', ')}`
    }

    return {
      success: true,
      message
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to remove pending notifications: ${error.message}`
    }
  }
}

async function removeDeliveredNotifications(identifiers: string[]): Promise<{ success: boolean; message: string }> {
  try {
    const allDeliveredNotifications = await Notification.getAllDelivereds()
    const notificationsToRemove = allDeliveredNotifications.filter(notification =>
      identifiers.includes(notification.request.identifier)
    )
    const notFoundIdentifiers = identifiers.filter(identifier =>
      !allDeliveredNotifications.find(notification => notification.request.identifier === identifier)
    )

    if (notFoundIdentifiers.length > 0) {
      AssistantTool.report(`Warning: The following identifiers were not found in delivered notifications: ${notFoundIdentifiers.join(', ')}`)
    }

    const identifiersToRemove = notificationsToRemove.map(notification => notification.request.identifier)
    await Notification.removeDelivereds(identifiersToRemove)

    let message = "Successfully removed the following delivered notifications:\n"
    message += notificationsToRemove.map(notification => `- ${notification.request.content.title}`).join("\n")

    if (notFoundIdentifiers.length > 0) {
      message += `\nBut the following identifiers were not found: ${notFoundIdentifiers.join(', ')}`
    }

    return {
      success: true,
      message
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to remove delivered notifications: ${error.message}`
    }
  }
}

const removeNotifications: AssistantToolExecuteWithApprovalFn<RemoveNotificationsParams> = async (
  params,
  {
    primaryConfirmed,
  }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "User denied the request to remove notifications."
    }
  }

  let result: { success: boolean; message: string }

  if (params.type === "pending") {
    result = await removePendingNotifications(params.identifiers)
  } else {
    result = await removeDeliveredNotifications(params.identifiers)
  }

  return result
}

const testRemoveNotificationsApprovalFn = AssistantTool.registerApprovalRequest(
  removeNotificationsApprovalRequest
)

const testRemoveNotificationsExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  removeNotifications
)

// Test the tool in the script editor:
testRemoveNotificationsApprovalFn({
  identifiers: ["test1", "test2", "test3"],
  type: "pending"
})
testRemoveNotificationsExecuteFn({
  identifiers: ["test1", "test2", "test3"],
  type: "pending"
}, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})