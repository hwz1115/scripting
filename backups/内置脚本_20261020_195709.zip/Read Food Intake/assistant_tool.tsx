type ReadFoodIntakeParams = {
  start_date: string
  end_date: string
}

const foodIntakeApprovalRequest: AssistantToolApprovalRequestFn<ReadFoodIntakeParams> = async (
  params,
) => {
  const startDate = params.start_date
  const endDate = params.end_date

  return {
    message: `The assistant wants to read your food intake data from HealthKit between ${startDate} and ${endDate}.`,
    primaryButtonLabel: "Allow",
  }
}

const readFoodIntake: AssistantToolExecuteWithApprovalFn<ReadFoodIntakeParams> = async (
  params,
  { primaryConfirmed }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "User did not approve the request to read food intake data.",
    }
  }

  try {
    const startDate = new Date(params.start_date)
    const endDate = new Date(params.end_date)

    const correlations = await Health.queryCorrelations("food", {
      startDate: startDate,
      endDate: endDate,
    })

    let message = ""
    if (correlations.length === 0) {
      message = "No food intake data found within the specified time range."
    } else {
      message = "Food intake data:\n"
      for (const correlation of correlations) {
        message += `\nFood intake at: ${correlation.startDate}\n`
        message += `UUID: ${correlation.uuid}\n`
        if (correlation.metadata && correlation.metadata["foodName"]) {
          message += `Food: ${correlation.metadata.foodName}\n`
        }
        for (const sample of correlation.quantitySamples) {
          const units = await Health.preferredUnits(
            [sample.quantityType]
          )
          const unit = units[sample.quantityType]
          if (!unit) {
            AssistantTool.report(`Could not find preferred unit for ${sample.quantityType}`)
            continue
          }
          const value = sample.quantityValue(
            unit
          )
          message += `  ${sample.quantityType}: ${value}\n`
        }
      }
    }

    return {
      success: true,
      message: message,
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to read food intake data: ${error.message}`,
    }
  }
}

const testFoodIntakeApprovalRequestFn = AssistantTool.registerApprovalRequest(
  foodIntakeApprovalRequest
)

const testFoodIntakeExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  readFoodIntake
)

// Test the tool in the script editor:
testFoodIntakeApprovalRequestFn({
  start_date: "2024/01/01 00:00:00",
  end_date: "2024/01/01 00:00:00",
})
testFoodIntakeExecuteFn(
  {
    start_date: "2025/07/05 00:00:00",
    end_date: "2025/07/07 00:00:00",
  },
  {
    primaryConfirmed: true,
    secondaryConfirmed: false,
  }
)