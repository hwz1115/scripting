import { fetch } from "scripting"

type Params = {
  url: string
}

// Approval request configuration
const approvalRequest = async (params: Params) => ({
  message: `Attempting to download image from:\n${params.url}`,
  primaryButtonLabel: "Allow"
})

// Execution logic with approval
const executeWithApproval = async (
  params: Params,
  { primaryConfirmed }: { primaryConfirmed: boolean }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "Operation canceled by user"
    }
  }

  try {
    // Step 1 - Fetch image
    AssistantTool.report("Starting image data download...")
    const response = await fetch(params.url)
    if (!response.ok) throw new Error(`HTTP error: ${response.status}`)

    const imageData = await response.data()

    AssistantTool.report("Image data download completed")
    AssistantTool.report("Decoding data to image...")

    const image = UIImage.fromData(imageData)

    if (!image) {
      AssistantTool.report("Failed to decode image data")
      return {
        success: false,
        message: "Failed to decode image data"
      }
    }

    AssistantTool.report("Image created.")
    AssistantTool.report("Recognizing text...")

    // Step 2 - Text recognition
    const result = await Vision.recognizeText(image, {
      recognitionLevel: "accurate",
      recognitionLanguages: ["en", "zh-Hans", "ja", "fr", "de"],
      usesLanguageCorrection: true
    })

    // Formatting recognition results
    // const formattedResult = result.candidates
    //   .map((c, idx) => `Block ${idx + 1} (${Math.round(c.confidence * 100)}%):\n${c.content}`)
    //   .join("\n\n")

    return {
      success: true,
      message: `Full text:\n${result.text}`
    }

  } catch (error) {
    const errorMessage = `Operation failed: ${error instanceof Error ? error.message : String(error)}`
    AssistantTool.report(errorMessage)
    return {
      success: false,
      message: errorMessage
    }
  }
}

// Tool registration
const testApprovalRequest = AssistantTool.registerApprovalRequest(approvalRequest)
const testExecute = AssistantTool.registerExecuteToolWithApproval(executeWithApproval)

// Test cases
testApprovalRequest({ url: "https://miro.medium.com/v2/resize:fit:1200/1*u6DDxlP8EP1-1AcSLq8bFg.png" })
testExecute(
  { url: "https://miro.medium.com/v2/resize:fit:1200/1*u6DDxlP8EP1-1AcSLq8bFg.png" },
  { primaryConfirmed: true, secondaryConfirmed: false }
)