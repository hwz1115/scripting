type ReadBodyMassParams = {}

const readBodyMassApprovalRequest: AssistantToolApprovalRequestFn<ReadBodyMassParams> = async (
  params,
) => {
  return {
    message: "The assistant wants to read your body mass from HealthKit.",
    primaryButtonLabel: "Allow"
  }
}

const readBodyMass: AssistantToolExecuteWithApprovalFn<ReadBodyMassParams> = async (
  params,
  {
    primaryConfirmed,
    secondaryConfirmed,
  }
) => {
  try {
    const bodyMassSamples = await Health.queryQuantitySamples("bodyMass", {
      limit: 1,
      sortDescriptors: [{ key: "startDate", order: "reverse" }]
    })

    if (bodyMassSamples && bodyMassSamples.length > 0) {
      const bodyMassSample = bodyMassSamples[0]
      const unit = HealthUnit.gramUnit(HealthMetricPrefix.kilo)
      const bodyMassInKG = bodyMassSample.quantityValue(unit)
      return {
        success: true,
        message: `The user's body mass is ${bodyMassInKG} ${unit.unitString}.`
      }
    } else {
      return {
        success: false,
        message: "Could not find body mass data in HealthKit."
      }
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to read body mass: ${error.message}`
    }
  }
}

const testReadBodyMassApprovalFn = AssistantTool.registerApprovalRequest(
  readBodyMassApprovalRequest
)

const testReadBodyMassExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  readBodyMass
)

// Test the tool in the script editor:
testReadBodyMassApprovalFn({})
testReadBodyMassExecuteFn({}, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})