import { Script } from "scripting"

console.present().then(() => {
  Script.exit()
})

console.log("This is an assistant tool to let the assistant read your body mass.")