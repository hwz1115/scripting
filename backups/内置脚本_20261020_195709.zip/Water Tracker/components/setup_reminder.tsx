import { Button, Form, Navigation, Text, Section, TextField, useState } from "scripting"
import { scheduleNotification } from "../utils/notification"
import { getStorage, updateStorage } from "../utils/storage"

export function SetupReminder({ fetchPendingNotification }: {
  fetchPendingNotification: () => void
}) {
  const dismiss = Navigation.useDismiss()
  const [interval, setInterval] = useState(() => getStorage().settings.interval.toString())
  const isValidInterval = Number(interval) > 0

  const scheduleReminder = async () => {
    const minutes = Number(interval)
    if (isNaN(minutes) || minutes <= 0) {
      return
    }

    const storage = getStorage()
    storage.settings.interval = minutes
    updateStorage(storage)

    await scheduleNotification(minutes)
    fetchPendingNotification()
    dismiss()
  }

  return <Form
    navigationTitle="Setup Reminder"
    navigationBarTitleDisplayMode={"inline"}
    toolbar={{
      confirmationAction: <Button
        title={"Save"}
        action={scheduleReminder}
        disabled={!isValidInterval}
      />,
    }}
  >
    <Section
      footer={
        <Text font="footnote" foregroundStyle="secondaryLabel">
          Enter how often you want to be reminded to drink water
        </Text>
      }
    >
      <TextField
        title="Interval (minutes)"
        value={interval}
        onChanged={setInterval}
        prompt="Enter minutes (e.g. 30)"
      />
    </Section>
  </Form>
} 