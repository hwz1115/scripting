import { HStack, Text, Spacer } from 'scripting'
import { getStorage } from '../utils/storage'
import { getDateKey } from '../utils/date'

export function TodayProgress() {
  const storage = getStorage()
  const todayKey = getDateKey()
  const count = storage.records[todayKey]?.count || 0

  return (
    <HStack alignment="center">
      <Text font="body">
        Water Count
      </Text>
      <Spacer />
      <Text
        font="title"
      >
        {count}
      </Text>
      <Text
        font="callout"
        foregroundStyle="secondaryLabel"
      >
        💧
      </Text>
    </HStack>
  )
} 