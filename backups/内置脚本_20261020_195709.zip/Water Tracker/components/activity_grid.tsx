import { Group, HStack, Image, LazyVGrid, Text, VStack } from 'scripting'
import { getThisMonthRecords, } from '../utils/storage'
import { getDayString, isDateInThisMonth, isDateToday, isFutureDate } from '../utils/date'

export function ActivityGrid() {
  const records = getThisMonthRecords()
  const maxCount = Math.max(...records.map(r => r.count))

  return (
    <VStack spacing={8}>
      <HStack
        foregroundStyle={"secondaryLabel"}
      >
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(item =>
          <Text
            frame={{
              maxWidth: "infinity"
            }}
          >{item}</Text>
        )}
      </HStack>
      <LazyVGrid
        columns={new Array(7).fill({
          size: { type: "flexible" }
        })}
        spacing={8}
      >
        {records.map((record) => {
          const isToday = isDateToday(record.date)
          const isFuture = isFutureDate(record.date)
          const isInThisMonth = isDateInThisMonth(record.date)

          return <VStack>
            <Image
              systemName={
                isFuture
                  ? "drop"
                  : "drop.fill"
              }
              imageScale={"large"}
              foregroundStyle={{
                color: "systemBlue",
                opacity: record.count
                  ? (0.3 + (record.count / maxCount) * 0.7)
                  : isInThisMonth
                    ? 0.1
                    : 0
              }}
              aspectRatio={{
                value: 1,
                contentMode: "fill"
              }}
            />
            <Text
              font={"footnote"}
              foregroundStyle={
                isToday
                  ? "label"
                  : "tertiaryLabel"
              }
            >{getDayString(record.date)}</Text>
          </VStack>
        })}
      </LazyVGrid>
      <Text
        font="caption"
        foregroundStyle="secondaryLabel"
      >
        This month's water intake
      </Text>
    </VStack>
  )
} 