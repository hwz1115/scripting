import {
  VStack,
  HStack,
  Text,
  Widget,
  Image,
  Spacer,
  Chart,
  BarChart,
  BarChartProps
} from 'scripting'
import { getTodayRecord } from './utils/storage'

function WidgetView() {
  const record = getTodayRecord()

  // Process times data for chart
  const hourlyData: number[] = Array(24).fill(0)
  record.times.forEach(timestamp => {
    const hour = new Date(timestamp).getHours()
    hourlyData[hour]++
  })

  const chartData: BarChartProps["marks"] = hourlyData.map((value, index) => {
    const date = new Date()
    date.setHours(index)
    return {
      label: date,
      value: value,
      foregroundStyle: "systemBlue"
    }
  })

  // Different layouts based on widget family
  switch (Widget.family) {
    case "systemSmall":
      return (
        <VStack
          spacing={8}
          padding={16}
          alignment="center"
        >
          <Image
            systemName="drop.fill"
            font="title"
            foregroundStyle="systemBlue"
          />
          <Text font="title">{record.count}</Text>
          <Text
            font="caption"
            foregroundStyle="secondaryLabel"
          >
            Today's Water Intake
          </Text>
        </VStack>
      )

    case "systemMedium":
      return (
        <HStack
          spacing={16}
          padding={20}
        >
          <VStack spacing={8} alignment="leading">
            <Text font="title">Water Intake</Text>
            <Text
              font="caption"
              foregroundStyle="secondaryLabel"
            >
              Today's Progress
            </Text>
          </VStack>
          <Spacer />
          <HStack spacing={4} alignment="center">
            <Image
              systemName="drop.fill"
              font="largeTitle"
              foregroundStyle="systemBlue"
            />
            <Text font="largeTitle">
              {record.count}
            </Text>
          </HStack>
        </HStack>
      )

    case "systemExtraLarge":
    case "systemLarge":
      return (
        <VStack
          spacing={16}
          padding={20}
        >
          <HStack>
            <VStack spacing={8} alignment="leading">
              <Text font="title">Water Intake</Text>
              <Text
                font="caption"
                foregroundStyle="secondaryLabel"
              >
                Today's Progress
              </Text>
            </VStack>
            <Spacer />
            <HStack spacing={4} alignment="center">
              <Image
                systemName="drop.fill"
                font="largeTitle"
                foregroundStyle="systemBlue"
              />
              <Text font="largeTitle">
                {record.count}
              </Text>
            </HStack>
          </HStack>

          <Chart>
            <BarChart
              marks={chartData}
              labelOnYAxis={false}
            />
          </Chart>

          <Text
            font="caption"
            foregroundStyle="secondaryLabel"
          >
            Hourly Distribution
          </Text>
        </VStack>
      )

    default:
      return (
        <VStack spacing={8}>
          <Image
            systemName="drop.fill"
            font="title"
            foregroundStyle="systemBlue"
          />
          <Text font="body">{record.count}</Text>
        </VStack>
      )
  }
}

// Present the widget UI
Widget.present(
  <WidgetView />
) 