import { Notification, Script } from 'scripting'

export const NOTIFICATION_ID = "water_tracker_reminder"

export async function scheduleNotification(interval: number) {
  return await Notification.schedule({
    threadIdentifier: NOTIFICATION_ID,
    title: "Drink Water",
    body: "Time to drink some water! 💧",
    triggerTime: Date.now() + (interval * 60 * 1000),
    userInfo: {
      scriptName: Script.name,
      interval
    },
    actions: [
      {
        title: "Done",
        url: Script.createRunURLScheme(Script.name, { action: "done" })
      },
      {
        title: "Skip",
        url: Script.createRunURLScheme(Script.name, { action: "skip" })
      },
      {
        title: "Skip and End",
        url: Script.createRunURLScheme(Script.name, { action: "skip_and_end" }),
        destructive: true
      },
      {
        title: "Done and End",
        url: Script.createRunURLScheme(Script.name, { action: "done_and_end" }),
        destructive: true
      },
    ]
  })
} 