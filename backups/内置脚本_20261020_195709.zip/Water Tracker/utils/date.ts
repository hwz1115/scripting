
export function isDateToday(date: string) {
  return getDateKey() == date
}

export function getDateKey(date: Date = new Date()): string {
  return date.toLocaleDateString('en-US', { year: 'numeric', month: '2-digit', day: '2-digit' })
}

export function getWeekday(date: string): number {
  return new Date(date).getDay()
}

export function isDateInThisMonth(date: string): boolean {
  const today = new Date()
  const targetDate = new Date(date)
  return targetDate.getMonth() === today.getMonth() && targetDate.getFullYear() === today.getFullYear()
}

export function getDayString(date: string): string {
  return new Date(date).toLocaleDateString('en-US', { day: 'numeric' })
}

export function isFutureDate(date: string): boolean {
  const today = new Date()
  const targetDate = new Date(date)
  return targetDate > today
}
