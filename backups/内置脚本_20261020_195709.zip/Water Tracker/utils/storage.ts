import { getDateKey, getWeekday } from "./date"

export interface WaterRecord {
  count: number
  times: number[]
}

export interface WaterStorage {
  records: {
    [date: string]: WaterRecord
  }
  settings: {
    interval: number
  }
}

const STORAGE_KEY = "water_tracker_data"

export function getStorage(): WaterStorage {
  return Storage.get<WaterStorage>(STORAGE_KEY) || {
    records: {},
    settings: {
      interval: 30
    }
  }
}

export function addRecordForToday(count: number) {
  const storage = getStorage()
  const todayKey = getDateKey()
  const record = storage.records[todayKey] || { count: 0, times: [] }
  record.count += count
  record.times.push(Date.now())
  storage.records[todayKey] = record
  updateStorage(storage)
}

export function updateStorage(data: WaterStorage) {
  Storage.set(STORAGE_KEY, data)
}

export function getTodayRecord(): WaterRecord {
  const storage = getStorage()
  const todayKey = getDateKey()
  return storage.records[todayKey] || { count: 0, times: [] }
}

export function getThisMonthRecords(): Array<{ date: string, count: number }> {
  const storage = getStorage()
  const result: Array<{ date: string, count: number }> = []

  const today = new Date()
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
  const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0)

  for (let date = startOfMonth; date <= endOfMonth; date.setDate(date.getDate() + 1)) {
    const key = getDateKey(date)
    result.push({
      date: key,
      count: storage.records[key]?.count || 0
    })
  }

  // Check the weekday of first item of the result, if it's not Sunday, add previous days(from Sunday to the first item) to the result
  const firstItemWeekday = getWeekday(result[0].date)
  if (firstItemWeekday !== 0) {
    const previousDays = Array.from({ length: firstItemWeekday }, (_, index) => {
      let date = new Date(result[0].date)
      date.setDate(date.getDate() - index - 1)
      return {
        date: getDateKey(date),
        count: 0
      }
    })
    result.unshift(...previousDays)
  }

  return result
}
