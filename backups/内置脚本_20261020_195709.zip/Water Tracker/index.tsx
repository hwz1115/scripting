import {
  NavigationStack,
  List,
  Text,
  Button,
  useState,
  Script,
  Navigation,
  Section,
  NotificationInfo,
  useEffect,
  Widget,
  Notification,
  HStack,
  Spacer,
  NavigationLink,
  useCallback
} from 'scripting'

import { getStorage, updateStorage, addRecordForToday } from './utils/storage'
import { NOTIFICATION_ID, scheduleNotification } from './utils/notification'
import { ActivityGrid } from './components/activity_grid'
import { TodayProgress } from './components/today_progress'
import { SetupReminder } from './components/setup_reminder'
import { getDateKey } from './utils/date'

function ReminderSetup() {
  const [pendingNotification, setPendingNotification] = useState<NotificationInfo | null>(null)
  const dismiss = Navigation.useDismiss()
  const [viewKey, setViewKey] = useState<string>(() => UUID.string())

  const fetchPendingNotification = useCallback(async () => {
    const notifications = await Notification.getAllPendings()
    const ourNotification = notifications.find(n => n.threadIdentifier === NOTIFICATION_ID)
    if (ourNotification) {
      setPendingNotification(ourNotification)
    }
  }, [])

  useEffect(() => {
    fetchPendingNotification()
  }, [fetchPendingNotification])

  const cancelReminder = async () => {
    if (pendingNotification) {
      await Notification.removePendings([pendingNotification.identifier])
      setPendingNotification(null)
    }
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="Water Tracker"
        navigationBarTitleDisplayMode="large"
        toolbar={{
          cancellationAction: (
            <Button
              title="Cancel"
              action={dismiss}
            />
          ),
          confirmationAction: pendingNotification ? undefined : (
            <NavigationLink
              title="Reminder"
              destination={<SetupReminder
                fetchPendingNotification={fetchPendingNotification}
              />}
            />
          )
        }}
        refreshable={async () => {
          setViewKey(UUID.string())
          fetchPendingNotification()
        }}
      >
        <Section
          header={
            <Text font="headline">
              Today's Progress
            </Text>
          }
        >
          <TodayProgress key={viewKey} />
        </Section>

        <Section
          header={
            <Text font="headline">
              Activity
            </Text>
          }
        >
          <ActivityGrid key={viewKey} />
        </Section>

        {pendingNotification ? (
          <Section
            header={
              <Text font="headline">Active Reminder</Text>
            }
            footer={
              <Text
                font="footnote"
                foregroundStyle="secondaryLabel"
              >
                Cancel the active reminder to set up a new one
              </Text>
            }
          >
            <HStack alignment="center">
              <Text font="body">
                Next reminder at {new Date(pendingNotification.deliveryTime).toLocaleTimeString()}
              </Text>
              <Spacer />
              <Button
                title="Cancel"
                action={cancelReminder}
                role="destructive"
              />
            </HStack>
          </Section>
        ) : null}
      </List>
    </NavigationStack>
  )
}

async function run() {
  const params = Script.queryParameters
  if (params?.action) {
    const storage = getStorage()
    const interval = storage.settings.interval

    switch (params.action) {
      case 'skip_and_continue':
        await scheduleNotification(interval)
        break

      case 'done_and_end':
        addRecordForToday(1)
        Widget.reloadAll()
        break

      case 'skip_and_end':
        break

      case 'done':
      default:
        addRecordForToday(1)
        Widget.reloadAll()
        await scheduleNotification(interval)
        break
    }

    Script.exit()
    return
  }

  if (Notification.current) {
    const storage = getStorage()
    const todayKey = getDateKey()
    const interval = storage.settings.interval

    const record = storage.records[todayKey] || { count: 0, times: [] }
    record.count += 1
    record.times.push(Date.now())
    storage.records[todayKey] = record
    updateStorage(storage)
    Widget.reloadAll()

    await scheduleNotification(interval)
    Script.exit()
    return
  }

  await Navigation.present({
    element: <ReminderSetup />,
    modalPresentationStyle: "pageSheet"
  })
  Script.exit()
}

run() 