import { Notification } from "scripting"

type ScheduleNotificationParams = {
  title: string
  subtitle?: string
  body?: string
  silent?: boolean
  trigger_time?: string
  repeats_type?: string
}

const requestScheduleNotificationApproval: AssistantToolApprovalRequestFn<ScheduleNotificationParams> = async (
  params
) => {
  return {
    title: "Schedule Notification",
    message: formatNotificationInfo(params),
    primaryButtonLabel: "Schedule",
  }
}

const scheduleNotification: AssistantToolExecuteWithApprovalFn<ScheduleNotificationParams> = async (
  params,
  { primaryConfirmed }
) => {
  try {
    let calendarNotificationTrigger: CalendarNotificationTrigger | undefined

    if (params.trigger_time) {
      const triggerTime = new Date(params.trigger_time)
      if (isNaN(triggerTime.getTime())) {
        return {
          success: false,
          message: `Invalid trigger time format: ${params.trigger_time}`,
        }
      }

      let dateMatching = DateComponents.fromDate(triggerTime)
      let repeats = false

      if (params.repeats_type) {
        if (!["hourly", "daily", "weekly", "monthly"].includes(params.repeats_type)) {
          return {
            success: false,
            message: `Invalid repeats type: ${params.repeats_type}. Valid values are "daily", "weekly", "monthly", "hourly".`,
          }
        }

        repeats = true

        switch (params.repeats_type) {
          case "hourly":
            dateMatching = DateComponents.forHourly(triggerTime)
            break
          case "daily":
            dateMatching = DateComponents.forDaily(triggerTime)
            break
          case "weekly":
            dateMatching = DateComponents.forWeekly(triggerTime)
            break
          case "monthly":
            dateMatching = DateComponents.forMonthly(triggerTime)
            break
        }
      }

      calendarNotificationTrigger = new CalendarNotificationTrigger({
        dateMatching: dateMatching,
        repeats: repeats,
      })
    }

    if (await Notification.schedule({
      title: params.title,
      subtitle: params.subtitle,
      body: params.body,
      silent: params.silent,
      trigger: calendarNotificationTrigger,
      avoidRunningCurrentScriptWhenTapped: true
    })) {
      return {
        success: true,
        message: `Notification "${params.title}" scheduled successfully.`,
      }
    } else {
      return {
        success: false,
        message: `Failed to schedule notification.`,
      }
    }

  } catch (error: any) {
    return {
      success: false,
      message: `Failed to schedule notification: ${error.message || error}`,
    }
  }
}

const testApprovalRequestFn = AssistantTool.registerApprovalRequest(
  requestScheduleNotificationApproval
)

const testExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  scheduleNotification
)

// 5 seconds from now
const date = new Date(Date.now() + 5 * 1000)
const formatedTriggerTime = `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`

const testParams: ScheduleNotificationParams = {
  title: "Test Notification",
  subtitle: "Subtitle",
  body: "This is a test notification.",
  silent: false,
  trigger_time: formatedTriggerTime,
  repeats_type: "daily",
}

// Test function
testApprovalRequestFn(testParams)
testExecuteFn(
  testParams,
  {
    primaryConfirmed: true,
    secondaryConfirmed: false,
  }
)

function formatNotificationInfo(
  params: ScheduleNotificationParams
): string {
  const title = params.title
  const subtitle = params.subtitle
  const body = params.body
  const silent = params.silent
  const triggerTime = params.trigger_time
  const repeatsType = params.repeats_type

  const arr: [String] = [
    `- Title: ${title}`,
  ]

  if (subtitle) {
    arr.push(`- Subtitle: ${subtitle}`)
  }
  if (body) {
    arr.push(`- Body: ${body}`)
  }
  if (silent) {
    arr.push(`- Play Sound: ${silent ? "No" : "Yes"}`)
  }
  if (triggerTime) {
    arr.push(`- Trigger Time: ${triggerTime}`)
  }
  if (repeatsType) {
    arr.push(`- Repeats Type: ${repeatsType}`)
  }

  return arr.join("\n")
}