import { Script } from "scripting"

console.present().then(() => Script.exit())

console.log(
  "[Schedule Notification] This tool allows the assistant to schedule a notification with a specified title, date, and time. The user will be prompted for approval before the notification is created."
)