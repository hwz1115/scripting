// This file is part of the Assistant Tool for requesting weather information.

// The input parameters for the tool.
type RequestWeatherParams = {
  query: "current" | "hourly" | "daily"
  latitude?: number
  longitude?: number
  daily_start_date?: string
  daily_end_date?: string
  hourly_start_date?: string
  hourly_end_date?: string
}

// The function to request the tool's approval.
const requestWeatherApprovalRequest: AssistantToolApprovalRequestFn<RequestWeatherParams> = async ({
  query,
  latitude,
  longitude,
  daily_start_date,
  daily_end_date,
  hourly_start_date,
  hourly_end_date,
}) => {
  const list = [
    "The assistant wants to request the weather information.",
    ` - Query: ${query}`,
  ]

  if (latitude) {
    list.push(` - Latitude: ${latitude}`)
  }
  if (longitude) {
    list.push(` - Longitude: ${longitude}`)
  }
  if (daily_start_date) {
    list.push(` - Daily Start Date: ${daily_start_date}`)
  }
  if (daily_end_date) {
    list.push(` - Daily End Date: ${daily_end_date}`)
  }
  if (hourly_start_date) {
    list.push(` - Hourly Start Date: ${hourly_start_date}`)
  }
  if (hourly_end_date) {
    list.push(` - Hourly End Date: ${hourly_end_date}`)
  }
  const message = list.join("\n\n")
  const title = "Request Weather Information"
  const primaryButtonLabel = "Allow"

  return {
    title,
    message,
    primaryButtonLabel,
  }
}

function formatCurrentWeather(weather: CurrentWeather): string {
  return `
  Current Weather:
  - Temperature: ${weather.temperature.formatted}
  - Feels Like: ${weather.apparentTemperature.formatted}
  - Humidity: ${weather.humidity}
  - Wind Direction: ${weather.wind.direction.formatted}
  - Condition: ${weather.condition}
  `
}

function formatHourlyWeather(hourlyWeather: WeatherHourlyForecast): string {
  let message = "Hourly Weather Forecast:\n"
  hourlyWeather.forecast.forEach((hour) => {
    const date = new Date(hour.date)
    message += `
    ${date.getHours()}:00:
    - Temperature: ${hour.temperature.formatted}
    - Humidity: ${hour.humidity}
    - Wind Direction: ${hour.wind.direction.formatted}
    - Condition: ${hour.condition}
    `
  })
  return message
}

function formatDailyWeather(dailyWeather: WeatherDailyForecast): string {
  let message = "Daily Weather Forecast:\n"
  dailyWeather.forecast.forEach((day) => {
    const date = new Date(day.date)
    message += `
    ${date.toLocaleDateString()}：
    - High Temperature: ${day.highTemperature.formatted}
    - Low Temperature: ${day.lowTemperature.formatted}
    - Wind Direction: ${day.wind.direction.formatted}
    - Condition: ${day.condition}
    `
  })
  return message
}

// The function to execute the tool.
const requestWeather: AssistantToolExecuteWithApprovalFn<RequestWeatherParams> = async (
  {
    query,
    latitude,
    longitude,
    daily_start_date,
    daily_end_date,
    hourly_start_date,
    hourly_end_date,
  },
  // { primaryConfirmed }
) => {
  let location: LocationInfo | null = null
  if (latitude && longitude) {
    location = {
      latitude,
      longitude,
    }
  } else {
    AssistantTool.report("Requesting current location...")
    try {
      location = await Location.requestCurrent()
      if (!location) {
        return {
          success: false,
          message: "Failed to request user's current location, ask user to check the device's location permission.",
        }
      }
    } catch (e) {
      console.error(e)
      return {
        success: false,
        message: "Failed to request user's current location, ask user to check the device's location permission.",
      }
    }
  }

  try {
    switch (query) {
      case "current":
        const currentWeather = await Weather.requestCurrent(location)
        if (currentWeather) {
          return {
            success: true,
            message: formatCurrentWeather(currentWeather),
          }
        } else {
          return {
            success: false,
            message: "Failed to request current weather information.",
          }
        }
      case "hourly":
        let startDate: Date | null = null
        let endDate: Date | null = null
        if (hourly_start_date) {
          startDate = new Date(hourly_start_date)
        }
        if (hourly_end_date) {
          endDate = new Date(hourly_end_date)
        }
        const hourlyWeather = await Weather.requestHourlyForecast(
          location,
          startDate != null && endDate != null
            ? {
              startDate,
              endDate,
            }
            : undefined
        )
        if (hourlyWeather) {
          return {
            success: true,
            message: formatHourlyWeather(hourlyWeather),
          }
        }
        return {
          success: false,
          message: "Failed to request hourly weather information.",
        }
      case "daily":
        let dailyStartDate: Date | null = null
        let dailyEndDate: Date | null = null
        if (daily_start_date) {
          dailyStartDate = new Date(daily_start_date)
        }
        if (daily_end_date) {
          dailyEndDate = new Date(daily_end_date)
        }
        const dailyWeather = await Weather.requestDailyForecast(
          location,
          dailyStartDate != null && dailyEndDate != null
            ? {
              startDate: dailyStartDate,
              endDate: dailyEndDate,
            }
            : undefined
        )
        if (dailyWeather) {
          return {
            success: true,
            message: formatDailyWeather(dailyWeather),
          }
        }
        return {
          success: false,
          message: "Failed to request daily weather information.",
        }
    }
  } catch (e) {
    console.error(e)
    return {
      success: false,
      message: "Failed to request weather information.",
    }
  }
}

// Register the approval request function.
const testRequestWeatherApprovalFn = AssistantTool.registerApprovalRequest(
  requestWeatherApprovalRequest
)

function formatDateTo_yyyyMMddHHmmss(date: Date): string {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, "0")
  const day = String(date.getDate()).padStart(2, "0")
  const hours = String(date.getHours()).padStart(2, "0")
  const minutes = String(date.getMinutes()).padStart(2, "0")
  const seconds = String(date.getSeconds()).padStart(2, "0")
  return `${year}/${month}/${day} ${hours}:${minutes}:${seconds}`
}

// Test the approval request function for "current" weather.
testRequestWeatherApprovalFn({
  query: "current",
  latitude: 37.7749,
  longitude: -122.4194,
})

// // Test the approval request function for "hourly" weather.
// // testRequestWeatherApprovalFn({
// //   query: "hourly",
// //   latitude: 37.7749,
// //   longitude: -122.4194,
// //   hourly_start_date: formatDateTo_yyyyMMddHHmmss(new Date()),
// //   hourly_end_date: formatDateTo_yyyyMMddHHmmss(new Date(Date.now() + 3600 * 1000)),
// // })

// // Test the approval request function for "daily" weather.
// // testRequestWeatherApprovalFn({
// //   query: "daily",
// //   latitude: 37.7749,
// //   longitude: -122.4194,
// //   daily_start_date: formatDateTo_yyyyMMddHHmmss(new Date()),
// //   daily_end_date: formatDateTo_yyyyMMddHHmmss(new Date(Date.now() + 86400 * 1000)),
// // })


// Register the execution function.
const testRequestWeatherFn = AssistantTool.registerExecuteToolWithApproval(
  requestWeather
)

// Test the execution function for "current" weather.
testRequestWeatherFn(
  {
    query: "current",
    latitude: 37.7749,
    longitude: -122.4194,
  },
  {
    primaryConfirmed: true,
    secondaryConfirmed: false,
  }
)
