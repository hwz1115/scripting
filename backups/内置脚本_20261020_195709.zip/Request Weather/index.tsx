import { Script } from "scripting"

console.present().then(() => Script.exit())

console.log("[Request Weather] This tool allows you to request the weather information of a specific location.")