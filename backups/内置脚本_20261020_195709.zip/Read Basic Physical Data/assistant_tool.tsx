type ReadBasicPhysicalDataParams = {}

const basicPhysicalDataApprovalRequest: AssistantToolApprovalRequestFn<ReadBasicPhysicalDataParams> = async (
  params,
) => {
  return {
    message: "The assistant wants to read your gender, age, height, and weight data. Do you allow it?",
    primaryButtonLabel: "Allow",
    secondaryButtonLabel: "Deny"
  }
}

const readBasicPhysicalData: AssistantToolExecuteWithApprovalFn<ReadBasicPhysicalDataParams> = async (
  params,
  {
    primaryConfirmed,
    secondaryConfirmed,
  }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "The user denied the request to read basic physical data."
    }
  }

  try {
    const birthDate = await Health.dateOfBirth()
    const sex = await Health.biologicalSex()
    const heightSamples = await Health.queryQuantitySamples("height", { startDate: new Date(0), endDate: new Date() })
    const weightSamples = await Health.queryQuantitySamples("bodyMass", { startDate: new Date(0), endDate: new Date() })

    let height: number | null = null
    if (heightSamples.length > 0) {
      height = heightSamples[heightSamples.length - 1].quantityValue(HealthUnit.meter()) ?? null
    }

    let weight: number | null = null
    if (weightSamples.length > 0) {
      weight = weightSamples[weightSamples.length - 1].quantityValue(HealthUnit.gramUnit(HealthMetricPrefix.kilo)) ?? null
    }

    const age = birthDate?.year ? new Date().getFullYear() - birthDate.year : null

    const sexString = sex === HealthBiologicalSex.female ? "Female" : sex === HealthBiologicalSex.male ? "Male" : "Unknown"

    return {
      success: true,
      message: [
        `Gender: ${sexString}`,
        `Age: ${age === null ? "Unknown" : age + " years"}`,
        `Height: ${height === null ? "Unknown" : height + " meters"}`,
        `Weight: ${weight === null ? "Unknown" : weight + " kilograms"}`
      ].join("\n")
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to read basic physical data: ${error.message}`
    }
  }
}

const testBasicPhysicalDataApprovalRequestFn = AssistantTool.registerApprovalRequest(
  basicPhysicalDataApprovalRequest
)

const testReadBasicPhysicalDataFn = AssistantTool.registerExecuteToolWithApproval(
  readBasicPhysicalData
)

// Test the tool in the script editor:
testBasicPhysicalDataApprovalRequestFn({})
testReadBasicPhysicalDataFn({}, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})