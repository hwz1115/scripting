type GetAllRemindersParams = {
  reminder_type: "incomplete" | "completed"
  start_date?: string
  end_date?: string
}

const getAllRemindersApprovalRequest: AssistantToolApprovalRequestFn<GetAllRemindersParams> = async (
  params,
) => {
  let message = "The assistant wants to retrieve your reminders."

  if (params.reminder_type) {
    message += ` Filtered by type: ${params.reminder_type}.`
  }

  if (params.start_date) {
    message += ` Start date: ${params.start_date}.`
  }

  if (params.end_date) {
    message += ` End date: ${params.end_date}.`
  }

  return {
    message: message,
    primaryButtonLabel: "Allow"
  }
}

const getAllReminders: AssistantToolExecuteWithApprovalFn<GetAllRemindersParams> = async (
  params,
  {
    primaryConfirmed,
    secondaryConfirmed,
  }
) => {
  try {
    let reminders: Reminder[] = []
    let message = ""

    const options: { startDate?: Date; endDate?: Date } = {}

    if (params.start_date) {
      options.startDate = new Date(params.start_date)
    }

    if (params.end_date) {
      options.endDate = new Date(params.end_date)
    }

    if (params.reminder_type === "incomplete") {
      reminders = await Reminder.getIncompletes(options)
      message = "Retrieved all incomplete reminders."
    } else if (params.reminder_type === "completed") {
      reminders = await Reminder.getCompleteds(options)
      message = "Retrieved all completed reminders."
    } else {
      reminders = await Reminder.getAll()
      message = "Retrieved all reminders."
    }

    if (reminders.length === 0) {
      return {
        success: true,
        message: "No reminders found."
      }
    }

    const reminderList = reminders.map(reminder => {
      let reminderDetails = `- ${reminder.title}`
      reminderDetails += `\n  Identifier: ${reminder.identifier}`
      if (reminder.dueDate) {
        reminderDetails += ` (Due: ${reminder.dueDate.toLocaleString()})`
      }
      if (reminder.notes) {
        reminderDetails += `\n  Notes: ${reminder.notes}`
      }
      reminderDetails += `\n  Priority: ${reminder.priority}`
      if (reminder.completionDate) {
        reminderDetails += `\n  Completed: ${reminder.completionDate.toLocaleString()}`
      }
      if (reminder.recurrenceRules && reminder.recurrenceRules.length > 0) {
        reminderDetails += `\n  Recurrence Rules: ${reminder.recurrenceRules.map(rule => {
          let ruleDetails = ""
          ruleDetails += `Frequency: ${rule.frequency}`
          ruleDetails += `, Interval: ${rule.interval}`
          if (rule.daysOfTheWeek) {
            ruleDetails += `, Days of the Week: ${rule.daysOfTheWeek.map(day => {
              if (typeof day === 'string') {
                return day
              } else {
                return day.weekday
              }
            }).join(", ")}`
          }
          if (rule.recurrenceEnd) {
            ruleDetails += `, End: ${rule.recurrenceEnd}`
          }
          return ruleDetails
        }).join("\n    ")}`
      }
      return reminderDetails
    }).join("\n")

    return {
      success: true,
      message: `${message}\n${reminderList}`
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to retrieve reminders: ${error.message}`
    }
  }
}

const testGetAllRemindersApprovalFn = AssistantTool.registerApprovalRequest(
  getAllRemindersApprovalRequest
)

const testGetAllRemindersExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  getAllReminders
)

// Test the tool in the script editor:
testGetAllRemindersApprovalFn({
  reminder_type: "incomplete"
})
testGetAllRemindersExecuteFn({
  reminder_type: "incomplete"
}, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})