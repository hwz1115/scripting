type GetActivitySummaryParams = {
  start_date?: string
  end_date?: string
}

const activitySummaryApprovalRequest: AssistantToolApprovalRequestFn<GetActivitySummaryParams> = async (
  params,
) => {
  return {
    message: "The assistant wants to access your activity summary from HealthKit.\n\nThis will allow it to retrieve your Move, Exercise, and Stand data.",
    primaryButtonLabel: "Allow",
  }
}

const getActivitySummary: AssistantToolExecuteWithApprovalFn<GetActivitySummaryParams> = async (
  params,
  {
    primaryConfirmed,
    secondaryConfirmed,
  }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "You denied access to your activity summary."
    }
  }

  const { start_date, end_date } = params

  if ((start_date && !end_date) || (!start_date && end_date)) {
    return {
      success: false,
      message: "Please provide both start_date and end_date, or neither."
    }
  }

  try {
    let startDate: DateComponents
    let endDate: DateComponents

    if (start_date && end_date) {
      const startDateParts = start_date.split('/').map(Number)
      const endDateParts = end_date.split('/').map(Number)

      if (startDateParts.length !== 3 || endDateParts.length !== 3) {
        return {
          success: false,
          message: "Invalid date format. Please use yyyy/MM/DD."
        }
      }

      const startDateObj = new Date(startDateParts[0], startDateParts[1] - 1, startDateParts[2])
      const endDateObj = new Date(endDateParts[0], endDateParts[1] - 1, endDateParts[2])

      startDate = DateComponents.fromDate(startDateObj)
      endDate = DateComponents.fromDate(endDateObj)
    } else {
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      startDate = DateComponents.fromDate(today)
      endDate = DateComponents.fromDate(today)
      endDate.day! += 1
    }

    const summaries = await Health.queryActivitySummaries({
      start: startDate,
      end: endDate,
    })

    if (!summaries || summaries.length === 0) {
      return {
        success: false,
        message: "No activity summary data found."
      }
    }

    const messages: string[] = []

    for (const summary of summaries) {

      const date = summary.dateComponents
      const move = summary.activeEnergyBurned(HealthUnit.kilocalorie())
      const moveGoal = summary.activeEnergyBurnedGoal(HealthUnit.kilocalorie())
      const exercise = summary.appleExerciseTime(HealthUnit.minute())
      const exerciseGoal = summary.appleExerciseTimeGoal(HealthUnit.minute())
      const stand = summary.appleStandHours(HealthUnit.count())
      const standGoal = summary.appleStandHoursGoal(HealthUnit.count())

      messages.push(
        [
          `Date: ${date.year}-${date.month}-${date.day}`,
          `Move: ${move.toFixed(0)}/${moveGoal.toFixed(0)} kcal`,
          `Exercise: ${exercise.toFixed(0)}/${exerciseGoal.toFixed(0)} min`,
          `Stand: ${stand.toFixed(0)}/${standGoal.toFixed(0)} hours`
        ].join("\n")
      )
    }

    return {
      success: true,
      message: messages.join("\n\n")
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to get activity summary: ${error.message}`
    }
  }
}

const testActivitySummaryApprovalFn = AssistantTool.registerApprovalRequest(
  activitySummaryApprovalRequest
)

const testActivitySummaryExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  getActivitySummary
)

// Test the tool in the script editor:
testActivitySummaryApprovalFn({})
testActivitySummaryExecuteFn({}, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})