type QueryCalendarEventsParams = {
  start_date: string
  end_date: string
}

const calendarEventsApprovalRequest: AssistantToolApprovalRequestFn<QueryCalendarEventsParams> = async (
  params: QueryCalendarEventsParams,
) => {
  return {
    message: `The assistant wants to query calendar events from ${params.start_date} to ${params.end_date}, is it allowed?`,
    primaryButtonLabel: "Allow"
  }
}

const queryCalendarEvents: AssistantToolExecuteWithApprovalFn<QueryCalendarEventsParams> = async (
  params: QueryCalendarEventsParams,
  userAction: {
    primaryConfirmed: boolean
    secondaryConfirmed: boolean
  }
) => {
  try {
    const startDate = new Date(params.start_date)
    const endDate = new Date(params.end_date)

    const events = await CalendarEvent.getAll(startDate, endDate)

    if (events && events.length > 0) {
      let eventDetails: string[] = []

      eventDetails = events.map((event: CalendarEvent) => {
        const details: string[] = [
          `Title: ${event.title}`,
          `Identifier: ${event.identifier}`,
          `Start Time: ${event.startDate.toLocaleString()}`,
          `End Time: ${event.endDate.toLocaleString()}`,
          `Location: ${event.location || 'None'}`,
          `Notes: ${event.notes || 'None'}`
        ]

        if (events.length <= 8) {
          if (event.url) {
            details.push(`URL: ${event.url}`)
          }
          details.push(`Is All Day: ${event.isAllDay}`)

          if (event.recurrenceRules && event.recurrenceRules.length > 0) {
            details.push(`Recurrence Rules: ${event.recurrenceRules.map(rule => rule.frequency).join(', ')}`)
          }
        }

        return details.join("\n")
      })

      return {
        success: true,
        message: `The following calendar events were found:\n\n${eventDetails.join("\n\n")}`
      }
    } else {
      return {
        success: true,
        message: "No calendar events were found in the specified time range."
      }
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to query calendar events: ${error.message || error}`
    }
  }
}

const testCalendarEventsApprovalFn = AssistantTool.registerApprovalRequest<QueryCalendarEventsParams>(
  calendarEventsApprovalRequest
)

const testCalendarEventsExecuteFn = AssistantTool.registerExecuteToolWithApproval<QueryCalendarEventsParams>(
  queryCalendarEvents
)

// Test the tool in the script editor:
testCalendarEventsApprovalFn({ start_date: "2024/01/01 00:00:00", end_date: "2024/01/31 23:59:59" })
testCalendarEventsExecuteFn({ start_date: "2024/01/01 00:00:00", end_date: "2024/01/31 23:59:59" }, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})