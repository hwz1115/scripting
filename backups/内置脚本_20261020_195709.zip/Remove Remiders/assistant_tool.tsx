type RemoveRemindersParams = {
  identifiers: string[]
}

const removeRemindersApprovalRequest: AssistantToolApprovalRequestFn<RemoveRemindersParams> = async (
  params,
) => {
  try {
    const reminders = await Reminder.getAll()
    const remindersToRemove = reminders.filter(reminder => params.identifiers.includes(reminder.identifier))
    const foundIdentifiers = remindersToRemove.map(reminder => reminder.identifier)
    const notFoundIdentifiers = params.identifiers.filter(identifier => !foundIdentifiers.includes(identifier))

    let message = "The assistant wants to remove the following reminders:\n";

    if (remindersToRemove.length > 0) {
      message += remindersToRemove.map(reminder => `- ${reminder.title}`).join('\n') + '\n';
    }

    if (notFoundIdentifiers.length > 0) {
      message += `\nThe following identifiers were not found and will be ignored:\n${notFoundIdentifiers.join(', ')}\n`;
    }

    if (remindersToRemove.length === 0 && notFoundIdentifiers.length > 0) {
      message = `No reminders found with the provided identifiers: ${params.identifiers.join(', ')}.`;
    } else if (remindersToRemove.length === 0) {
      message = "No reminders found with the provided identifiers.";
    }

    return {
      message,
      primaryButtonLabel: "Allow",
      secondaryButtonLabel: "Deny"
    }
  } catch (error: any) {
    return {
      message: `Failed to retrieve reminders: ${error.message}`,
      primaryButtonLabel: "Allow",
      secondaryButtonLabel: "Deny"
    }
  }
}

const removeReminders: AssistantToolExecuteWithApprovalFn<RemoveRemindersParams> = async (
  params,
  {
    primaryConfirmed,
    secondaryConfirmed,
  }
) => {
  if (!primaryConfirmed) {
    return {
      success: false,
      message: "User denied the request to remove reminders."
    }
  }

  try {
    const reminders = await Reminder.getAll()
    const remindersToRemove = reminders.filter(reminder => params.identifiers.includes(reminder.identifier))
    const foundIdentifiers = remindersToRemove.map(reminder => reminder.identifier)
    const notFoundIdentifiers = params.identifiers.filter(identifier => !foundIdentifiers.includes(identifier))

    let successCount = 0
    let failureCount = 0
    const failureMessages: string[] = []

    for (const reminder of remindersToRemove) {
      try {
        await reminder.remove()
        AssistantTool.report(`Removed reminder: ${reminder.title}`)
        successCount++
      } catch (error: any) {
        failureCount++
        failureMessages.push(`Failed to remove reminder ${reminder.title}: ${error.message}`)
      }
    }

    let message = `Successfully removed ${successCount} reminders.\n`

    if (notFoundIdentifiers.length > 0) {
      message += `The following identifiers were not found and were ignored: ${notFoundIdentifiers.join(', ')}.\n`
    }

    if (failureCount > 0) {
      message += `Failed to remove ${failureCount} reminders:\n${failureMessages.join('\n')}`
    }

    return {
      success: true,
      message
    }
  } catch (error: any) {
    return {
      success: false,
      message: `Failed to remove reminders: ${error.message}`
    }
  }
}

const testRemoveRemindersApprovalFn = AssistantTool.registerApprovalRequest(
  removeRemindersApprovalRequest
)

const testRemoveRemindersExecuteFn = AssistantTool.registerExecuteToolWithApproval(
  removeReminders
)

// Test the tool in the script editor:
testRemoveRemindersApprovalFn({ identifiers: ["identifier1", "identifier2"] })
testRemoveRemindersExecuteFn({ identifiers: ["identifier1", "identifier2"] }, {
  primaryConfirmed: true,
  secondaryConfirmed: false
})