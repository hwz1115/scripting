import {
  Button,
  HStack,
  Image,
  List,
  TextField,
  Section,
  Spacer,
  Text,
  useState,
  Navigation,
  NavigationStack,
  Widget,
} from "scripting";
import {
  getAccounts,
  setAccounts,
  getActiveAccountId,
  setActiveAccountId,
  getMediumLeftId,
  setMediumLeftId,
  getMediumRightId,
  setMediumRightId,
  getLargeIds,
  setLargeIds,
  Account,
} from "../util/storage/accounts";
import { API } from "../util/api";

function makeId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export function View() {
  const dismiss = Navigation.useDismiss();

  const [accounts, setAccountsState] = useState<Account[]>(() => getAccounts());
  const [activeId, setActiveIdState] = useState<string>(() => getActiveAccountId());
  const [leftId, setLeftIdState] = useState<string>(() => getMediumLeftId());
  const [rightId, setRightIdState] = useState<string>(() => getMediumRightId());
  const [largeIds, setLargeIdsState] = useState<string[]>(() => getLargeIds());
  const [newTitle, setNewTitle] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [loading, setLoading] = useState(false);

  function persistAccounts(next: Account[]) {
    setAccounts(next);
    setAccountsState([...next]);
  }

  function persistActive(id: string) {
    setActiveAccountId(id);
    setActiveIdState(id);
  }

  function persistLeft(id: string) {
    setMediumLeftId(id);
    setLeftIdState(id);
  }

  function persistRight(id: string) {
    setMediumRightId(id);
    setRightIdState(id);
  }

  function persistLargeIds(next: string[]) {
    setLargeIds(next);
    setLargeIdsState([...next]);
  }

  const MAX_LARGE_ACCOUNTS = 4;

  function toggleLarge(id: string) {
    if (largeIds.includes(id)) {
      persistLargeIds(largeIds.filter((x) => x !== id));
    } else {
      if (largeIds.length >= MAX_LARGE_ACCOUNTS) {
        return;
      }
      persistLargeIds([...largeIds, id]);
    }
  }

  async function addAccount() {
    const url = (newUrl || "").trim();
    if (!url) return;

    setLoading(true);
    let title = (newTitle || "").trim();
    if (!title) {
      try {
        const api = new API(url);
        await api.fetchData();
        title = (api.title || "").trim();
      } catch {
        title = "";
      }
    }
    if (!title) title = "Airport";

    const account: Account = { id: makeId(), title, url };
    const current = getAccounts();
    const next = [...current, account];
    persistAccounts(next);
    if (!getActiveAccountId()) {
      persistActive(account.id);
    }
    setNewTitle("");
    setNewUrl("");
    setLoading(false);
  }

  function deleteAccount(id: string) {
    const current = getAccounts();
    const next = current.filter((a) => a.id !== id);
    persistAccounts(next);

    if (getActiveAccountId() === id) {
      persistActive(next.length > 0 ? next[0].id : "");
    }
    if (getMediumLeftId() === id) {
      persistLeft("");
    }
    if (getMediumRightId() === id) {
      persistRight("");
    }
    const lids = getLargeIds().filter((x) => x !== id);
    persistLargeIds(lids);
  }

  function clearAll() {
    persistAccounts([]);
    persistActive("");
    persistLeft("");
    persistRight("");
    persistLargeIds([]);
  }

  return (
    <NavigationStack>
      <List
        navigationTitle={"设置"}
        toolbar={{
          topBarLeading: [<Button title="完成" action={() => dismiss()} />],
          topBarTrailing: [
            <Button
              title="预览"
              action={async () => {
                await Widget.preview();
              }}
            />,
          ],
        }}>
        <Section title="添加机场">
          <TextField
            title="机场名（留空则自动获取）"
            value={newTitle}
            onChanged={(v) => setNewTitle(v ?? "")}
          />
          <TextField
            title="请输入订阅链接"
            value={newUrl}
            onChanged={(v) => setNewUrl(v ?? "")}
          />
          <Button
            disabled={loading || !newUrl.trim()}
            title={loading ? "添加中..." : "添加机场"}
            action={addAccount}
          />
        </Section>
        <Section
          title="我的机场"
          footer={
            <Text foregroundStyle="secondaryLabel">
              圆圈：小尺寸/锁屏。方框：大尺寸（最多可选 4 个）。L/R：中尺寸左右。点「删除」即可去掉该机场。
            </Text>
          }>
          {accounts.length === 0 ? (
            <Text foregroundStyle="secondaryLabel">
              暂无机场，请先在上方添加
            </Text>
          ) : null}
          {accounts.map((account) => (
            <HStack key={account.id}>
              <Button
                buttonStyle="plain"
                action={() => persistActive(account.id)}>
                <Image
                  systemName={
                    account.id === activeId
                      ? "checkmark.circle.fill"
                      : "circle"
                  }
                />
              </Button>
              <Button
                buttonStyle="plain"
                disabled={
                  !largeIds.includes(account.id) &&
                  largeIds.length >= MAX_LARGE_ACCOUNTS
                }
                action={() => toggleLarge(account.id)}>
                <Image
                  systemName={
                    largeIds.includes(account.id)
                      ? "checkmark.square.fill"
                      : "square"
                  }
                  foregroundStyle={
                    !largeIds.includes(account.id) &&
                    largeIds.length >= MAX_LARGE_ACCOUNTS
                      ? "tertiaryLabel"
                      : undefined
                  }
                />
              </Button>
              <Text>{account.title || "Airport"}</Text>
              <Spacer />
              <Button
                buttonStyle="plain"
                action={() =>
                  persistLeft(leftId === account.id ? "" : account.id)
                }>
                <Text
                  bold={leftId === account.id}
                  foregroundStyle={
                    leftId === account.id ? "systemBlue" : "secondaryLabel"
                  }>
                  {"L"}
                </Text>
              </Button>
              <Button
                buttonStyle="plain"
                action={() =>
                  persistRight(rightId === account.id ? "" : account.id)
                }>
                <Text
                  bold={rightId === account.id}
                  foregroundStyle={
                    rightId === account.id ? "systemBlue" : "secondaryLabel"
                  }>
                  {"R"}
                </Text>
              </Button>
              <Button
                title="删除"
                buttonStyle="plain"
                action={() => deleteAccount(account.id)}
              />
            </HStack>
          ))}
          {accounts.length > 0 ? (
            <Button title="清空全部机场" action={() => clearAll()} />
          ) : null}
        </Section>
      </List>
    </NavigationStack>
  );
}
