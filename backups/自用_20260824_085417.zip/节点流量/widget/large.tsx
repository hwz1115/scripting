import { VStack, HStack, Text, Image, Gauge, Spacer, Divider } from "scripting";
import { formatBytes, formatBytesCompact, formatExpire } from "../util/format";

type AccountData = { api: any; title?: string; error?: string } | null;

function Cell({ data }: { data: AccountData }) {
  if (!data) {
    return (
      <VStack
        padding={{ horizontal: 10, vertical: 8 }}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <Spacer />
        <Text font={12} foregroundStyle="secondaryLabel">
          未设置
        </Text>
        <Spacer />
      </VStack>
    );
  }

  const { api, title, error } = data;
  const widgetTitle = title || api.title || "Airport";

  if (error) {
    return (
      <VStack
        padding={{ horizontal: 10, vertical: 8 }}
        spacing={4}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <HStack>
          <Text font={14} bold={true} lineLimit={1}>
            {widgetTitle}
          </Text>
          <Spacer />
        </HStack>
        <Spacer />
        <Text font={12} foregroundStyle="systemRed">
          {error === "403" ? "403 被拒绝" : error}
        </Text>
        <Spacer />
      </VStack>
    );
  }

  const leftData = formatBytes(api.total - api.upload - api.download);
  const used = api.upload + api.download;
  const percent =
    api.total > 0 ? Math.min(100, Math.round((used / api.total) * 100)) : 0;
  const remainColor =
    percent < 50 ? "systemGreen" : percent < 80 ? "systemOrange" : "systemRed";
  const expireText = api.expire ? formatExpire(api.expire) + " 到期" : "长期有效";

  return (
    <VStack
      padding={{ horizontal: 10, vertical: 8 }}
      spacing={5}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <Spacer />

      <HStack alignment="firstTextBaseline">
        <Text font={14} bold={true} lineLimit={1}>
          {widgetTitle}
        </Text>
        <Spacer />
        <Text font={10} foregroundStyle="secondaryLabel" lineLimit={1}>
          {expireText}
        </Text>
      </HStack>

      <HStack alignment="firstTextBaseline" spacing={2}>
        <Text font={26} bold={true} foregroundStyle={remainColor}>
          {leftData.value}
        </Text>
        <Text font={13} bold={true} foregroundStyle={remainColor}>
          {leftData.unit}
        </Text>
        <Text font={11} foregroundStyle="secondaryLabel" padding={{ leading: 2 }}>
          剩余
        </Text>
        <Spacer />
        <Text font={11} foregroundStyle="secondaryLabel">
          {percent + "%"}
        </Text>
      </HStack>

      <Gauge
        gaugeStyle="accessoryLinear"
        label={<Text>{""}</Text>}
        value={used}
        max={Math.max(api.total, 1)}
        tint={{ color: remainColor }}
      />

      <HStack>
        <Text font={11} foregroundStyle="secondaryLabel">
          {"总量 " + formatBytesCompact(api.total)}
        </Text>
      </HStack>

      <HStack spacing={4}>
        <Image
          systemName="arrow.down.circle.fill"
          imageScale="small"
          foregroundStyle="systemGreen"
        />
        <Text font={11} foregroundStyle="secondaryLabel">
          {formatBytesCompact(api.download)}
        </Text>
        <Spacer />
        <Image
          systemName="arrow.up.circle.fill"
          imageScale="small"
          foregroundStyle="systemOrange"
        />
        <Text font={11} foregroundStyle="secondaryLabel">
          {formatBytesCompact(api.upload)}
        </Text>
      </HStack>

      <Spacer />
    </VStack>
  );
}

export function View({ items }: { items: AccountData[] }) {
  const list = (items || []).filter((x) => x) as Exclude<AccountData, null>[];

  if (list.length === 0) {
    return (
      <VStack padding>
        <Spacer />
        <Text foregroundStyle="secondaryLabel">
          请在设置中勾选要在大尺寸小组件显示的机场
        </Text>
        <Spacer />
      </VStack>
    );
  }

  const rows: AccountData[][] = [];
  for (let i = 0; i < list.length; i += 2) {
    rows.push([list[i], list[i + 1] || null]);
  }

  return (
    <VStack padding={{ horizontal: 0, vertical: 0 }} spacing={0} frame={{ maxHeight: "infinity" }}>
      {rows.map((row, rowIndex) => (
        <VStack key={String(rowIndex)} spacing={0} frame={{ maxHeight: "infinity" }}>
          <HStack spacing={0} alignment="top" frame={{ maxHeight: "infinity" }}>
            <Cell data={row[0]} />
            <Divider />
            <Cell data={row[1]} />
          </HStack>
          {rowIndex < rows.length - 1 ? <Divider /> : null}
        </VStack>
      ))}
    </VStack>
  );
}
