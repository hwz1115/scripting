import { Navigation, Script } from "scripting"
import StarredPage from "./starred-page"

const PRESENTATION_STYLE_KEY = "github-star.presentation-style"
const BOTTOM_TABS_KEY = "github-star.bottom-tabs"
type PresentationStyle = "automatic" | "overFullScreen"
type PresentationResult =
  | { type: "close-script" }
  | { type: "change-presentation-style"; style: PresentationStyle }
  | { type: "change-layout"; bottomTabs: boolean }
  | undefined

function readPresentationStyle(): PresentationStyle {
  return Storage.get<string>(PRESENTATION_STYLE_KEY) === "overFullScreen" ? "overFullScreen" : "automatic"
}

function readBottomTabs(): boolean {
  return Storage.get<boolean>(BOTTOM_TABS_KEY) === true
}

async function run() {
  let result: PresentationResult
  do {
    result = await Navigation.present<PresentationResult>({
      element: <StarredPage presentationStyle={readPresentationStyle()} bottomTabs={readBottomTabs()} />,
      modalPresentationStyle: readPresentationStyle(),
    })
    if (result?.type === "change-presentation-style") {
      Storage.set(PRESENTATION_STYLE_KEY, result.style)
    }
    if (result?.type === "change-layout") {
      Storage.set(BOTTOM_TABS_KEY, result.bottomTabs)
    }
  } while (result?.type === "change-presentation-style" || result?.type === "change-layout")
  Script.exit()
}

void run()
