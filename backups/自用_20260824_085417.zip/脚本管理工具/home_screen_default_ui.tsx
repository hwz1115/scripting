/**
 * 脚本管理工具 — 首页标签页
 * 直接复用 index.tsx 的 MainPage，效果与直接运行脚本完全一致。
 * 启用方式：Scripting → 设置 → 显示首页标签 → 选择「脚本管理工具」
 */
import { MainPage } from "./index"

export default function HomeScreenView() {
  return <MainPage />
}