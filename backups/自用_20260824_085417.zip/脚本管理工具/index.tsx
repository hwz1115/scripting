// ===== 更新说明检查（脚本管理工具注入，勿删） =====
;(async () => {
  try {
    const note = "修复：首页脚本管理部分因修改名字后运行次数被重置影响的排序功能，且确保修改后立即生效\n修复：ios26暗色模式下首页备份板块四个按钮出现黑色方框\n优化：版本发布页面下方增加当前版本号显示"
    if (!note) return
    const version = "5.0.70"
    const scriptName = "脚本管理工具"
    const folderName = "脚本管理工具"
    if (!version) return
    const scriptAuthor = "WWWeng🐝"
    const notifyAuthor = true
    const publishId = "p1787285602880-39635"
    const base = FileManager.appGroupDocumentsDirectory || ""
    if (!base) return
    // 记录历史更新说明（changelog_history/{scriptName}.json，按版本号降序，最多 20 条，同版本去重）
    const histDir = base + "/changelog_history"
    try { await FileManager.createDirectory(histDir, true) } catch (e) {}
    const histPath = histDir + "/" + scriptName + ".json"
    let history: { version: string; note: string }[] = []
    try {
      const raw = JSON.parse(await FileManager.readAsString(histPath))
      if (Array.isArray(raw)) history = raw
    } catch (e) {}
    try {
      history = history.filter((h) => h && h.version !== version)
      history.push({ version, note })
      const verNums = (v: string) => {
        const p = String(v || "").split(".").map((n) => parseInt(n, 10) || 0)
        while (p.length < 3) p.push(0)
        return p
      }
      history.sort((a, b) => {
        const pa = verNums(a.version)
        const pb = verNums(b.version)
        for (let i = 0; i < 3; i++) {
          if (pa[i] !== pb[i]) return pb[i] - pa[i]
        }
        return 0
      })
      history = history.slice(0, 20)
      await FileManager.writeAsString(histPath, JSON.stringify(history))
    } catch (e) {}
    const seenDir = base + "/changelog_seen"
    try { await FileManager.createDirectory(seenDir, true) } catch (e) {}
    const statePath = seenDir + "/" + scriptName + ".json"
    let seen: Record<string, boolean> = {}
    try { seen = JSON.parse(await FileManager.readAsString(statePath)) || {} } catch (e) {}
    if (seen[version]) return
    // 作者本人不提示：本机脚本管理工具发布过该版本（本机即作者/发布者设备），或设置里填写的用户名与脚本作者一致，
    // 且本次发布未勾选「作者本人也提示更新」时，不弹更新说明
    try {
      const mgrCfgPath = base + "/script-manager-config.json"
      const mgrCfg = JSON.parse(await FileManager.readAsString(mgrCfgPath)) || {}
      const mgrName = String(mgrCfg.authorName || "").trim()
      const published = mgrCfg.publishedVersions || {}
      if (!notifyAuthor && ((scriptAuthor && mgrName && mgrName === scriptAuthor) || published[folderName] === version)) {
        return
      }
    } catch (e) {}
    // 同一发布实例只提示一次（按 版本号@发布序号 去重）：即使版本号一致，重新发布也会重新提示
    const seenKey = version + "@" + publishId
    if (seen[seenKey]) return
    await new Promise<void>((resolve) => setTimeout(() => resolve(), 600))
    const { Navigation, NavigationStack, ScrollView, VStack, HStack, Text, Button, Divider, Spacer, Image, useState } = await import("scripting")
    const markSeen = async () => {
      try {
        seen[seenKey] = true
        await FileManager.writeAsString(statePath, JSON.stringify(seen))
      } catch (e) {}
    }
    function ChangelogView(props: { note: string; version: string; scriptName: string; history: { version: string; note: string }[] }) {
      const dismiss = Navigation.useDismiss()
      const [pageIndex, setPageIndex] = useState(0)
      const total = props.history.length
      const current = total > 0 ? props.history[Math.min(pageIndex, total - 1)] : null
      const atFirst = pageIndex <= 0
      const atLast = pageIndex >= total - 1
      const navButton = (icon: string, label: string, disabled: boolean, action: () => void) => (
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 48, height: 52 }}
          background={{ style: { color: "label", opacity: 0.08 }, shape: { type: "rect", cornerRadius: 12 } }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={() => { if (!disabled) action() }}
        >
          <Image systemName={icon} foregroundStyle={disabled ? "secondaryLabel" : "tintColor"} />
          <Text font="caption2" foregroundStyle={disabled ? "secondaryLabel" : "tintColor"}>{label}</Text>
        </VStack>
      )
      return (
        <NavigationStack>
          <VStack navigationTitle={props.scriptName + " · 更新说明"} navigationBarTitleDisplayMode="inline" navigationBarBackButtonHidden spacing={0}>
            {total === 0 ? (
              <VStack alignment="center" spacing={8} padding={32} frame={{ maxHeight: "infinity" }}>
                <Text font="subheadline" foregroundStyle="secondaryLabel">暂无历史更新记录</Text>
              </VStack>
            ) : current ? (
              <>
                <HStack alignment="center" padding={{ top: 14, horizontal: 16, bottom: 10 }}>
                  <Text font="headline" bold>版本 {current.version}</Text>
                  <Spacer />
                  <Text font="caption2" foregroundStyle="secondaryLabel">第 {pageIndex + 1} / {total} 页</Text>
                </HStack>
                <Divider />
                <ScrollView frame={{ maxHeight: "infinity" }}>
                  <VStack alignment="leading" spacing={10} padding={{ horizontal: 16, bottom: 16 }}>
                    <Text font="body" multilineTextAlignment="leading">{current.note}</Text>
                  </VStack>
                </ScrollView>
              </>
            ) : null}
            <Divider />
            <VStack spacing={12} alignment="center" padding={{ horizontal: 16, vertical: 12 }} background={{ style: { color: "secondarySystemBackground", opacity: 0.95 }, shape: { type: "rect", cornerRadius: 20 } }}>
              <HStack spacing={10} alignment="center" padding={{ horizontal: 10, vertical: 8 }}>
                {navButton("backward.end.fill", "首页", atFirst, () => setPageIndex(0))}
                {navButton("chevron.left", "上页", atFirst, () => setPageIndex(pageIndex - 1))}
                {navButton("chevron.right", "下页", atLast, () => setPageIndex(pageIndex + 1))}
                {navButton("forward.end.fill", "尾页", atLast, () => setPageIndex(total - 1))}
              </HStack>
              <HStack spacing={12} alignment="center" padding={{ horizontal: 6, vertical: 2 }}>
                <Button action={() => { markSeen(); dismiss() }} buttonStyle="bordered" controlSize="large">
                  <Text font="footnote" foregroundStyle="secondaryLabel">此版不再显示</Text>
                </Button>
                <Button action={() => dismiss()} buttonStyle="borderedProminent" controlSize="large">
                  <Text font="footnote" bold>稍候再看说明</Text>
                </Button>
              </HStack>
            </VStack>
          </VStack>
        </NavigationStack>
      )
    }
    await Navigation.present({
      element: <ChangelogView note={note} version={version} scriptName={scriptName} history={history} />,
    })
  } catch (e) {}
})();
// ===== 更新说明检查结束 =====



































import {
  Button,
  DragGesture,
  fetch,
  ForEach,
  HStack,
  Image,
  Link,
  List,
  Navigation,
  NavigationLink,
  NavigationStack,
  Notification,
  Path,
  Picker,
  Rectangle,
  Script,
  ScrollViewProxy,
  ScrollViewReader,
  Section,
  Spacer,
  Text,
  TextField,
  Toggle,
  Toolbar,
  ToolbarItem,
  VStack,
  ZStack,
  useEffect,
  useMemo,
  useObservable,
  useRef,
  useState,
} from "scripting"
import {
  APP_NAME,
  AppConfig,
  BackupItem,
  BackupScopeKey,
  CandidateScript,
  ChannelChange,
  ChannelCheckResult,
  ChannelCheckSummary,
  ChannelMonitorLink,
  Destination,
  GroupInfo,
  GithubConfig,
  GithubBackupManifest,
  GithubRepoFile,
  GithubRepoParams,
  ScriptInfo,
  absorbPublishedIntoChannelBaseline,
  backupRootFor,
  backupScripts,
  backupScriptsToGithub,
  clearErrorLogs,
  computeBackupScriptCount,
  deleteGithubBackup,
  deleteGithubRepoFile,
  deleteLocalBackup,
  deleteScript,
  disableScriptAutoUpdate,
  dismissChannelRemoved,
  dismissChannelUpdates,
  downloadGithubBackup,
  downloadGithubRepoFile,
  fetchScriptCloudMeta,
  formatBytes,
  formatDate,
  githubVerify,
  buildGroupNameMap,
  channelMonitorIntervalSeconds,
  compareVersions,
  enforceGroupMoveTargets,
  getBackupScriptCount,
  getScriptRemoteResource,
  getGithubRepoFilesModifiedAt,
  groupNameForScript,
  inspectBackup,
  isGithubBackupConfigured,
  isGithubConfigured,
  listGithubBackups,
  listGithubRepoFiles,
  logError,
  moveScriptToGroup,
  normalizeChannelExcludeKeywords,
  normalizeChannelIgnoredPaths,
  normalizeChannelMonitorLinks,
  normalizeRepoUrl,
  pathExists,
  publishScriptsToGithub,
  renameScript,
  repoDisplayName,
  repoParts,
  resolveFreshRawScriptUrl,
  resolveRawScriptUrl,
  restoreImportedScriptGroups,
  snapshotScriptGroups,
  resolveConfig,
  resolveGithubConfig,
  resolvePublishGithubConfig,
  resolveBackupGithubConfig,
  restoreScripts,
  runChannelMonitorCheck,
  readLastChannelCheck,
  readLastChannelUpdate,
  saveLastChannelCheck,
  saveLastChannelUpdate,
  readScriptChangelog,
  readScriptMeta,
  injectChangelogChecker,
  safeFileName,
  saveBackupScriptCount,
  saveConfig,
  saveGithubConfig,
  scanBackups,
  readGithubBackupManifest,
  readScriptingGroups,
  renameGithubBackup,
  renameGithubRepoFile,
  renameLocalBackup,
  resolveErrorLogs,
  scanGroups,
  scanScripts,
  scanScriptDirsInTree,
  scriptContentFingerprint,
  scriptDirFingerprint,
  scriptInfoFromDir,
  scriptZipSize,
  readScriptContributors,
  readScriptCoAuthors,
  clearScriptAuthor,
  setScriptAuthorName,
  setScriptCoAuthor,
  removeScriptContributor,
  setScriptVersion,
  setScriptChangelog,
  shareGithubBackups,
  sortGithubBackupsByTime,
  shareLocalBackups,
  shareScripts,
  timestampForName,
  updateChannelMonitorConfig,
  uploadLocalBackupToGithub,
} from "./manager"
import { t, tpl, setLanguage, subscribeLanguageChange } from "./lang"

// 初始化界面语言（设置页可切换 中文/English，默认中文）
setLanguage(resolveConfig().language)

// Dialog 全局模块：alert / confirm / prompt / actionSheet（与其他脚本一致，类型宽松处理）
declare const Dialog: any
// 打开系统浏览器统一用 Safari.openURL（全局命名空间，无需 import；运行时无全局 openURL）
// confirm 为全局确认框（返回 Promise<boolean>），类型宽松处理避免与全局声明冲突时用 any
declare const confirm: any
type PromptOptions = {
  title: string
  message?: string
  defaultValue?: string
  obscureText?: boolean
  selectAll?: boolean
  placeholder?: string
  cancelLabel?: string
  confirmLabel?: string
  keyboardType?: string
}
function inputPrompt(options: PromptOptions): Promise<string | null> {
  return Dialog.prompt(options)
}

/** 移动到分组的弹窗按钮顺序：与设置页「分组顺序」调整页保持一致 —— 分组自定义顺序正向排列，未配置顺序的分组按原顺序附在末尾 */
function orderGroupsForMove(named: GroupInfo[], groupOrder?: string[]): GroupInfo[] {
  if (!groupOrder || groupOrder.length === 0) {
    return [...named]
  }
  const ordered: GroupInfo[] = []
  const used = new Set<string>()
  for (const name of groupOrder) {
    const g = named.find((x) => x.name === name)
    if (g && !used.has(g.name)) {
      ordered.push(g)
      used.add(g.name)
    }
  }
  // 未在自定义顺序里的分组，保持原顺序附在末尾
  for (const g of named) {
    if (!used.has(g.name)) {
      ordered.push(g)
    }
  }
  return ordered
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/**
 * 仓库监控：检测到变化时发系统通知（列出各仓库变更的脚本，最多各列 10 个）。
 * 变更通知立即送达；点通知会运行本脚本并再次检查。
 */
async function notifyChannelChanges(results: ChannelCheckResult[]) {
  // 设置里关闭「打开监控通知」后不再发送系统通知（监控仍正常检查，应用内提示不受影响）
  const cfg = resolveConfig()
  if (!cfg.channelMonitorNotificationEnabled) return
  const changed = results.filter((r) => r.ok && r.changes.length > 0)
  if (changed.length === 0) return
  let total = 0
  let singleChange: ChannelChange | null = null
  for (const r of changed) {
    total += r.changes.length
    if (!singleChange && r.changes.length === 1) singleChange = r.changes[0]
  }
  try {
    // 仓库显示名可能自带「的脚本仓库」后缀（如默认“WWWeng🐝的脚本仓库”），拼标题前先去掉，避免重复
    const repoName = changed[0].name.replace(/的脚本仓库\s*$/i, "")
    let title: string
    let body: string
    if (total === 1 && singleChange) {
      // 单个脚本可更新：标题用仓库名，正文写脚本名与可更新的版本号
      title = tpl("{repo}的脚本仓库有更新", { repo: repoName })
      const name = singleChange.path.replace(/\.scripting$/i, "")
      const ver = singleChange.cloudVersion
      body = ver
        ? tpl("「{name}」可更新到 {ver}", { name, ver })
        : tpl("「{name}」有更新可安装", { name })
    } else if (changed.length === 1) {
      // 多个脚本可更新（单仓库）：标题用仓库名，正文写共有几个脚本可更新
      title = tpl("{repo}的脚本仓库有更新", { repo: repoName })
      body = tpl("共有 {n} 个脚本可更新", { n: String(total) })
    } else {
      // 多个脚本可更新（多仓库）
      title = "多个脚本仓库有更新"
      body = tpl("共有 {n} 个脚本可更新", { n: String(total) })
    }
    await Notification.schedule({
      title,
      body,
      threadIdentifier: "channel-monitor",
    })
  } catch (error) {
    logError("仓库监控通知", error)
  }
}

/**
 * 频道更新页：本地覆盖安装脚本成功后发系统通知（提示已更新到最新版本）。
 * 仅覆盖工具内部确认安装成功的脚本；走 Scripting 导入器的新装脚本无法获知结果，不发通知。
 */
async function notifyChannelUpdateSuccess(names: string[]) {
  if (names.length === 0) return
  try {
    const title = "脚本更新成功"
    const body =
      names.length === 1
        ? tpl("「{name}」已更新到最新版本", { name: names[0] })
        : tpl("已成功更新 {n} 个脚本", { n: String(names.length) })
    await Notification.schedule({
      title,
      body,
      threadIdentifier: "channel-update",
    })
  } catch (error) {
    logError("更新成功通知", error)
  }
}

/**
 * 移除通知中心里已送达的「有更新」通知（threadIdentifier=channel-monitor）。
 * 弹出更新页后调用，避免残留的旧通知被再次点击时重复打开更新页。
 */
async function removeDeliveredChannelUpdateNotifications() {
  try {
    const infos = await Notification.getAllDeliveredsOfCurrentScript()
    const ids = infos
      .map((info) => {
        const tid =
          info.request?.content?.threadIdentifier ?? info.threadIdentifier
        return tid === "channel-monitor" ? info.request?.identifier : null
      })
      .filter((x): x is string => Boolean(x))
    if (ids.length > 0) {
      await Notification.removeDelivereds(ids)
    }
  } catch {
    // ignore
  }
}

/**
 * 仓库监控变化集合签名：把一次检查的变化集编码成字符串，用于「同一批变化只自动弹一次更新页」去重。
 * 用户关闭更新页后，只要仓库没有新变化，定时循环不会再重复弹。
 */
function channelChangesSignature(results: ChannelCheckResult[]): string {
  const parts: string[] = []
  for (const r of results) {
    if (!r.ok) continue
    for (const c of r.changes) {
      // sha 参与签名：同一文件每次新发布（sha 变）视为新一批变化；同一批变化（sha 相同）可去重
      parts.push(`${r.url}|${c.type}|${c.path}|${c.sha ?? ""}`)
    }
  }
  return parts.sort().join("\n")
}

/** 已忽略脚本路径（`仓库url|脚本路径`）的展示：拆成脚本名 + 仓库显示名 */
function ignoredPathDisplay(
  key: string
): { name: string; repo: string } {
  const sep = key.indexOf("|")
  if (sep < 0) return { name: key, repo: "" }
  const url = key.slice(0, sep)
  const path = key.slice(sep + 1)
  return {
    name: path.replace(/\.scripting$/i, ""),
    repo: repoDisplayName(url),
  }
}

/** 判断通知是否为仓库监控通知，是则返回其 threadIdentifier，否则返回 null */
function channelNotificationThreadId(
  info: any
): "channel-monitor" | "channel-monitor-reminder" | null {
  if (!info) return null
  const tid = info.request?.content?.threadIdentifier ?? info.threadIdentifier
  if (tid === "channel-monitor" || tid === "channel-monitor-reminder") {
    return tid
  }
  return null
}

/**
 * 等待脚本内容稳定后再备份：每轮间隔 1.2s 重扫目录，连续两次目录指纹一致才认为内容已稳定，
 * 返回重扫后的最新 ScriptInfo（保证备份到的是刷新后的内容）。
 * 期间若版本又被修改则返回 null（放弃本次自动备份，下一次扫描会按新基线重新触发）。
 */
async function waitForStableScripts(
  changed: ScriptInfo[],
  expected: Record<string, string>
): Promise<ScriptInfo[] | null> {
  let prevFp: string[] | null = null
  let latest: ScriptInfo[] = changed
  for (let attempt = 0; attempt < 4; attempt++) {
    await sleep(1200)
    const fresh = changed
      .map((s) => scriptInfoFromDir(s.path))
      .filter((s): s is ScriptInfo => s !== null)
    if (fresh.length === 0) {
      return null
    }
    // 版本被再次修改：放弃本次，让下一次扫描按新基线重新触发
    const versionMoved = fresh.some(
      (s) => (s.version ?? "") !== (expected[s.folderName] ?? "")
    )
    if (versionMoved) {
      return null
    }
    const fp = fresh.map((s) => scriptDirFingerprint(s.path))
    if (prevFp != null && fp.join("\u0001") === prevFp.join("\u0001")) {
      return fresh
    }
    prevFp = fp
    latest = fresh
  }
  return latest
}

/**
 * 修改版本号前检查脚本是否开启自动更新：带 remoteResource 的脚本由 Scripting 管理远程更新，
 * 本地修改的版本号在下一次应用云端更新时会被云端版本替换。这里给用户两个选择：
 * 「直接修改」保留更新链接，改动仅本地生效；「修改并关闭自动更新」则彻底避免被云端覆盖。
 * 返回 false 表示用户取消。
 */
async function ensureVersionNotOverridden(script: ScriptInfo): Promise<boolean> {
  const remote = getScriptRemoteResource(script)
  if (!remote || remote.autoUpdateInterval == null) {
    return true
  }
  const index = await Dialog.actionSheet({
    title: t("该脚本开启了自动更新"),
    message:
      tpl("「{name}」配置了远程自动更新（约每 {interval} 秒检查一次）。", { name: script.displayName, interval: String(remote.autoUpdateInterval) }) +
      t(`修改的版本号会保留到下一次应用云端更新为止（应用后版本号会被替换为云端版本）。`) +
      t(`也可以选择同时关闭自动更新（保留更新链接，之后可重新开启），避免后续被云端覆盖。`),
    actions: [
      { label: t("修改并关闭自动更新"), destructive: true },
      { label: t("直接修改") },
    ],
  })
  if (index == null) {
    return false
  }
  if (index === 0) {
    disableScriptAutoUpdate(script)
  }
  return true
}

/** 去掉名称尾部的版本号（如「脚本名_5.0.9」→「脚本名」），用于重命名并安装的默认名称 */
function stripTrailingVersion(name: string): string {
  return name.replace(/_\d+\.\d+\.\d+$/, "")
}

/** 重命名并安装后：把新目录 script.json 的显示名改成最终名称（与目录名一致，脚本列表按新名显示） */
function renameInstalledScriptJsonName(finalName: string): void {
  const metaPath = Path.join(
    FileManager.scriptsDirectory,
    finalName,
    "script.json"
  )
  if (!pathExists(metaPath)) {
    return
  }
  try {
    const obj = JSON.parse(FileManager.readAsStringSync(metaPath))
    if (obj && typeof obj === "object") {
      obj.name = finalName
      if (obj.localizedNames && typeof obj.localizedNames === "object") {
        obj.localizedNames.zh = finalName
      }
      FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
    }
  } catch {}
}

// ==================== 通用小组件 ====================

function useToast() {
  const [toast, setToast] = useState<{
    msg: string
    isError: boolean
  }>({ msg: "", isError: false })
  // 可见性单独用状态控制：Toast 的 isPresented 需要 false→true 边沿才会重新 present。
  // 若直接靠 msg 非空驱动，连续两次 showToast 时 isPresented 一直为 true，原生端不会刷新，
  // 旧 toast 会卡在屏幕上（表现为「一个类似卡住的通知」）。
  const [toastVisible, setToastVisible] = useState(false)
  const showToast = (msg: string, isError = false) => {
    setToast({ msg, isError })
    // 先关闭再打开，保证每次都有 false→true 边沿，避免连续 toast 时旧的卡住
    setToastVisible(false)
    setTimeout(() => setToastVisible(true), 40)
  }
  const toastProps = {
    isPresented: toastVisible,
    onChanged: (v: boolean) => {
      if (!v) setToastVisible(false)
    },
    content: (
      <HStack spacing={6} alignment="center">
        <Image
          systemName={toast.isError ? "exclamationmark.triangle.fill" : "checkmark.circle.fill"}
          foregroundStyle={toast.isError ? "systemRed" : "systemGreen"}
        />
        <Text font="body" foregroundStyle="white">
          {toast.msg}
        </Text>
      </HStack>
    ),
    // 强制深色背景：旧系统默认黑底白字，iOS 26 上默认背景变浅色，白字会看不清
    backgroundColor: "black" as const,
    textColor: "white" as const,
    position: "top" as const,
    duration: 2,
  }
  return { toast, showToast, toastProps }
}

function RowIcon({
  systemName,
  color = "tintColor",
  small = false,
  leftPad = 0,
  onTap,
}: {
  systemName: string
  color?: any
  small?: boolean
  leftPad?: number
  onTap?: () => void
}) {
  return (
    <Image
      systemName={systemName}
      foregroundStyle={color}
      imageScale={small ? "small" : undefined}
      padding={leftPad !== 0 ? { leading: leftPad } : undefined}
      contentShape={onTap ? { kind: "interaction", shape: "rect" } : undefined}
      onTapGesture={onTap}
    />
  )
}

function Chevron({ color = "tertiaryLabel" }: { color?: any }) {
  return <Image systemName="chevron.right" foregroundStyle={color} />
}

function EmptyState({ message }: { message: string }) {
  return (
    <VStack alignment="center" spacing={8} padding={{ vertical: 16 }}>
      <Image systemName="tray" foregroundStyle="secondaryLabel" />
      <Text foregroundStyle="secondaryLabel">{message}</Text>
    </VStack>
  )
}

/** 名称比较：拉丁字母/数字开头的排前面（A-Z），中文按拼音排序，大小写不敏感 */
function compareNames(a: string, b: string): number {
  const la = a.toLowerCase()
  const lb = b.toLowerCase()
  const aLatin = /^[a-z0-9]/.test(la)
  const bLatin = /^[a-z0-9]/.test(lb)
  if (aLatin !== bLatin) {
    return aLatin ? -1 : 1
  }
  return la.localeCompare(lb, "zh-Hans-CN") || a.localeCompare(b, "zh-Hans-CN")
}

/** 脚本排序比较：最新修改 / 最近使用 / 名称 A-Z / 名称 Z-A / 按分组（分组间与设置内排序反着来，同分组内按最近使用；无分组的排最后） / 按脚本作者（填了用户名则自己的脚本固定最前，其余按作者名 A-Z 分组） / 按运行次数（累计运行次数多的排前，次数相同按名称稳定排序），置顶排序在调用方处理 */
function compareScripts(
  a: ScriptInfo,
  b: ScriptInfo,
  mode: "modified" | "recent" | "name" | "name_desc" | "group" | "author" | "usage",
  recentMap?: Record<string, number>,
  authorName?: string,
  groupOrder?: string[],
  groupMap?: Map<string, string>,
  homeGroupOrder?: string[] | null,
  usageMap?: Record<string, number>
): number {
  if (mode === "group") {
    const groupA = groupMap?.get(a.folderName)
    const groupB = groupMap?.get(b.folderName)
    if (groupA !== groupB) {
      // 不在任何命名分组的脚本（默认分组）排最后
      if (!groupA) return 1
      if (!groupB) return -1
      // 首页分组筛选页设置了展示顺序（上方在前）时优先正序；未设置时沿用设置页 groupOrder 反序（如设置 1,2,3 → 显示 3,2,1）
      if (homeGroupOrder && homeGroupOrder.length > 0) {
        const ha = homeGroupOrder.indexOf(groupA)
        const hb = homeGroupOrder.indexOf(groupB)
        if (ha !== -1 && hb !== -1) return ha - hb
        if (ha !== -1) return -1
        if (hb !== -1) return 1
        return groupA.localeCompare(groupB, "zh-Hans-CN")
      }
      const ia = groupOrder ? groupOrder.indexOf(groupA) : -1
      const ib = groupOrder ? groupOrder.indexOf(groupB) : -1
      // 已配置顺序的分组按设置顺序反着排（如设置 1,2,3 → 显示 3,2,1）；未配置的分组按名称排在后面
      if (ia !== -1 && ib !== -1) return ib - ia
      if (ia !== -1) return -1
      if (ib !== -1) return 1
      return groupA.localeCompare(groupB, "zh-Hans-CN")
    }
    // 同一分组（含默认分组）内按最近使用倒序
    const ra = recentMap?.[a.folderName] ?? 0
    const rb = recentMap?.[b.folderName] ?? 0
    return rb - ra || b.modifiedAt - a.modifiedAt
  }
  if (mode === "author") {
    // 填了用户名时把自己的脚本固定排最前
    const selfA = Boolean(authorName && a.authorName === authorName)
    const selfB = Boolean(authorName && b.authorName === authorName)
    if (selfA !== selfB) return selfA ? -1 : 1
    // 其余脚本按作者名 A-Z 分组（无作者名的排最后），同作者组内按最近使用倒序
    const authorA = a.authorName || ""
    const authorB = b.authorName || ""
    if (authorA !== authorB) {
      if (!authorA) return 1
      if (!authorB) return -1
      return authorA.localeCompare(authorB, "zh-Hans-CN")
    }
    const ra = recentMap?.[a.folderName] ?? 0
    const rb = recentMap?.[b.folderName] ?? 0
    return rb - ra || b.modifiedAt - a.modifiedAt
  }
  if (mode === "recent") {
    const ra = recentMap?.[a.folderName] ?? 0
    const rb = recentMap?.[b.folderName] ?? 0
    return rb - ra || b.modifiedAt - a.modifiedAt
  }
  if (mode === "usage") {
    // 按最近 50 次运行记录中出现次数倒序；次数相同保持稳定顺序（按名称 A-Z，不按最近使用，避免点谁谁跳前）
    const ua = usageMap?.[a.folderName] ?? 0
    const ub = usageMap?.[b.folderName] ?? 0
    if (ua !== ub) return ub - ua
    // 次数相同（常见于都已被挤出最近 50 次窗口、次数均为 0）时：
    // 曾经被本工具运行过的脚本（recentUsedAt 有记录，持久保存不重置）排在从未运行过的脚本前面
    const everA = recentMap?.[a.folderName] != null ? 1 : 0
    const everB = recentMap?.[b.folderName] != null ? 1 : 0
    if (everA !== everB) return everB - everA
    return (
      compareNames(a.displayName, b.displayName) ||
      compareNames(a.folderName, b.folderName)
    )
  }
  if (mode === "name") {
    return (
      compareNames(a.displayName, b.displayName) ||
      compareNames(a.folderName, b.folderName)
    )
  }
  if (mode === "name_desc") {
    return (
      compareNames(b.displayName, a.displayName) ||
      compareNames(b.folderName, a.folderName)
    )
  }
  return b.modifiedAt - a.modifiedAt
}

/**
 * 关键字匹配：关键字需作为独立“词”出现（前后不能是字母/数字/下划线），
 * 避免搜 “tg” 误匹配到 “ChatGPT反代” 这类名字里嵌着子串的脚本。
 * 中文字符视为词边界，因此 “tg” 能匹配 “TG频道 / 我的tg / v2rayTG”。
 */
function keywordMatches(text: string, keyword: string): boolean {
  const kw = keyword.trim().toLowerCase()
  if (!kw) return true
  const escaped = kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
  return new RegExp(
    `(^|[^a-z0-9_])${escaped}|${escaped}([^a-z0-9_]|$)`,
    "i"
  ).test(text)
}

/** 生成 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]，urls 值为 URL 编码的 JSON 数组） */
function buildImportLinkFromUrl(url: string): string {
  const urls = JSON.stringify([url])
  return `https://scripting.fun/import_scripts?urls=${encodeURIComponent(urls)}`
}

/** 生成脚本的 Scripting 导入链接，无发布链接返回 null */
function buildScriptImportLink(script: ScriptInfo): string | null {
  const remote = getScriptRemoteResource(script)
  if (!remote?.url) {
    return null
  }
  return buildImportLinkFromUrl(remote.url)
}

/** 脚本是否已发布（script.json 里有远程链接） */
function hasPublishedLink(script: ScriptInfo): boolean {
  return getScriptRemoteResource(script)?.url != null
}

/** 脚本是否由本工具发布到本人 GitHub 仓库（remoteResource 为 raw.githubusercontent.com 的 .scripting 链接，且 owner 为当前发布账号） */
function isPublishedByTool(script: ScriptInfo): boolean {
  const url = getScriptRemoteResource(script)?.url
  if (!url || !url.startsWith("https://raw.githubusercontent.com/")) {
    return false
  }
  // 发布链接可能带时间戳参数（?t=...，用于穿透 raw CDN 缓存），判断时先去掉参数再看后缀
  const path = url.replace(/\?.*$/, "")
  if (!path.endsWith(".scripting")) {
    return false
  }
  const gh = resolvePublishGithubConfig(resolveGithubConfig())
  if (!gh.owner) {
    return false
  }
  return url.startsWith(`https://raw.githubusercontent.com/${gh.owner}/`)
}

/**
 * 脚本是否「云端与本地不同步」：由本工具发布过，且本地版本号与云端版本号不一致。
 * 云端版本优先取「从云端包实际下载读取的版本缓存」（cloudVersions，随安装/更新重新拉取，
 * 是真实云端版本），无云端缓存时回退到「上次发布时记录的版本」（publishedVersions，
 * 可能因后续通过云端安装/更新而过时）。两者都无则视为同步。
 */
function isCloudDesynced(
  script: ScriptInfo,
  publishedVersions: Record<string, string>,
  cloudVersions: Record<string, string>
): boolean {
  if (!isPublishedByTool(script)) {
    return false
  }
  const cloud =
    cloudVersions[script.folderName] ?? publishedVersions[script.folderName]
  return cloud != null && cloud !== (script.version ?? "")
}

/**
 * 版本号相同但本地内容与发布/云端不同（微调了内容未重新发布）：返回 true，
 * 首页显示橙色普通云（cloud.fill + systemOrange；版本号不对时显示橙色感叹号云，两者区分）。
 * 基线优先取「从云端包实际下载计算的指纹」（cloudFingerprints，真实云端内容），
 * 无云端缓存时回退到发布成功时记录的本地内容指纹（publishedFingerprints）。
 * 本地实时指纹在 refreshScripts 里预计算。
 */
function isCloudContentDesynced(
  script: ScriptInfo,
  publishedFingerprints: Record<string, string>,
  cloudFingerprints: Record<string, string>,
  localFingerprints: Record<string, string>
): boolean {
  const baseline =
    cloudFingerprints[script.folderName] ??
    publishedFingerprints[script.folderName]
  if (baseline == null) return false
  const local = localFingerprints[script.folderName]
  if (local == null) return false
  // 旧版本缓存里 script.json 参与过指纹（含 Scripting 安装时规范化重写导致的天然差异），
  // 现指纹已不含 script.json，比较时统一剥离该条目以兼容旧缓存。
  const strip = (fp: string) =>
    fp
      .split("\n")
      .filter((l) => l && !l.startsWith("script.json|"))
      .join("\n")
  return strip(local) !== strip(baseline)
}

/** 备份数据变更订阅：恢复页删除/重命名备份后，通知首页刷新备份计数 */
let backupChangeListeners: Array<() => void> = []
function subscribeBackupChange(fn: () => void): () => void {
  backupChangeListeners.push(fn)
  return () => {
    backupChangeListeners = backupChangeListeners.filter((f) => f !== fn)
  }
}
function notifyBackupChange() {
  backupChangeListeners.forEach((fn) => fn())
}

/** 脚本列表变更订阅：频道更新页在工具内部覆盖安装脚本成功后，通知首页重新扫描脚本列表 */
let scriptsChangeListeners: Array<() => void> = []
function subscribeScriptsChange(fn: () => void): () => void {
  scriptsChangeListeners.push(fn)
  return () => {
    scriptsChangeListeners = scriptsChangeListeners.filter((f) => f !== fn)
  }
}
function notifyScriptsChange() {
  scriptsChangeListeners.forEach((fn) => fn())
}

/** 去掉备份文件名尾缀（.scripting / .zip），仅用于确认提示等显示场景 */
function stripScriptExt(name: string): string {
  const lower = name.toLowerCase()
  if (lower.endsWith(".scripting")) return name.slice(0, -10)
  if (lower.endsWith(".zip")) return name.slice(0, -4)
  return name
}

/** 确认恢复单个脚本（存在同名时提示覆盖），供主页面与恢复页共用。
 *  恢复页传 allowRename 时额外提供「重命名并安装」；不传 cancelButton：与首页脚本名菜单一致，
 *  取消由系统独立显示在底部。返回 "restore" | "rename" | null */
async function confirmRestoreOne(
  candidate: CandidateScript,
  allowRename?: boolean
): Promise<"restore" | "rename" | null> {
  const exists = pathExists(
    Path.join(FileManager.scriptsDirectory, candidate.folderName)
  )
  // 提示里的名字去掉 .scripting / .zip 尾缀（folderName 来自解压目录名，单脚本备份会带尾缀）
  const display = stripScriptExt(candidate.folderName)
  const actions: { label: string; destructive?: boolean }[] = [
    { label: t("覆盖并恢复"), destructive: true },
  ]
  if (allowRename) {
    actions.push({ label: t("重命名并安装") })
  }
  const index = await Dialog.actionSheet({
    title: t("恢复脚本"),
    message: exists
      ? tpl("将恢复脚本「{name}」，目录中已存在同名脚本，恢复会覆盖当前版本。", { name: display })
      : tpl("将恢复脚本「{name}」到 Scripting 脚本目录。", { name: display }),
    // 不传 cancelButton：与首页脚本名菜单一致，取消由系统独立显示在底部
    actions,
  })
  if (index == null) {
    return null
  }
  return index === 0 ? "restore" : "rename"
}

/**
 * 恢复脚本后把恢复脚本的当前版本与内容指纹写入「自动备份升级项」基线，
 * 避免恢复被误判为脚本版本/内容变化而触发检测并再次自动备份。
 */
function markRestoredAsBaseline(scripts: CandidateScript[]) {
  try {
    const cfg = resolveConfig()
    if (!cfg.autoBackupOnUpgrade) return
    const record = { ...(cfg.scriptVersionRecord ?? {}) }
    const contentRecord = { ...(cfg.scriptContentRecord ?? {}) }
    let changed = false
    for (const c of scripts) {
      const v = c.version ?? ""
      if (record[c.folderName] !== v) {
        record[c.folderName] = v
        changed = true
      }
      // 恢复会用备份内容覆盖当前脚本，内容指纹一并写基线，避免触发内容变化自动备份
      try {
        const fp = scriptDirFingerprint(
          Path.join(FileManager.scriptsDirectory, c.folderName)
        )
        if (contentRecord[c.folderName] !== fp) {
          contentRecord[c.folderName] = fp
          changed = true
        }
      } catch {}
    }
    if (changed) {
      saveConfig({ ...cfg, scriptVersionRecord: record, scriptContentRecord: contentRecord })
    }
  } catch {
    // 基线写入失败不影响恢复结果
  }
}

// ==================== 主页面 ====================

export function MainPage() {
  const dismiss = Navigation.useDismiss()
  const [config, setConfigState] = useState<AppConfig>(resolveConfig)
  // 备份目的地分段当前按压中的段（模拟系统 segmented 按压反馈）
  const [pressedDestSeg, setPressedDestSeg] = useState<string | null>(null)
  const [selectedGroup, setSelectedGroup] = useState<GroupInfo | null>(null)
  const [selectedScripts, setSelectedScripts] = useState<ScriptInfo[]>([])
  const [busy, setBusy] = useState(false)
  // 当前忙碌操作类型：发布（Github发布）时显示「正在发布…」，其余显示「正在备份…」
  const [busyAction, setBusyAction] = useState<"backup" | "publish">("backup")
  const [backupVersion, setBackupVersion] = useState(0)
  const [backupCount, setBackupCount] = useState(0)
  // 订阅备份变更（恢复页删除/重命名备份后触发），返回主页时刷新「N 个备份」
  useEffect(() => {
    const unsub = subscribeBackupChange(() => setBackupVersion((v) => v + 1))
    return unsub
  }, [])
  // 订阅语言切换：语言变化时强制重渲染以刷新文案
  useEffect(() => {
    const unsub = subscribeLanguageChange(() => setBackupVersion((v) => v + 1))
    return unsub
  }, [])

  /**
   * 仓库监控循环：打开即查 + 按间隔定时检查 + 到点提醒通知 + 后台保活（尽力而为）。
   * 开启状态/间隔/链接变化时重建（关闭后清理定时器与提醒通知）。
   * 首次检查只建立基线不提示；之后检测到 .scripting 变化才发通知 + 弹提示。
   */
  async function runMonitorCycle(): Promise<ChannelCheckSummary | null> {
    const cfg = resolveConfig()
    if (!cfg.channelMonitorEnabled) return null
    const summary = await runChannelMonitorCheck()
    if (summary.newBaseline) {
      // 首次只记录基线，不打扰
      return summary
    }
    if (summary.totalChanges > 0) {
      // 同一批变化只弹一次：签名持久化到配置，跨实例/重启后仍能去重；
      // sha 参与签名，同一文件每次新发布（sha 变）会作为新一批变化正常提示
      const sig = channelChangesSignature(summary.results)
      // 重新读配置再比较：多个实例（首页常驻 + 新打开脚本）并发检查时，
      // 另一实例可能刚把同一批签名写入配置；用函数开头读到的旧配置判断会漏掉去重导致重复弹窗
      const freshCfg = resolveConfig()
      const alreadyNotified =
        sig !== "" &&
        (sig === freshCfg.channelMonitorNotifiedSig ||
          sig === lastAutoPresentSigRef.current)
      if (sig && !alreadyNotified) {
        updateChannelMonitorConfig({ channelMonitorNotifiedSig: sig })
        lastAutoPresentSigRef.current = sig
        // 记录「有更新」缓存（独立于 last-check，不会被后续无更新检查覆盖）：
        // 弹窗关闭后 5 分钟内长按首页右上角图标可再次打开更新页
        saveLastChannelUpdate(summary)
        notifyChannelChanges(summary.results)
        showToast(
          tpl("仓库监控：发现 {n} 个脚本有更新", {
            n: String(summary.totalChanges),
          })
        )
        // 应用内直接跳转更新页，无需点击通知
        setTimeout(() => {
          Navigation.present({
            element: <ChannelUpdatePage />,
            modalPresentationStyle: "overFullScreen",
          })
          removeDeliveredChannelUpdateNotifications()
        }, 350)
      }
    }
    return summary
  }

  /**
   * 长按首页右上角「立即监控」图标：最近一次检测到更新的 5 分钟内可再次打开更新页。
   * 更新弹窗按批次签名去重（同一批变化只自动弹一次），关闭后想再看就长按图标重新打开；
   * 读的是独立「有更新」缓存（弹窗/通知时才写入），不会被后续无更新的定时检查覆盖；
   * 超过 5 分钟或已「忽略」清空结果时提示重新检查。
   */
  async function reopenLastChannelUpdatePage() {
    const last = readLastChannelUpdate()
    if (
      last &&
      !last.summary.newBaseline &&
      last.summary.totalChanges > 0 &&
      Date.now() - last.checkedAt <= 5 * 60 * 1000
    ) {
      // 更新页的数据源是 last-check，而它可能已被后续无更新的定时检查覆盖成空；
      // 打开前把「有更新」结果写回 last-check，保证页面能显示这批可更新的脚本
      saveLastChannelCheck(last.summary)
      await Navigation.present({
        element: <ChannelUpdatePage />,
        modalPresentationStyle: "overFullScreen",
      })
      removeDeliveredChannelUpdateNotifications()
    } else {
      showToast(
        t("5 分钟内没有可再次打开的更新页，点击图标可重新检查"),
        true
      )
    }
  }

  useEffect(() => {
    const cfg = resolveConfig()
    if (!cfg.channelMonitorEnabled) return
    const seconds = Math.max(
      channelMonitorIntervalSeconds(
        cfg.channelMonitorInterval,
        cfg.channelMonitorIntervalUnit
      ),
      60
    )
    // 打开即查 + 定时循环：首查延迟到首屏渲染完成，之后按间隔循环（setTimeout 递归，避免依赖未暴露的 setInterval）
    let timer: ReturnType<typeof setTimeout> | null = null
    const loop = () => {
      runMonitorCycle()
      timer = setTimeout(loop, seconds * 1000)
    }
    const openTimer = setTimeout(loop, 1500)
    // 到点提醒通知：不再调度无条件重复的提醒（无更新时也会每间隔响一次，属噪音）。
    // 改为仅在检测到变化时由 notifyChannelChanges 发送「有更新」通知。
    // 这里仍清掉本脚本历史遗留的 pending 提醒，避免旧提醒继续按时弹出。
    Notification.removeAllPendingsOfCurrentScript().catch(() => {})
    // 同时清理通知中心里残留的已送达「有更新」通知，避免旧通知被误认为本次提示
    removeDeliveredChannelUpdateNotifications()
    // 后台保活：仅主应用环境可用；尽力而为，系统仍可能挂起
    if (Script.env === "index") {
      BackgroundKeeper.keepAlive()
    }
    return () => {
      clearTimeout(openTimer)
      if (timer != null) clearTimeout(timer)
      Notification.removeAllPendingsOfCurrentScript()
      if (Script.env === "index") {
        BackgroundKeeper.stopKeepAlive()
      }
    }
  }, [
    config.channelMonitorEnabled,
    config.channelMonitorInterval,
    config.channelMonitorIntervalUnit,
    config.channelMonitorLinks,
  ])

  /**
   * 仓库监控通知点击跳转：点「有更新」通知直接打开更新页；
   * 点「提醒」通知先补查一次，有变化才打开更新页。
   * 全新实例（脚本由点通知启动）走 Notification.current；应用已在运行时走 onResume。
   */
  useEffect(() => {
    async function handleNotificationTap(
      tid: "channel-monitor" | "channel-monitor-reminder" | null
    ) {
      if (!tid) return
      if (tid === "channel-monitor-reminder") {
        try {
          const summary = await runChannelMonitorCheck()
          if (summary.totalChanges === 0) {
            showToast(t("检查完成，没有发现更新"))
            return
          }
        } catch (error) {
          logError("仓库监控", error)
          showToast(
            error instanceof Error ? error.message : String(error),
            true
          )
          return
        }
      }
      const last = readLastChannelCheck()
      if (last && last.summary.totalChanges > 0) {
        // 防御：该批次已被「忽略全部」处理过（签名已持久化）或刚在应用内自动弹过页时不重复弹
        const sig = channelChangesSignature(last.summary.results)
        if (sig && sig === resolveConfig().channelMonitorNotifiedSig) {
          showToast(t("检查完成，没有发现更新"))
          return
        }
        // 记录「有更新」缓存：长按首页右上角图标可再次打开本次更新页
        saveLastChannelUpdate(last.summary)
        // 稍作延迟再 present：全新实例由通知启动时 MainPage 可能还在呈现动画中，
        // 立即嵌套 present 会导致导航栏/工具栏不渲染，延迟后再弹出更稳定
        setTimeout(() => {
          Navigation.present({
            element: <ChannelUpdatePage />,
            modalPresentationStyle: "overFullScreen",
          })
          removeDeliveredChannelUpdateNotifications()
        }, 350)
      } else {
        showToast(t("检查完成，没有发现更新"))
      }
    }
    const initial = channelNotificationThreadId(Notification.current)
    if (initial) {
      handleNotificationTap(initial)
      return
    }
    if (Script.env === "index") {
      return Script.onResume((event) => {
        handleNotificationTap(channelNotificationThreadId(event.notificationInfo))
      })
    }
  }, [])
  const [scriptCount, setScriptCount] = useState(0)
  const [scriptList, setScriptList] = useState<ScriptInfo[]>([])
  // 本地内容指纹（folderName → scriptContentFingerprint）：refreshScripts 预计算，用于「版本号没变但内容与发布不同」的小黄云标识
  const [localContentFingerprints, setLocalContentFingerprints] = useState<
    Record<string, string>
  >({})
  const [showBackupRestore, setShowBackupRestore] = useState(() => {
    const saved = resolveConfig()
    return saved.rememberExpandState ? saved.backupRestoreExpanded : true
  })
  const [searchText, setSearchText] = useState("")
  const [multiSelect, setMultiSelect] = useState<Set<string>>(new Set())
  // 一次性构建 脚本文件夹名 → 分组名 映射，复用已扫描的 scriptList，避免重复全量扫描（会非常卡）
  const groupNameMap = useMemo(() => buildGroupNameMap(scriptList), [scriptList])
  // 置顶脚本集合（文件夹名）
  const pinnedSet = useMemo(
    () => new Set(config.pinnedScripts),
    [config.pinnedScripts]
  )
  // 首页分组过滤选项：当前所有脚本所属分组 + 已定义的空分组（与设置页分组顺序编辑保持一致），供长按标题勾选；未分组脚本（key 为空串）固定在列表末尾（不可拖动），已设置展示顺序时命名分组按该顺序排列。每项带该分组内脚本个数（空分组为 0，与设置页分组顺序编辑一致）
  const groupFilterOptions = useMemo(() => {
    const countByName = new Map<string, number>()
    for (const s of scriptList) {
      const g = groupNameMap.get(s.folderName) ?? ""
      countByName.set(g, (countByName.get(g) ?? 0) + 1)
    }
    // 补充已定义但当前没有任何脚本的空分组，让首页分组列表与设置页分组顺序编辑显示的分组一致（count 为 0）
    const definedGroups = readScriptingGroups(scriptList)
    for (const g of definedGroups) {
      if (!countByName.has(g.name)) {
        countByName.set(g.name, 0)
      }
    }
    const hasUngrouped = countByName.has("")
    const names = new Set(countByName.keys())
    names.delete("")
    const toRows = (list: string[]) =>
      list.map((name) => ({ name, count: countByName.get(name) ?? 0 }))
    const order = config.homeGroupOrder
    if (order && order.length > 0) {
      const known = order.filter((g) => names.has(g))
      const rest = [...names]
        .filter((g) => !known.includes(g))
        .sort((a, b) => a.localeCompare(b, "zh"))
      return hasUngrouped
        ? toRows([...known, ...rest, ""])
        : toRows([...known, ...rest])
    }
    const sorted = [...names].sort((a, b) => a.localeCompare(b, "zh"))
    return hasUngrouped ? toRows([...sorted, ""]) : toRows(sorted)
  }, [scriptList, groupNameMap, config.homeGroupOrder])
  // 最近 50 次运行记录统计（folderName → 次数，持久保存在配置文件里，最新记录替换最旧记录），用于「按运行次数」排序
  const usageCountMap = useMemo(() => {
    const m: Record<string, number> = {}
    for (const f of config.recentRunLog) {
      if (f) {
        m[f] = (m[f] ?? 0) + 1
      }
    }
    return m
  }, [config.recentRunLog])
  // 按排序方式排序：置顶的脚本始终排在最上方（按置顶顺序，最后置顶的排最前），其余按「最新修改 / 名称 A-Z」排序
  const sortedScripts = useMemo(() => {
    const pinnedByOrder = config.pinnedScripts
      .map((folderName) =>
        scriptList.find((s) => s.folderName === folderName)
      )
      .filter((s): s is ScriptInfo => Boolean(s))
    const cmp = (a: ScriptInfo, b: ScriptInfo) =>
      compareScripts(
        a,
        b,
        config.scriptSort,
        config.recentUsedAt,
        config.authorName,
        config.groupOrder,
        groupNameMap,
        config.homeGroupOrder,
        usageCountMap
      )
    const rest = scriptList
      .filter((s) => !pinnedSet.has(s.folderName))
      .sort(cmp)
    return [...pinnedByOrder, ...rest]
  }, [scriptList, config.pinnedScripts, pinnedSet, config.scriptSort, config.authorName, config.groupOrder, config.homeGroupOrder, groupNameMap, config.recentRunLog, usageCountMap])
  // 搜索时按「关键字匹配 → 置顶 → 其他」三段展示；无关键字时直接展示排序后的列表。
  // 设置「搜索不隐藏其他脚本」（默认开启）时搜索仍显示全部；关闭则只显示匹配项。
  // 长按「脚本管理」标题勾选过分组时：仅显示勾选分组内的脚本（含未分组），置顶脚本始终显示。
  const visibleScripts = useMemo(() => {
    let base = sortedScripts
    if (config.homeGroupFilter != null) {
      const filterSet = new Set(config.homeGroupFilter)
      base = sortedScripts.filter(
        (s) =>
          pinnedSet.has(s.folderName) ||
          filterSet.has(groupNameMap.get(s.folderName) ?? "")
      )
    }
    const keyword = searchText.trim().toLowerCase()
    if (!keyword) {
      return base
    }
    // 匹配脚本名；勾选「搜索包含作者」时也匹配作者名
    const matchesSearch = (s: ScriptInfo) =>
      keywordMatches(s.displayName, keyword) ||
      (config.searchMatchAuthor && s.authorName
        ? keywordMatches(s.authorName, keyword)
        : false)
    const matched = base.filter(matchesSearch)
    if (!config.searchKeepAll) {
      return matched
    }
    const pinnedRest = base.filter(
      (s) => !matchesSearch(s) && pinnedSet.has(s.folderName)
    )
    const others = base.filter(
      (s) => !matchesSearch(s) && !pinnedSet.has(s.folderName)
    )
    return [...matched, ...pinnedRest, ...others]
  }, [sortedScripts, searchText, pinnedSet, config.searchKeepAll, config.searchMatchAuthor, config.homeGroupFilter, groupNameMap])
  const { showToast, toastProps } = useToast()
  // 滚动代理：点击搜索框时滚动到「脚本管理」Section 顶部，让标题行露出来、键盘不遮挡下方脚本名
  const scrollProxyRef = useRef<ScrollViewProxy | null>(null)
  function scrollSearchFieldToTop() {
    setTimeout(() => {
      withAnimation(() => {
        scrollProxyRef.current?.scrollTo("scripts-anchor", "top")
      })
    }, 300)
  }

  // 异步统计首页数量，避免首次渲染同步扫描（解压 zip / 读 script.json）卡住主线程
  function refreshScripts() {
    setTimeout(() => {
      setBackupCount(scanBackups(config.destination).length)
      const list = scanScripts()
      // 自动纠偏期望分组：Scripting 应用可能在内存缓存 settings.json 并整体写回覆盖移动结果
      enforceGroupMoveTargets(list)
      // 恢复「刚导入覆盖」脚本的分组：Scripting 导入覆盖后写回 settings.json 会把脚本
      // 从分组中丢失，用导入前快照把脚本重新加回原分组
      restoreImportedScriptGroups(list)
      setScriptCount(list.length)
      setScriptList(list)
      // 预计算每个已发布脚本的本地内容指纹，用于「版本号没变但内容与发布不同」的橙色普通云标识
      const fp: Record<string, string> = {}
      for (const s of list) {
        if (isPublishedByTool(s)) {
          fp[s.folderName] = scriptContentFingerprint(s.path)
        }
      }
      setLocalContentFingerprints(fp)
      checkAutoBackup(list)
      refreshCloudVersions(list)
    }, 50)
  }

  // 点击脚本行 / 点运行按钮时先做一次节流后的全量刷新（版本号 + 内容），
  // 让智能体刚改过的脚本在列表里立即显示新版本，自动备份也能基于最新内容。
  const lastTapRefreshRef = useRef(0)
  function refreshScriptsOnTap() {
    const now = Date.now()
    if (now - lastTapRefreshRef.current < 3000) return
    lastTapRefreshRef.current = now
    refreshScripts()
  }

  // 异步拉取脚本的云端版本与内容指纹（remoteResource 下载读取），
  // 用于显示「云端与本地不同步」标识、云端更新说明，以及小黄云的兜底基线；
  // 拉取结果缓存到 cloudVersions/cloudChangelogs/cloudFingerprints。
  // 除了「从未拉取/缺指纹基线」之外，当本地版本与云端缓存不一致时也会重新拉取确认
  //（例如用户从云端安装/更新了新版本后，缓存仍是旧版本），避免把「已与云端同步」
  // 误判为不同步；为避免「本地领先未发布」的脚本每次打开都重复下载，用 cloudCheckedAt 节流。
  const CLOUD_META_REFRESH_MS = 10 * 60 * 1000
  function refreshCloudVersions(list: ScriptInfo[]) {
    const cfg = resolveConfig()
    const now = Date.now()
    const checkedAt = cfg.cloudCheckedAt ?? {}
    const need = list.filter(
      (s) =>
        isPublishedByTool(s) &&
        (cfg.cloudVersions[s.folderName] == null ||
          (cfg.cloudVersions[s.folderName] !== s.version &&
            now - (checkedAt[s.folderName] ?? 0) > CLOUD_META_REFRESH_MS) ||
          (cfg.publishedFingerprints[s.folderName] == null &&
            cfg.cloudFingerprints[s.folderName] == null))
    )
    if (need.length === 0) return
    const patch: Record<string, string> = { ...cfg.cloudVersions }
    const changelogPatch: Record<string, string> = { ...cfg.cloudChangelogs }
    const fpPatch: Record<string, string> = { ...cfg.cloudFingerprints }
    const checkedAtPatch: Record<string, number> = { ...checkedAt }
    let changed = false
    let done = 0
    for (const s of need) {
      fetchScriptCloudMeta(s).then((meta) => {
        if (meta != null) {
          if (meta.version) {
            patch[s.folderName] = meta.version
            changed = true
          }
          if (meta.changelog) {
            changelogPatch[s.folderName] = meta.changelog
          }
          if (meta.fingerprint) {
            fpPatch[s.folderName] = meta.fingerprint
            changed = true
          }
        }
        // 无论成功与否都记录本次检查时间，避免每次都重试下载
        checkedAtPatch[s.folderName] = Date.now()
        done += 1
        if (done === need.length) {
          if (changed) {
            updateConfig({
              cloudVersions: patch,
              cloudChangelogs: changelogPatch,
              cloudFingerprints: fpPatch,
              cloudCheckedAt: checkedAtPatch,
            })
            setBackupVersion((x) => x + 1)
          } else if (
            Object.keys(changelogPatch).length > 0 ||
            Object.keys(checkedAtPatch).length > 0
          ) {
            updateConfig({
              cloudChangelogs: changelogPatch,
              cloudCheckedAt: checkedAtPatch,
            })
            setBackupVersion((x) => x + 1)
          }
        }
      })
    }
  }

  // 自动备份在途标记：一次备份完成前不重复触发。备份被跳过/失败时保留旧基线，下次扫描自动重试
  const autoBackupInflightRef = useRef(false)

  /** 智能体修改标记有效窗口：AI 维护流程标记脚本后的这段时间内，扫描视为“手动修改” */
  const AGENT_MODIFIED_WINDOW_MS = 5 * 60 * 1000
  /** 刚导入标记有效窗口：仓库监控更新页发起导入脚本后的这段时间内，同版本内容刷新视为“刚导入” */
  const IMPORTED_WINDOW_MS = 10 * 60 * 1000

  /**
   * 版本/内容变化自动备份：开启后扫描到脚本版本号变化、或内容被刷新但版本号未变时，
   * 自动把变化的脚本固定备份到 iPhone 端。
   * 仅当恰好一个脚本变化时才触发（对应“用户修改单个脚本”或“单个脚本内容更新”）；
   * 一次多个脚本同时变化（如批量自动更新）不触发自动备份，只吸收版本/内容基线。
   * manualFolder：由「手动改版本号」入口传入用户改的那个脚本，此时即使同时有其他脚本变化
   * （自动更新），也只备份该脚本并忽略其余变化。
   * agentModifiedAt 时间窗内的脚本同样视为手动修改（智能体维护流程改过版本号）。
   * 首次扫描只建立基线不备份。
   * 为避免备份到旧内容：检测到变化后先等脚本内容稳定（连续两次目录指纹一致）再打包，
   * 期间版本又被修改则放弃本次，下一次扫描会按新基线重新触发。
   * 注意：版本基线（scriptVersionRecord）与内容基线（scriptContentRecord）只在备份成功后
   * 才写入，若备份被跳过或失败，旧基线会保留，下次扫描仍能检测到变化并自动重试，
   * 不会出现「记录已更新但没备份」的漏备。
   */
  function checkAutoBackup(list: ScriptInfo[], manualFolder?: string) {
    const cfg = resolveConfig()
    if (!cfg.autoBackupOnUpgrade) return
    if (autoBackupInflightRef.current) return
    const record = cfg.scriptVersionRecord ?? {}
    const contentRecord = cfg.scriptContentRecord ?? {}
    const now = Date.now()
    // 计算每个脚本当前内容指纹（内容更新但版本号未变也能检测到）
    const fpOf = new Map<string, string>()
    for (const s of list) {
      try {
        fpOf.set(s.folderName, scriptDirFingerprint(s.path))
      } catch {}
    }
    // 刚导入标记：仓库监控更新页发起导入的脚本，窗口内视为“刚导入”
    const importedRecently = new Set(
      Object.entries(cfg.channelImportedAt ?? {})
        .filter(([, at]) => now - at <= IMPORTED_WINDOW_MS)
        .map(([name]) => name)
    )
    const changed = list.filter((s) => {
      const versionChanged =
        record[s.folderName] != null &&
        record[s.folderName] !== (s.version ?? "")
      if (versionChanged) return true
      const fp = fpOf.get(s.folderName)
      if (fp == null) return false
      const baseFp = contentRecord[s.folderName]
      if (baseFp == null || baseFp === fp) return false
      // 内容变化但版本号未变：刚导入且版本号与本地一致（同版本内容刷新）→ 不触发自动备份，只吸收基线
      if (importedRecently.has(s.folderName)) return false
      return true
    })
    // 智能体修改标记：最近窗口内被标记的脚本视为手动修改
    const agentMarked = new Set(
      Object.entries(cfg.agentModifiedAt ?? {})
        .filter(([, at]) => now - at <= AGENT_MODIFIED_WINDOW_MS)
        .map(([name]) => name)
    )
    // 手动改版本号触发：只备份手动改的那个脚本，其余变化（自动更新）忽略；
    // 无 manualFolder 但有智能体标记时，备份标记脚本；都无则备份全部变化脚本。
    const targets = changed.filter(
      (s) =>
        manualFolder != null
          ? s.folderName === manualFolder
          : agentMarked.size > 0
            ? agentMarked.has(s.folderName)
            : true
    )
    if (targets.length === 0) {
      // 无待备份脚本：把新出现（尚无基线）/内容基线缺失的脚本补记基线；
      // 刚导入的同版本内容刷新（窗口内、版本未变但内容已变）也吸收进基线，避免下次扫描重复判定
      const recordChanged = list.some((s) => {
        if (record[s.folderName] !== (s.version ?? "")) return true
        if (contentRecord[s.folderName] == null) return true
        if (!importedRecently.has(s.folderName)) return false
        const fp = fpOf.get(s.folderName)
        if (fp == null) return false
        return contentRecord[s.folderName] !== fp
      })
      if (recordChanged) {
        const next: Record<string, string> = {}
        const nextContent: Record<string, string> = {}
        for (const s of list) {
          next[s.folderName] = s.version ?? ""
          const fp = fpOf.get(s.folderName)
          if (fp != null) nextContent[s.folderName] = fp
        }
        updateConfig({ scriptVersionRecord: next, scriptContentRecord: nextContent })
      }
      return
    }
    // 扫描触发、无任何手动来源（既非手动改版本号也无智能体标记）且一次多个脚本版本/内容变化
    // （如批量自动更新）：不触发自动备份，只吸收基线，避免误备份
    if (manualFolder == null && agentMarked.size === 0 && changed.length > 1) {
      const next: Record<string, string> = {}
      const nextContent: Record<string, string> = {}
      for (const s of list) {
        next[s.folderName] = s.version ?? ""
        const fp = fpOf.get(s.folderName)
        if (fp != null) nextContent[s.folderName] = fp
      }
      updateConfig({ scriptVersionRecord: next, scriptContentRecord: nextContent })
      return
    }
    const next: Record<string, string> = {}
    const nextContent: Record<string, string> = {}
    for (const s of list) {
      next[s.folderName] = s.version ?? ""
      const fp = fpOf.get(s.folderName)
      if (fp != null) nextContent[s.folderName] = fp
    }
    const expected: Record<string, string> = {}
    for (const s of targets) {
      expected[s.folderName] = s.version ?? ""
    }
    showToast(tpl("检测到 {n} 个脚本变化，正在刷新内容…", { n: String(targets.length) }))
    autoBackupInflightRef.current = true
    setTimeout(async () => {
      try {
        // 先等待内容稳定（刷新完成）再备份，避免备份到旧内容
        const stable = await waitForStableScripts(targets, expected)
        if (stable == null || stable.length === 0) {
          return
        }
        // 固定备份到 iPhone 端（不跟随当前选择组，也不弹窗询问名称）
        const zipName =
          stable.length === 1
            ? `${stable[0].displayName}_${stable[0].version}`
            : tpl("自动备份_{stamp}", { stamp: timestampForName() })
        await backupScripts(stable, "iphone", zipName)
        // 备份成功后才更新版本/内容基线（changed 对应脚本写入新版本与最新内容指纹，
        // 其余脚本保留原记录），并清除已处理的智能体修改标记；
        // 等待期间内容可能又变化，稳定脚本的内容指纹重新计算，避免写入旧指纹导致下次重复备份
        const consumed = new Set(targets.map((s) => s.folderName))
        const agentLeft: Record<string, number> = {}
        for (const [name, at] of Object.entries(cfg.agentModifiedAt ?? {})) {
          if (!consumed.has(name)) agentLeft[name] = at
        }
        for (const s of stable) {
          try {
            nextContent[s.folderName] = scriptDirFingerprint(s.path)
          } catch {}
        }
        updateConfig({ scriptVersionRecord: next, scriptContentRecord: nextContent, agentModifiedAt: agentLeft })
        showToast(tpl("已自动备份 {n} 个脚本到 iPhone", { n: String(stable.length) }))
        setBackupVersion((v) => v + 1)
      } catch (error) {
        logError("自动备份", error)
        showToast(error instanceof Error ? error.message : String(error), true)
      } finally {
        autoBackupInflightRef.current = false
      }
    }, 100)
  }
  useEffect(() => {
    refreshScripts()
  }, [config.destination, backupVersion])
  // 主页标签（home_screen_default_ui）常驻内存，切走再切回不会重建，更新后的内容（如版本号）不会自动出现。
  // 监听 Home tab 事件：切回主页（selected）或再点主页（reselected）时重新扫描，自动更新变化的内容。
  const refreshScriptsRef = useRef(refreshScripts)
  refreshScriptsRef.current = refreshScripts
  useEffect(() => {
    if (Script.env !== "home_screen") return
    return Script.onHomeTabEvent((event) => {
      if (event === "selected" || event === "reselected") {
        refreshScriptsRef.current()
      }
    })
  }, [])
  // 从脚本编辑页（点击脚本行左侧图标用 scripting://open 打开）返回时刷新列表：
  // 编辑会改变本地脚本内容/指纹，已发布脚本的「内容一致」绿勾应更新为「内容不同步」的小黄云。
  // 与主页标签刷新共用 refreshScriptsRef，onResume 在实例存活时返回（含最小化后恢复）都会触发。
  useEffect(() => {
    const remove = Script.onResume(() => {
      refreshScriptsRef.current()
    })
    return remove
  }, [])
  // 脚本列表变更订阅：频道更新页在工具内部覆盖安装脚本后（不经过 Scripting 导入，
  // 返回主页不会触发 onResume/HomeTab 刷新），主动重新扫描脚本列表让用户看到更新结果
  useEffect(() => {
    const unsub = subscribeScriptsChange(() => refreshScriptsRef.current())
    return unsub
  }, [])

  /** 点击运行脚本（调用 Script.run 运行目标脚本，singleMode 终止其他实例） */
  function runScript(script: ScriptInfo) {
    // 以磁盘最新配置为基准记录（避免内存闭包过期导致连续运行丢记录）
    const latest = resolveConfig()
    // 记录最近使用时间（用于「按最近使用」排序）
    updateConfig({
      recentUsedAt: {
        ...latest.recentUsedAt,
        [script.folderName]: Date.now(),
      },
      // 记录最近 50 次运行（持久保存在配置里，最新在前，超出后丢弃最旧记录），用于「按运行次数」排序
      recentRunLog: [script.folderName, ...latest.recentRunLog].slice(0, 50),
    })
    // 运行前先节流刷新一次，确保列表版本号与自动备份基于最新内容
    refreshScriptsOnTap()
    Script.run({
      name: script.folderName,
      singleMode: true,
    }).catch(() => {})
  }

  /** 点击脚本图标：用 scripting://open URL scheme 在编辑器中打开该脚本（Safari.openURL 支持任意自定义 scheme，系统会交给 Scripting 处理） */
  function openScriptInEditor(script: ScriptInfo) {
    // 打开前记录目录轻量指纹（各文件 size|mtime）。从编辑页返回不一定会触发 onResume，
    // 所以打开后轮询检测：编辑保存后指纹变化即刷新首页，已发布脚本的「内容一致」绿勾
    // 会更新为「内容不同步」的小黄云；若实例被系统终止，用户重新打开脚本时入口也会全量刷新。
    const beforeFp = scriptDirFingerprint(script.path)
    Safari.openURL(Script.createOpenURLScheme(script.folderName)).catch(() => {})
    let elapsed = 0
    const poll = () => {
      elapsed += 1000
      let changed = false
      try {
        changed = scriptDirFingerprint(script.path) !== beforeFp
      } catch {}
      if (changed) {
        refreshScripts()
      } else if (elapsed < 20000) {
        setTimeout(poll, 1000)
      }
    }
    setTimeout(poll, 1000)
  }

  /** 置顶 / 取消置顶脚本（保存在配置里，置顶脚本排在列表最上方，最后置顶的排在最前） */
  function togglePin(script: ScriptInfo) {
    const wasPinned = config.pinnedScripts.includes(script.folderName)
    // 记录最近一次置顶时间：置顶触发列表重排/重渲染，紧接着的点击可能丢失一拍或落错行，
    // 短时间内的单击不再弹菜单（连续置顶多个脚本时避免误弹）
    lastPinAtRef.current = Date.now()
    updateConfig({
      pinnedScripts: wasPinned
        ? config.pinnedScripts.filter((f) => f !== script.folderName)
        : [script.folderName, ...config.pinnedScripts],
    })
    showToast(wasPinned ? t("已取消置顶") : t("已置顶"))
  }

  /** 已置顶脚本再次置顶：移到所有置顶项目的最上方（双击置顶图标触发） */
  function rePinToTop(script: ScriptInfo) {
    const rest = config.pinnedScripts.filter((f) => f !== script.folderName)
    // 与 togglePin 一致：重排列表后同一位置紧接着的点击可能落错行，记录置顶时间避免误弹菜单
    lastPinAtRef.current = Date.now()
    updateConfig({ pinnedScripts: [script.folderName, ...rest] })
    showToast(t("已置顶到最上方"))
  }

  // ---- 置顶顺序拖动排序：按住尾部置顶图标上下拖动，被拖行浮动跟随手指并“拎起”，其余置顶行实时让位（仿系统 onMove 动效），松手一次性重排保存 ----
  // 拖动期间列表不真正重排（避免重排导致正在进行的拖动手势中断、每次只能换一位），被拖行浮动 + 其他行让位都是视觉反馈；松手时一次把脚本移到目标位置
  const PIN_ROW_HEIGHT = 56 // 首页脚本行高近似值（pt），用于把拖动位移换算成目标格数
  // 拖动排序状态：folder=被拖脚本，startIndex=起始置顶索引，targetIndex=当前目标置顶索引，offsetY=被拖行浮动偏移（跟随手指）
  const [pinDrag, setPinDrag] = useState<{
    folder: string
    startIndex: number
    targetIndex: number
    offsetY: number
  } | null>(null)
  // 拖动状态镜像（onChanged 高频更新，用 ref 保证 finish 能拿到最新值）
  const pinDragRef = useRef<{
    folder: string
    startIndex: number
    targetIndex: number
    offsetY: number
  } | null>(null)

  /** 拖动过程中实时计算目标置顶位置：手指跨过约半行高度移动一格；每次只允许跨越一格，快速拖动时也一个个划过去，同一时刻只有被拖行与相邻一行在让位（仿系统 onMove 相邻交换），可一次拖到任意位置 */
  function updatePinReorder(
    script: ScriptInfo,
    d: { translation: { height: number } }
  ) {
    if (multiSelect.size > 0) return
    const idx = config.pinnedScripts.indexOf(script.folderName)
    if (idx < 0) return
    const cur = pinDragRef.current
    const startIndex =
      cur?.folder === script.folderName ? cur.startIndex : idx
    const len = config.pinnedScripts.length
    const wantedDelta = Math.round(d.translation.height / PIN_ROW_HEIGHT)
    // 目标格数每次最多相对当前目标前进/后退 1 格：避免快速拖动时多行同时跳动，让“划过去”更自然
    let delta = wantedDelta
    if (cur && cur.folder === script.folderName) {
      const curDelta = cur.targetIndex - cur.startIndex
      if (Math.abs(wantedDelta - curDelta) > 1) {
        delta = curDelta + Math.sign(wantedDelta - curDelta)
      }
    }
    const targetIndex = Math.min(Math.max(startIndex + delta, 0), len - 1)
    const offsetY = d.translation.height
    if (
      cur &&
      cur.folder === script.folderName &&
      cur.startIndex === startIndex &&
      cur.targetIndex === targetIndex &&
      cur.offsetY === offsetY
    ) {
      return
    }
    const next = { folder: script.folderName, startIndex, targetIndex, offsetY }
    pinDragRef.current = next
    setPinDrag(next)
    lastPinAtRef.current = Date.now()
  }

  /** 结束拖动：清空状态；目标位置变了才一次性重排并写盘保存 */
  function finishPinReorder() {
    const st = pinDragRef.current
    pinDragRef.current = null
    setPinDrag(null)
    if (!st) return
    if (st.targetIndex !== st.startIndex) {
      const order = [...resolveConfig().pinnedScripts]
      order.splice(order.indexOf(st.folder), 1)
      order.splice(st.targetIndex, 0, st.folder)
      saveConfig({ ...resolveConfig(), pinnedScripts: order })
      setConfigState((prev) => ({ ...prev, pinnedScripts: order }))
      showToast(t("已调整置顶顺序"))
    }
  }

  // 单击行：先等 300ms（双击判定窗口，快速连点即置顶/取消置顶），未成双击再弹出行菜单，
  // 减少单击菜单的等待感；菜单刚弹出（800ms 内）又被点掉时，把这次点击当作双击，只置顶，不再连弹两个菜单。
  const lastTapTimeRef = useRef(0)
  // 最近一次置顶时间：置顶会重排列表（该位置的脚本会换），同一位置连点置顶多个脚本时，
  // 1.5s 内的单击只记录双击基准、不弹菜单（防连续置顶时误弹）；停止点击 1.5s 后单击恢复正常弹菜单
  const lastPinAtRef = useRef(0)
  const tapMenuTimerRef = useRef(0)
  const menuShownAtRef = useRef(0)
  const menuScriptRef = useRef("")
  // 菜单弹出序号：弹菜单前置位；期间发生双击/新菜单时递增，使旧的（可能还在打包取大小的）菜单不再弹出
  const menuGenRef = useRef(0)
  // 发布页打开序号：每次打开更新说明编辑页时递增并作为 key，强制重建页面，
  // 保证「自动检测更新」「作者更新提示」两个开关每次重新打开都恢复默认勾选状态（不记忆上次选择）
  const publishEditorGenRef = useRef(0)
  // 菜单真正弹出（actionSheet 展示）的时间：1.2s 内禁止再弹，防止双击/连点/重渲染重复弹两个菜单
  const lastMenuPresentedAtRef = useRef(0)
  // 仓库监控：最近一次自动弹出更新页的变化签名（同一批变化只弹一次，避免定时循环反复打扰）。
  // 初始值取持久化的已提示签名，实例重启后同一批变化也不会重复弹
  const lastAutoPresentSigRef = useRef(
    resolveConfig().channelMonitorNotifiedSig ?? ""
  )
  function handleScriptTap(script: ScriptInfo) {
    if (multiSelect.size > 0) {
      toggleMultiSelect(script)
      return
    }
    // 点击（含置顶脚本）时先节流刷新一次：版本号与脚本内容重新从磁盘读取，再弹菜单；
    // 若开了自动备份，刷新完成后才会基于最新内容备份
    refreshScriptsOnTap()
    const now = Date.now()
    // ① 窗口内第二次点击 → 双击：取消待弹菜单，置顶/取消置顶（同一位置连点置顶时两击间隔可能略长，用 800ms）
    if (now - lastTapTimeRef.current < 800) {
      if (tapMenuTimerRef.current) {
        clearTimeout(tapMenuTimerRef.current)
        tapMenuTimerRef.current = 0
      }
      lastTapTimeRef.current = 0
      menuGenRef.current += 1
      togglePin(script)
      return
    }
    // ② 菜单刚弹出又被点掉（第二次点击落在菜单展示动画期间，底层行仍可点）：
    // 同一行的这次点击按双击处理，避免再弹一个菜单
    if (
      script.folderName === menuScriptRef.current &&
      now - menuShownAtRef.current < 800
    ) {
      lastTapTimeRef.current = 0
      menuGenRef.current += 1
      togglePin(script)
      return
    }
    // ③ 刚置顶过（1.5s 内）：置顶会触发列表重排/重渲染，同一位置连点置顶多个脚本时，
    // 每次重排后该位置的脚本都换了，单击不应弹菜单（避免误弹）；只记录双击基准，下一次 500ms 内点击仍可双击置顶
    if (now - lastPinAtRef.current < 1500) {
      lastTapTimeRef.current = now
      return
    }
    lastTapTimeRef.current = now
    tapMenuTimerRef.current = setTimeout(() => {
      tapMenuTimerRef.current = 0
      lastTapTimeRef.current = 0
      showScriptMenu(script)
    }, 300)
  }

  /** 脚本菜单「改作者名」：设置页填了用户名就显示该按钮（用户名是否已是作者都显示，点开后自行判断）。
   *  用户名=WWWeng🐝：无作者直接填入；有作者且自己不是作者时弹「清空作者名 / 覆盖作者名 / 填入贡献者」三选一；
   *  自己已是作者时不显示「覆盖作者名」（覆盖自己没意义），保留清空与贡献者操作。
   *  其他用户名：无作者直接填入（成为作者）；有作者弹「填入贡献者」确认（保留原作者），
   *  自己已是作者时提示并返回（不弹窗）。若自己已在贡献者中则只显示「移除贡献者」。 */
  async function fillScriptAuthor(script: ScriptInfo) {
    const name = (config.authorName || "").trim()
    if (!name) {
      return
    }
    try {
      const fresh = scriptInfoFromDir(script.path) ?? script
      const old = fresh.authorName
      let done: string | null = null
      let toastName = name
      if (name === "WWWeng🐝") {
        if (old) {
          const contribs = readScriptContributors(fresh.path)
          const isContributor = contribs.includes(name)
          const isSelfAuthor = old === name
          const actions: Array<{ label: string; destructive?: boolean }> = [
            { label: t("清空作者名"), destructive: true },
          ]
          if (!isSelfAuthor) {
            actions.push({ label: t("覆盖作者名"), destructive: true })
          }
          actions.push({ label: t("手写作者名") })
          if (isContributor) {
            actions.push({ label: t("移除贡献者") })
          } else if (!isSelfAuthor) {
            actions.push({ label: t("填入贡献者") })
          }
          const index = await Dialog.actionSheet({
            title: t("改作者名"),
            message: tpl(
              isSelfAuthor
                ? isContributor
                  ? "当前作者就是你（{name}），且你已在贡献者中。选择「清空作者名」删除作者；「移除贡献者」把自己从贡献者移除。"
                  : "当前作者就是你（{name}）。选择「清空作者名」删除作者。"
                : isContributor
                  ? "当前作者为「{old}」，你已在贡献者中。选择「清空作者名」删除作者；「覆盖作者名」替换为「{name}」；「移除贡献者」把自己从贡献者移除。"
                  : "当前作者为「{old}」。选择「清空作者名」删除作者；「覆盖作者名」替换为「{name}」；「填入贡献者」保留原作者，把「{name}」记为贡献者。",
              { old, name }
            ),
            actions,
          })
          if (index === 0) {
            clearScriptAuthor(script)
            const list = scanScripts()
            setScriptList(list)
            setScriptCount(list.length)
            showToast(t("已清空作者名"))
            return
          } else if (!isSelfAuthor && index === 1) {
            setScriptAuthorName(script, name)
            done = t("已覆盖作者名")
          } else if (index === (isSelfAuthor ? 1 : 2)) {
            // 手写作者名：弹出输入框，手动输入任意作者名
            const typed = await inputPrompt({
              title: t("手写作者名"),
              message: t("输入新的作者名"),
              defaultValue: old,
            })
            if (typed == null || !typed.trim()) {
              return
            }
            setScriptAuthorName(script, typed.trim())
            done = t("已覆盖作者名")
            toastName = typed.trim()
          } else if (index === (isSelfAuthor ? 2 : 3)) {
            if (isContributor) {
              removeScriptContributor(script, name)
              done = t("已移除贡献者")
            } else {
              setScriptCoAuthor(script, name)
              done = t("已填入贡献者")
            }
          } else {
            return
          }
        } else {
          // 无作者：弹「手写作者名 / 填入用户名」两个选项
          const pick = await Dialog.actionSheet({
            title: t("改作者名"),
            message: tpl(
              "该脚本还没有作者名。可「手写作者名」输入任意作者名，或「填入用户名」把「{name}」填为作者名。",
              { name }
            ),
            actions: [
              { label: t("手写作者名") },
              { label: t("填入用户名") },
            ],
          })
          if (pick === 0) {
            const typed = await inputPrompt({
              title: t("手写作者名"),
              message: t("输入新的作者名"),
            })
            if (typed == null || !typed.trim()) {
              return
            }
            setScriptAuthorName(script, typed.trim())
            done = t("已覆盖作者名")
            toastName = typed.trim()
          } else if (pick === 1) {
            setScriptAuthorName(script, name)
            done = t("已填入作者")
          } else {
            return
          }
        }
      } else {
        if (old) {
          const contribs = readScriptContributors(fresh.path)
          const isContributor = contribs.includes(name)
          const actions: Array<{ label: string; destructive?: boolean }> = []
          if (isContributor) {
            actions.push({ label: t("移除贡献者") })
          } else if (old !== name) {
            actions.push({ label: t("填入贡献者") })
          }
          if (actions.length === 0) {
            // 自己就是作者且不在贡献者中：没有可操作项，直接提示
            showToast(t("你已是该脚本作者"))
            return
          }
          const index = await Dialog.actionSheet({
            title: t("填入贡献者"),
            message: tpl(
              isContributor
                ? "当前作者为「{old}」，你已在贡献者中。「移除贡献者」把自己从贡献者移除。"
                : "当前作者为「{old}」。将把「{name}」记为贡献者，原作者保持不变。",
              { old, name }
            ),
            actions,
          })
          if (index == null) {
            return
          }
          if (isContributor) {
            if (index === 0) {
              removeScriptContributor(script, name)
              done = t("已移除贡献者")
            } else {
              return
            }
          } else {
            if (index !== 0) {
              return
            }
            setScriptCoAuthor(script, name)
            done = t("已填入贡献者")
          }
        } else {
          setScriptAuthorName(script, name)
          done = t("已填入作者")
        }
      }
      const list = scanScripts()
      setScriptList(list)
      setScriptCount(list.length)
      showToast(tpl("{done} {name}", { done: done ?? "", name: toastName }))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 关闭脚本自动更新（保留云端链接，仅移除自动更新间隔；之后可重新开启） */
  async function closeScriptAutoUpdate(script: ScriptInfo) {
    try {
      disableScriptAutoUpdate(script)
      const list = scanScripts()
      setScriptList(list)
      setScriptCount(list.length)
      showToast(t("已关闭自动更新，保留更新链接"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 脚本行菜单：重命名 / 移动分组 / 分享文件 / 修改版本号 / 删除（分享链接、备份、发布按设置与云端链接显示） */
  async function showScriptMenu(script: ScriptInfo) {
    // 全局防连弹：1.2s 内刚弹过菜单（无论哪个脚本）就不再弹，双击/连点/重渲染重复排的定时器在此拦截
    if (Date.now() - lastMenuPresentedAtRef.current < 1200) {
      return
    }
    // 记录菜单展示时间与脚本，供 handleScriptTap 判断“菜单刚弹出又被点掉”的情况（避免连弹两个菜单）；
    // 弹菜单前可能先打包取大小（await），期间发生双击/新菜单会递增 menuGenRef，此处据此放弃弹出
    const gen = ++menuGenRef.current
    menuShownAtRef.current = Date.now()
    menuScriptRef.current = script.folderName
    // 弹菜单前重新读取最新信息（版本号/时间/大小），智能体改过的脚本立即显示新版本
    const fresh = scriptInfoFromDir(script.path) ?? script
    // 大小显示与备份/分享产物（.scripting 压缩包）保持一致：打包取真实大小；
    // 打包属于磁盘 IO，弹菜单前最多等 150ms，超时先按内容大小展示（zipSize 为 null 时回退 byteSize），保证菜单尽快弹出
    const zipSize = await Promise.race([
      scriptZipSize(fresh),
      sleep(150).then(() => null),
    ])
    if (menuGenRef.current !== gen) {
      return
    }
    const group = groupNameMap.get(fresh.folderName) ?? null
    const actions: Array<{ label: string; destructive?: boolean }> = [
      { label: t("删除"), destructive: true },
      { label: t("改版本号") },
      { label: t("移动分组") },
      { label: t("重新命名") },
    ]
    const handlers: Array<() => void | Promise<void>> = [
      () => deleteOneScript(fresh),
      () => changeVersionWithPrompt(fresh),
      () => moveScriptGroupWithPrompt(fresh),
      () => renameScriptWithPrompt(fresh),
    ]
    // 设置页填了用户名时提供「改作者名」：用户名=WWWeng🐝 弹三选一（清空/覆盖/贡献者），
    // 其他用户名有作者时弹「填入贡献者」；用户名是否已是作者都显示，点开后自行判断；插到「删除」下方（索引 1）
    const menuAuthorName = (config.authorName || "").trim()
    if (menuAuthorName) {
      actions.splice(1, 0, { label: t("改作者名") })
      handlers.splice(1, 0, () => fillScriptAuthor(fresh))
    }
    // 有云端链接且当前开启了自动更新时，提供「关闭更新」（紧挨删除下方）：保留链接、仅移除自动更新间隔
    const remote = getScriptRemoteResource(fresh)
    if (remote?.url && remote.autoUpdateInterval != null) {
      actions.splice(1, 0, { label: t("关闭更新") })
      handlers.splice(1, 0, () => closeScriptAutoUpdate(fresh))
    }
    // 分享文件：始终显示（无云端链接时同样叫「分享文件」），放在重新命名下方、脚本发布上方
    actions.push({ label: t("分享文件") })
    handlers.push(() => shareOneScript(fresh))
    // 有云端更新链接时提供「分享链接」，在分享文件下方、脚本发布上方
    if (config.githubPublishEnabled && hasPublishedLink(fresh)) {
      actions.push({ label: t("分享链接") })
      handlers.push(() => copyScriptShareLink(fresh))
    }
    // 一键发布（含更新说明填写入口）放在分享下方、脚本备份上方
    if (config.githubPublishEnabled) {
      actions.push({ label: t("脚本发布") })
      handlers.push(() => startGithubPublish([fresh]))
    }
    if (config.githubBackupEnabled) {
      actions.push({ label: t("脚本备份") })
      handlers.push(() => backupScriptsFromMenu([fresh]))
    }

    // 菜单即将弹出：记录展示时间，供防连弹闸门使用（在 await 之前设置，弹出的瞬间即生效）
    lastMenuPresentedAtRef.current = Date.now()
    const index = await Dialog.actionSheet({
      title: fresh.displayName,
      message: tpl("版本 {v} · {date} · {size} · 分组 {group}", { v: fresh.version, date: formatDate(fresh.modifiedAt), size: formatBytes(zipSize ?? fresh.byteSize), group: group ?? t("未分组") }),
      actions,
    })
    if (index == null) {
      return
    }
    await handlers[index]()
  }

  /** 长按进入多选并勾选/取消脚本 */
  function toggleMultiSelect(script: ScriptInfo) {
    setMultiSelect((prev) => {
      const next = new Set(prev)
      if (next.has(script.folderName)) {
        next.delete(script.folderName)
      } else {
        next.add(script.folderName)
      }
      return next
    })
  }

  /** 分享当前勾选的脚本 */
  async function shareSelected() {
    if (multiSelect.size === 0) {
      showToast(t("请先勾选脚本"), true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    try {
      await shareScripts(scripts)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 删除当前勾选的脚本 */
  async function deleteSelected() {
    if (multiSelect.size === 0) {
      showToast(t("请先勾选脚本"), true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    const index = await Dialog.actionSheet({
      title: t("删除确认"),
      message: tpl("确定删除 {n} 个脚本？此操作不可恢复。", { n: String(scripts.length) }),
      actions: [{ label: t("删除"), destructive: true }],
    })
    if (index !== 0) {
      return
    }
    try {
      for (const script of scripts) {
        deleteScript(script)
      }
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      setMultiSelect(new Set())
      showToast(t("已删除"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 移动当前勾选的脚本到指定分组 */
  async function moveSelectedToGroup() {
    if (multiSelect.size === 0) {
      showToast(t("请先勾选脚本"), true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast(t("没有可移动的分组"), true)
      return
    }
    const ordered = orderGroupsForMove(named, config.groupOrder)
    const index = await Dialog.actionSheet({
      title: t("移动到分组"),
      message: tpl("把勾选的 {n} 个脚本移动到哪个分组？", { n: String(scripts.length) }),
      // 不传 cancelButton：与首页脚本名菜单一致，取消由系统独立显示在底部
      actions: ordered.map((g) => ({ label: g.name })),
    })
    if (index == null) {
      return
    }
    const target = ordered[index]
    try {
      let moved = 0
      for (const script of scripts) {
        try {
          moveScriptToGroup(script, target.name)
          moved++
        } catch {
          // 已在目标分组的脚本跳过
        }
      }
      setScriptList(scanScripts())
      setMultiSelect(new Set())
      if (moved > 0) {
        showToast(tpl("已移动 {n} 个脚本到「{group}」", { n: String(moved), group: target.name }))
      } else {
        showToast(t("没有可移动的脚本"), true)
      }
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 按当前备份位置备份脚本（菜单 / 多选快捷备份） */
  async function backupScriptsFromMenu(scripts: ScriptInfo[]) {
    if (scripts.length === 0) {
      showToast(t("没有可备份的脚本"), true)
      return
    }
    if (config.destination === "github_publish") {
      await startGithubPublish(scripts)
    } else if (config.destination === "github_backup") {
      await startGithubBackup(scripts, scripts.length > 1 ? t("临时备份") : undefined)
    } else {
      await startBackup(undefined, scripts, undefined, scripts.length > 1 ? t("临时备份") : undefined)
    }
  }

  async function renameScriptWithPrompt(script: ScriptInfo) {
    const name = await inputPrompt({
      title: t("重命名脚本"),
      message: t("输入新的脚本名称"),
      defaultValue: script.folderName,
      placeholder: script.folderName,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameScript(script, name.trim())
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      setConfigState(resolveConfig())
      showToast(t("已重命名"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function moveScriptGroupWithPrompt(script: ScriptInfo) {
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast(t("没有可移动的分组"), true)
      return
    }
    const ordered = orderGroupsForMove(named, config.groupOrder)
    const index = await Dialog.actionSheet({
      title: t("移动到分组"),
      message: tpl("把「{name}」移动到哪个分组？", { name: script.displayName }),
      // 不传 cancelButton：与首页脚本名菜单一致，取消由系统独立显示在底部
      actions: ordered.map((g) => ({ label: g.name })),
    })
    if (index == null) {
      return
    }
    const target = ordered[index]
    try {
      moveScriptToGroup(script, target.name)
      setScriptList(scanScripts())
      setConfigState(resolveConfig())
      showToast(tpl("已移动到「{group}」", { group: target.name }))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function shareOneScript(script: ScriptInfo) {
    try {
      await shareScripts([script])
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 复制该脚本的 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]） */
  async function copyScriptShareLink(script: ScriptInfo) {
    const link = buildScriptImportLink(script)
    if (!link) {
      showToast(t("该脚本没有发布链接，请先发布"), true)
      return
    }
    try {
      await Pasteboard.setString(link)
      showToast(t("导入链接已复制"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function changeVersionWithPrompt(script: ScriptInfo) {
    if (!(await ensureVersionNotOverridden(script))) {
      return
    }
    const version = await inputPrompt({
      title: t("修改版本号"),
      message: t("输入新的版本号（格式 x.y.z，例如 1.0.1）"),
      defaultValue: script.version,
      placeholder: script.version,
      keyboardType: "numbersAndPunctuation",
    })
    if (version == null || !version.trim()) {
      return
    }
    try {
      setScriptVersion(script, version.trim())
      const list = scanScripts()
      setScriptList(list)
      setScriptCount(list.length)
      // 手动改版本号同样触发「自动备份升级项」检测（本地版本变化 → 自动备份到 iPhone）
      // 传入该脚本标识，即使同时有其他脚本自动更新也只备份手动改的这个
      checkAutoBackup(list, script.folderName)
      showToast(t("版本号已更新"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function deleteOneScript(script: ScriptInfo) {
    const index = await Dialog.actionSheet({
      title: t("删除确认"),
      message: tpl("确定删除「{name}」？此操作不可恢复。", { name: script.displayName }),
      actions: [{ label: t("删除"), destructive: true }],
    })
    if (index !== 0) {
      return
    }
    try {
      deleteScript(script)
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      showToast(t("已删除"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  function updateConfig(patch: Partial<AppConfig>) {
    // 以磁盘最新配置为基准合并，避免多实例（home tab 常驻 + 新打开脚本）并发时
    // 用本实例内存中的旧字段值整体覆盖写盘，导致 backupRestoreExpanded 等被“回退”
    const next = { ...resolveConfig(), ...patch }
    saveConfig(next)
    setConfigState(next)
  }

  function handleDestinationChanged(value: string | number) {
    const dest = String(value) as Destination
    if (dest === "icloud" && !FileManager.isiCloudEnabled) {
      showToast(t("iCloud 不可用，请先在系统设置中登录 iCloud 并授权 Scripting"), true)
      return
    }
    if (dest === "github_publish" && !config.githubPublishEnabled) {
      showToast(t("请在设置中勾选「Github发布」以使用此功能"), true)
      return
    }
    // 发布模式仅支持「最新/名称」，若之前选了分组/全部则重置为最新
    if (dest === "github_publish" && (config.scope === "group" || config.scope === "all")) {
      updateConfig({ destination: dest, scope: "recent" })
      return
    }
    updateConfig({ destination: dest })
  }

  /** 长按「Github备份/Github发布」分段 → 进入对应仓库管理页 */
  function openGithubRepoManage(mode: "backup" | "publish") {
    Navigation.present(<GithubRepoManagePage mode={mode} />)
  }

  /** 长按「脚本管理」标题 → 勾选要显示的分组（置顶的脚本始终显示），拖动可调整分组展示顺序 */
  function openGroupFilter() {
    const current = config.homeGroupFilter
    Navigation.present(
      <GroupFilterPage
        options={groupFilterOptions}
        initial={current}
        initialOrder={config.homeGroupOrder}
        onSave={(next, order, moved) => {
          updateConfig({ homeGroupFilter: next, homeGroupOrder: order })
          // 拖动过分组顺序时，同步设置页「调整分组顺序」用的 groupOrder（同向一致；未分组自动排最后，不进顺序表）
          if (moved && order) {
            updateConfig({ groupOrder: order.filter((g) => g !== "") })
          }
          if (next != null && next.length === 0) {
            showToast(t("只显示置顶的脚本"))
          }
        }}
      />
    )
  }

  /** 长按「iPhone/iCloud/Github备份」分段 → 打开对应恢复备份页（与首页恢复界面一致） */
  function openDestinationRestore(tag: string) {
    if (tag === "github_backup") {
      Navigation.present(<GithubRestorePage />)
    } else {
      Navigation.present(<RestorePage destination={tag as Destination} />)
    }
  }

  /** 弹出「按名称」脚本选择页（modal，选完直接开始备份/发布） */
  function openScriptPicker() {
    const isPublish = config.destination === "github_publish"
    Navigation.present(
      <ScriptPickerPage
        initial={[]}
        pickerMode={isPublish ? "github" : "backup"}
        onSelect={(scripts) => {
          setSelectedScripts(scripts)
          if (scripts.length === 0) return
          if (config.destination === "github_publish") {
            startGithubPublish(scripts)
          } else if (config.destination === "github_backup") {
            startGithubBackup(scripts)
          } else {
            startBackup("select", scripts)
          }
        }}
      />
    )
  }

  /** 弹出「按分组」选择页（modal，选完直接开始备份/发布对应分组） */
  function openGroupPicker() {
    Navigation.present(
      <GroupPickerPage
        onSelect={(group) => {
          setSelectedGroup(group)
          if (group.scripts.length === 0) {
            showToast(t("该分组没有可备份的脚本"), true)
            return
          }
          if (config.destination === "github_backup") {
            startGithubBackup(group.scripts, group.name)
          } else {
            startBackup("group", group.scripts, group.name)
          }
        }}
      />
    )
  }

  /** 执行某个备份范围对应的动作：最新/全部直接备份，按名称/按分组弹选择页 */
  function runScopeAction(scope: BackupScopeKey) {
    if (config.destination === "github_publish") {
      // GitHub 发布模式：仅「最新/名称」两个范围
      if (scope === "recent") {
        startGithubPublish(scanScripts().slice(0, 1))
      } else if (scope === "select") {
        openScriptPicker()
      }
    } else if (config.destination === "github_backup") {
      // GitHub 备份模式：打包 zip 上传到私密备份仓库
      if (scope === "recent" || scope === "all") {
        startGithubBackup(
          scope === "recent" ? scanScripts().slice(0, 1) : scanScripts(),
          scope === "all" ? t("全部") : undefined
        )
      } else if (scope === "select") {
        openScriptPicker()
      } else if (scope === "group") {
        openGroupPicker()
      }
    } else {
      // 本地备份模式：保持原有逻辑
      if (scope === "recent" || scope === "all") {
        startBackup(scope)
      } else if (scope === "select") {
        openScriptPicker()
      } else if (scope === "group") {
        openGroupPicker()
      }
    }
  }

  /**
   * 说明为空时的处理：询问保留上次说明 / 不显示说明。
   * 返回 null 取消；"keep" 保留上次（不写 changelog）；"clear" 清空；否则为要写入的新说明。
   */
  async function resolveChangelogPolicy(
    script: ScriptInfo,
    notes: string
  ): Promise<string | null | "keep" | "clear"> {
    if (notes.trim()) {
      return notes.trim()
    }
    const choice = await Dialog.actionSheet({
      title: t("更新说明为空"),
      message: t("本次更新说明留空了：要保留上次发布的说明，还是本次不显示更新说明？"),
      actions: [
        { label: t("取消") },
        { label: t("保留上次更新说明") },
        { label: t("不显示更新说明") },
      ],
      cancelButton: false,
    })
    if (choice == null || choice === 0) {
      return null
    }
    if (choice === 1) {
      return "keep"
    }
    return "clear"
  }

  /**
   * 执行 GitHub 发布核心流程，顺序固定为：
   * ① 勾选「当前版本加一」时先把本地版本号加一（写入 script.json）
   * ② 再更新更新说明（写入 script.json 的 changelog + 注入更新说明检查块，注入块使用加一后的新版本号）
   * ③ 最后打包上传发布（zip 里的 script.json 已含新版本号与新说明）
   * ④ 发布成功后再记录发布版本与说明。
   * notifyAuthor=true 时本次发布勾选「作者本人也提示更新」，作者本人（设置里用户名==脚本作者）下次也会弹更新说明，默认 false 不弹。
   */
  async function doGithubPublish(
    scripts: ScriptInfo[],
    gh: GithubConfig,
    notes: string | null | "keep" | "clear",
    bumpVersion?: boolean,
    notifyAuthor?: boolean
  ): Promise<boolean> {
    // ① 勾选「当前版本加一」：先把本地版本号最后一组（patch）自动 +1 并写入 script.json，
    //    同时同步到脚本对象，保证后面更新说明、注入检查块与打包发布用的都是新版本号。
    //    版本号加一失败则中止发布，避免发布包版本号与本地/注入说明不一致。
    if (bumpVersion) {
      for (const s of scripts) {
        try {
          const newVersion = bumpPatchVersion(s.version ?? "")
          setScriptVersion(s, newVersion)
          s.version = newVersion
        } catch {
          showToast(
            tpl("「{name}」版本号加一失败，已取消发布", { name: s.displayName }),
            true
          )
          return false
        }
      }
    }
    // ② 再更新更新说明：先把说明写入 script.json 的 changelog 字段（随发布包分发），
    //    再注入更新说明检查块（使用加一后的新版本号 + 本次说明，保证安装方弹窗版本号与包内一致）。
    for (const s of scripts) {
      // 说明文本直接嵌入注入代码（不依赖 script.json 的 changelog 字段，避免被 Scripting 重写后丢失）
      let changelogText: string
      if (notes === "keep") {
        // 保留上次说明：取已记录的说明（云端/本地），没有则为空（不弹）
        changelogText =
          config.publishedChangelogs[s.folderName] ??
          readScriptChangelog(s) ??
          ""
      } else if (notes === "clear") {
        changelogText = ""
        try {
          setScriptChangelog(s, "")
        } catch {}
      } else if (notes) {
        changelogText = notes
        try {
          setScriptChangelog(s, notes)
        } catch {}
      } else {
        changelogText = ""
      }
      try {
        injectChangelogChecker(s, changelogText, notifyAuthor)
      } catch {}
    }
    // ③ 最后打包上传发布
    setBusyAction("publish")
    setBusy(true)
    try {
      const results = await publishScriptsToGithub(scripts, gh)
      // 记录本次发布的版本，用于检测「云端与本地不同步」（本地版本号变化后未重新发布）
      const published: Record<string, string> = { ...config.publishedVersions }
      // 记录本次发布时的本地内容指纹：之后「版本号没变但本地内容改了」会显示小黄云
      const fingerprints: Record<string, string> = {
        ...config.publishedFingerprints,
      }
      const changelogs: Record<string, string> = { ...config.publishedChangelogs }
      for (const r of results) {
        const s = scripts.find((x) => x.folderName === r.folderName)
        if (s) {
          // 以磁盘实际版本为准：勾选「当前版本加一」时发布前已改写 script.json，
          // 内存中的 s.version 可能还是旧值，若按旧值记录云端缓存，导入/安装后版本一致
          // 也会被误判为「云端与本地不同步」而显示橙色感叹号云。
          published[r.folderName] =
            readScriptMeta(s.path).version ?? s.version ?? ""
          try {
            fingerprints[r.folderName] = scriptContentFingerprint(s.path)
          } catch {}
          if (notes === "keep") {
            // 保留上次：本地记录不动
          } else if (notes === "clear") {
            delete changelogs[r.folderName]
          } else if (notes) {
            changelogs[r.folderName] = notes
          }
        }
      }
      // 发布后云端包即当前本地内容：同步真实云端缓存，立即显示绿勾（无需再下载确认）
      const checkedAt = { ...(config.cloudCheckedAt ?? {}) }
      const publishAt = Date.now()
      for (const r of results) {
        checkedAt[r.folderName] = publishAt
      }
      updateConfig({
        publishedVersions: published,
        publishedFingerprints: fingerprints,
        publishedChangelogs: changelogs,
        cloudVersions: { ...config.cloudVersions, ...published },
        cloudFingerprints: { ...config.cloudFingerprints, ...fingerprints },
        cloudCheckedAt: checkedAt,
      })
      // 未勾选「作者提示」：本次发布是作者本人操作，把刚发布的文件吸收进仓库监控基线，
      // 避免仓库监控（默认监控作者自己的发布仓库）把这次发布当成「有更新」再弹更新页/通知
      if (!notifyAuthor && results.length > 0) {
        try {
          const pub = resolvePublishGithubConfig(resolveGithubConfig())
          await absorbPublishedIntoChannelBaseline(
            pub.owner,
            pub.repo,
            pub.path,
            results.map((r) => r.folderName)
          )
        } catch {}
      }
      // 发布时 injectChangelogChecker 可能改写了 index.tsx（注入/替换更新说明检查块），
      // 立即按发布后的磁盘内容重算本地指纹，与刚记录的基线保持一致，避免误判为「内容微调」小黄云。
      setLocalContentFingerprints((prev) => {
        const fpNow: Record<string, string> = { ...prev }
        for (const r of results) {
          const s = scripts.find((x) => x.folderName === r.folderName)
          if (s) {
            try {
              fpNow[r.folderName] = scriptContentFingerprint(s.path)
            } catch {}
          }
        }
        return fpNow
      })
      // 勾选「当前版本加一」时本地版本号已在发布前写入 script.json：
      // 立即重扫首页列表，让本地版本号同步显示（无需等切 tab 或手动下拉刷新）
      refreshScripts()
      const links = results.map((r) => buildImportLinkFromUrl(r.url))
      await Pasteboard.setString(links.join("\n"))
      showToast(
        tpl("已发布 {n} 个脚本并同步更新链接，更新链接已复制", { n: String(results.length) })
      )
      console.log(
        t("GitHub 发布完成:"),
        links
      )
      return true
    } catch (error) {
      logError("Github发布", error)
      showToast(
        error instanceof Error ? error.message : String(error),
        true
      )
      return false
    } finally {
      setBusy(false)
      setBusyAction("backup")
    }
  }

  /** 发布脚本到 GitHub（公开仓库，可自动创建）：直接进入更新说明编辑页，打包上传并更新链接 */
  async function startGithubPublish(scripts: ScriptInfo[]) {
    if (busy && busyAction === "publish") {
      // 上一次发布尚未完成：明确提示，避免静默失败
      showToast(
        t("请等待上个脚本发布成功，或者去 Github 发布页面使用长按多选发布"),
        true
      )
      return
    }
    if (busy) {
      return
    }
    const gh = resolvePublishGithubConfig(resolveGithubConfig())
    if (!isGithubConfigured(gh)) {
      showToast(t("请先到右上角「设置」配置 GitHub 发布（Token/所有者/仓库名）"), true)
      return
    }
    // 多项发布：不弹更新说明编辑页（保留各脚本已有的更新说明，不新增/不清空）
    if (scripts.length > 1) {
      await doGithubPublish(scripts, gh, "keep")
      return
    }
    // 单项发布：进入更新说明编辑页，默认预填「版本号更高那一侧」的说明：
    // 先比较云端版本与本地版本，取版本高的说明；高版本侧为空则回退另一侧（云端→本地）。
    // 本地与云端版本号一致时：优先读取云端最新的更新说明自动填入（为空再回退本地）。
    // 云端信息优先实时拉取 GitHub 上的 .scripting 包（保证是最新发布的说明），
    // 实时拉取失败（未发布/网络异常等）才回退本地缓存的 cloudChangelogs/publishedChangelogs。
    // 为让编辑页尽快弹出：先用本地说明立即弹窗，云端说明由页面后台拉取后自动补填（用户未编辑时）。
    const folder = scripts[0].folderName
    const localNote = readScriptChangelog(scripts[0]) ?? ""
    const result = await Navigation.present(
      <ChangelogEditorPage
        key={++publishEditorGenRef.current}
        initial={localNote}
        scriptName={scripts[0].displayName}
        version={scripts[0].version}
        loadCloudNote={async () => {
          let cloudVersion: string | null = null
          let cloudNote: string | null = null
          try {
            const meta = await fetchScriptCloudMeta(scripts[0])
            if (meta != null) {
              cloudVersion = meta.version
              cloudNote = meta.changelog
            }
          } catch {}
          if (cloudVersion == null) {
            cloudVersion =
              config.cloudVersions[folder] ??
              config.publishedVersions[folder] ??
              null
          }
          if (cloudNote == null) {
            cloudNote =
              config.cloudChangelogs[folder] ??
              config.publishedChangelogs[folder] ??
              null
          }
          return { version: cloudVersion, changelog: cloudNote }
        }}
      />
    )
    if (result == null) {
      return
    }
    const policy = await resolveChangelogPolicy(scripts[0], result.notes)
    if (policy == null) {
      return
    }
    await doGithubPublish(scripts, gh, policy, result.bumpVersion, result.notifyAuthor)
  }


  /** 备份脚本到 GitHub 私密备份仓库（可自动创建）：打包 zip 上传，不更新更新链接 */
  async function startGithubBackup(scripts: ScriptInfo[], nameHint?: string) {
    if (busy) {
      return
    }
    const gh = resolveBackupGithubConfig(resolveGithubConfig())
    if (!isGithubBackupConfigured(gh)) {
      showToast(t("请先到右上角「设置」配置 GitHub 备份（Token/所有者/备份仓库名）"), true)
      return
    }
    let zipName: string
    if (nameHint) {
      // 分组/全部备份：默认「前缀_时间编号」
      const def = `${safeFileName(nameHint)}_${timestampForName()}`
      const input = await inputPrompt({
        title: t("备份名称"),
        message: tpl("将 {n} 个脚本打包为一个 zip 上传到 GitHub 私密仓库，默认命名为「{name}+时间编号」", { n: String(scripts.length), name: nameHint }),
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || def
    } else if (scripts.length === 1) {
      const script = scripts[0]
      const def = `${script.displayName}_${script.version}`
      const input = await inputPrompt({
        title: t("备份名称"),
        message: t("单个脚本备份为 .scripting 格式上传到 GitHub 私密仓库，默认使用「脚本名+版本号」"),
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || def
    } else {
      const def = tpl("脚本备份_{stamp}", { stamp: timestampForName() })
      const input = await inputPrompt({
        title: t("备份名称"),
        message: tpl("将 {n} 个脚本打包为一个 zip 上传到 GitHub 私密仓库", { n: String(scripts.length) }),
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || t("脚本备份")
    }
    setBusy(true)
    try {
      const result = await backupScriptsToGithub(scripts, gh, zipName)
      showToast(tpl("已备份 {n} 个脚本到 {repo}", { n: String(scripts.length), repo: `${gh.owner}/${gh.backupRepo}` }))
      console.log("GitHub 备份完成:", result.url)
    } catch (error) {
      logError("Github备份", error)
      showToast(
        error instanceof Error ? error.message : String(error),
        true
      )
    } finally {
      setBusy(false)
    }
  }

  /** 计算当前范围要备份的脚本 */
  async function resolveBackupScripts(
    scope: BackupScopeKey = config.scope
  ): Promise<ScriptInfo[] | null> {
    if (scope === "all") {
      return scanScripts()
    }
    if (scope === "recent") {
      return scanScripts().slice(0, 1)
    }
    if (scope === "select") {
      const pickable = selectedScripts.filter((s) => pathExists(s.path))
      if (pickable.length === 0) {
        showToast(t("请先选择要备份的脚本"), true)
        return null
      }
      return pickable
    }
    // 按分组
    if (!selectedGroup) {
      showToast(t("请先选择要备份的分组"), true)
      return null
    }
    return selectedGroup.scripts
  }

  async function startBackup(
    scope?: BackupScopeKey,
    scriptsOverride?: ScriptInfo[],
    groupName?: string,
    multiDefaultName?: string
  ) {
    if (busy) {
      return
    }
    setBusy(true)
    try {
      const scripts = scriptsOverride ?? (await resolveBackupScripts(scope))
      if (!scripts) {
        return
      }
      if (scripts.length === 0) {
        showToast(t("没有可备份的脚本"), true)
        return
      }

      let zipName: string
      if (groupName) {
        // 按分组备份：默认「分组名_时间戳编号」
        const def = `${safeFileName(groupName)}_${timestampForName()}`
        const input = await inputPrompt({
          title: t("备份名称"),
          message: tpl("将 {n} 个脚本打包为一个 zip 上传到 iPhone/iCloud，默认命名为「分组名+时间编号」", { n: String(scripts.length) }),
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || def
      } else if (scripts.length === 1) {
        const script = scripts[0]
        const def = `${script.displayName}_${script.version}`
        const input = await inputPrompt({
          title: t("备份名称"),
          message: t("单个备份默认使用「脚本名+版本号」"),
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || def
      } else {
        const isAll = scope === "all"
        const baseName = isAll ? t("全部") : (multiDefaultName ?? t("脚本备份"))
        const def = `${baseName}_${timestampForName()}`
        const input = await inputPrompt({
          title: t("备份名称"),
          message: tpl("将 {n} 个脚本打包为一个 zip 上传到 iPhone/iCloud，留空则命名为「{base}_时间码」", { n: String(scripts.length), base: baseName }),
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || (isAll ? def : (multiDefaultName ?? t("临时备份")))
      }

      const finalPath = await backupScripts(scripts, config.destination, zipName)
      showToast(tpl("已备份 {n} 个脚本", { n: String(scripts.length) }))
      // 吸收自动备份基线：手动备份成功后，已备份脚本不再视为「版本/内容变化」，
      // 避免紧随其后的 refreshScripts → checkAutoBackup 把同一批脚本再当变化触发自动备份，
      // 导致「已备份」之后又弹出「检测到变化/已自动备份」等多余通知与重复备份。
      const record = { ...(config.scriptVersionRecord ?? {}) }
      const contentRecord = { ...(config.scriptContentRecord ?? {}) }
      for (const s of scripts) {
        record[s.folderName] = s.version ?? ""
        try {
          contentRecord[s.folderName] = scriptDirFingerprint(s.path)
        } catch {}
      }
      updateConfig({ scriptVersionRecord: record, scriptContentRecord: contentRecord })
      setBackupVersion((v) => v + 1)
      console.log("备份完成:", finalPath)
    } catch (error) {
      logError("本地备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setBusy(false)
    }
  }

  /** 从外部 zip 恢复 */
  async function importFromZip() {
    const files = await DocumentPicker.pickFiles({
      allowsMultipleSelection: false,
    })
    if (!files || files.length === 0) {
      return
    }
    const file = files[0]
    const tempDir = Path.join(
      FileManager.temporaryDirectory,
      `import-restore-${Date.now()}`
    )
    FileManager.createDirectorySync(tempDir, true)
    try {
      const lower = file.toLowerCase()
      if (lower.endsWith(".zip") || lower.endsWith(".scripting")) {
        FileManager.unzipSync(file, tempDir)
      } else {
        // 单个文件夹：直接按脚本目录树扫描
        const name = Path.basename(file)
        FileManager.copyFileSync(file, Path.join(tempDir, name))
      }
      const candidates = scanScriptDirsInTree(tempDir)
      if (candidates.length === 0) {
        showToast(t("所选文件中没有找到脚本（缺少 script.json）"), true)
        return
      }
      if (candidates.length === 1) {
        const ok = await confirmRestoreOne(candidates[0])
        if (ok) {
          await restoreScripts([candidates[0]], true)
          markRestoredAsBaseline([candidates[0]])
          notifyBackupChange()
          showToast(t("已恢复"))
        }
      } else {
        const result = await Navigation.present(
          <ScriptSelectionPage candidates={candidates} />
        )
        if (result?.restored != null) {
          showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
        }
      }
    } catch (error) {
      logError("从zip恢复", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (pathExists(tempDir)) {
        FileManager.removeSync(tempDir)
      }
    }
  }

  return (
    <NavigationStack>
      <ScrollViewReader>
        {(proxy) => {
          scrollProxyRef.current = proxy
          return (
      <List
        navigationTitle={APP_NAME}
        navigationBarTitleDisplayMode="inline"
        scrollDismissesKeyboard="immediately"
        toast={toastProps}
        safeAreaInset={{
          bottom: {
            alignment: "center",
            spacing: 8,
            content: multiSelect.size > 0 ? (
              <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setMultiSelect(new Set())}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("取消")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={deleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("删除")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={moveSelectedToGroup}
                >
                  <Image systemName="folder" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("移动")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() =>
                    backupScriptsFromMenu(
                      scriptList.filter((s) => multiSelect.has(s.folderName))
                    )
                  }
                >
                  <Image systemName="arrow.down.circle" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("备份")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={shareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("分享")}
                  </Text>
                </VStack>
              </HStack>
              </VStack>
            ) : (
              <></>
            ),
          },
        }}
        toolbar={
          <Toolbar>
            {Script.env !== "home_screen" ? (
              <ToolbarItem placement="topBarLeading">
                <Button title={t("关闭")} action={dismiss} />
              </ToolbarItem>
            ) : null}
            <ToolbarItem placement="topBarLeading">
              <Button
                action={() => {
                  const next = !showBackupRestore
                  setShowBackupRestore(next)
                  if (config.rememberExpandState) {
                    updateConfig({ backupRestoreExpanded: next })
                  }
                }}
              >
                <Image
                  systemName={showBackupRestore ? "chevron.up" : "chevron.down"}
                />
              </Button>
            </ToolbarItem>
            {config.channelMonitorEnabled ? (
              <ToolbarItem placement="topBarTrailing">
                <HStack
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={async () => {
                    // 首页「立即监控」：开启仓库监控时显示，点击立即检查一次；无更新时提示
                    const summary = await runMonitorCycle()
                    if (
                      summary &&
                      !summary.newBaseline &&
                      summary.totalChanges === 0
                    ) {
                      showToast(t("检查完成，没有发现更新"))
                    }
                  }}
                  onLongPressGesture={{
                    minDuration: 400,
                    // 长按：检测到更新的 5 分钟内再次打开更新页
                    perform: reopenLastChannelUpdatePage,
                  }}
                >
                  <Image
                    systemName="tray.and.arrow.down"
                    font={15} // 图标大小(pt)，数字越大按钮图标越大；也可用 imageScale="large"
                  />
                </HStack>
              </ToolbarItem>
            ) : null}
            <ToolbarItem placement="topBarTrailing">
              <Button
                action={async () => {
                  // 打开设置页；关闭后立即刷新配置，无需重新打开脚本即可生效
                  await Navigation.present(<SettingsPage />)
                  setConfigState(resolveConfig())
                }}
              >
                <Image systemName="gearshape" />
              </Button>
            </ToolbarItem>
          </Toolbar>
        }
      >
        {showBackupRestore ? (
          <Section
            header={<Text font="headline">{t("备份")}</Text>}
            footer={
              config.destination === "github_publish" ? (
                <Text font="footnote">
                  {(() => {
                    const gh = resolvePublishGithubConfig(resolveGithubConfig())
                    const pub =
                      gh.owner && gh.repo
                        ? `${gh.owner}/${gh.repo}`
                        : t("未配置，请在设置中填写 GitHub 发布参数")
                    const pubSuffix = gh.path ? ` / ${gh.path}` : ""
                    return tpl("发布到仓库：{pub}（{branch} 分支，公开，可自动创建）", {
                      pub: pub + pubSuffix,
                      branch: gh.branch || "main",
                    })
                  })()}
                </Text>
              ) : config.destination === "github_backup" ? (
                <Text font="footnote">
                  {(() => {
                    const gh = resolveBackupGithubConfig(resolveGithubConfig())
                    const bak =
                      gh.owner && gh.backupRepo
                        ? `${gh.owner}/${gh.backupRepo}`
                        : t("未配置，请在设置中填写 GitHub 备份参数")
                    const bakSuffix = gh.backupPath ? ` / ${gh.backupPath}` : ""
                    return tpl("备份到仓库：{backup}（{branch} 分支，私密，可自动创建）", {
                      backup: bak + bakSuffix,
                      branch: gh.backupBranch || "main",
                    })
                  })()}
                </Text>
              ) : (
                <Text font="footnote">
                  {tpl("备份目录：{dir}", { dir: backupRootFor(config.destination) })}
                </Text>
              )
            }
          >
            <HStack
              spacing={0}
              padding={{ vertical: 2, horizontal: 2 }}
              listRowSeparator="hidden"
              // 复刻下方「备份范围」分段控件的悬浮阴影效果：改用接近原生的轻微阴影，避免选中态黑色阴影过重
              shadow={{ color: "rgba(0,0,0,0.08)", radius: 4, x: 0, y: 1 }}
              background={{
                style: { color: "secondarySystemFill", opacity: 1 },
                shape: { type: "rect", cornerRadius: 9 },
              }}
            >
              {(() => {
                const destSegs = [
                  { tag: "iphone", label: "iPhone" },
                  { tag: "icloud", label: "iCloud" },
                  ...(config.githubBackupEnabled ? [{ tag: "github_backup" as const, label: t("Github备份") }] : []),
                  ...(config.githubPublishEnabled
                    ? [{ tag: "github_publish" as const, label: t("Github发布") }]
                    : []),
                ] as { tag: string; label: string }[]
                return destSegs.map((seg, i) => {
                  const active = config.destination === seg.tag
                  const pressed = pressedDestSeg === seg.tag
                  const nextActive = i < destSegs.length - 1 && config.destination === destSegs[i + 1].tag
                  return [
                    <HStack
                      key={seg.tag}
                      alignment="center"
                      frame={{ maxWidth: "infinity" }}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={() => handleDestinationChanged(seg.tag)}
                      onLongPressGesture={{
                        minDuration: 400,
                        perform: () => {
                          if (seg.tag === "github_publish") {
                            openGithubRepoManage("publish")
                          } else {
                            openDestinationRestore(seg.tag)
                          }
                        },
                        onPressingChanged: (pressing) => setPressedDestSeg(pressing ? seg.tag : null),
                      }}
                    >
                      <HStack
                        alignment="center"
                        frame={{ maxWidth: "infinity" }}
                        padding={{ vertical: 7, leading: 3, trailing: 5 }}
                        background={
                          active
                            ? {
                                // 接近下方分段选中段的白，但带一点透明度柔化，避免纯白刺眼
                                style: { color: "systemBackground", opacity: 0.95 },
                                shape: { type: "rect", cornerRadius: 7 },
                              }
                            : pressed
                              ? {
                                  style: { color: "label", opacity: 0.06 },
                                  shape: { type: "rect", cornerRadius: 7 },
                                }
                              : undefined
                        }
                      >
                        <Text
                          font="footnote"
                          frame={{ maxWidth: "infinity" }}
                          multilineTextAlignment="center"
                          foregroundStyle="label"
                          fontWeight={active ? "medium" : "regular"}
                          lineLimit={1}
                          allowsTightening={true}
                        >
                          {seg.label}
                        </Text>
                      </HStack>
                    </HStack>,
                    i < destSegs.length - 1 ? (
                      <HStack
                        key={"sep-" + seg.tag}
                        // 竖线与下排备份范围分段的分隔线对齐：线贴段左边界，不留左侧空隙
                        padding={{ leading: 0, trailing: 4 }}
                      >
                        <Rectangle
                          frame={{ width: 1, height: 20 }}
                          foregroundStyle={
                            !active && !nextActive
                              ? { color: "label", opacity: 0.1 }
                              : "clear"
                          }
                        />
                      </HStack>
                    ) : null,
                  ]
                })
              })()}
            </HStack>

            <Picker
              title={t("备份范围")}
              value={config.scope}
              onChanged={(value: string | number) => {
                // 兼容 segmented 回调的两种取值：tag 字符串（"recent"/"select"...）或分段下标（0/1/2/3）。
                // 部分场景下 segmented 控件回调返回的是下标，直接 String(value) 会得到 "0" 这类
                // 非法 scope，导致配置被写坏、受控选中态弹回上一项（表现为“切换失败弹回名称”）。
                const raw = String(value)
                const scope: BackupScopeKey =
                  raw === "recent" || raw === "select" || raw === "group" || raw === "all"
                    ? (raw as BackupScopeKey)
                    : raw === "0"
                      ? "recent"
                      : raw === "1"
                        ? config.destination === "github_publish"
                          ? "select"
                          : "all"
                        : raw === "2"
                          ? config.destination === "github_publish"
                            ? config.scope
                            : "select"
                          : raw === "3" && config.destination !== "github_publish"
                            ? "group"
                            : config.scope
                if (scope === config.scope) return
                updateConfig({ scope })
                // 延迟执行动作：先让 Picker 受控选中值同步到原生端，再弹输入框/选择页，
                // 避免模态打断导致选中态弹回上一项（“切换失败弹回名称”的另一条路径）。
                // 用磁盘最新配置核对，快速连点时旧动作自动跳过。
                setTimeout(() => {
                  if (resolveConfig().scope === scope) runScopeAction(scope)
                }, 120)
              }}
              pickerStyle="segmented"
            >
              <Text tag="recent">{t("最新")}</Text>
              {config.destination !== "github_publish" && <Text tag="all">{t("全部")}</Text>}
              <Text tag="select">{t("名称")}</Text>
              {config.destination !== "github_publish" && <Text tag="group">{t("分组")}</Text>}
            </Picker>

            <HStack
              spacing={8}
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => runScopeAction(config.scope)}
            >
              <Spacer />
              <Image
                systemName={config.destination === "github_publish" ? "arrow.up.doc.fill" : "externaldrive.fill.badge.checkmark"}
                foregroundStyle="tintColor"
              />
              <Text font="body" foregroundStyle="tintColor">
                {busy
                  ? busyAction === "publish" ? t("正在发布…") : t("正在备份…")
                  : config.destination === "github_publish" ? t("开始发布") : t("开始备份")}
              </Text>
              <Spacer />
            </HStack>
          </Section>
        ) : null}

        {showBackupRestore && !config.hideRestoreModule && config.destination !== "github_publish" ? (
          <Section
            header={<Text font="headline">{t("恢复")}</Text>}
            footer={
              <Text font="footnote">
                {config.destination === "github_backup"
                  ? t("从 GitHub 私密备份仓库下载 .scripting 恢复脚本")
                  : t("从备份目录或外部 .scripting 文件恢复脚本")}
              </Text>
            }
          >
            <NavigationLink
              destination={
                config.destination === "github_backup" ? (
                  <GithubRestorePage />
                ) : (
                  <RestorePage destination={config.destination} />
                )
              }
            >
              <HStack spacing={10}>
                <RowIcon systemName="tray.and.arrow.down" />
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{t("恢复备份")}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {config.destination === "github_backup"
                      ? t("Github备份仓库")
                      : tpl("{n} 个备份", { n: String(backupCount) })}
                  </Text>
                </VStack>
                <Spacer />
              </HStack>
            </NavigationLink>

            {config.destination !== "github_backup" && (
              <HStack
                spacing={8}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={importFromZip}
              >
                <Spacer />
                <Image systemName="folder.badge.plus" foregroundStyle="tintColor" />
                <Text font="body" foregroundStyle="tintColor">{t("从文件恢复")}</Text>
                <Spacer />
              </HStack>
            )}
          </Section>
        ) : null}

        <Section
          key="scripts-anchor"
          header={
            <HStack spacing={8} alignment="center">
              <Text
                font="headline"
                onLongPressGesture={{ minDuration: 400, perform: openGroupFilter }}
              >
                {tpl("脚本管理（{n}）", { n: String(scriptList.length) })}
              </Text>
              <Spacer />
              <Picker
                value={config.scriptSort}
                onChanged={(value: string | number) => {
                  const v = String(value)
                  updateConfig({
                    scriptSort:
                      v === "recent" ||
                      v === "name" ||
                      v === "name_desc" ||
                      v === "author" ||
                      v === "group" ||
                      v === "usage"
                        ? v
                        : "modified",
                  })
                }}
                pickerStyle="menu"
                padding={{ trailing: -12 }}
                label={
                  <HStack spacing={4}>
                    <Image
                      systemName="arrow.up.arrow.down"
                      foregroundStyle="secondaryLabel"
                    />
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      {config.scriptSort === "usage"
                        ? t("按运行次数")
                        : config.scriptSort === "recent"
                          ? t("按最近使用")
                          : config.scriptSort === "group" && config.showScriptGroupName
                            ? t("按脚本分组")
                            : config.scriptSort === "name"
                            ? t("按名称 A-Z")
                            : config.scriptSort === "name_desc"
                              ? t("按名称 Z-A")
                              : config.scriptSort === "author"
                                ? t("按脚本作者")
                                : t("按最新修改")}
                    </Text>
                  </HStack>
                }
              >
                <Text tag="usage">{t("按运行次数")}</Text>
                <Text tag="modified">{t("按最新修改")}</Text>
                <Text tag="author">{t("按脚本作者")}</Text>
                <Text tag="recent">{t("按最近使用")}</Text>
                {config.showScriptGroupName ? (
                  <Text tag="group">{t("按脚本分组")}</Text>
                ) : null}
                <Text tag="name">{t("按名称 A-Z")}</Text>
                <Text tag="name_desc">{t("按名称 Z-A")}</Text>
              </Picker>
            </HStack>
          }
          footer={
            <VStack alignment="leading" spacing={2}>
              <Text font="footnote"> </Text>
              <Text font="footnote">{t("注：")}</Text>
              <Text font="footnote">
                {t("①点击首页脚本管理处脚本前方脚本图标可跳转脚本编辑页面")}
              </Text>
              <Text font="footnote">
                {t("②单击行弹出菜单（删除/版本号/移动分组/重命名/备份/分享）")}
              </Text>
              <Text font="footnote">{t("③双击单项快速置顶，再次双击取消置顶；已置顶的脚本双击右侧置顶图标可移到所有置顶项目最上方，按住置顶图标上下拖动可调整置顶顺序")}</Text>
              <Text font="footnote">
                {t("④点击右侧按钮(三角图标)直接运行该脚本")}
              </Text>
              <Text font="footnote">{t("⑤长按任意脚本可多选备份、分享、移动或删除")}</Text>
              <Text font="footnote">
                {t("⑥搜索时匹配的脚本排在前面；默认不隐藏其他脚本（设置里可关闭，关闭后只显示匹配项）")}
              </Text>
              <Text font="footnote">
                {t("⑦点击左上角按钮可隐藏备份相关板块")}
              </Text>
              <Text font="footnote">
                {t("⑧自己已发布到仓库的脚本：绿色勾=与云端一致；橙色感叹号云=版本号与云端不同步；橙色云=版本号相同但内容被微调过(未重新发布)")}
              </Text>
              <Text font="footnote">
                {t("⑨该脚本若被固定到首页，更新后有些功能可能需要长按主页按钮并点击重新加载才会生效")}
              </Text>
              <Text font="footnote">
                {t("⑩长按iPhone、iCloud、Github备份、Github发布四个按钮可分别进入其对应文件管理界面")}
              </Text>
              <Text font="footnote">
                {t("⑪根据脚本作者和分组排序需要设置内启用该功能才能使用")}
              </Text>
              <Text font="footnote">
                {t("⑫长按「脚本管理」标题可勾选要显示的分组，只显示勾选分组内的脚本（置顶的脚本始终显示）；该页面长按分组名可控制脚本管理板块按脚本分组排序时分组的上下顺序")}
              </Text>
              <Text font="footnote">
                {t("⑬首页脚本菜单改作者名功能仅当设置内填入用户名时才能启用，当脚本没作者名点击后会直接填入用户名，当脚本已有作者名，则会出现填入贡献者按钮，当你已在贡献者则会出现移除贡献者按钮")}
              </Text>
            </VStack>
          }
        >
          {scriptList.length > 0 ? (
            <HStack spacing={8}>
              <TextField
                value={searchText}
                onChanged={setSearchText}
                onFocus={scrollSearchFieldToTop}
                prompt={t("搜索脚本名")}
                label={
                  <Image
                    systemName="magnifyingglass"
                    foregroundStyle="secondaryLabel"
                  />
                }
              />
              {searchText.length > 0 ? (
                <HStack
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setSearchText("")}
                >
                  <Image
                    systemName="xmark.circle.fill"
                    foregroundStyle="secondaryLabel"
                  />
                </HStack>
              ) : null}
            </HStack>
          ) : null}
          {scriptList.length === 0 ? (
            <EmptyState message={t("正在加载脚本…")} />
          ) : (
            visibleScripts.map((script) => {
              const checked = multiSelect.has(script.folderName)
              const group = groupNameMap.get(script.folderName) ?? null
              const isPinned = pinnedSet.has(script.folderName)
              // 该行在置顶区（= pinnedScripts 顺序）里的索引；非置顶行为 -1，不参与让位
              const pinIdx = isPinned
                ? config.pinnedScripts.indexOf(script.folderName)
                : -1
              // 置顶拖动排序：被拖行浮动跟随手指并“拎起”（保持不透明、加阴影与轻微放大，显示在其他脚本行上方）；
              // 拖动过程中其余置顶行实时向被拖行腾出的空位让位（平滑动画），仿系统 onMove 动效，松手一次性重排
              const isDragging = pinDrag?.folder === script.folderName
              // 让位偏移：向上拖（target<start）时 target..start-1 的行下移一行；向下拖时 start+1..target 的行上移一行
              const letOffset =
                pinDrag && !isDragging && pinIdx >= 0
                  ? pinDrag.targetIndex < pinDrag.startIndex &&
                    pinIdx >= pinDrag.targetIndex &&
                    pinIdx < pinDrag.startIndex
                    ? PIN_ROW_HEIGHT
                    : pinDrag.targetIndex > pinDrag.startIndex &&
                      pinIdx > pinDrag.startIndex &&
                      pinIdx <= pinDrag.targetIndex
                      ? -PIN_ROW_HEIGHT
                      : 0
                  : 0
              // 灰字说明：版本 · 分组 · 作者（两项都按设置开关决定是否显示）
              const metaParts = [
                `v${script.version}`,
                config.showScriptGroupName ? group ?? t("未分组") : null,
                config.showScriptAuthor && script.authorName
                  ? script.authorName
                  : null,
              ].filter((x): x is string => x != null && x.length > 0)
              return (
                <HStack
                  key={script.folderName}
                  spacing={10}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  // 拖动中给行加显式背景：offset 移动时背景跟随一起走，避免内容移开后残留白底（仿系统 onMove 拎起行时背景随行移动）
                  background={pinDrag ? "systemBackground" : undefined}
                  onTapGesture={() => handleScriptTap(script)}
                  onLongPressGesture={{
                    minDuration: 400,
                    perform: () => toggleMultiSelect(script),
                  }}
                  offset={
                    isDragging && pinDrag
                      ? { x: 0, y: pinDrag.offsetY }
                      : { x: 0, y: letOffset }
                  }
                  // 让位行偏移变化时弹簧移动（仿系统 onMove 弹性让位；被拖行不挂动画，保持即时跟随手指）
                  animation={
                    isDragging || pinDrag == null
                      ? undefined
                      : {
                          animation: Animation.spring({
                            duration: 0.3,
                            bounce: 0.25,
                          }),
                          value: letOffset,
                        }
                  }
                  zIndex={isDragging ? 100 : undefined}
                  shadow={
                    isDragging
                      ? { color: "rgba(0,0,0,0.28)", radius: 14, x: 0, y: 6 }
                      : undefined
                  }
                  // 拎起效果：放大 1.1 倍 + 半透明（仿系统/collectionPanSort 长按排序），加阴影浮在其他行上方
                  scaleEffect={isDragging ? 1.1 : undefined}
                  opacity={isDragging ? 0.6 : undefined}
                >
                  {multiSelect.size > 0 ? (
                    <Image
                      systemName={checked ? "checkmark.circle.fill" : "circle"}
                      foregroundStyle={
                        checked ? "systemBlue" : "secondaryLabel"
                      }
                    />
                  ) : (
                    <RowIcon
                      systemName="chevron.left.forwardslash.chevron.right"
                      color="tintColor"
                      onTap={() => openScriptInEditor(script)}
                    />
                  )}
                  <VStack alignment="leading" spacing={2}>
                    <Text font="body">{script.displayName}</Text>
                    <HStack spacing={4}>
                      {config.githubPublishEnabled && isPublishedByTool(script) ? (
                        isCloudDesynced(script, config.publishedVersions, config.cloudVersions) ? (
                          <Image
                            systemName="exclamationmark.icloud.fill"
                            foregroundStyle="systemOrange"
                            imageScale="small"
                          />
                        ) : isCloudContentDesynced(
                            script,
                            config.publishedFingerprints,
                            config.cloudFingerprints,
                            localContentFingerprints
                          ) ? (
                          <Image
                            systemName="cloud.fill"
                            foregroundStyle="systemOrange"
                            font={14} // 普通小黄云：稍大于 small（约 13pt），比感叹号云/绿勾更醒目
                          />
                        ) : (
                          <Image
                            systemName="checkmark.seal.fill"
                            foregroundStyle="systemGreen"
                            imageScale="small"
                          />
                        )
                      ) : null}
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        {metaParts.join(" · ")}
                      </Text>
                    </HStack>
                  </VStack>
                  <Spacer />
                  {isPinned && multiSelect.size === 0 ? (
                    <Image
                      systemName="pin.fill"
                      foregroundStyle="secondaryLabel"
                      imageScale="small"
                      padding={{ top: 2, trailing: 6 }}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={{
                        count: 2,
                        perform: () => rePinToTop(script),
                      }}
                      highPriorityGesture={DragGesture({
                        minDistance: 10,
                        coordinateSpace: "global",
                      })
                        .onChanged((d) => updatePinReorder(script, d))
                        .onEnded(() => finishPinReorder())}
                    />
                  ) : null}
                  <Image
                    systemName="play.circle.fill"
                    foregroundStyle="tintColor"
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => runScript(script)}
                  />
                </HStack>
              )
            })
          )}
        </Section>
      </List>
          )
        }}
      </ScrollViewReader>
    </NavigationStack>
  )
}

// ==================== 设置页 ====================

function SettingsPage() {
  const dismiss = Navigation.useDismiss()
  const savedConfig = useMemo(resolveConfig, [])
  const savedGithub = useMemo(resolveGithubConfig, [])
  const [githubBackupEnabled, setGithubBackupEnabled] = useState(
    savedConfig.githubBackupEnabled
  )
  const [githubPublishEnabled, setGithubPublishEnabled] = useState(
    savedConfig.githubPublishEnabled
  )
  const [rememberExpandState, setRememberExpandState] = useState(
    savedConfig.rememberExpandState
  )
  const [searchKeepAll, setSearchKeepAll] = useState(
    savedConfig.searchKeepAll
  )
  // 首页搜索时关键词是否匹配脚本作者名（默认不勾选）
  const [searchMatchAuthor, setSearchMatchAuthor] = useState(
    savedConfig.searchMatchAuthor
  )
  const [autoBackupOnUpgrade, setAutoBackupOnUpgrade] = useState(
    savedConfig.autoBackupOnUpgrade
  )
  // 是否隐藏首页「恢复备份」模块（默认不勾选）
  const [hideRestoreModule, setHideRestoreModule] = useState(
    savedConfig.hideRestoreModule
  )
  // 首页脚本名称下方是否显示脚本作者（默认勾选）
  const [showScriptAuthor, setShowScriptAuthor] = useState(
    savedConfig.showScriptAuthor
  )
  // 首页脚本名称下方是否显示分组名（默认勾选）
  const [showScriptGroupName, setShowScriptGroupName] = useState(
    savedConfig.showScriptGroupName
  )
  // 自己的用户名（脚本作者名），用于「按脚本作者」排序；不填也能排序，只是不把自己的脚本置顶
  const [authorName, setAuthorName] = useState(savedConfig.authorName)
  // 分组自定义顺序（分组名列表）：首页「按分组」排序时按此顺序显示分组
  const [groupOrder, setGroupOrder] = useState<string[]>(
    savedConfig.groupOrder || []
  )
  // 首页分组过滤（与首页长按「脚本管理」标题共用同一配置）：null=显示全部；数组=仅显示这些分组
  const [homeGroupFilter, setHomeGroupFilter] = useState<string[] | null>(
    savedConfig.homeGroupFilter
  )
  // 首页分组展示顺序（与首页长按「脚本管理」标题共用同一配置）：null=未设置；数组=命名分组展示顺序（上方在前）
  const [homeGroupOrder, setHomeGroupOrder] = useState<string[] | null>(
    savedConfig.homeGroupOrder
  )
  // 当前已存在的命名分组（只在设置页打开时扫描一次）
  const existingGroups = useMemo(() => {
    try {
      return readScriptingGroups()
    } catch {
      return []
    }
  }, [])
  // 生效分组顺序 = 自定义顺序在前，未配置的分组按原顺序附后；丢弃已不存在的分组名
  const groupRows = useMemo(() => {
    const names = existingGroups.map((g) => g.name)
    const countByName = new Map(
      existingGroups.map((g) => [g.name, g.scripts.length])
    )
    const ordered = groupOrder.filter((g) => names.includes(g))
    const rest = names.filter((g) => !ordered.includes(g))
    return [...ordered, ...rest].map((name) => ({
      name,
      count: countByName.get(name) ?? 0,
    }))
  }, [groupOrder, existingGroups])
  const [language, setLanguageState] = useState<"zh" | "en">(
    savedConfig.language
  )
  // 发布与备份可分别配置账号；savedGithub.token/owner 为旧版共用字段，作为兼容回退
  const [publishToken, setPublishToken] = useState(
    savedGithub.publishToken || savedGithub.token
  )
  const [publishOwner, setPublishOwner] = useState(
    savedGithub.publishOwner || savedGithub.owner
  )
  const [repo, setRepo] = useState(savedGithub.repo)
  const [branch, setBranch] = useState(savedGithub.branch)
  const [path, setPath] = useState(savedGithub.path)
  const [backupToken, setBackupToken] = useState(
    savedGithub.backupToken || savedGithub.token
  )
  const [backupOwner, setBackupOwner] = useState(
    savedGithub.backupOwner || savedGithub.owner
  )
  const [backupRepo, setBackupRepo] = useState(savedGithub.backupRepo)
  const [backupBranch, setBackupBranch] = useState(savedGithub.backupBranch)
  const [backupPath, setBackupPath] = useState(savedGithub.backupPath)
  // Github备份/发布 设置项的展开状态：仅在刚打开开关时自动展开，之后默认收起（可点标题展开按钮手动展开）
  const [backupExpanded, setBackupExpanded] = useState(false)
  const [publishExpanded, setPublishExpanded] = useState(false)
  const [checking, setChecking] = useState(false)
  const [errorLogs, setErrorLogs] = useState(resolveErrorLogs)
  // 仓库监控
  const [monitorEnabled, setMonitorEnabled] = useState(
    savedConfig.channelMonitorEnabled
  )
  // 仓库监控：是否发送「有更新」系统通知（默认开启；关闭后监控仍检查，但不再通过通知提示有脚本更新）
  const [monitorNotify, setMonitorNotify] = useState(
    savedConfig.channelMonitorNotificationEnabled !== false
  )
  const [monitorInterval, setMonitorInterval] = useState(
    String(savedConfig.channelMonitorInterval || 12)
  )
  const [monitorUnit, setMonitorUnit] = useState<
    "minute" | "hour" | "day"
  >(savedConfig.channelMonitorIntervalUnit)
  const [monitorLinks, setMonitorLinks] = useState<ChannelMonitorLink[]>(
    normalizeChannelMonitorLinks(savedConfig.channelMonitorLinks)
  )
  const [newMonitorUrl, setNewMonitorUrl] = useState("")
  const [monitorChecking, setMonitorChecking] = useState(false)
  const [excludeKeywords, setExcludeKeywords] = useState<string[]>(
    normalizeChannelExcludeKeywords(
      savedConfig.channelMonitorExcludeKeywords
    )
  )
  const [newExcludeKeyword, setNewExcludeKeyword] = useState("")
  const [monitorIgnoredPaths, setMonitorIgnoredPaths] = useState<string[]>(
    normalizeChannelIgnoredPaths(savedConfig.channelMonitorIgnoredPaths)
  )
  // 仓库监控设置的展开状态：仅首次打开开关时自动展开，之后进入设置页默认收起（标题后有展开按钮）
  const [monitorExpanded, setMonitorExpanded] = useState(false)
  const { showToast, toastProps } = useToast()

  function collect(): GithubConfig {
    return {
      publishToken: publishToken.trim(),
      publishOwner: publishOwner.trim(),
      repo: repo.trim(),
      branch: branch.trim() || "main",
      path: path.trim(),
      backupToken: backupToken.trim(),
      backupOwner: backupOwner.trim(),
      backupRepo: backupRepo.trim(),
      backupBranch: backupBranch.trim() || "main",
      backupPath: backupPath.trim(),
      // 兼容旧字段：保存时同步两套字段，旧版字段与各自专用字段保持一致
      token: (publishToken.trim() || backupToken.trim()).trim(),
      owner: (publishOwner.trim() || backupOwner.trim()).trim(),
    }
  }

  // ---- 自动保存：任意设置变更立即写入配置文件，无需手动点保存 ----
  // AppConfig（通用开关 + 仓库监控等）变更时自动保存
  useEffect(() => {
    const next: AppConfig = {
      ...resolveConfig(),
      githubBackupEnabled,
      githubPublishEnabled,
      rememberExpandState,
      searchKeepAll,
      searchMatchAuthor,
      language,
      autoBackupOnUpgrade,
      hideRestoreModule,
      showScriptAuthor,
      showScriptGroupName,
      authorName: authorName.trim(),
      groupOrder: groupOrder.filter((g) =>
        existingGroups.some((eg) => eg.name === g)
      ),
      homeGroupFilter,
      homeGroupOrder: homeGroupOrder == null ? null : [...homeGroupOrder],
      channelMonitorEnabled: monitorEnabled,
      channelMonitorNotificationEnabled: monitorNotify,
      channelMonitorInterval: Math.max(
        1,
        parseInt(monitorInterval, 10) || 12
      ),
      channelMonitorIntervalUnit: monitorUnit,
      channelMonitorLinks: normalizeChannelMonitorLinks(monitorLinks),
      channelMonitorExcludeKeywords: normalizeChannelExcludeKeywords(
        excludeKeywords
      ),
    }
    // 关闭对应开关后，首页若停留在该 Github 目的地则回到 iPhone，避免显示已隐藏的选项
    if (!githubBackupEnabled && next.destination === "github_backup") {
      next.destination = "iphone"
    }
    if (!githubPublishEnabled && next.destination === "github_publish") {
      next.destination = "iphone"
    }
    // 关闭「显示脚本分组」后，首页若按分组排序则回到最新修改，避免显示已隐藏的选项
    if (!showScriptGroupName && next.scriptSort === "group") {
      next.scriptSort = "modified"
    }
    saveConfig(next)
  }, [
    githubBackupEnabled,
    githubPublishEnabled,
    rememberExpandState,
    searchKeepAll,
    searchMatchAuthor,
    language,
    autoBackupOnUpgrade,
    hideRestoreModule,
    showScriptAuthor,
    showScriptGroupName,
    authorName,
    groupOrder,
    homeGroupFilter,
    homeGroupOrder,
    monitorEnabled,
    monitorNotify,
    monitorInterval,
    monitorUnit,
    monitorLinks,
    excludeKeywords,
  ])

  // Github 配置（发布/备份的 Token、仓库、分支、目录等输入框）变更时自动保存
  useEffect(() => {
    saveGithubConfig(collect())
  }, [
    publishToken,
    publishOwner,
    repo,
    branch,
    path,
    backupToken,
    backupOwner,
    backupRepo,
    backupBranch,
    backupPath,
  ])

  async function verify() {
    const gh = collect()
    // 优先验证发布 Token，未填则回退到备份 Token
    const token = gh.publishToken || gh.backupToken
    if (!token) {
      showToast(t("请先填写 GitHub Token"), true)
      return
    }
    setChecking(true)
    try {
      const login = await githubVerify(token)
      if (gh.publishToken) {
        if (!gh.publishOwner) {
          setPublishOwner(login)
        }
        saveGithubConfig({ ...gh, publishOwner: gh.publishOwner || login })
      } else {
        if (!gh.backupOwner) {
          setBackupOwner(login)
        }
        saveGithubConfig({ ...gh, backupOwner: gh.backupOwner || login })
      }
      showToast(tpl("Token 有效：@{login}", { login }))
    } catch (error) {
      logError("验证Token", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setChecking(false)
    }
  }

  // ---- 仓库监控：链接管理 + 立即检查 ----
  function addMonitorLink() {
    const url = normalizeRepoUrl(newMonitorUrl)
    if (!url) {
      showToast(
        t("链接无效，请输入形如 https://github.com/所有者/仓库名 的 GitHub 地址"),
        true
      )
      return
    }
    if (monitorLinks.some((l) => l.url === url)) {
      showToast(t("该仓库已在监控列表中"), true)
      return
    }
    setMonitorLinks([
      ...monitorLinks,
      { url, name: repoDisplayName(url) },
    ])
    setNewMonitorUrl("")
  }

  async function renameMonitorLink(link: ChannelMonitorLink) {
    const name = await inputPrompt({
      title: t("修改备注名"),
      message: link.url,
      defaultValue: link.name,
      placeholder: t("仓库备注名"),
    })
    if (name == null) return
    const trimmed = name.trim()
    setMonitorLinks(
      monitorLinks.map((l) =>
        l.url === link.url
          ? { ...l, name: trimmed || repoDisplayName(link.url) }
          : l
      )
    )
  }

  async function editMonitorLink(link: ChannelMonitorLink) {
    const url = await inputPrompt({
      title: t("修改仓库链接"),
      message: link.name,
      defaultValue: link.url,
      placeholder: "https://github.com/owner/repo",
    })
    if (url == null) return
    const normalized = normalizeRepoUrl(url)
    if (!normalized) {
      showToast(
        t("链接无效，请输入形如 https://github.com/所有者/仓库名 的 GitHub 地址"),
        true
      )
      return
    }
    if (
      monitorLinks.some((l) => l.url === normalized && l.url !== link.url)
    ) {
      showToast(t("该仓库已在监控列表中"), true)
      return
    }
    setMonitorLinks(
      monitorLinks.map((l) =>
        l.url === link.url ? { ...l, url: normalized } : l
      )
    )
    showToast(t("修改成功"))
  }

  function removeMonitorLink(link: ChannelMonitorLink) {
    // 即时删除，不弹确认框（confirm 在本页嵌套模态中不工作，且删除为轻量操作）
    setMonitorLinks(monitorLinks.filter((l) => l.url !== link.url))
    showToast(t("删除成功"))
  }

  function addExcludeKeyword() {
    const kw = newExcludeKeyword.trim()
    if (!kw) {
      showToast(t("请输入排除关键词"), true)
      return
    }
    if (excludeKeywords.some((k) => k === kw)) {
      showToast(t("该关键词已存在"), true)
      return
    }
    setExcludeKeywords([...excludeKeywords, kw])
    setNewExcludeKeyword("")
  }

  async function editExcludeKeyword(kw: string) {
    const value = await inputPrompt({
      title: t("修改排除关键词"),
      defaultValue: kw,
      placeholder: t("如：测试、请勿下载"),
    })
    if (value == null) return
    const trimmed = value.trim()
    if (!trimmed) {
      showToast(t("请输入排除关键词"), true)
      return
    }
    if (excludeKeywords.some((k) => k === trimmed && k !== kw)) {
      showToast(t("该关键词已存在"), true)
      return
    }
    setExcludeKeywords(
      excludeKeywords.map((k) => (k === kw ? trimmed : k))
    )
    showToast(t("修改成功"))
  }

  function removeExcludeKeyword(kw: string) {
    // 即时删除，不弹确认框（confirm 在本页嵌套模态中不工作，且删除为轻量操作）
    setExcludeKeywords(excludeKeywords.filter((k) => k !== kw))
    showToast(t("删除成功"))
  }

  // 恢复「已忽略更新」脚本的提醒：从忽略列表移除该路径，之后该脚本再发新版会正常提示
  function removeIgnoredPath(key: string) {
    const next = monitorIgnoredPaths.filter((k) => k !== key)
    setMonitorIgnoredPaths(next)
    updateChannelMonitorConfig({ channelMonitorIgnoredPaths: next })
    showToast(t("已恢复提醒"))
  }

  async function checkNow() {
    if (!monitorEnabled) {
      showToast(t("请先打开仓库监控开关"), true)
      return
    }
    setMonitorChecking(true)
    try {
      const summary = await runChannelMonitorCheck()
      const okCount = summary.results.filter((r) => r.ok).length
      const failCount = summary.results.length - okCount
      const excludedTotal = summary.results.reduce(
        (n, r) => n + (r.excludedCount ?? 0),
        0
      )
      if (summary.newBaseline) {
        const total = summary.results.reduce(
          (n, r) => n + r.scriptCount,
          0
        )
        showToast(
          tpl("已建立基线：共 {n} 个仓库、{m} 个脚本，之后有变化会提醒", {
            n: String(okCount),
            m: String(total),
          })
        )
      } else if (summary.totalChanges > 0) {
        showToast(
          tpl("发现 {n} 个脚本有更新", {
            n: String(summary.totalChanges),
          })
        )
        notifyChannelChanges(summary.results)
      } else if (failCount > 0) {
        showToast(
          tpl("{n} 个仓库检查失败，请检查链接或网络", {
            n: String(failCount),
          }),
          true
        )
      } else if (excludedTotal > 0) {
        showToast(
          tpl("{n} 个脚本因排除关键词未显示", { n: String(excludedTotal) })
        )
      } else {
        showToast(t("检查完成，没有发现更新"))
      }
    } catch (error) {
      logError("仓库监控", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setMonitorChecking(false)
    }
  }

  return (
    <List
      navigationTitle={t("设置")}
      navigationBarTitleDisplayMode="inline"
      toast={toastProps}
      // 从屏幕左边缘向右划动手势 → 返回上一页（模态页没有系统边缘返回手势，这里手动实现；
      // 用 simultaneousGesture 不抢占列表滚动，只有明确从边缘开始的右滑才触发 dismiss）
      simultaneousGesture={
        DragGesture({ coordinateSpace: "global", minDistance: 20 })
          .onEnded((d) => {
            if (
              d.startLocation.x < 40 &&
              (d.translation.width > 100 || d.velocity.width > 600)
            ) {
              dismiss()
            }
          })
      }
      toolbar={
        <Toolbar>
          <ToolbarItem placement="topBarLeading">
            <Button title={t("关闭")} action={dismiss} />
          </ToolbarItem>
          <ToolbarItem placement="topBarTrailing">
            <Button
              title={checking ? t("验证中…") : t("验证 Token")}
              action={() => verify()}
            />
          </ToolbarItem>
        </Toolbar>
      }
    >
      <Section
        header={
          <HStack
            spacing={8}
            alignment="center"
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => setBackupExpanded(!backupExpanded)}
          >
            <Text font="headline">{t("GitHub 备份")}</Text>
            <Spacer />
            <HStack spacing={4} alignment="center">
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {backupExpanded ? t("收起") : t("展开")}
              </Text>
              <Image
                systemName={backupExpanded ? "chevron.up" : "chevron.down"}
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          </HStack>
        }
        footer={
          <Text font="footnote">
            {t("首页「备份到 → Github备份」把脚本打包为 zip 上传到私密备份仓库，仅用于备份，不影响脚本更新链接。备份仓库不存在时会自动创建，默认私密。备份 Token 与所有者可独立于发布设置；若留空则自动沿用发布账号")}
          </Text>
        }
      >
        <Toggle
          title={t("开启Github备份功能")}
          value={githubBackupEnabled}
          onChanged={(v) => {
            setGithubBackupEnabled(v)
            if (v) setBackupExpanded(true)
          }}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("勾选后首页显示「Github备份」入口（可把脚本打包 zip 上传到私密仓库备份）")}
        </Text>
        {githubBackupEnabled && backupExpanded ? (
          <>
          <TextField
            title={t("Token（备份）")}
            value={backupToken}
            onChanged={setBackupToken}
            prompt="GitHub Personal Access Token"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("填 GitHub 个人访问令牌。获取：GitHub 网页 → 右上角头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限 → 生成后复制 ghp_… 粘贴到这里。备份可用独立 Token（与发布不同账号）；留空自动沿用发布 Token")}
          </Text>
          <TextField
            title={t("仓库所有者（备份）")}
            value={backupOwner}
            onChanged={setBackupOwner}
            prompt={t("如 vvvvvveng")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("备份仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。备份可用独立所有者（不同账号）；留空自动沿用发布所有者")}
          </Text>
          <TextField
            title={t("备份仓库名（必填）")}
            value={backupRepo}
            onChanged={setBackupRepo}
            prompt={t("如 scripting-backups")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("必填：存放备份 zip 的仓库名（私密）。若不存在，首次备份时会自动创建私密仓库，其他人不可见")}
          </Text>
          <TextField
            title={t("备份分支")}
            value={backupBranch}
            onChanged={setBackupBranch}
            prompt="main"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("备份到的分支，一般用默认的 main，留空自动填 main")}
          </Text>
          <TextField
            title={t("仓库内目录")}
            value={backupPath}
            onChanged={setBackupPath}
            prompt={t("留空为根目录，如 backups")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("备份 zip 放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 backups")}
          </Text>
          </>
        ) : null}
      </Section>

      <Section
        header={
          <HStack
            spacing={8}
            alignment="center"
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => setPublishExpanded(!publishExpanded)}
          >
            <Text font="headline">{t("GitHub 发布")}</Text>
            <Spacer />
            <HStack spacing={4} alignment="center">
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {publishExpanded ? t("收起") : t("展开")}
              </Text>
              <Image
                systemName={publishExpanded ? "chevron.up" : "chevron.down"}
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          </HStack>
        }
        footer={
          <Text font="footnote">
            {t("首页「备份到 → Github发布」即可把脚本打包为 .scripting 上传到公开仓库并同步更新脚本的远程更新链接（remoteResource）。发布仓库不存在时会自动创建，默认公开。发布 Token 与所有者可独立于备份设置；若留空则自动沿用备份账号")}
          </Text>
        }
      >
        <Toggle
          title={t("开启Github发布功能")}
          value={githubPublishEnabled}
          onChanged={(v) => {
            setGithubPublishEnabled(v)
            if (v) setPublishExpanded(true)
          }}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("只有开发者才用得上：勾选后显示「Github发布」入口（可把脚本作为可更新版本发布到公开仓库）")}
        </Text>
        {githubPublishEnabled && publishExpanded ? (
          <>
          <TextField
            title={t("Token（发布）")}
            value={publishToken}
            onChanged={setPublishToken}
            prompt="GitHub Personal Access Token"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("填 GitHub 个人访问令牌，与备份可用不同账号。获取方式同备份：GitHub 网页 → 头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限。留空自动沿用备份 Token")}
          </Text>
          <TextField
            title={t("仓库所有者（发布）")}
            value={publishOwner}
            onChanged={setPublishOwner}
            prompt={t("如 vvvvvveng")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("发布仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。发布可用独立所有者（不同账号）；留空自动沿用备份所有者")}
          </Text>
          <TextField
            title={t("发布仓库名（必填）")}
            value={repo}
            onChanged={setRepo}
            prompt={t("如 scripting-releases")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("必填：接收发布文件的仓库名（公开）。若不存在，首次发布时会自动创建公开仓库，无需手动建仓")}
          </Text>
          <TextField
            title={t("发布分支")}
            value={branch}
            onChanged={setBranch}
            prompt="main"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("发布到的分支，一般用默认的 main，留空自动填 main。如仓库默认分支是 master 就填 master")}
          </Text>
          <TextField
            title={t("仓库内目录")}
            value={path}
            onChanged={setPath}
            prompt={t("留空为根目录，如 releases")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("发布文件放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 releases。脚本会在该目录下按脚本名生成 .scripting 文件")}
          </Text>
          </>
        ) : null}
      </Section>

      <Section
        header={
          <HStack
            spacing={8}
            alignment="center"
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => setMonitorExpanded(!monitorExpanded)}
          >
            <Text font="headline">{t("仓库监控")}</Text>
            <Spacer />
            <HStack spacing={4} alignment="center">
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {monitorExpanded ? t("收起") : t("展开")}
              </Text>
              <Image
                systemName={monitorExpanded ? "chevron.up" : "chevron.down"}
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          </HStack>
        }
        footer={
          <Text font="footnote">
            {t("打开后定时检查监控仓库里的 .scripting 脚本是否有更新，有变化时发通知提醒。应用在前台或后台保活期间按间隔自动检查；被系统挂起后，每次打开应用会补查，并按间隔发送提醒通知（点通知立即检查）。开启后首页右上角会增加一个手动检测按钮。首次启用只记录，之后有变化才提示")}
          </Text>
        }
      >
        <Toggle
          title={t("开启仓库监控功能")}
          value={monitorEnabled}
          onChanged={(v) => {
            setMonitorEnabled(v)
            // 打开/关闭监控开关时同步开关通知开关（之后仍可单独调整）
            setMonitorNotify(v)
            // 仅首次打开开关时自动展开，之后默认收起
            if (v) setMonitorExpanded(true)
          }}
        />
        <Toggle
          title={t("打开监控通知")}
          value={monitorNotify}
          onChanged={setMonitorNotify}
        />
        {monitorEnabled ? (
          <>
            {monitorExpanded ? (
              <>
                <HStack spacing={10} alignment="center">
                  <TextField
                    title={t("检查间隔")}
                    value={monitorInterval}
                    onChanged={setMonitorInterval}
                    keyboardType="numberPad"
                    frame={{ maxWidth: 150 }}
                  />
                  <Picker
                    value={monitorUnit}
                    onChanged={(v: string | number) =>
                      setMonitorUnit(
                        String(v) === "hour" || String(v) === "day"
                          ? (String(v) as "hour" | "day")
                          : "minute"
                      )
                    }
                    pickerStyle="menu"
                    label={<Text font="body">{t("单位")}</Text>}
                  >
                    <Text tag="minute">{t("分")}</Text>
                    <Text tag="hour">{t("小时")}</Text>
                    <Text tag="day">{t("天")}</Text>
                  </Picker>
                  <Spacer />
                </HStack>
                <Text font="footnote" foregroundStyle="secondaryLabel">
                  {t("默认 12 小时，最短 1 分钟；按间隔自动检查并发送提醒通知")}
                </Text>

                {monitorLinks.map((link) => (
                  <HStack key={link.url} spacing={10} alignment="center">
                    <VStack
                      alignment="leading"
                      spacing={2}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={() => editMonitorLink(link)}
                    >
                      <Text font="body">{link.name}</Text>
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        {link.url}
                      </Text>
                    </VStack>
                    <Spacer />
                    <HStack
                      spacing={4}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={() => renameMonitorLink(link)}
                    >
                      <Image
                        systemName="pencil"
                        foregroundStyle="tintColor"
                      />
                      <Text font="footnote" foregroundStyle="tintColor">
                        {t("备注")}
                      </Text>
                    </HStack>
                    <HStack
                      spacing={4}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={() => removeMonitorLink(link)}
                    >
                      <Image
                        systemName="trash"
                        foregroundStyle="systemRed"
                      />
                      <Text font="footnote" foregroundStyle="systemRed">
                        {t("删除")}
                      </Text>
                    </HStack>
                  </HStack>
                ))}

                <HStack spacing={10} alignment="center">
                  <TextField
                    title={t("添加仓库链接")}
                    value={newMonitorUrl}
                    onChanged={setNewMonitorUrl}
                    prompt="https://github.com/owner/repo"
                  />
                  <HStack
                    spacing={4}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={addMonitorLink}
                  >
                    <Image systemName="plus.circle" foregroundStyle="tintColor" />
                    <Text font="footnote" foregroundStyle="tintColor">
                      {t("添加")}
                    </Text>
                  </HStack>
                </HStack>

                <Text font="body" padding={{ top: 6 }}>
                  {t("排除关键词")}
                </Text>
                <Text font="footnote" foregroundStyle="secondaryLabel">
                  {t("脚本名称包含任一关键词时，即使有更新也不提示、不列入更新页（例如排除「测试」可忽略测试脚本）")}
                </Text>
                {excludeKeywords.length > 0 ? (
                  excludeKeywords.map((kw) => (
                    <HStack key={kw} spacing={10} alignment="center">
                      <HStack
                        spacing={10}
                        alignment="center"
                        contentShape={{ kind: "interaction", shape: "rect" }}
                        onTapGesture={() => editExcludeKeyword(kw)}
                      >
                        <Image
                          systemName="nosign"
                          foregroundStyle="systemRed"
                        />
                        <Text font="body">{kw}</Text>
                      </HStack>
                      <Spacer />
                      <HStack
                        spacing={4}
                        contentShape={{ kind: "interaction", shape: "rect" }}
                        onTapGesture={() => removeExcludeKeyword(kw)}
                      >
                        <Image
                          systemName="xmark.circle"
                          foregroundStyle="systemRed"
                        />
                        <Text font="footnote" foregroundStyle="systemRed">
                          {t("删除")}
                        </Text>
                      </HStack>
                    </HStack>
                  ))
                ) : (
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {t("未设置排除关键词")}
                  </Text>
                )}
                <HStack spacing={10} alignment="center">
                  <TextField
                    title={t("添加排除关键词")}
                    value={newExcludeKeyword}
                    onChanged={setNewExcludeKeyword}
                    prompt={t("如：测试、请勿下载")}
                  />
                  <HStack
                    spacing={4}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={addExcludeKeyword}
                  >
                    <Image systemName="plus.circle" foregroundStyle="tintColor" />
                    <Text font="footnote" foregroundStyle="tintColor">
                      {t("添加")}
                    </Text>
                  </HStack>
                </HStack>
              </>
            ) : null}

            {/* 已忽略更新的脚本：点「忽略全部」后按路径持久化忽略，这里可恢复提醒 */}
            {monitorExpanded ? (
              <>
                <VStack alignment="leading" spacing={4} padding={{ top: 6 }}>
                  <Text font="body">{t("已忽略更新的脚本")}</Text>
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {t("这些脚本再发布新版本也不会提示；点「恢复提醒」后正常提示")}
                  </Text>
                </VStack>
                {monitorIgnoredPaths.length > 0 ? (
                  monitorIgnoredPaths.map((key) => {
                    const d = ignoredPathDisplay(key)
                    return (
                      <HStack key={key} spacing={10} alignment="center">
                        <Image
                          systemName="bell.slash"
                          foregroundStyle="secondaryLabel"
                        />
                        <VStack alignment="leading" spacing={2}>
                          <Text font="body">{d.name}</Text>
                          <Text font="caption" foregroundStyle="secondaryLabel">
                            {d.repo}
                          </Text>
                        </VStack>
                        <Spacer />
                        <HStack
                          spacing={4}
                          contentShape={{ kind: "interaction", shape: "rect" }}
                          onTapGesture={() => removeIgnoredPath(key)}
                        >
                          <Image
                            systemName="bell.badge"
                            foregroundStyle="tintColor"
                          />
                          <Text font="footnote" foregroundStyle="tintColor">
                            {t("恢复提醒")}
                          </Text>
                        </HStack>
                      </HStack>
                    )
                  })
                ) : (
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {t("未忽略任何脚本")}
                  </Text>
                )}
              </>
            ) : null}

            {/* 立即检查：始终显示，不随设置区折叠 */}
            <HStack
              spacing={8}
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={checkNow}
            >
              <Spacer />
              <Image
                systemName={
                  monitorChecking
                    ? "antenna.radiowaves.left.and.right"
                    : "arrow.clockwise"
                }
                foregroundStyle="tintColor"
              />
              <Text font="body" foregroundStyle="tintColor">
                {monitorChecking ? t("检查中…") : t("立即检查")}
              </Text>
              <Spacer />
            </HStack>
          </>
        ) : null}
      </Section>

      <Section
        header={<Text font="headline">{t("通用")}</Text>}
        footer={
          <Text font="footnote">
            {t("所有设置修改后自动保存，无需手动保存")}
          </Text>
        }
      >
        <HStack spacing={10}>
          <Picker
            value={language}
            onChanged={(v: string | number) => {
              const next = String(v) === "en" ? "en" : "zh"
              setLanguageState(next)
              // 语言立即生效（主页面通过订阅强制重渲染）
              setLanguage(next)
            }}
            pickerStyle="menu"
            label={
              // label 保持左侧不动；Picker 撑满整行，让右侧蓝色选中值（中文/English）贴到最右
              <Text font="body" frame={{ minWidth: 210, alignment: "leading" }}>
                {t("语言 / Language")}
              </Text>
            }
            frame={{ maxWidth: "infinity" }}
          >
            <Text tag="zh">中文</Text>
            <Text tag="en">English</Text>
          </Picker>
        </HStack>
        <TextField
          title={t("我的用户名")}
          value={authorName}
          onChanged={setAuthorName}
          prompt={t("如 WWWeng🐝")}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("填入自己的用户名（脚本作者名）后，按脚本作者排序会把你的脚本固定排最前；不填也能排序（全部脚本按作者名 A-Z 分组），只是无法把脚本置顶")}
        </Text>
        <HStack spacing={8} alignment="center">
          <Text
            font="body"
            frame={{ maxWidth: "infinity", alignment: "leading" }}
          >
            {t("设置分组顺序")}
          </Text>
          <Button
            action={() => {
              Navigation.present(
                <GroupOrderEditPage
                  rows={groupRows}
                  checked={
                    new Set(
                      homeGroupFilter == null
                        ? groupRows.map((r) => r.name)
                        : homeGroupFilter.filter((n) =>
                            groupRows.some((r) => r.name === n)
                          )
                    )
                  }
                  allChecked={
                    groupRows.length > 0 &&
                    (homeGroupFilter == null ||
                      groupRows.every((r) =>
                        homeGroupFilter.includes(r.name)
                      ))
                  }
                  onToggleChecked={(name) => {
                    setHomeGroupFilter((prev) => {
                      const names = groupRows.map((r) => r.name)
                      // 当前视为勾选的命名分组：null=全选；数组=其中的命名分组
                      const cur = new Set(
                        prev == null
                          ? names
                          : prev.filter((n) => names.includes(n))
                      )
                      // 保留未分组显示状态：null 时未分组也显示；数组含空串时也显示
                      const ungroupedShown = prev == null || prev.includes("")
                      if (cur.has(name)) {
                        cur.delete(name)
                      } else {
                        cur.add(name)
                      }
                      // 命名分组全部勾选 → 还原为 null（显示全部）；否则保存勾选数组
                      if (cur.size === names.length && names.length > 0) {
                        return ungroupedShown ? null : [...names]
                      }
                      return ungroupedShown ? [...cur, ""] : [...cur]
                    })
                  }}
                  onToggleAll={() => {
                    setHomeGroupFilter((prev) => {
                      const names = groupRows.map((r) => r.name)
                      const ungroupedShown =
                        prev == null || prev.includes("")
                      const allChecked =
                        groupRows.length > 0 &&
                        (prev == null ||
                          groupRows.every((r) => prev.includes(r.name)))
                      // 全选 → 还原为 null（显示全部）；取消全选 → 只保留未分组显示状态
                      if (allChecked) {
                        return ungroupedShown ? null : names
                      }
                      return ungroupedShown ? [""] : []
                    })
                  }}
                  onChange={(next) => {
                    setGroupOrder(next)
                    // 与首页筛选分组页共用同一份展示顺序：设置页拖动后同步首页展示顺序（同向一致）
                    setHomeGroupOrder(next.length > 0 ? [...next] : null)
                  }}
                />
              )
            }}
            buttonStyle="bordered"
            buttonBorderShape="capsule"
            controlSize="small"
            title={t("调整")}
          />
        </HStack>
        <Toggle
          title={t("记住展开状态")}
          value={rememberExpandState}
          onChanged={setRememberExpandState}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("勾选后记住首页左上角「备份 / 恢复」的展开 / 收起状态，下次打开仍保持（默认勾选）")}
        </Text>
        <Toggle
          title={t("显示脚本作者")}
          value={showScriptAuthor}
          onChanged={setShowScriptAuthor}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("首页脚本名称下方的灰色说明字显示脚本作者（默认勾选）")}
        </Text>
        <Toggle
          title={t("显示脚本分组")}
          value={showScriptGroupName}
          onChanged={setShowScriptGroupName}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("首页脚本名称下方的灰色说明字显示脚本所在分组（默认勾选）")}
        </Text>
        <Toggle
          title={t("搜索显示全部")}
          value={searchKeepAll}
          onChanged={setSearchKeepAll}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("首页搜索时仍显示全部脚本，匹配的排在前面；关闭后只显示匹配的脚本（默认勾选）")}
        </Text>
        <Toggle
          title={t("搜索包含作者")}
          value={searchMatchAuthor}
          onChanged={setSearchMatchAuthor}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("首页搜索时关键词也能匹配脚本作者名（默认不勾选）")}
        </Text>
        <Toggle
          title={t("自动备份更新")}
          value={autoBackupOnUpgrade}
          onChanged={setAutoBackupOnUpgrade}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("检测到脚本版本变化、或脚本内容被刷新（版本号未变）后，先刷新脚本内容，内容稳定后才自动备份到 iPhone 端，避免备份到旧内容（默认不勾选）")}
        </Text>
        <Toggle
          title={t("隐藏恢复模块")}
          value={hideRestoreModule}
          onChanged={setHideRestoreModule}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("勾选后首页不显示「恢复备份」模块（默认不勾选）")}
        </Text>
      </Section>

      <Section
        header={<Text font="headline">{t("反馈")}</Text>}
        footer={
          <Text font="footnote">
            {t("使用中遇到问题或有功能建议？欢迎到 WWWeng🐝的仓库提 Issue，或发邮件联系")}
          </Text>
        }
      >
        <Link url="https://github.com/vvvvvveng/Scripting-releases/tree/main">
          <HStack spacing={10}>
            <Image systemName="link" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              {t("我的仓库")}
            </Text>
            <Spacer />
          </HStack>
        </Link>
        <Link url="https://t.me/WWWengShare">
          <HStack spacing={10}>
            <Image systemName="paperplane" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              {t("我的频道")}
            </Text>
            <Spacer />
          </HStack>
        </Link>
        <Link url="mailto:skype-lavish-yeast@duck.com">
          <HStack spacing={10}>
            <Image systemName="envelope" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              {t("我的邮箱")}
            </Text>
            <Spacer />
          </HStack>
        </Link>
      </Section>

      <Section
        header={<Text font="headline">{t("错误记录")}</Text>}
        footer={
          <Text font="footnote">
            {t("最近失败的备份 / 发布 / 恢复等操作会记录在这里（最多保留 50 条），方便排查问题")}
          </Text>
        }
      >
        {errorLogs.length === 0 ? (
          <EmptyState message={t("暂无错误记录")} />
        ) : (
          errorLogs.slice(0, 20).map((log, index) => (
            <VStack key={`${log.time}-${index}`} alignment="leading" spacing={3}>
              <HStack spacing={8}>
                <Text font="caption" foregroundStyle="secondaryLabel">
                  {formatDate(log.time)}
                </Text>
                <Text font="caption" foregroundStyle="systemOrange">
                  {t(log.operation)}
                </Text>
              </HStack>
              <Text font="caption" foregroundStyle="secondaryLabel">
                {log.message}
              </Text>
            </VStack>
          ))
        )}
        {errorLogs.length > 0 && (
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => {
              clearErrorLogs()
              setErrorLogs([])
              showToast(t("已清空错误记录"))
            }}
          >
            <Spacer />
            <Image systemName="trash" foregroundStyle="systemRed" />
            <Text font="body" foregroundStyle="systemRed">{t("清空错误记录")}</Text>
            <Spacer />
          </HStack>
        )}
      </Section>
    </List>
  )
}

// ==================== 分组顺序拖拽编辑页 ====================

/** 分组顺序编辑页：进入编辑模式后按住行右侧手柄拖动即可调整分组顺序；每行左侧可勾选该分组是否显示在首页；底部悬浮条支持全选/取消全选与保存 */
function GroupOrderEditPage({
  rows,
  checked,
  allChecked,
  onToggleChecked,
  onToggleAll,
  onChange,
}: {
  rows: { name: string; count: number }[]
  /** 当前勾选为「显示在首页」的分组名集合 */
  checked: Set<string>
  /** 命名分组是否全部勾选 */
  allChecked: boolean
  onToggleChecked: (name: string) => void
  /** 全选 / 取消全选 */
  onToggleAll: () => void
  onChange: (next: string[]) => void
}) {
  const [items, setItems] = useState(rows)
  const editMode = useObservable(() => EditMode.active())
  function onMove(indices: number[], newOffset: number) {
    const movingItems = indices.map((i) => items[i])
    const rest = items.filter((_, i) => !indices.includes(i))
    const target = Math.max(0, Math.min(newOffset, rest.length))
    rest.splice(target, 0, ...movingItems)
    setItems(rest)
    onChange(rest.map((r) => r.name))
  }

  return (
    <NavigationStack>
      <List
        navigationTitle={t("调整分组顺序")}
        navigationBarTitleDisplayMode="inline"
        environments={{ editMode }}
        toolbar={
          <Toolbar>
            <ToolbarItem placement="topBarTrailing">
              <Button
                title={allChecked ? t("取消全选") : t("全选")}
                action={onToggleAll}
              />
            </ToolbarItem>
          </Toolbar>
        }
      >
        {items.length === 0 ? (
          <Text font="footnote" foregroundStyle="tertiaryLabel">
            {t("暂无分组")}
          </Text>
        ) : (
          <ForEach
            count={items.length}
            itemBuilder={(index) => {
              const item = items[index]
              const isChecked = checked.has(item.name)
              return (
                <HStack
                  key={item.name}
                  spacing={8}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => onToggleChecked(item.name)}
                >
                  <Image
                    systemName={isChecked ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={
                      isChecked ? "tintColor" : "secondaryLabel"
                    }
                  />
                  <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                    <Text font="body">
                      {item.name === "" ? t("未分组") : item.name}
                    </Text>
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      {item.count}
                      {t("个")}
                    </Text>
                  </VStack>
                </HStack>
              )
            }}
            onMove={onMove}
          />
        )}
        <Section>
          <VStack alignment="leading" spacing={2}>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("①左侧勾选控制该分组是否显示在首页，与首页长按「脚本管理」标题的勾选一致")}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("②长按拖动分组即可")}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("③这里调整的顺序与首页长按「脚本管理」进入的筛选分组页顺序一致，两处任意一处调整都会同步")}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("④按分组排序时，列表最上方显示的就是这个列表最上方的分组")}
            </Text>
          </VStack>
        </Section>
      </List>
    </NavigationStack>
  )
}

// ==================== 首页分组筛选页 ====================

/** 首页长按「脚本管理」标题进入：勾选要显示的分组；未分组脚本 key 为空串、固定在列表最下方不可拖动；置顶脚本不受过滤影响；长按拖动可调整命名分组展示顺序。每行显示分组内脚本个数（与设置页分组顺序编辑一致） */
function GroupFilterPage({
  options,
  initial,
  initialOrder,
  onSave,
}: {
  /** 可勾选的分组列表（name 为空串表示未分组，固定在末尾），已按当前展示顺序排好，count 为该分组内脚本个数 */
  options: { name: string; count: number }[]
  /** 当前过滤名单：null=不过滤（显示全部）；数组=仅显示这些分组 */
  initial: string[] | null
  /** 当前已保存的分组展示顺序：null=未设置 */
  initialOrder: string[] | null
  /** 保存结果：next=null 显示全部、数组=仅显示勾选分组（空数组=只显示置顶）；order=分组展示顺序（null=未调整，保持原设置）；moved=是否拖动过分组顺序 */
  onSave: (next: string[] | null, order: string[] | null, moved?: boolean) => void
}) {
  // 可拖动排序：命名分组可拖动调整顺序；未分组固定在 options 末尾、不可拖动（moveDisabled）。
  // 不渲染任何额外拖动图标——系统是否出现拖动手柄由 iOS 编辑模式决定（有 onMove 时自动带上，无法单独隐藏）。
  const hasUngrouped = options.some((o) => o.name === "")
  const [items, setItems] = useState(() => [...options])
  const [moved, setMoved] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(() =>
    new Set(
      initial == null
        ? options.map((o) => o.name)
        : initial.filter((k) => options.some((o) => o.name === k))
    )
  )
  const editMode = useObservable(() => EditMode.active())
  const allSelected = options.length > 0 && selected.size === options.length

  function toggle(key: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(key)) {
        next.delete(key)
      } else {
        next.add(key)
      }
      return next
    })
  }

  // 长按拖动调整命名分组展示顺序；未分组固定末尾：无论怎么拖，结束后把它强制弹回列表末尾
  function onMove(indices: number[], newOffset: number) {
    const movingItems = indices.map((i) => items[i])
    const rest = items.filter((_, i) => !indices.includes(i))
    const target = Math.max(0, Math.min(newOffset, rest.length))
    rest.splice(target, 0, ...movingItems)
    if (hasUngrouped) {
      const gi = rest.findIndex((o) => o.name === "")
      if (gi !== -1) rest.push(rest.splice(gi, 1)[0])
    }
    setItems(rest)
    setMoved(true)
  }

  // 保存当前勾选与分组展示顺序（关闭页面自动保存，右上角「全选/取消全选」仅切换勾选）
  function saveNow() {
    const order = moved ? items.map((o) => o.name) : initialOrder
    onSave(allSelected ? null : [...selected], order, moved)
  }

  return (
    // 关闭页面自动保存：onDisappear 挂在外层 NavigationStack 根上（比挂在 List 上更可靠，
    // 覆盖点返回/滑动关闭/系统手势等所有关闭方式）
    <NavigationStack onDisappear={saveNow}>
      <List
        navigationTitle={t("筛选分组")}
        navigationBarTitleDisplayMode="inline"
        environments={{ editMode }}
        toolbar={
          <Toolbar>
            <ToolbarItem placement="topBarTrailing">
              <Button
                title={allSelected ? t("取消全选") : t("全选")}
                action={() =>
                  setSelected(
                    allSelected
                      ? new Set()
                      : new Set(options.map((o) => o.name))
                  )
                }
              />
            </ToolbarItem>
          </Toolbar>
        }
      >
        {options.length === 0 ? (
          <Text font="footnote" foregroundStyle="tertiaryLabel">
            {t("暂无分组")}
          </Text>
        ) : (
          <ForEach
            count={items.length}
            itemBuilder={(index) => {
              const item = items[index]
              const checked = selected.has(item.name)
              return (
                <HStack
                  key={item.name}
                  spacing={10}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => toggle(item.name)}
                  moveDisabled={item.name === ""}
                >
                  <Image
                    systemName={checked ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={
                      checked ? "tintColor" : "secondaryLabel"
                    }
                  />
                  <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                    <Text font="body">
                      {item.name === "" ? t("未分组") : item.name}
                    </Text>
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      {item.count}
                      {t("个")}
                    </Text>
                  </VStack>
                </HStack>
              )
            }}
            onMove={onMove}
          />
        )}
        {/* 注释逐行显示在分组底下，不留白底 */}
        <VStack
          alignment="leading"
          spacing={4}
          padding={{ top: 8, bottom: 8 }}
          listRowBackground={<Rectangle fill="rgba(0,0,0,0)" />}
        >
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("① 勾选要在首页脚本管理显示的分组；置顶的脚本不受影响，始终显示")}
          </Text>
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("② 分组排序顺序在最上方的就是最先显示在脚本管理界面的脚本")}
          </Text>
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("③ 这里调整的顺序与设置页「调整分组顺序」页一致，两处任意一处调整都会同步生效")}
          </Text>
        </VStack>
      </List>
    </NavigationStack>
  )
}

// ==================== 频道更新页 ====================

/**
 * 全新脚本交给 Scripting 导入页面后，工具无法获知导入完成的时机（Safari.openURL 只是打开
 * scripting://import_scripts URL，不等导入结果；应用内导航返回也不一定触发 onResume）。
 * 这里轮询检测目标脚本目录是否出现：一旦出现（导入完成），通知首页重新扫描脚本列表，
 * 让最新导入的脚本出现在列表里。最多轮询 60 秒，全部出现或超时后自动停止。
 */
function watchNewScriptImports(baseNames: string[]) {
  const targets = Array.from(new Set(baseNames.filter((b) => b)))
  if (targets.length === 0) return
  const appeared: Record<string, boolean> = {}
  let tries = 0
  const tick = () => {
    tries += 1
    let changed = false
    for (const base of targets) {
      if (appeared[base]) continue
      if (
        pathExists(Path.join(FileManager.scriptsDirectory, base, "script.json"))
      ) {
        appeared[base] = true
        changed = true
      }
    }
    if (changed) {
      notifyScriptsChange()
    }
    if (targets.every((b) => appeared[b]) || tries >= 30) {
      return
    }
    setTimeout(tick, 2000)
  }
  setTimeout(tick, 2000)
}

/** 频道更新页：列出最近一次检查发现的脚本变化，默认全选，可取消部分后点「更新」导入安装新版本 */
function ChannelUpdatePage() {
  const dismiss = Navigation.useDismiss()
  const lastCheck = useMemo(() => readLastChannelCheck(), [])
  // 已从仓库删除的记录不提示：runChannelMonitorCheck 已不再产生 removed；
  // 此处兜底清理历史 last-check 里可能残留的 removed 条目（打开一次后即不再显示）
  useEffect(() => {
    dismissChannelRemoved()
  }, [])
  const excludedTotal = useMemo(() => {
    let n = 0
    for (const r of lastCheck?.summary.results ?? []) {
      n += r.excludedCount ?? 0
    }
    return n
  }, [lastCheck])
  // 本次检查中被「忽略全部」按路径忽略的变化数（同一脚本再发新版也不再提示）
  const ignoredTotal = useMemo(() => {
    let n = 0
    for (const r of lastCheck?.summary.results ?? []) {
      n += r.ignoredCount ?? 0
    }
    return n
  }, [lastCheck])
  const items = useMemo(() => {
    const list: {
      id: string
      name: string
      type: "added" | "updated"
      repoName: string
      repoUrl: string
      path: string
      localVersion?: string
      cloudVersion?: string
    }[] = []
    for (const r of lastCheck?.summary.results ?? []) {
      if (!r.ok) continue
      const parts = repoParts(r.url)
      if (!parts) continue
      for (const c of r.changes) {
        // 防御：历史 last-check 可能残留 removed，一律不展示（已从仓库删除不提示）
        if (c.type === "removed") continue
        list.push({
          id: `${r.url}|${c.path}`,
          name: c.path.replace(/\.scripting$/i, ""),
          type: c.type,
          repoName: r.name,
          repoUrl: r.url,
          path: c.path,
          localVersion: c.localVersion,
          cloudVersion: c.cloudVersion,
        })
      }
    }
    return list
  }, [lastCheck])
  // 待处理脚本列表：每更新完一批就从这里移除已处理的项，全部处理完才自动关闭页面；
  // 只处理部分时页面保留，剩余项可继续处理或手动关闭
  const [pendingItems, setPendingItems] = useState<typeof items>(items)
  const [selected, setSelected] = useState<Set<string>>(() =>
    new Set(items.map((item) => item.id))
  )
  const [updating, setUpdating] = useState(false)
  const { showToast, toastProps } = useToast()

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  // 版本号提示文案：本地与云端都有显示「v旧 → v新」，只有云端显示「新版本 vX」，都没有为空
  function versionHint(item: (typeof items)[number]): string {
    const v =
      item.localVersion && item.cloudVersion
        ? `v${item.localVersion} → v${item.cloudVersion}`
        : item.cloudVersion
        ? tpl("新版本 v{ver}", { ver: item.cloudVersion })
        : ""
    return v ? v + " · " : ""
  }

  const allSelected = pendingItems.length > 0 && selected.size === pendingItems.length
  function toggleAll() {
    setSelected(
      allSelected ? new Set() : new Set(pendingItems.map((item) => item.id))
    )
  }

  // 忽略本次：只记录当前批次的签名（同一批变化不再提示/弹页），不写「不再更新」列表；
  // 同一脚本下次再发布（sha 变）仍会正常提醒。同时清零最近检查结果并关闭页面。
  function ignoreThisTime() {
    const sig = channelChangesSignature(lastCheck?.summary.results ?? [])
    if (sig) {
      updateChannelMonitorConfig({ channelMonitorNotifiedSig: sig })
    }
    dismissChannelUpdates()
    showToast(t("已忽略本次更新，不再提示"))
    dismiss()
  }

  // 不再更新：把当前批次涉及的所有脚本路径持久化到「已忽略」列表——同一脚本之后再次发布新版本
  // 也不再提示（直到在设置→仓库监控→已忽略更新的脚本 中恢复提醒）；同时记录批次签名防重复弹窗，
  // 并清零最近检查结果（通知点击路径也不再打开更新页），然后关闭页面
  function ignoreForever() {
    const cfg = resolveConfig()
    const sig = channelChangesSignature(lastCheck?.summary.results ?? [])
    const ignored = new Set(cfg.channelMonitorIgnoredPaths ?? [])
    let addedCount = 0
    for (const r of lastCheck?.summary.results ?? []) {
      if (!r.ok) continue
      for (const c of r.changes) {
        if (c.type === "removed") continue
        const key = `${r.url}|${c.path}`
        if (!ignored.has(key)) {
          ignored.add(key)
          addedCount += 1
        }
      }
    }
    const patch: Partial<AppConfig> = {
      channelMonitorIgnoredPaths: [...ignored],
    }
    if (sig) {
      patch.channelMonitorNotifiedSig = sig
    }
    updateChannelMonitorConfig(patch)
    dismissChannelUpdates()
    showToast(
      addedCount > 0
        ? tpl("已忽略 {n} 个脚本的更新，不再提示；可在设置→仓库监控 中恢复", {
            n: String(addedCount),
          })
        : t("已忽略本次更新，不再提示")
    )
    dismiss()
  }

  // 本地已有同名脚本时不能走 scripting://import_scripts：Scripting 导入器会在目标目录
  // 已存在时报「无法将…移到 scripts（已存在同名项目）」而失败；改为工具内下载 raw 包、
  // 解压、用 restoreScripts 覆盖安装（与恢复备份同一套覆盖逻辑，安全处理同名目录）。
  async function installUpdateItem(item: (typeof items)[number]): Promise<void> {
    // 优先用「分支最新 commit sha」构造一次性 raw 链接：GitHub raw CDN 的缓存键忽略
    // query string（?t= 无效）且最多缓存 5 分钟，发布后立刻用分支 raw 链接导入会装成
    // 低一个版本；commit sha 每次发布都变，URL 唯一必然回源最新内容，导入版本号一定
    // 与检测到的一致。拿不到 commit sha 时回退到原分支链接（并加时间戳兜底）。
    let raw = await resolveFreshRawScriptUrl(item.repoUrl, item.path)
    if (!raw) {
      raw = await resolveRawScriptUrl(item.repoUrl, item.path)
    }
    if (!raw) {
      throw new Error(tpl("获取下载地址失败：{name}", { name: item.name }))
    }
    raw = `${raw}${raw.includes("?") ? "&" : "?"}t=${Date.now()}`
    const res = await fetch(raw)
    if (!res.ok) {
      throw new Error(
        tpl("下载失败（{status}）：{name}", {
          status: String(res.status),
          name: item.name,
        })
      )
    }
    const bytes = await res.bytes()
    const staging = Path.join(
      FileManager.temporaryDirectory,
      `channel-update-${Date.now()}-${Math.round(Math.random() * 1e6)}`
    )
    FileManager.createDirectorySync(staging, true)
    try {
      const zipPath = Path.join(staging, `${safeFileName(item.name)}.scripting`)
      FileManager.writeAsBytesSync(zipPath, bytes)
      FileManager.unzipSync(zipPath, staging)
      const candidates = scanScriptDirsInTree(staging)
      const candidate =
        candidates.find((c) => c.folderName === item.name) ?? candidates[0]
      if (!candidate) {
        throw new Error(tpl("解压后未找到脚本：{name}", { name: item.name }))
      }
      await restoreScripts([candidate], true)
      markRestoredAsBaseline([candidate])
    } finally {
      if (pathExists(staging)) {
        FileManager.removeSync(staging)
      }
    }
  }

  async function doUpdate() {
    if (updating) return
    const chosen = pendingItems.filter((item) => selected.has(item.id))
    if (chosen.length === 0) {
      showToast(t("请先选择要更新的脚本"), true)
      return
    }
    setUpdating(true)
    try {
      // 本地已存在同名脚本：Scripting 的 import_scripts 导入器在目标目录已存在时会
      // 「无法将…移到 scripts（已存在同名项目）」而失败，改为工具内下载解压并覆盖安装；
      // 本地没有同名脚本的全新安装仍走 Scripting 导入链接。
      const updateItems = chosen.filter((item) => {
        const base = Path.basename(item.path).replace(/\.scripting$/i, "")
        return (
          base &&
          pathExists(Path.join(FileManager.scriptsDirectory, base, "script.json"))
        )
      })
      const newItems = chosen.filter((item) => !updateItems.includes(item))
      // 标记刚发起导入/更新的脚本（folderName → 当前时间戳）：导入后若版本号与本地一致
      // （同版本内容刷新）不触发自动备份，只吸收基线；本地无同名脚本的全新安装
      // 由「基线缺失」逻辑自然跳过，无需标记
      const cfgNow = resolveConfig()
      const importedAt = { ...(cfgNow.channelImportedAt ?? {}) }
      const importedStamp = Date.now()
      for (const item of chosen) {
        const base = Path.basename(item.path).replace(/\.scripting$/i, "")
        if (base) {
          importedAt[base] = importedStamp
        }
      }
      updateChannelMonitorConfig({ channelImportedAt: importedAt })
      // 更新前记录当前分组快照：覆盖安装会替换脚本目录，restoreScripts 内部会用快照
      // 把脚本恢复回原分组；走 Scripting 导入的新脚本如被写回 settings.json 丢分组，
      // 用户回到工具刷新页面时也会用快照恢复
      snapshotScriptGroups(
        chosen
          .map((item) => Path.basename(item.path).replace(/\.scripting$/i, ""))
          .filter((b) => b)
      )
      // ① 本地已有同名：工具内直接下载解压并覆盖安装（逐个安装，失败不中断其它项）
      let installedCount = 0
      const installedNames: string[] = []
      for (const item of updateItems) {
        try {
          await installUpdateItem(item)
          installedCount += 1
          installedNames.push(item.name)
        } catch (error) {
          logError("频道更新安装", error)
          showToast(error instanceof Error ? error.message : String(error), true)
        }
      }
      if (installedCount > 0) {
        // 更新成功：发系统通知 + 通知首页刷新脚本列表
        notifyChannelUpdateSuccess(installedNames)
        notifyScriptsChange()
      }
      // ② 全新脚本：交给 Scripting 导入页面（scripting://import_scripts?urls=[...]）
      const urls: string[] = []
      for (const item of newItems) {
        let raw = await resolveFreshRawScriptUrl(item.repoUrl, item.path)
        if (!raw) {
          raw = await resolveRawScriptUrl(item.repoUrl, item.path)
        }
        if (raw) {
          urls.push(`${raw}${raw.includes("?") ? "&" : "?"}t=${Date.now()}`)
        }
      }
      if (urls.length > 0) {
        const importLink = Script.createImportScriptsURLScheme(urls)
        await Safari.openURL(importLink)
        // 全新脚本交给 Scripting 导入页面后工具无法获知导入完成时机，
        // 轮询检测目标目录出现（导入完成）后通知首页刷新列表
        watchNewScriptImports(
          newItems
            .map((item) =>
              Path.basename(item.path).replace(/\.scripting$/i, "")
            )
            .filter((b) => b)
        )
      }
      const doneIds = new Set(chosen.map((item) => item.id))
      const remaining = pendingItems.filter((item) => !doneIds.has(item.id))
      const startedTotal = installedCount + urls.length
      showToast(
        remaining.length > 0
          ? tpl("已开始更新 {n} 个脚本，还有 {m} 个待处理", {
              n: String(startedTotal),
              m: String(remaining.length),
            })
          : tpl("已开始更新 {n} 个脚本", { n: String(startedTotal) })
      )
      if (remaining.length === 0) {
        dismiss()
        return
      }
      setPendingItems(remaining)
      setSelected(new Set(remaining.map((item) => item.id)))
    } catch (error) {
      logError("频道更新", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setUpdating(false)
    }
  }

  // 顶部操作行（关闭 / 全选）：放在页面内容里，不依赖导航栏 toolbar（嵌套模态中 toolbar 不渲染）。
  // 关闭样式与其他页面工具栏关闭按钮一致：纯文字、无图标。
  // 不用 Button / contentShape：实测 Button 仍带白色高亮框，纯 Text 点击无任何背景。
  // 不用 Section 包裹，避免产生白色卡片背景。
  const actionRow = (
    // 关闭/全选操作行：listRowBackground 透明，底色与页面其他区域一致（List 直接子元素默认是带卡片背景的 row）
    <HStack
      spacing={8}
      padding={{ top: 0, bottom: 0 }}
      listRowInsets={{ top: -10, bottom: -30, leading: 0, trailing: 0 }}
      listRowBackground={<Rectangle fill="rgba(0,0,0,0)" />}
    >
      <Text
        font="body"
        foregroundStyle="tintColor"
        onTapGesture={dismiss}
      >
        {t("关闭")}
      </Text>
      <Spacer />
      <Text
        font="body"
        foregroundStyle="tintColor"
        onTapGesture={toggleAll}
      >
        {allSelected ? t("取消全选") : t("全选")}
      </Text>
    </HStack>
  )

  // 被排除关键词隐藏的脚本提示：让用户明白为什么“新上传的脚本检测不到”
  const excludedRow =
    excludedTotal > 0 ? (
      <HStack spacing={6}>
        <Image
          systemName="eye.slash"
          foregroundStyle="secondaryLabel"
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {tpl("{n} 个脚本因名称含排除关键词未显示，可在设置里调整", {
            n: String(excludedTotal),
          })}
        </Text>
      </HStack>
    ) : null

  // 被「忽略全部」按路径忽略的脚本提示：同一脚本再发新版也不提示，可去设置里恢复提醒
  const ignoredRow =
    ignoredTotal > 0 ? (
      <HStack spacing={6}>
        <Image
          systemName="bell.slash"
          foregroundStyle="secondaryLabel"
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {tpl("{n} 个脚本已忽略更新（再发新版也不再提示），可在设置→仓库监控 中恢复", {
            n: String(ignoredTotal),
          })}
        </Text>
      </HStack>
    ) : null

  // 底部悬浮操作条：与首页长按多选同款胶囊样式（secondarySystemBackground 圆角底栏 + 方形图标胶囊按钮）。
  // 三个按钮依次为「不再更新」「忽略本次」「更新选中」；通过 safeAreaInset 固定在底部，同样不依赖导航栏 toolbar。
  const updateBar = (
    <VStack alignment="center" padding={{ bottom: 10 }}>
      <HStack
        spacing={8}
        alignment="center"
        padding={{ horizontal: 10, vertical: 8 }}
        background={{
          style: { color: "secondarySystemBackground", opacity: 0.95 },
          shape: { type: "rect", cornerRadius: 20 },
        }}
      >
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 70, height: 58 }}
          background={{
            style: { color: "label", opacity: 0.08 },
            shape: { type: "rect", cornerRadius: 14 },
          }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={ignoreForever}
        >
          <Image
            systemName="bell.slash"
            font={17}
            foregroundStyle="secondaryLabel"
          />
          <Text font="caption2" foregroundStyle="secondaryLabel">
            {t("不再更新")}
          </Text>
        </VStack>
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 70, height: 58 }}
          background={{
            style: { color: "label", opacity: 0.08 },
            shape: { type: "rect", cornerRadius: 14 },
          }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={ignoreThisTime}
        >
          <Image
            systemName="eye.slash"
            font={17}
            foregroundStyle="secondaryLabel"
          />
          <Text font="caption2" foregroundStyle="secondaryLabel">
            {t("忽略本次")}
          </Text>
        </VStack>
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 70, height: 58 }}
          background={{
            style: { color: "systemBlue", opacity: 0.15 },
            shape: { type: "rect", cornerRadius: 14 },
          }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={doUpdate}
        >
          <Image
            systemName={
              updating ? "arrow.triangle.2.circlepath" : "arrow.down.circle"
            }
            font={17}
            foregroundStyle="tintColor"
          />
          <Text font="caption2" foregroundStyle="tintColor">
            {updating ? t("更新中…") : t("更新选中")}
          </Text>
        </VStack>
      </HStack>
    </VStack>
  )

  if (pendingItems.length === 0) {
    return (
      <List
        navigationTitle={t("频道更新")}
        navigationBarTitleDisplayMode="inline"
        listSectionSpacing="compact"
        contentMargins={{ edges: "top", insets: -2 }}
        toast={toastProps}
      >
        {actionRow}
        {excludedRow}
        {ignoredRow}
        <Section>
          <EmptyState message={t("没有可更新的脚本")} />
        </Section>
      </List>
    )
  }

  return (
    <List
      navigationTitle={t("频道更新")}
      navigationBarTitleDisplayMode="inline"
      listSectionSpacing="compact"
      contentMargins={{ edges: "top", insets: -2 }}
      toast={toastProps}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: updateBar,
        },
      }}
    >
      {actionRow}
      {excludedRow}
      {ignoredRow}
      <Section
        header={<Text font="headline">{t("可更新的脚本")}</Text>}
        footer={
          <Text font="footnote">
            {t(
              "默认全选；点「更新」通过 Scripting 导入安装新版本，未勾选的跳过；全部处理完自动关闭"
            )}
          </Text>
        }
      >
        {pendingItems.length === 0 ? (
          <EmptyState message={t("没有可更新的脚本")} />
        ) : (
          pendingItems.map((item) => (
            <HStack
              key={item.id}
              spacing={10}
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => toggle(item.id)}
            >
              <Image
                systemName={
                  selected.has(item.id)
                    ? "checkmark.circle.fill"
                    : "circle"
                }
                foregroundStyle={
                  selected.has(item.id) ? "systemBlue" : "secondaryLabel"
                }
              />
              <VStack alignment="leading" spacing={2}>
                <Text font="body">{item.name}</Text>
                <Text font="caption" foregroundStyle="secondaryLabel">
                  {versionHint(item)}
                  {item.repoName} · {item.type === "added" ? t("新增") : t("更新")}
                </Text>
              </VStack>
              <Spacer />
              <Chevron />
            </HStack>
          ))
        )}
      </Section>
    </List>
  )
}

// ==================== 分组选择 ====================

function GroupPickerPage({ onSelect }: { onSelect: (group: GroupInfo) => void }) {
  const dismiss = Navigation.useDismiss()
  const groups = useMemo(() => {
    const all = readScriptingGroups()
    if (all.length === 0) return all
    const cfg = resolveConfig()
    const order = cfg.homeGroupOrder
    if (order && order.length > 0) {
      const groupMap = new Map<string, GroupInfo>()
      for (const g of all) groupMap.set(g.name, g)
      const known: GroupInfo[] = []
      for (const name of order) {
        const g = groupMap.get(name)
        if (g) { known.push(g); groupMap.delete(name) }
      }
      const rest = [...groupMap.values()].sort((a, b) => a.name.localeCompare(b.name, "zh"))
      return [...known, ...rest]
    }
    return [...all].sort((a, b) => a.name.localeCompare(b.name, "zh"))
  }, [])

  return (
    <List
      navigationTitle={t("选择分组")}
      navigationBarTitleDisplayMode="inline"
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
    >
      <Section
        header={<Text font="headline">{t("脚本分组")}</Text>}
        footer={
          <Text font="footnote">
            {t("来自 Scripting 应用的分组（.scripting/settings.json），点击分组直接备份该组全部脚本")}
          </Text>
        }
      >
        {groups.length === 0 ? (
          <EmptyState message={t("没有可备份的分组")} />
        ) : (
          groups.map((group) => (
            <HStack
              key={group.key}
              spacing={10}
              contentShape="rect"
              onTapGesture={() => {
                dismiss()
                onSelect(group)
              }}
            >
              <RowIcon systemName="folder.fill" />
              <Text font="body">{group.name}</Text>
              <Spacer />
              <Text font="caption" foregroundStyle="secondaryLabel">
                {tpl("{n} 个脚本", { n: String(group.scripts.length) })}
              </Text>
              <Chevron />
            </HStack>
          ))
        )}
      </Section>
    </List>
  )
}

// ==================== 备份（按名称选择脚本） ====================

function ScriptPickerPage({
  initial,
  onSelect,
  pickerMode = "backup",
}: {
  initial: ScriptInfo[]
  onSelect: (scripts: ScriptInfo[]) => void
  pickerMode?: "backup" | "github"
}) {
  const dismiss = Navigation.useDismiss()
  const [allScripts, setAllScripts] = useState<ScriptInfo[]>([])
  const [scriptsLoading, setScriptsLoading] = useState(true)
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(initial.map((s) => s.folderName))
  )
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">(() => {
    const s = resolveConfig().scriptSort
    return s === "name" || s === "name_desc" ? s : "modified"
  })
  const { showToast, toastProps } = useToast()

  useEffect(() => {
    setTimeout(() => {
      setAllScripts(scanScripts())
      setScriptsLoading(false)
    }, 50)
  }, [])

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? allScripts.filter(
          (s) =>
            keywordMatches(s.displayName, keyword) ||
            keywordMatches(s.folderName, keyword)
        )
      : [...allScripts]
    list.sort((a, b) => compareScripts(a, b, sortMode))
    return list
  }, [allScripts, query, sortMode])

  function toggleOne(script: ScriptInfo) {
    const next = new Set(selected)
    if (next.has(script.folderName)) {
      next.delete(script.folderName)
    } else {
      next.add(script.folderName)
    }
    setSelected(next)
  }

  const isGithub = pickerMode === "github"
  const allSelected =
    filtered.length > 0 && filtered.every((s) => selected.has(s.folderName))

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      const allOn =
        filtered.length > 0 && filtered.every((s) => next.has(s.folderName))
      if (allOn) {
        filtered.forEach((s) => next.delete(s.folderName))
      } else {
        filtered.forEach((s) => next.add(s.folderName))
      }
      return next
    })
  }

  function clearSelection() {
    setSelected(new Set())
  }

  function done() {
    const picked = allScripts.filter((s) => selected.has(s.folderName))
    if (picked.length === 0) {
      showToast(t("请至少选择一个脚本"), true)
      return
    }
    dismiss()
    onSelect(picked)
  }

  /** 点击单个脚本：直接开始备份/发布该脚本 */
  function backupOne(script: ScriptInfo) {
    dismiss()
    onSelect([script])
  }

  return (
    <List
      navigationTitle={isGithub ? t("选择要发布的脚本") : t("选择要备份的脚本")}
      navigationBarTitleDisplayMode="inline"
      scrollDismissesKeyboard="immediately"
      toast={toastProps}
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
      toolbar={
        <Toolbar>
          <ToolbarItem placement="topBarTrailing">
            <Button title={t("取消")} action={() => dismiss()} />
          </ToolbarItem>
        </Toolbar>
      }
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content:
            selected.size > 0 ? (
              <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => dismiss()}
                >
                  <Image systemName="chevron.left" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("返回")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={clearSelection}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("取消")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName="checklist"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? t("取消全选") : t("全选")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={done}
                >
                  <Image systemName="checkmark.circle" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {isGithub ? t("发布") : t("备份")}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
            ) : (
              <></>
            ),
        },
      }}
    >
      <Section
        header={
          <HStack spacing={8} alignment="center">
            <Text font="headline">{tpl("脚本列表（共 {n} 个脚本）", { n: String(allScripts.length) })}</Text>
            <Spacer />
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const v = String(value)
                const next = v === "name" || v === "name_desc" ? v : "modified"
                setSortMode(next)
                saveConfig({ ...resolveConfig(), scriptSort: next })
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name"
                      ? t("按名称 A-Z")
                      : sortMode === "name_desc"
                        ? t("按名称 Z-A")
                        : t("按最新修改")}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">{t("按最新修改")}</Text>
              <Text tag="name">{t("按名称 A-Z")}</Text>
              <Text tag="name_desc">{t("按名称 Z-A")}</Text>
            </Picker>
          </HStack>
        }
        footer={
          <VStack
            alignment="leading"
            spacing={2}
            padding={{ top: 8, bottom: 24 }}
          >
            <Text font="caption" foregroundStyle="secondaryLabel">
              {t("点击脚本名：直接开始备份/发布该脚本")}
            </Text>
            <Text font="caption" foregroundStyle="secondaryLabel">
              {t("长按脚本名：进入多选模式，可勾选多个后统一备份/发布")}
            </Text>
          </VStack>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索脚本名")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {scriptsLoading ? (
          <EmptyState message={t("正在加载脚本…")} />
        ) : filtered.length === 0 ? (
          <EmptyState message={t("未找到匹配的脚本")} />
        ) : (
          filtered.map((script) => {
            const isOn = selected.has(script.folderName)
            return (
              <HStack
                key={script.folderName}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(script)
                  } else {
                    backupOne(script)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => toggleOne(script),
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName="chevron.left.forwardslash.chevron.right"
                    color="tintColor"
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{script.displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    v{script.version} · {formatDate(script.modifiedAt)}
                  </Text>
                </VStack>
                <Spacer />
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 同名备份折叠工具（长按列表标题切换） ====================

/** 解析备份名：返回 { base: 基名, version: 版本号/null, isTimeCode: 是否时间码格式 }
 *  规则：_YYYYMMDD_HHMMSS 为时间码（全部_20260820_123648 / 分组名_20260820_123648，按前缀折叠只留最新）；_x.y.z / (n) / 空格n 为编号（归入同一组）
 *  循环剥离：脚本管理工具_5.0.26 (2) → 先剥 (2) → 脚本管理工具_5.0.26 → 再剥 _5.0.26 → 脚本管理工具（base=脚本管理工具，version=5.0.26）
 *  脚本管理工具(自修改版) → 括号内不是数字，不剥离 → base=脚本管理工具(自修改版) 独立 */
function parseBackupNameParts(name: string): { base: string; version: string | null; isTimeCode: boolean } {
  const clean = name.replace(/\.(scripting|zip)$/i, "")
  // 时间码格式：前缀_YYYYMMDD_HHMMSS（timestampForName 格式，如 脚本备份_20260814_041023）
  const timeCodeMatch = clean.match(/^(.*)_(\d{8})_(\d{6})$/)
  if (timeCodeMatch) {
    return { base: timeCodeMatch[1], version: null, isTimeCode: true }
  }
  let base = clean
  let version: string | null = null
  let changed = true
  while (changed) {
    changed = false
    // 括号序号：前缀(2) 或 前缀 (2)（括号内**必须纯数字**，脚本管理工具(自修改版)不会匹配）
    const paren = base.match(/^(.*?)\s*\((\d+)\)$/)
    if (paren && paren[1].trim().length > 0) {
      base = paren[1].trimEnd()
      if (version == null) version = paren[2]
      changed = true
      continue
    }
    // 版本号：前缀_1.2.3
    const ver = base.match(/^(.*)_(\d+)\.(\d+)\.(\d+)$/)
    if (ver && ver[1].trim().length > 0) {
      base = ver[1].trimEnd()
      version = `${ver[2]}.${ver[3]}.${ver[4]}`
      changed = true
      continue
    }
    // 空格序号：前缀 2
    const space = base.match(/^(.*?)\s(\d+)$/)
    if (space && space[1].trim().length > 0) {
      base = space[1].trimEnd()
      if (version == null) version = space[2]
      changed = true
      continue
    }
  }
  return { base: base.trim(), version, isTimeCode: false }
}

/** 获取 Github 备份项的时间戳（优先 manifest createdAt，否则文件名 YYYYMMDD_HHMMSS 解析，最后 0） */
function githubBackupTime(item: { name: string; path: string }, manifest: GithubBackupManifest | null): number {
  const meta = manifest?.backups[item.path]
  if (meta && typeof meta.createdAt === "number" && Number.isFinite(meta.createdAt)) {
    return meta.createdAt
  }
  const m = item.name.match(/(\d{8})_(\d{6})/)
  if (m) {
    const day = m[1], time = m[2]
    const ts = new Date(
      Number(day.slice(0, 4)),
      Number(day.slice(4, 6)) - 1,
      Number(day.slice(6, 8)),
      Number(time.slice(0, 2)),
      Number(time.slice(2, 4)),
      Number(time.slice(4, 6))
    ).getTime()
    if (!Number.isNaN(ts)) return ts
  }
  return 0
}

/** 同脚本名仅显示最新：按基名分组，组内保留时间最新 + 版本号最高（同一则一，否则保留两个）
 *  时间码格式（全部_YYYYMMDD_HHMMSS、分组名_YYYYMMDD_HHMMSS）也按前缀折叠，只保留时间最新一个 */
function dedupBackupsBySameName<T extends { name: string; path: string; time: number }>(list: T[]): T[] {
  const keep: T[] = []
  // 时间码组 vs 版本号/序号组：分别处理，互不混合
  const timeCodeGroups = new Map<string, T[]>()
  const versionGroups = new Map<string, T[]>()
  for (const item of list) {
    const parts = parseBackupNameParts(item.name)
    if (parts.isTimeCode) {
      const key = parts.base || item.name
      const arr = timeCodeGroups.get(key)
      if (arr) arr.push(item)
      else timeCodeGroups.set(key, [item])
      continue
    }
    // 版本号/序号组：只有带编号（version != null）的才归组
    if (parts.version != null) {
      const key = parts.base || item.name
      const arr = versionGroups.get(key)
      if (arr) arr.push(item)
      else versionGroups.set(key, [item])
      continue
    }
    // 无编号（如 脚本(自修改版) 等微调名字）：独立保留
    keep.push(item)
  }
  // 处理时间码组：只保留时间最新一个
  for (const group of timeCodeGroups.values()) {
    if (group.length === 0) continue
    let timeLatest = group[0]
    for (const it of group) if (it.time > timeLatest.time) timeLatest = it
    keep.push(timeLatest)
  }
  // 处理版本号组：保留时间最新 + 版本号最高（同取一，不同取二）
  for (const group of versionGroups.values()) {
    if (group.length === 0) continue
    if (group.length === 1) { keep.push(group[0]); continue }
    let timeLatest = group[0]
    for (const it of group) if (it.time > timeLatest.time) timeLatest = it
    let versionHighest = group[0]
    for (const it of group) {
      const va = parseBackupNameParts(it.name).version
      const vb = parseBackupNameParts(versionHighest.name).version
      if (va != null && (vb == null || compareVersions(va, vb) > 0)) versionHighest = it
    }
    if (timeLatest.path === versionHighest.path) {
      keep.push(timeLatest)
    } else {
      keep.push(timeLatest)
      keep.push(versionHighest)
    }
  }
  return keep
}

// ==================== 恢复（备份列表） ====================

function RestorePage({ destination }: { destination: Destination }) {
  const [query, setQuery] = useState("")
  const [items, setItems] = useState<BackupItem[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [scriptCounts, setScriptCounts] = useState<Map<string, number>>(new Map())
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">("modified")
  // 同名仅显示最新：长按「备份列表」标题切换（有编号的算同一个，时间最新+版本号最高不同时保留两个；时间码格式全保留）
  const [sameNameOnly, setSameNameOnly] = useState(false)
  // 备份到Github：上传中的防重入标记（上传过程禁用上传按钮，避免重复上传）
  const [uploading, setUploading] = useState(false)
  const { showToast, toastProps } = useToast()
  const dismiss = Navigation.useDismiss()
  // GitHub 备份配置（与 GithubRestorePage 一致：备份专用，自动回退发布配置）
  const gh = useMemo(
    () => resolveBackupGithubConfig(resolveGithubConfig()),
    []
  )

  /** 列表加载完成后，后台逐个统计备份脚本数（缓存命中直接显示，否则解压统计后写缓存） */
  function countScriptsInBackground(list: BackupItem[]) {
    const counts = new Map<string, number>()
    let index = 0
    function next() {
      if (index >= list.length) {
        return
      }
      const item = list[index]
      index += 1
      const cached = getBackupScriptCount(destination, item)
      if (cached != null) {
        counts.set(item.path, cached)
        setScriptCounts(new Map(counts))
        next()
        return
      }
      // 逐个让出主线程，避免一次性解压全部卡住 UI
      setTimeout(() => {
        try {
          const count = computeBackupScriptCount(item)
          counts.set(item.path, count)
          saveBackupScriptCount(destination, item, count)
        } catch {
          counts.set(item.path, -1)
        }
        setScriptCounts(new Map(counts))
        next()
      }, 30)
    }
    next()
  }

  useEffect(() => {
    setScriptCounts(new Map())
    setLoading(true)
    setTimeout(() => {
      const list = scanBackups(destination)
      setItems(list)
      setLoading(false)
      countScriptsInBackground(list)
    }, 50)
  }, [destination])

  const visibleItems = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? items.filter((item) => keywordMatches(item.name, keyword))
      : [...items]
    // 同名仅显示最新：先把同基名的备份折叠（有编号的算同一个），再按当前排序模式排
    if (sameNameOnly) {
      const deduped = dedupBackupsBySameName(
        list.map((item) => ({ ...item, time: item.modifiedAt }))
      )
      return deduped.sort((a, b) => {
        if (sortMode === "name") return a.name.localeCompare(b.name)
        if (sortMode === "name_desc") return b.name.localeCompare(a.name)
        return b.modifiedAt - a.modifiedAt
      })
    }
    list.sort((a, b) => {
      if (sortMode === "name") return a.name.localeCompare(b.name)
      if (sortMode === "name_desc") return b.name.localeCompare(a.name)
      return b.modifiedAt - a.modifiedAt
    })
    return list
  }, [items, query, sortMode, sameNameOnly])

  /** 匹配数：有关键字时显示过滤后匹配的备份个数，无关键字时显示总数 */
  const matchedCount = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    return keyword
      ? items.filter((item) => keywordMatches(item.name, keyword)).length
      : items.length
  }, [items, query])

  /** 长按「备份列表」标题：切换同名仅显示最新（直接切换，不再弹确认框） */
  function toggleSameNameOnly() {
    setSameNameOnly((v) => !v)
    showToast(sameNameOnly ? t("已关闭同名仅显示最新") : t("已开启同名仅显示最新"))
  }

  const selectedItems = items.filter((item) => selected.has(item.path))
  const allSelected =
    visibleItems.length > 0 && visibleItems.every((item) => selected.has(item.path))

  function refresh() {
    setScriptCounts(new Map())
    setLoading(true)
    setTimeout(() => {
      const list = scanBackups(destination)
      setItems(list)
      setLoading(false)
      countScriptsInBackground(list)
    }, 50)
  }

  function toggleOne(item: BackupItem) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(item.path)) {
        next.delete(item.path)
      } else {
        next.add(item.path)
      }
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      if (allSelected) {
        visibleItems.forEach((item) => next.delete(item.path))
      } else {
        visibleItems.forEach((item) => next.add(item.path))
      }
      return next
    })
  }

  async function doDeleteSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要删除的备份"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("删除备份"),
      message: tpl("确定删除 {n} 个备份？此操作不可恢复。", { n: String(selectedItems.length) }),
      actions: [{ label: t("删除"), destructive: true }],
    })
    if (index !== 0) {
      return
    }
    let okCount = 0
    for (const item of selectedItems) {
      if (deleteLocalBackup(item)) {
        okCount += 1
      }
    }
    if (okCount > 0) {
      showToast(tpl("已删除 {n} 个备份", { n: String(okCount) }))
      notifyBackupChange()
    } else {
      showToast(t("删除失败"), true)
    }
    setSelected(new Set())
    refresh()
  }

  async function doShareSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要分享的备份"), true)
      return
    }
    try {
      await shareLocalBackups(selectedItems)
    } catch (error) {
      logError("分享备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doRenameSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要重命名的备份"), true)
      return
    }
    if (selectedItems.length > 1) {
      showToast(t("重命名仅支持单选备份"), true)
      return
    }
    const item = selectedItems[0]
    const name = await inputPrompt({
      title: t("重命名备份"),
      message: t("输入新的备份名称"),
      defaultValue: item.name,
      placeholder: item.name,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameLocalBackup(item, name.trim())
      showToast(t("已重命名"))
      setSelected(new Set())
      refresh()
    } catch (error) {
      logError("重命名备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 重命名并安装：弹输入框改脚本名（不改名直接回车时自动在名称后加括号数字避免重名），再安装到脚本目录 */
  /** 重命名并安装单个备份脚本：弹输入框改脚本名（不改名直接回车时自动在名称后加括号数字避免重名），再安装到脚本目录 */
  async function renameAndInstallCandidate(
    candidate: CandidateScript,
    defaultName: string
  ): Promise<boolean> {
    const name = await inputPrompt({
      title: t("重命名并安装"),
      message: t("输入脚本名称；不改名直接回车会自动在名称后加括号数字避免重名"),
      defaultValue: defaultName,
      placeholder: defaultName,
    })
    if (name == null || !name.trim()) {
      return false
    }
    const base = name.trim()
    if (/[\/\\:]/.test(base)) {
      showToast(t("名称不能包含 / \\ : 字符"), true)
      return false
    }
    // 目标名已存在（通常是不改名直接回车）→ 自动在名称后加括号数字：(2)(3)…
    let finalName = base
    let n = 2
    while (pathExists(Path.join(FileManager.scriptsDirectory, finalName))) {
      finalName = `${base}(${n})`
      n += 1
    }
    try {
      const renamed: CandidateScript = { ...candidate, folderName: finalName }
      const result = await restoreScripts([renamed], false)
      if (result.restored.length === 0) {
        showToast(t("安装失败"), true)
        return false
      }
      // 同步把新目录 script.json 的显示名改成最终名称，保证脚本列表显示与目录一致
      renameInstalledScriptJsonName(finalName)
      markRestoredAsBaseline([renamed])
      notifyBackupChange()
      showToast(
        finalName !== base
          ? tpl("已安装「{name}」", { name: finalName })
          : t("已安装")
      )
      return true
    } catch (error) {
      logError("重命名并安装", error)
      showToast(error instanceof Error ? error.message : String(error), true)
      return false
    }
  }

  async function openBackup(item: BackupItem) {
    if (refreshing) {
      return
    }
    setRefreshing(true)
    try {
      const inspected = inspectBackup(item)
      if (!inspected) {
        showToast(t("无法读取该备份"), true)
        return
      }
      const { candidates, tempDir } = inspected
      if (candidates.length === 0) {
        showToast(t("该备份中没有找到脚本（缺少 script.json）"), true)
        cleanupTemp(tempDir)
        return
      }
      // zip（压缩包备份，可能含多脚本）：保持旧体验，进选择页查看内部并勾选恢复。
      // 注意：本地备份的 .scripting 文件在 scanBackups 里也被标记 isZip=true（同属压缩包），
      // 这里用路径扩展名区分，只有真正的 .zip 才进选择页
      const isZipFile = item.path.toLowerCase().endsWith(".zip")
      if (isZipFile) {
        const result = await Navigation.present(
          <ScriptSelectionPage candidates={candidates} />
        )
        if (result?.restored != null) {
          showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
          refresh()
        }
        cleanupTemp(tempDir)
        return
      }
      // .scripting（单/分组脚本备份）：单脚本弹操作列表（重命名 / 重命名并安装 / 覆盖并恢复）
      if (candidates.length === 1) {
        const display = stripScriptExt(item.name)
        const exists = pathExists(
          Path.join(FileManager.scriptsDirectory, display)
        )
        const choice = await Dialog.actionSheet({
          title: t("恢复备份"),
          message: exists
            ? tpl(
                "将恢复脚本「{name}」，目录中已存在同名脚本，恢复会覆盖当前版本。",
                { name: display }
              )
            : tpl("将恢复脚本「{name}」到 Scripting 脚本目录。", { name: display }),
          actions: [
            { label: t("重命名") },
            { label: t("重命名并安装") },
            { label: t("覆盖并恢复"), destructive: true },
          ],
        })
        if (choice == null) {
          cleanupTemp(tempDir)
          return
        }
        if (choice === 0) {
          // 重命名：改本地备份名称（与长按多选重命名一致）
          const name = await inputPrompt({
            title: t("重命名备份"),
            message: t("输入新的备份名称"),
            defaultValue: item.name,
            placeholder: item.name,
          })
          if (name == null || !name.trim()) {
            cleanupTemp(tempDir)
            return
          }
          try {
            renameLocalBackup(item, name.trim())
            showToast(t("已重命名"))
            setSelected(new Set())
            refresh()
          } catch (error) {
            logError("重命名备份", error)
            showToast(error instanceof Error ? error.message : String(error), true)
          }
          cleanupTemp(tempDir)
          return
        }
        if (choice === 1) {
          // 重命名并安装：默认名只取脚本名（去掉尾缀与版本号），不改名直接回车自动加括号数字避免重名
          const installed = await renameAndInstallCandidate(
            candidates[0],
            stripTrailingVersion(stripScriptExt(item.name))
          )
          if (installed) {
            setSelected(new Set())
            refresh()
          }
          cleanupTemp(tempDir)
          return
        }
        // choice === 2：覆盖并恢复
        await restoreScripts([candidates[0]], true)
        markRestoredAsBaseline([candidates[0]])
        notifyBackupChange()
        showToast(t("已恢复"))
        refresh()
        cleanupTemp(tempDir)
        return
      }
      // .scripting 多脚本：进选择页勾选恢复
      const result = await Navigation.present(
        <ScriptSelectionPage candidates={candidates} />
      )
      if (result?.restored != null) {
        showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
        refresh()
      }
      cleanupTemp(tempDir)
    } catch (error) {
      logError("恢复备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setRefreshing(false)
    }
  }

  /** 把选中的本地备份上传到 GitHub 备份仓库（按钮仅在开启 Github 备份时显示，多选时逐个上传） */
  async function doUploadSelected() {
    if (uploading) {
      return
    }
    if (!resolveConfig().githubBackupEnabled) {
      return
    }
    if (!isGithubBackupConfigured(gh)) {
      showToast(t("请先到右上角「设置」配置 GitHub 备份（Token/所有者/备份仓库名）"), true)
      return
    }
    const list = selectedItems
    if (list.length === 0) {
      return
    }
    setUploading(true)
    // 与其他备份一致的提示：上传中 / 完成均为黑底白字 toast
    showToast(tpl("正在上传 {n} 个备份到 GitHub…", { n: String(list.length) }))
    let ok = 0
    let lastError: unknown = null
    try {
      for (const item of list) {
        try {
          const cachedCount = scriptCounts.get(item.path)
          const result = await uploadLocalBackupToGithub(
            item,
            gh,
            cachedCount != null && cachedCount >= 0 ? cachedCount : undefined
          )
          ok += 1
          console.log("本地备份上传 GitHub 完成:", result.url)
        } catch (error) {
          logError("Github备份上传", error)
          lastError = error
          break
        }
      }
    } finally {
      setUploading(false)
    }
    if (ok === list.length) {
      showToast(tpl("已备份到 {repo}", { repo: `${gh.owner}/${gh.backupRepo}` }))
    } else if (lastError) {
      showToast(lastError instanceof Error ? lastError.message : String(lastError), true)
    }
  }

  function cleanupTemp(tempDir: string | null) {
    if (tempDir && pathExists(tempDir)) {
      try {
        FileManager.removeSync(tempDir)
      } catch {
        // ignore
      }
    }
  }

  const toolbar = (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button title={t("返回")} action={dismiss} />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("刷新")} action={refresh} />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle={t("恢复备份")}
      navigationBarTitleDisplayMode="inline"
      navigationBarBackButtonHidden
      scrollDismissesKeyboard="immediately"
      toolbar={toolbar}
      toast={toastProps}
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: selected.size > 0 ? (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 1 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                {visibleItems.length === 1 || !allSelected ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => {
                      setSelected(new Set())
                    }}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      {t("取消")}
                    </Text>
                  </VStack>
                ) : null}
                {visibleItems.length > 1 ? (
                  <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName={allSelected ? "checkmark.circle.fill" : "checkmark.circle"}
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? t("取消全选") : t("全选")}
                  </Text>
                </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doDeleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("删除")}
                  </Text>
                </VStack>
                {resolveConfig().githubBackupEnabled ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doUploadSelected}
                  >
                    <Image systemName="arrow.up.doc" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {uploading ? t("上传中…") : t("上传")}
                    </Text>
                  </VStack>
                ) : null}
                {selectedItems.length === 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doRenameSelected}
                  >
                    <Image systemName="pencil" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("重命名")}
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doShareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("分享")}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
          ) : (
            <></>
          ),
        },
      }}
    >
      <Section
        header={
          <VStack alignment="leading" spacing={4}>
            <HStack spacing={8} alignment="center">
            <HStack spacing={4}>
              <Text
                font="headline"
                onLongPressGesture={{ minDuration: 400, perform: toggleSameNameOnly }}
                allowsTightening={true}
              >
                {query.trim()
                  ? tpl("备份列表（匹配 {n} 个）", { n: String(matchedCount) })
                  : tpl("备份列表（共 {n} 个）", { n: String(items.length) })}
              </Text>
              {sameNameOnly ? (
                <Image
                  systemName="line.3.horizontal.decrease.circle.fill"
                  foregroundStyle="systemBlue"
                />
              ) : null}
            </HStack>
            <Spacer />
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const v = String(value)
                setSortMode(v === "name" || v === "name_desc" ? v : "modified")
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name"
                      ? t("按名称 A-Z")
                      : sortMode === "name_desc"
                        ? t("按名称 Z-A")
                        : t("按最新修改")}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">{t("按最新修改")}</Text>
              <Text tag="name">{t("按名称 A-Z")}</Text>
              <Text tag="name_desc">{t("按名称 Z-A")}</Text>
            </Picker>
            </HStack>
            <Text font="caption" foregroundStyle="secondaryLabel">
              {t("长按标题可切换「同名仅显示最新」")}
            </Text>
          </VStack>
        }
        footer={
          <Text font="footnote">{tpl("备份目录：{dir}", { dir: backupRootFor(destination) })}</Text>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索备份")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {loading ? (
          <EmptyState message={t("正在读取备份…")} />
        ) : visibleItems.length === 0 ? (
          <EmptyState message={t("暂无备份，先到首页开始备份吧")} />
        ) : (
          visibleItems.map((item) => {
            const isOn = selected.has(item.path)
            return (
              <HStack
                key={item.path}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(item)
                  } else {
                    openBackup(item)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    toggleOne(item)
                  },
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName={
                      item.path.toLowerCase().endsWith(".zip")
                        ? "doc.zipper"
                        : "chevron.left.forwardslash.chevron.right"
                    }
                    color="tintColor"
                    small={!item.path.toLowerCase().endsWith(".zip")}
                    leftPad={
                      item.path.toLowerCase().endsWith(".zip") ? 0 : -3
                    }
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{item.name}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {formatDate(item.modifiedAt)} · {formatBytes(item.byteSize)}
                    {selected.size > 0
                      ? ""
                      : ` · ${
                          scriptCounts.has(item.path)
                            ? scriptCounts.get(item.path)! >= 0
                              ? tpl("{n} 个脚本", { n: String(scriptCounts.get(item.path) ?? 0) })
                              : t("未知")
                            : t("统计中…")
                        }`}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（Github 备份仓库） ====================

/** 从 GitHub 私密备份仓库列出并下载 zip 恢复脚本 */
function GithubRestorePage() {
  const [query, setQuery] = useState("")
  const [items, setItems] = useState<{ name: string; path: string; size: number }[]>([])
  const [manifest, setManifest] = useState<GithubBackupManifest | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">("modified")
  // 同名仅显示最新：长按「备份列表」标题切换（有编号的算同一个，时间最新+版本号最高不同时保留两个；时间码格式全保留）
  const [sameNameOnly, setSameNameOnly] = useState(false)
  const { showToast, toastProps } = useToast()
  const dismiss = Navigation.useDismiss()
  const gh = useMemo(
    () => resolveBackupGithubConfig(resolveGithubConfig()),
    []
  )

  const visibleItems = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? items.filter((item) => keywordMatches(item.name, keyword))
      : [...items]
    // 同名仅显示最新：先把同基名的备份折叠（有编号的算同一个），再按当前排序模式排
    if (sameNameOnly) {
      const deduped = dedupBackupsBySameName(
        list.map((item) => ({ ...item, time: githubBackupTime(item, manifest) }))
      )
      if (sortMode === "name") {
        deduped.sort((a, b) => a.name.localeCompare(b.name))
      } else if (sortMode === "name_desc") {
        deduped.sort((a, b) => b.name.localeCompare(a.name))
      } else {
        sortGithubBackupsByTime(deduped, manifest)
      }
      return deduped
    }
    if (sortMode === "name") {
      list.sort((a, b) => a.name.localeCompare(b.name))
    } else if (sortMode === "name_desc") {
      list.sort((a, b) => b.name.localeCompare(a.name))
    } else {
      sortGithubBackupsByTime(list, manifest)
    }
    return list
  }, [items, query, sortMode, manifest, sameNameOnly])

  /** 匹配数：有关键字时显示过滤后匹配的备份个数，无关键字时显示总数 */
  const matchedCount = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    return keyword
      ? items.filter((item) => keywordMatches(item.name, keyword)).length
      : items.length
  }, [items, query])

  /** 长按「备份列表」标题：切换同名仅显示最新（直接切换，不再弹确认框） */
  function toggleSameNameOnly() {
    setSameNameOnly((v) => !v)
    showToast(sameNameOnly ? t("已关闭同名仅显示最新") : t("已开启同名仅显示最新"))
  }

  const selectedItems = items.filter((item) => selected.has(item.path))
  const allSelected =
    visibleItems.length > 0 && visibleItems.every((item) => selected.has(item.path))

  async function reload() {
    setLoading(true)
    try {
      const [list, meta] = await Promise.all([
        listGithubBackups(gh),
        readGithubBackupManifest(gh),
      ])
      setItems(sortGithubBackupsByTime(list, meta))
      setManifest(meta)
    } catch (error) {
      logError("Github备份列表", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setLoading(false)
    }
  }

  // 进入页面时拉取一次列表
  useEffect(() => {
    reload()
  }, [])

  function toggleOne(item: { name: string; path: string; size: number }) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(item.path)) {
        next.delete(item.path)
      } else {
        next.add(item.path)
      }
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      if (allSelected) {
        visibleItems.forEach((item) => next.delete(item.path))
      } else {
        visibleItems.forEach((item) => next.add(item.path))
      }
      return next
    })
  }

  async function doDeleteSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要删除的备份"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("删除备份"),
      message: tpl("确定删除 {n} 个远端备份？此操作不可恢复。", { n: String(selectedItems.length) }),
      actions: [{ label: t("删除"), destructive: true }],
    })
    if (index !== 0) {
      return
    }
    let okCount = 0
    for (const item of selectedItems) {
      try {
        await deleteGithubBackup(gh, item.path)
        okCount += 1
      } catch (error) {
        logError("Github备份删除", error)
      }
    }
    if (okCount > 0) {
      showToast(tpl("已删除 {n} 个备份", { n: String(okCount) }))
      notifyBackupChange()
    } else {
      showToast(t("删除失败"), true)
    }
    setSelected(new Set())
    reload()
  }

  async function doShareSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要分享的备份"), true)
      return
    }
    try {
      await shareGithubBackups(gh, selectedItems)
    } catch (error) {
      logError("分享Github备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doRenameSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要重命名的备份"), true)
      return
    }
    if (selectedItems.length > 1) {
      showToast(t("重命名仅支持单选备份"), true)
      return
    }
    const item = selectedItems[0]
    const lower = item.name.toLowerCase()
    const base = lower.endsWith(".scripting")
      ? item.name.slice(0, -10)
      : lower.endsWith(".zip")
        ? item.name.slice(0, -4)
        : item.name
    const name = await inputPrompt({
      title: t("重命名备份"),
      message: t("输入新的备份名称"),
      defaultValue: base,
      placeholder: base,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      await renameGithubBackup(gh, item, name.trim())
      showToast(t("已重命名"))
      setSelected(new Set())
      reload()
    } catch (error) {
      logError("重命名Github备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 重命名并安装：下载备份后弹输入框改脚本名，再以新名安装到本地（不覆盖同名脚本） */
  async function renameInstallBackup(item: {
    name: string
    path: string
    size: number
  }) {
    setRefreshing(true)
    let tempDir: string | null = null
    try {
      const zipPath = await downloadGithubBackup(gh, item.path)
      const inspected = inspectBackup({
        name: item.name,
        path: zipPath,
        isZip: true,
        modifiedAt: Date.now(),
        byteSize: item.size,
        scriptCount: 0,
      })
      if (!inspected) {
        showToast(t("无法读取该备份"), true)
        return
      }
      tempDir = inspected.tempDir
      const candidates = inspected.candidates
      if (candidates.length === 0) {
        showToast(t("该备份中没有找到脚本（缺少 script.json）"), true)
        return
      }
      // 多脚本备份不支持改名安装：进选择页勾选恢复（与 .scripting 多脚本行为一致）
      if (candidates.length > 1) {
        const result = await Navigation.present(
          <ScriptSelectionPage candidates={candidates} />
        )
        if (result?.restored != null) {
          showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
        }
        return
      }
      // 默认名只取脚本名（去掉尾缀与版本号），不改名直接回车自动加括号数字避免重名
      const baseName = stripTrailingVersion(stripScriptExt(item.name))
      const name = await inputPrompt({
        title: t("重命名并安装"),
        message: t("输入脚本名称；不改名直接回车会自动在名称后加括号数字避免重名"),
        defaultValue: baseName,
        placeholder: baseName,
      })
      if (name == null || !name.trim()) {
        return
      }
      const base = name.trim()
      if (/[\/\\:]/.test(base)) {
        showToast(t("名称不能包含 / \\ : 字符"), true)
        return
      }
      // 目标名已存在（通常是不改名直接回车）→ 自动在名称后加括号数字：(2)(3)…
      let finalName = base
      let n = 2
      while (pathExists(Path.join(FileManager.scriptsDirectory, finalName))) {
        finalName = `${base}(${n})`
        n += 1
      }
      const renamed: CandidateScript = { ...candidates[0], folderName: finalName }
      const result = await restoreScripts([renamed], false)
      if (result.restored.length === 0) {
        showToast(t("安装失败"), true)
        return
      }
      // 同步把新目录 script.json 的显示名改成最终名称，保证脚本列表显示与目录一致
      renameInstalledScriptJsonName(finalName)
      markRestoredAsBaseline([renamed])
      notifyBackupChange()
      showToast(
        finalName !== base
          ? tpl("已安装「{name}」", { name: finalName })
          : t("已安装")
      )
      reload()
    } catch (error) {
      logError("重命名并安装", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (tempDir && pathExists(tempDir)) {
        try {
          FileManager.removeSync(tempDir)
        } catch {}
      }
      setRefreshing(false)
    }
  }

  /**
   * 恢复远端备份：
   * - .zip（备份包，可能含多脚本）点击即可下载并查看里面包含的脚本，进选择页勾选恢复（保持旧体验）
   * - .scripting（单/分组脚本备份）点击弹操作列表：重命名 / 重命名并安装 / 覆盖并恢复
   */
  async function openGithubBackup(item: {
    name: string
    path: string
    size: number
  }) {
    if (refreshing) {
      return
    }
    const isZip = item.name.toLowerCase().endsWith(".zip")
    const display = stripScriptExt(item.name)
    // .scripting：点击弹操作列表（重命名 / 重命名并安装 / 覆盖并恢复）；zip 点击直接看内容，不做预先弹窗
    if (!isZip) {
      // 去尾缀的名称命中 scripts 目录中已有目录时，提示会覆盖；多脚本打包名不匹配任何目录时视为不存在
      const exists = pathExists(
        Path.join(FileManager.scriptsDirectory, display)
      )
      const choice = await Dialog.actionSheet({
        title: t("恢复备份"),
        message: exists
          ? tpl(
              "将恢复「{name}」，确认后开始下载；目录中已存在同名脚本，恢复会覆盖当前版本。",
              { name: display }
            )
          : tpl("将恢复「{name}」，确认后开始下载并恢复。", { name: display }),
        actions: [
          { label: t("重命名") },
          { label: t("重命名并安装") },
          { label: t("覆盖并恢复"), destructive: true },
        ],
      })
      if (choice == null) {
        return
      }
      if (choice === 0) {
        // 重命名：改远端备份文件名（与长按多选重命名一致）
        const name = await inputPrompt({
          title: t("重命名备份"),
          message: t("输入新的备份名称"),
          defaultValue: display,
          placeholder: display,
        })
        if (name == null || !name.trim()) {
          return
        }
        try {
          await renameGithubBackup(gh, item, name.trim())
          showToast(t("已重命名"))
          reload()
        } catch (error) {
          logError("重命名Github备份", error)
          showToast(error instanceof Error ? error.message : String(error), true)
        }
        return
      }
      if (choice === 1) {
        // 重命名并安装：下载后改名安装到本地（不覆盖）
        await renameInstallBackup(item)
        return
      }
      // choice === 2：覆盖并恢复，继续走下方下载恢复逻辑
    }
    // zip 且 manifest 已有脚本名单：先用名单秒出骨架列表，后台下载解压填充真实内容
    const manifestScripts = manifest?.backups[item.path]?.scripts
    if (isZip && manifestScripts && manifestScripts.length > 0) {
      const skeleton: CandidateScript[] = manifestScripts.map((s) => ({
        folderName: s.name,
        sourcePath: "",
        version: s.version,
      }))
      let skeletonTempDir: string | null = null
      const result = await Navigation.present(
        <ScriptSelectionPage
          candidates={skeleton}
          loader={async () => {
            const zipPath = await downloadGithubBackup(gh, item.path)
            const inspected = inspectBackup({
              name: item.name,
              path: zipPath,
              isZip: true,
              modifiedAt: Date.now(),
              byteSize: item.size,
              scriptCount: 0,
            })
            if (!inspected) {
              throw new Error(t("无法读取该备份"))
            }
            skeletonTempDir = inspected.tempDir
            if (inspected.candidates.length === 0) {
              throw new Error(t("该备份中没有找到脚本（缺少 script.json）"))
            }
            return inspected.candidates
          }}
          cleanup={() => {
            if (skeletonTempDir && pathExists(skeletonTempDir)) {
              try {
                FileManager.removeSync(skeletonTempDir)
              } catch {}
            }
          }}
        />
      )
      if (result?.restored != null) {
        showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
      }
      return
    }
    setRefreshing(true)
    showToast(tpl("正在下载 {name}…", { name: display }))
    let tempDir: string | null = null
    try {
      const zipPath = await downloadGithubBackup(gh, item.path)
      const inspected = inspectBackup({
        name: item.name,
        path: zipPath,
        isZip: true,
        modifiedAt: Date.now(),
        byteSize: item.size,
        scriptCount: 0,
      })
      if (!inspected) {
        showToast(t("无法读取该备份"), true)
        return
      }
      tempDir = inspected.tempDir
      const candidates = inspected.candidates
      if (candidates.length === 0) {
        showToast(t("该备份中没有找到脚本（缺少 script.json）"), true)
        return
      }
      if (!isZip && candidates.length === 1) {
        // .scripting 下载前已确认恢复/覆盖，这里直接恢复，不再重复弹确认
        await restoreScripts([candidates[0]], true)
        markRestoredAsBaseline([candidates[0]])
        notifyBackupChange()
        showToast(t("已恢复"))
        return
      }
      // zip 或 .scripting 多脚本：进选择页查看并勾选要恢复的脚本
      const result = await Navigation.present(
        <ScriptSelectionPage candidates={candidates} />
      )
      if (result?.restored != null) {
        showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
      }
    } catch (error) {
      logError("Github备份恢复", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (tempDir && pathExists(tempDir)) {
        try {
          FileManager.removeSync(tempDir)
        } catch {}
      }
      setRefreshing(false)
    }
  }

  const toolbar = (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button title={t("返回")} action={dismiss} />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button
          title={refreshing ? t("加载中…") : t("刷新")}
          action={() => reload()}
        />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle={t("恢复备份")}
      navigationBarTitleDisplayMode="inline"
      navigationBarBackButtonHidden
      scrollDismissesKeyboard="immediately"
      toast={toastProps}
      toolbar={toolbar}
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: selected.size > 0 ? (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 1 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                {visibleItems.length === 1 || !allSelected ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => {
                      setSelected(new Set())
                    }}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      {t("取消")}
                    </Text>
                  </VStack>
                ) : null}
                {visibleItems.length > 1 ? (
                  <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName={allSelected ? "checkmark.circle.fill" : "checkmark.circle"}
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? t("取消全选") : t("全选")}
                  </Text>
                </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doDeleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("删除")}
                  </Text>
                </VStack>
                {selectedItems.length === 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doRenameSelected}
                  >
                    <Image systemName="pencil" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("重命名")}
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doShareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("分享")}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
          ) : (
            <></>
          ),
        },
      }}
    >
      <Section
        header={
          <VStack alignment="leading" spacing={4}>
            <HStack spacing={8} alignment="center">
            <HStack spacing={4}>
              <Text
                font="headline"
                onLongPressGesture={{ minDuration: 400, perform: toggleSameNameOnly }}
                allowsTightening={true}
              >
                {query.trim()
                  ? tpl("备份列表（匹配 {n} 个）", { n: String(matchedCount) })
                  : tpl("备份列表（共 {n} 个）", { n: String(items.length) })}
              </Text>
              {sameNameOnly ? (
                <Image
                  systemName="line.3.horizontal.decrease.circle.fill"
                  foregroundStyle="systemBlue"
                />
              ) : null}
            </HStack>
            <Spacer />
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const v = String(value)
                setSortMode(v === "name" || v === "name_desc" ? v : "modified")
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name"
                      ? t("按名称 A-Z")
                      : sortMode === "name_desc"
                        ? t("按名称 Z-A")
                        : t("按最新修改")}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">{t("按最新修改")}</Text>
              <Text tag="name">{t("按名称 A-Z")}</Text>
              <Text tag="name_desc">{t("按名称 Z-A")}</Text>
            </Picker>
            </HStack>
            <Text font="caption" foregroundStyle="secondaryLabel">
              {t("长按标题可切换「同名仅显示最新」")}
            </Text>
          </VStack>
        }
        footer={
          <VStack alignment="leading" spacing={4}>
            <Text font="footnote">
              {gh.backupPath
                ? tpl("仓库目录：{dir}（{repo}）", { dir: gh.backupPath, repo: `${gh.owner}/${gh.backupRepo}` })
                : tpl("仓库：{repo}", { repo: `${gh.owner}/${gh.backupRepo}` })}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("备份、删除的文件受网络传输影响不会立马成功，耐心等待即可")}
            </Text>
          </VStack>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索备份")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {loading ? (
          <EmptyState message={t("正在读取备份仓库…")} />
        ) : visibleItems.length === 0 ? (
          <EmptyState message={t("备份仓库里暂无备份，先到首页开始备份吧")} />
        ) : (
          visibleItems.map((item) => {
            const isOn = selected.has(item.path)
            const lower = item.name.toLowerCase()
            const displayName = lower.endsWith(".scripting")
              ? item.name.slice(0, -10)
              : lower.endsWith(".zip")
                ? item.name.slice(0, -4)
                : item.name
            return (
              <HStack
                key={item.path}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(item)
                  } else {
                    openGithubBackup(item)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    toggleOne(item)
                  },
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName={
                      lower.endsWith(".zip")
                        ? "doc.zipper"
                        : "chevron.left.forwardslash.chevron.right"
                    }
                    color="tintColor"
                    small={!lower.endsWith(".zip")}
                    leftPad={lower.endsWith(".zip") ? 0 : -3}
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {formatBytes(item.size)}
                    {manifest?.backups[item.path]
                      ? tpl(" · {date} · {n} 个脚本", {
                          date: formatDate(manifest.backups[item.path].createdAt),
                          n: String(manifest.backups[item.path].scriptCount),
                        })
                      : t(" · 未知")}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== GitHub 仓库文件管理（长按首页分段进入） ====================

/** 长按首页「Github备份 / Github发布」分段后进入的仓库文件管理页：
 *  列出仓库目录下的 .scripting / .zip，点击弹操作列表：删除 / 重命名 /（分享安装链接，仅发布） / 分享链接 / 分享文件 */
function GithubRepoManagePage({ mode }: { mode: "backup" | "publish" }) {
  const isPublish = mode === "publish"
  const [query, setQuery] = useState("")
  const [items, setItems] = useState<GithubRepoFile[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  // 排序模式：与备份管理页一致（按最新修改 / 按名称 A-Z / 按名称 Z-A）；最新修改时间来自 commits API
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">("modified")
  // 文件最新修改时间缓存：path → 时间戳（发布仓库 Contents API 无时间字段，reload 时并行查 commits API）
  const [modifiedAt, setModifiedAt] = useState<Record<string, number>>({})
  const { showToast, toastProps } = useToast()
  const dismiss = Navigation.useDismiss()

  // 用解析后的实际生效配置（token/owner/repo/branch/dir）
  const gh = useMemo(
    () =>
      (isPublish ? resolvePublishGithubConfig : resolveBackupGithubConfig)(
        resolveGithubConfig()
      ),
    [isPublish]
  )
  const params = useMemo<GithubRepoParams>(
    () => ({
      token: gh.token,
      owner: gh.owner,
      repo: isPublish ? gh.repo : gh.backupRepo,
      branch: isPublish ? gh.branch : gh.backupBranch,
      dir: isPublish ? gh.path : gh.backupPath,
    }),
    [gh, isPublish]
  )

  const visibleItems = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? items.filter((item) => keywordMatches(item.name, keyword))
      : [...items]
    // 排序逻辑与 GithubRestorePage（备份管理页）一致：按最新修改 / 按名称 A-Z / 按名称 Z-A
    if (sortMode === "name") {
      list.sort((a, b) => a.name.localeCompare(b.name))
    } else if (sortMode === "name_desc") {
      list.sort((a, b) => b.name.localeCompare(a.name))
    } else {
      list.sort((a, b) => (modifiedAt[b.path] ?? 0) - (modifiedAt[a.path] ?? 0))
    }
    return list
  }, [items, query, sortMode, modifiedAt])

  const selectedItems = items.filter((item) => selected.has(item.path))
  const allSelected =
    visibleItems.length > 0 && visibleItems.every((item) => selected.has(item.path))

  async function reload() {
    if (!params.token || !params.owner || !params.repo) {
      setLoading(false)
      showToast(
        t(isPublish ? "未配置，请在设置中填写 GitHub 发布参数" : "未配置，请在设置中填写 GitHub 备份参数"),
        true
      )
      return
    }
    setLoading(true)
    try {
      const list = await listGithubRepoFiles(params)
      setItems(list)
      // 发布仓库 Contents API 不返回文件修改时间，并行查 commits API（单个失败跳过，不影响列表）
      const times = await getGithubRepoFilesModifiedAt(params, list)
      setModifiedAt(times)
    } catch (error) {
      logError("Github仓库文件列表", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    reload()
  }, [])

  const rawUrl = (path: string) =>
    `https://raw.githubusercontent.com/${params.owner}/${params.repo}/${params.branch}/${path}`

  function displayName(name: string) {
    const lower = name.toLowerCase()
    return lower.endsWith(".scripting")
      ? name.slice(0, -10)
      : lower.endsWith(".zip")
        ? name.slice(0, -4)
        : name
  }

  /** 删除仓库文件（即时执行，无确认） */
  async function doDelete(item: GithubRepoFile) {
    setRefreshing(true)
    try {
      await deleteGithubRepoFile(params, item.path)
      showToast(t("已删除"))
      setItems(items.filter((x) => x.path !== item.path))
    } catch (error) {
      logError("删除Github仓库文件", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setRefreshing(false)
    }
  }

  /** 重命名仓库文件（仅备份管理页显示入口） */
  async function doRename(item: GithubRepoFile) {
    const base = displayName(item.name)
    const name = await inputPrompt({
      title: t("重命名"),
      message: t("输入新的备份名称"),
      defaultValue: base,
      placeholder: base,
    })
    if (name == null || !name.trim()) {
      return
    }
    setRefreshing(true)
    try {
      await renameGithubRepoFile(params, item, name.trim())
      showToast(t("已重命名"))
      reload()
    } catch (error) {
      logError("重命名Github仓库文件", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setRefreshing(false)
    }
  }

  /** 分享安装链接（仅发布页、非 zip）：生成导入链接并复制 */
  async function doShareInstall(item: GithubRepoFile) {
    const link = buildImportLinkFromUrl(rawUrl(item.path))
    try {
      await Pasteboard.setString(link)
      showToast(t("安装链接已复制"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 分享文件链接：复制到剪贴板（URL 编码后的链接，中文文件名会被百分号编码，便于直接粘贴分享/导入） */
  async function doShareLink(item: GithubRepoFile) {
    try {
      await Pasteboard.setString(encodeURI(rawUrl(item.path)))
      showToast(t("链接已复制"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 分享文件：下载到临时目录后调起系统分享面板 */
  async function doShareFile(item: GithubRepoFile) {
    setRefreshing(true)
    let localPath: string | null = null
    try {
      localPath = await downloadGithubRepoFile(params, item.path)
      await ShareSheet.present([localPath])
    } catch (error) {
      logError("分享Github仓库文件", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (localPath) {
        const dirPath = Path.dirname(localPath)
        if (pathExists(dirPath)) {
          try {
            FileManager.removeSync(dirPath)
          } catch {}
        }
      }
      setRefreshing(false)
    }
  }

  /** 覆盖到本地：下载仓库文件并解压恢复到本地脚本目录（覆盖同名脚本），发布页与备份管理页共用 */
  async function doOverwriteLocal(item: GithubRepoFile) {
    setRefreshing(true)
    showToast(tpl("正在下载 {name}…", { name: displayName(item.name) }))
    let localPath: string | null = null
    let tempDir: string | null = null
    try {
      localPath = await downloadGithubRepoFile(params, item.path)
      const inspected = inspectBackup({
        name: item.name,
        path: localPath,
        isZip: true,
        modifiedAt: Date.now(),
        byteSize: item.size,
        scriptCount: 0,
      })
      if (!inspected) {
        showToast(t("无法读取该文件"), true)
        return
      }
      tempDir = inspected.tempDir
      const candidates = inspected.candidates
      if (candidates.length === 0) {
        showToast(t("该备份中没有找到脚本（缺少 script.json）"), true)
        return
      }
      const conflicts = candidates.filter((c) =>
        pathExists(Path.join(FileManager.scriptsDirectory, c.folderName))
      )
      if (conflicts.length > 0) {
        const index = await Dialog.actionSheet({
          title: t("覆盖确认"),
          message: tpl("以下 {n} 个脚本已存在，将覆盖当前版本：\n{names}", {
            n: String(conflicts.length),
            names: conflicts.map((c) => c.folderName).join("、"),
          }),
          // 不传 cancelButton：与首页脚本名菜单一致，取消由系统独立显示在底部
          actions: [{ label: t("覆盖并恢复"), destructive: true }],
        })
        if (index !== 0) {
          return
        }
      }
      const restored = await restoreScripts(candidates, true)
      markRestoredAsBaseline(candidates)
      notifyBackupChange()
      showToast(tpl("已恢复 {n} 个脚本", { n: String(restored.restored.length) }))
    } catch (error) {
      logError("覆盖到本地", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (localPath) {
        const staging = Path.dirname(localPath)
        if (pathExists(staging)) {
          try {
            FileManager.removeSync(staging)
          } catch {}
        }
      }
      if (tempDir && pathExists(tempDir)) {
        try {
          FileManager.removeSync(tempDir)
        } catch {}
      }
      setRefreshing(false)
    }
  }

  function toggleOne(item: GithubRepoFile) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(item.path)) {
        next.delete(item.path)
      } else {
        next.add(item.path)
      }
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      if (allSelected) {
        visibleItems.forEach((item) => next.delete(item.path))
      } else {
        visibleItems.forEach((item) => next.add(item.path))
      }
      return next
    })
  }

  /** 批量删除仓库文件（带确认） */
  async function doDeleteSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要删除的文件"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("删除文件"),
      message: tpl("确定删除 {n} 个远端文件？此操作不可恢复。", {
        n: String(selectedItems.length),
      }),
      actions: [{ label: t("删除"), destructive: true }],
    })
    if (index !== 0) {
      return
    }
    let okCount = 0
    for (const item of selectedItems) {
      try {
        await deleteGithubRepoFile(params, item.path)
        okCount += 1
      } catch (error) {
        logError("Github仓库文件删除", error)
      }
    }
    if (okCount > 0) {
      showToast(tpl("已删除 {n} 个文件", { n: String(okCount) }))
    } else {
      showToast(t("删除失败"), true)
    }
    setSelected(new Set())
    reload()
  }

  /** 重命名选中的文件（仅备份管理页显示入口，单选） */
  async function doRenameSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要重命名的文件"), true)
      return
    }
    if (selectedItems.length > 1) {
      showToast(t("重命名仅支持单选文件"), true)
      return
    }
    const item = selectedItems[0]
    const name = await inputPrompt({
      title: t("重命名"),
      message: t("输入新的文件名称"),
      defaultValue: displayName(item.name),
      placeholder: displayName(item.name),
    })
    if (name == null || !name.trim()) {
      return
    }
    setRefreshing(true)
    try {
      await renameGithubRepoFile(params, item, name.trim())
      showToast(t("已重命名"))
      setSelected(new Set())
      reload()
    } catch (error) {
      logError("重命名Github仓库文件", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setRefreshing(false)
    }
  }

  /** 批量分享：下载多个文件到临时目录后调起系统分享面板 */
  async function doShareSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要分享的文件"), true)
      return
    }
    setRefreshing(true)
    const downloaded: string[] = []
    try {
      for (const item of selectedItems) {
        downloaded.push(await downloadGithubRepoFile(params, item.path))
      }
      await ShareSheet.present(downloaded)
    } catch (error) {
      logError("分享Github仓库文件", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      for (const localPath of downloaded) {
        const dirPath = Path.dirname(localPath)
        if (pathExists(dirPath)) {
          try {
            FileManager.removeSync(dirPath)
          } catch {}
        }
      }
      setRefreshing(false)
    }
  }

  function onTapItem(item: GithubRepoFile) {
    const isZip = item.name.toLowerCase().endsWith(".zip")
    const showInstall = isPublish && !isZip
    const actions = [
      { label: t("删除"), destructive: true },
      { label: t("覆盖到本地"), destructive: true },
      // 重命名仅备份管理页提供：发布页文件名由导入决定，不提供改名
      ...(!isPublish ? [{ label: t("重命名") }] : []),
      ...(showInstall ? [{ label: t("分享安装链接") }] : []),
      { label: t("分享链接") },
      { label: t("分享文件") },
    ]
    Dialog.actionSheet({
      title: item.name,
      message: tpl("大小：{size}", { size: formatBytes(item.size) }),
      // 不传 cancelButton: false：与首页脚本名菜单一致，取消由系统独立显示在底部
      actions,
    }).then((index: number | null) => {
      if (index == null) return
      const action = actions[index]
      if (!action) return
      if (action.label === t("删除")) {
        doDelete(item)
      } else if (action.label === t("覆盖到本地")) {
        doOverwriteLocal(item)
      } else if (action.label === t("重命名")) {
        doRename(item)
      } else if (action.label === t("分享安装链接")) {
        doShareInstall(item)
      } else if (action.label === t("分享链接")) {
        doShareLink(item)
      } else if (action.label === t("分享文件")) {
        doShareFile(item)
      }
    })
  }

  const toolbar = (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button title={t("返回")} action={dismiss} />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button
          title={refreshing ? t("加载中…") : t("刷新")}
          action={() => reload()}
        />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle={t(isPublish ? "Github发布" : "Github备份")}
      navigationBarTitleDisplayMode="inline"
      navigationBarBackButtonHidden
      scrollDismissesKeyboard="immediately"
      toast={toastProps}
      toolbar={toolbar}
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: selected.size > 0 ? (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 1 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                {visibleItems.length === 1 || !allSelected ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => {
                      setSelected(new Set())
                    }}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      {t("取消")}
                    </Text>
                  </VStack>
                ) : null}
                {visibleItems.length > 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={toggleAll}
                  >
                    <Image
                      systemName={allSelected ? "checkmark.circle.fill" : "checkmark.circle"}
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    />
                    <Text
                      font="caption2"
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    >
                      {allSelected ? t("取消全选") : t("全选")}
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doDeleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("删除")}
                  </Text>
                </VStack>
                {!isPublish && selectedItems.length === 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doRenameSelected}
                  >
                    <Image systemName="pencil" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("重命名")}
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doShareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("分享")}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
          ) : (
            // 未多选时底部不放固定内容——仓库信息与提示放在下方 Section 的 footer 里随列表滚动，
            // 与 GithubRestorePage（恢复备份页）的排版保持一致，不固定在屏幕底部
            <></>
          ),
        },
      }}
    >
      <Section
        header={
          <HStack spacing={8} alignment="center">
            <Text font="headline" allowsTightening={true}>
              {tpl(isPublish ? "发布列表（共 {n} 个）" : "备份列表（共 {n} 个）", {
                n: String(items.length),
              })}
            </Text>
            <Spacer />
            {/* 排序菜单：样式抄 GithubRestorePage（备份管理页），选项一致：按最新修改 / 按名称 A-Z / 按名称 Z-A；
                最新修改时间来自 commits API（Contents API 不返回时间） */}
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const v = String(value)
                setSortMode(v === "name" || v === "name_desc" ? v : "modified")
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name"
                      ? t("按名称 A-Z")
                      : sortMode === "name_desc"
                        ? t("按名称 Z-A")
                        : t("按最新修改")}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">{t("按最新修改")}</Text>
              <Text tag="name">{t("按名称 A-Z")}</Text>
              <Text tag="name_desc">{t("按名称 Z-A")}</Text>
            </Picker>
          </HStack>
        }
        footer={
          // 仓库信息与提示（两行小字）：抄自 GithubRestorePage 的 footer 结构，
          // 放在 Section footer 随列表滚动，而不是固定在屏幕下方
          <VStack alignment="leading" spacing={4}>
            <Text font="footnote">
              {params.dir.trim()
                ? tpl("仓库目录：{dir}（{repo}）", {
                    dir: params.dir,
                    repo: `${params.owner}/${params.repo}`,
                  })
                : tpl("仓库：{repo}", { repo: `${params.owner}/${params.repo}` })}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("发布、删除的文件受网络传输影响不会立马成功，耐心等待即可")}
            </Text>
          </VStack>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索文件")}
            label={
              <Image systemName="magnifyingglass" foregroundStyle="secondaryLabel" />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image systemName="xmark.circle.fill" foregroundStyle="secondaryLabel" />
            </HStack>
          ) : null}
        </HStack>
        {loading ? (
          <EmptyState message={t("正在读取仓库…")} />
        ) : visibleItems.length === 0 ? (
          <EmptyState message={t("仓库里暂无文件，先到首页开始备份或发布吧")} />
        ) : (
          visibleItems.map((item) => {
            const isZip = item.name.toLowerCase().endsWith(".zip")
            const isOn = selected.has(item.path)
            return (
              <HStack
                key={item.path}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(item)
                  } else {
                    onTapItem(item)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    toggleOne(item)
                  },
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName={isZip ? "doc.zipper" : "chevron.left.forwardslash.chevron.right"}
                    color="tintColor"
                    small={!isZip}
                    leftPad={isZip ? 0 : -3}
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{displayName(item.name)}</Text>
                  {/* 灰色小字：抄备份管理页「大小 · 时间」格式；时间来自 commits API（拿不到时显示未知） */}
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {formatBytes(item.size)}
                    {modifiedAt[item.path]
                      ? tpl(" · {date}", { date: formatDate(modifiedAt[item.path]) })
                      : t(" · 未知")}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（多脚本选择：搜索 + 全选 + 单恢复/全部恢复） ====================

/** 版本号第三组（patch）+1：输入可为 x.y.z / x.y / x，输出统一三组数字（如 1.2.3 → 1.2.4） */
function bumpPatchVersion(version: string): string {
  const parts = String(version || "0")
    .split(".")
    .map((n) => parseInt(n.trim(), 10) || 0)
  while (parts.length < 3) parts.push(0)
  parts[2] += 1
  return parts.join(".")
}

/** 去掉行首编号（支持 1、1.1、(1)、①、一、 等格式；纯数字+空格等非编号内容不动） */
function stripLineNumber(line: string): string {
  let s = line
  // 圈号（① ② …）或括号编号 (1)（2）：可后跟顿号/点等分隔符或直接接内容
  s = s.replace(/^\s*(?:[①-⑳㉑-㉟㊱-㊿]|[（(]\s*\d+(?:\.\d+)*\s*[)）])[、.．:：]?\s*/, "")
  // 数字/中文数字编号：1、 1.1、 一、 等（必须后跟顿号/点/冒号等分隔符，避免误删正文数字）
  s = s.replace(/^\s*(?:\d+(?:\.\d+)*|[一二三四五六七八九十百千]+)[、.．:：]\s*/, "")
  return s
}

/** 更新说明全屏编辑器：多行 TextField 方便编排格式，默认预填云端/本地说明，底部悬浮按钮取消/清空/发布 */
function ChangelogEditorPage({
  initial,
  scriptName,
  version,
  loadCloudNote,
}: {
  initial: string
  scriptName: string
  version: string
  /** 异步拉取云端更新说明：页面挂载后执行，拉到后若用户尚未编辑则自动补填 */
  loadCloudNote?: () => Promise<
    | { version: string | null; changelog: string | null }
    | null
  >
}) {
  const dismiss = Navigation.useDismiss()
  const [text, setText] = useState(initial)
  // 异步补填云端说明：页面挂载后立即执行，拉到后按版本比较自动填入（用户已编辑则跳过）
  useEffect(() => {
    if (!loadCloudNote) return
    let cancelled = false
    loadCloudNote()
      .then((meta) => {
        if (cancelled || !meta) return
        setText((prev) => {
          // 用户已编辑过（不等于 initial）则不覆盖
          if (prev !== initial) return prev
          if (
            meta.version &&
            compareVersions(meta.version, version) >= 0
          ) {
            // 云端版本更高或相等：优先云端说明，为空回退本地
            return meta.changelog || initial
          }
          // 本地版本更高：优先本地说明，本地为空则回退云端
          return initial || meta.changelog || prev
        })
      })
      .catch(() => {})
    return () => {
      cancelled = true
    }
  }, [])
  // 发布时是否自动把当前版本号最后一组（patch）+1（默认不勾选）。
  // 每次打开都恢复默认不勾选，不记忆上次选择（页面由调用方以自增 key 强制重建）
  const [bumpVersion, setBumpVersion] = useState(false)
  // 发布时是否让作者本人（脚本管理工具设置里用户名==脚本作者）也收到本次更新提示（默认不勾选，作者本人不弹）。
  // 每次打开都恢复默认不勾选，不记忆上次选择（页面由调用方以自增 key 强制重建）
  const [notifyAuthor, setNotifyAuthor] = useState(false)
  const { showToast, toastProps } = useToast()
  /** 一键给每行（非空行）加编号：1、2、3…（已有编号先去除再重新编号） */
  const addLineNumbers = () => {
    let n = 0
    const next = text
      .split("\n")
      .map((line) => {
        if (line.trim() === "") return line
        n += 1
        return `${n}、${stripLineNumber(line)}`
      })
      .join("\n")
    if (next === text) {
      showToast(t("文本没有变化"), true)
      return
    }
    setText(next)
    showToast(t("已为每行加上编号"))
  }
  /** 一键去掉每行行首编号 */
  const removeLineNumbers = () => {
    const next = text.split("\n").map((line) => stripLineNumber(line)).join("\n")
    if (next === text) {
      showToast(t("文本没有变化"), true)
      return
    }
    setText(next)
    showToast(t("已取消每行编号"))
  }
  return (
    <List
      navigationTitle={t("更新说明")}
      navigationBarTitleDisplayMode="inline"
      navigationBarBackButtonHidden
      scrollDismissesKeyboard="immediately"
      toast={toastProps}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: (
            <VStack alignment="center" spacing={6} padding={{ bottom: 10 }}>
              <VStack
                spacing={8}
                alignment="center"
                padding={{ horizontal: 8, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <HStack spacing={12} alignment="center">
                <Text font="caption2" foregroundStyle="secondaryLabel" lineLimit={1} allowsTightening>
                  {tpl("当前版本: {v}", { v: version })}
                </Text>
                <HStack
                  spacing={4}
                  alignment="center"
                  padding={{ horizontal: 4, vertical: 2 }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setNotifyAuthor(!notifyAuthor)}
                >
                  <Image
                    systemName={notifyAuthor ? "checkmark.square.fill" : "square"}
                    foregroundStyle={notifyAuthor ? "tintColor" : "secondaryLabel"}
                  />
                  <Text font="footnote" lineLimit={1} allowsTightening>
                    {t("作者推送")}
                  </Text>
                </HStack>
                <HStack
                  spacing={4}
                  alignment="center"
                  padding={{ horizontal: 4, vertical: 2 }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setBumpVersion(!bumpVersion)}
                >
                  <Image
                    systemName={bumpVersion ? "checkmark.square.fill" : "square"}
                    foregroundStyle={bumpVersion ? "tintColor" : "secondaryLabel"}
                  />
                  <Text font="footnote" lineLimit={1} allowsTightening>
                    {t("版本加一")}
                  </Text>
                </HStack>
                </HStack>
                <HStack spacing={6} alignment="center">
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 44, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => dismiss(null)}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("取消")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 44, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setText("")}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("清空")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 44, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => dismiss({ notes: text, bumpVersion, notifyAuthor })}
                >
                  <Image systemName="paperplane" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("发布")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 44, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={removeLineNumbers}
                >
                  <Image systemName="list.bullet.below.rectangle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("去编")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 44, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={addLineNumbers}
                >
                  <Image systemName="list.number" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("加编")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 44, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={async () => {
                    await Pasteboard.setString(text)
                    showToast(t("已复制更新说明"))
                  }}
                >
                  <Image systemName="doc.on.doc" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("复制")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 44, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={async () => {
                    const s = await Pasteboard.getString()
                    if (s == null) {
                      showToast(t("剪贴板没有文本内容"), true)
                      return
                    }
                    setText(s)
                    showToast(t("已粘贴更新说明"))
                  }}
                >
                  <Image systemName="doc.on.clipboard" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("粘贴")}
                  </Text>
                </VStack>
              </HStack>
              </VStack>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {tpl("{name} 更新后首次运行会自动弹出此说明", { name: scriptName })}
              </Text>
            </VStack>
          ),
        },
      }}
    >
      {/* 标题行：撑满宽度居中，listRowBackground 透明使底色与页面其他区域一致（List 直接子元素默认是带卡片背景的 row） */}
      <VStack
        alignment="center"
        spacing={4}
        padding={{ top: 12, bottom: 12 }}
        frame={{ maxWidth: "infinity" }}
        listRowBackground={<Rectangle fill="rgba(0,0,0,0)" />}
      >
        <Text font="headline">
          {scriptName} · {t("更新说明")}
        </Text>
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {tpl("{name} {v}", { name: t("版本"), v: version })}
        </Text>
      </VStack>
      <Section
        footer={
          <VStack alignment="leading" spacing={2}>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("作者推送：勾选后作者本人（脚本管理工具设置里填写的用户名与脚本作者一致）下次运行也会收到本次更新提示；默认不勾选，作者本人不提示")}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("版本加一：勾选后本次发布时版本号在当前版本基础上自动加一（如 1.2.3 → 1.2.4），并写入脚本 script.json；默认不勾选")}
            </Text>
          </VStack>
        }
      >
        <TextField
          title=""
          value={text}
          onChanged={setText}
          axis="vertical"
          autofocus
          prompt={t("填写本次更新说明，可换行编排格式…")}
        />
      </Section>
    </List>
  )
}

function ScriptSelectionPage({
  candidates: initialCandidates,
  loader,
  cleanup,
}: {
  candidates: CandidateScript[]
  /** 骨架模式：进入页面后后台加载真实列表替换显示（用于恢复页 zip 秒开） */
  loader?: () => Promise<CandidateScript[]>
  /** 页面结束（恢复成功/取消/返回）时清理临时资源（如下载解压的临时目录） */
  cleanup?: () => void
}) {
  const dismiss = Navigation.useDismiss()
  const [candidates, setCandidates] = useState<CandidateScript[]>(initialCandidates)
  const [loadingContent, setLoadingContent] = useState(loader != null)
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [busy, setBusy] = useState(false)
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">(() => {
    const s = resolveConfig().scriptSort
    return s === "name" || s === "name_desc" ? s : "modified"
  })
  const { showToast, toastProps } = useToast()

  // 骨架模式：后台加载真实 candidates 替换骨架列表；失败时保留骨架并提示
  useEffect(() => {
    if (!loader) {
      return
    }
    let cancelled = false
    loader()
      .then((real) => {
        if (cancelled) {
          return
        }
        setCandidates(real)
        setLoadingContent(false)
      })
      .catch((error) => {
        if (cancelled) {
          return
        }
        setLoadingContent(false)
        showToast(
          error instanceof Error ? error.message : String(error),
          true
        )
      })
    return () => {
      cancelled = true
    }
  }, [])

  // 页面卸载（恢复成功 dismiss / 取消 / 系统返回）时清理临时资源
  useEffect(() => {
    return () => cleanup?.()
  }, [])

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    let list = keyword
      ? candidates.filter((c) => keywordMatches(c.folderName, keyword))
      : [...candidates]
    list.sort((a, b) => {
      if (sortMode === "name") {
        return compareNames(a.folderName, b.folderName)
      }
      if (sortMode === "name_desc") {
        return compareNames(b.folderName, a.folderName)
      }
      return (b.modifiedAt ?? 0) - (a.modifiedAt ?? 0)
    })
    return list
  }, [candidates, query, sortMode])

  const allSelected =
    filtered.length > 0 && filtered.every((c) => selected.has(c.folderName))

  function toggleOne(candidate: CandidateScript) {
    const next = new Set(selected)
    if (next.has(candidate.folderName)) {
      next.delete(candidate.folderName)
    } else {
      next.add(candidate.folderName)
    }
    setSelected(next)
  }

  function toggleAll() {
    const next = new Set(selected)
    if (allSelected) {
      filtered.forEach((c) => next.delete(c.folderName))
    } else {
      filtered.forEach((c) => next.add(c.folderName))
    }
    setSelected(next)
  }

  async function doRestore(restoreAll: boolean) {
    if (busy || loadingContent) {
      if (loadingContent) {
        showToast(t("正在获取脚本内容，请稍候…"), true)
      }
      return
    }
    const targets = restoreAll
      ? candidates
      : candidates.filter((c) => selected.has(c.folderName))
    if (targets.length === 0) {
      showToast(t("请先选择要恢复的脚本"), true)
      return
    }

    const conflicts = targets.filter((c) =>
      pathExists(Path.join(FileManager.scriptsDirectory, c.folderName))
    )
    if (conflicts.length > 0) {
      const names = conflicts.map((c) => c.folderName).join("、")
      const index = await Dialog.actionSheet({
        title: t("覆盖确认"),
        message: tpl("以下 {n} 个脚本已存在，恢复将覆盖当前版本：\n{names}", { n: String(conflicts.length), names }),
        // 不传 cancelButton：与首页脚本名菜单一致，取消由系统独立显示在底部
        actions: [{ label: t("覆盖并恢复"), destructive: true }],
      })
      if (index !== 0) {
        return
      }
    }

    setBusy(true)
    try {
      const { restored } = await restoreScripts(targets, true)
      markRestoredAsBaseline(targets)
      notifyBackupChange()
      dismiss({ restored: restored.length })
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
      setBusy(false)
    }
  }

  return (
    <NavigationStack>
      <List
        navigationTitle={t("选择要恢复的脚本")}
        navigationBarTitleDisplayMode="inline"
        scrollDismissesKeyboard="immediately"
        toast={toastProps}
        safeAreaInset={{
          bottom: {
            alignment: "center",
            spacing: 8,
            content: (
              <VStack alignment="center" padding={{ bottom: 10 }}>
                <HStack
                  spacing={10}
                  alignment="center"
                  padding={{ horizontal: 10, vertical: 8 }}
                  background={{
                    style: { color: "secondarySystemBackground", opacity: 0.95 },
                    shape: { type: "rect", cornerRadius: 20 },
                  }}
                >
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => dismiss(null)}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("取消")}
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={toggleAll}
                  >
                    <Image
                      systemName="checklist"
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    />
                    <Text
                      font="caption2"
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    >
                      {allSelected ? t("取消全选") : t("全选")}
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => doRestore(true)}
                  >
                    <Image systemName="checkmark.circle" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("全部")}
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => doRestore(false)}
                  >
                    <Image systemName="arrow.uturn.backward" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {busy ? t("恢复中…") : tpl("恢复 ({n})", { n: String(selected.size) })}
                    </Text>
                  </VStack>
                </HStack>
              </VStack>
            ),
          },
        }}
      >
        <Section
          header={
            <HStack spacing={8} alignment="center">
              <Text font="headline">{tpl("这个备份里有 {n} 个脚本", { n: String(candidates.length) })}</Text>
              <Spacer />
              <Picker
                value={sortMode}
                onChanged={(value: string | number) => {
                  const v = String(value)
                  const next = v === "name" || v === "name_desc" ? v : "modified"
                  setSortMode(next)
                  saveConfig({ ...resolveConfig(), scriptSort: next })
                }}
                pickerStyle="menu"
                padding={{ trailing: -12 }}
                label={
                  <HStack spacing={4}>
                    <Image
                      systemName="arrow.up.arrow.down"
                      foregroundStyle="secondaryLabel"
                    />
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      {sortMode === "name"
                        ? t("按名称 A-Z")
                        : sortMode === "name_desc"
                          ? t("按名称 Z-A")
                          : t("按最新修改")}
                    </Text>
                  </HStack>
                }
              >
                <Text tag="modified">{t("按最新修改")}</Text>
                <Text tag="name">{t("按名称 A-Z")}</Text>
                <Text tag="name_desc">{t("按名称 Z-A")}</Text>
              </Picker>
            </HStack>
          }
        />

        <Section>
          <HStack spacing={8}>
            <TextField
              value={query}
              onChanged={setQuery}
              prompt={t("搜索脚本名")}
              label={
                <Image
                  systemName="magnifyingglass"
                  foregroundStyle="secondaryLabel"
                />
              }
            />
            {query.length > 0 ? (
              <HStack
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => setQuery("")}
              >
                <Image
                  systemName="xmark.circle.fill"
                  foregroundStyle="secondaryLabel"
                />
              </HStack>
            ) : null}
          </HStack>
        </Section>

        <Section header={<Text font="headline">{t("脚本列表")}</Text>}>
          {loadingContent ? (
            <HStack spacing={8} padding={{ vertical: 4 }}>
              <Image
                systemName="arrow.triangle.2.circlepath"
                foregroundStyle="secondaryLabel"
              />
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {t("正在获取脚本内容…")}
              </Text>
            </HStack>
          ) : null}
          {filtered.length === 0 ? (
            <EmptyState message={t("未找到匹配的脚本")} />
          ) : (
            filtered.map((candidate) => {
              const isOn = selected.has(candidate.folderName)
              const metaLine = [
                candidate.version ? `v${candidate.version}` : null,
                candidate.modifiedAt ? formatDate(candidate.modifiedAt) : null,
              ]
                .filter(Boolean)
                .join(" · ")
              return (
                <HStack
                  key={candidate.folderName}
                  spacing={10}
                  contentShape="rect"
                  onTapGesture={() => toggleOne(candidate)}
                >
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                  <VStack alignment="leading" spacing={2}>
                    <Text font="body">{candidate.folderName}</Text>
                    {metaLine ? (
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        {metaLine}
                      </Text>
                    ) : null}
                  </VStack>
                  <Spacer />
                </HStack>
              )
            })
          )}
        </Section>
      </List>
    </NavigationStack>
  )
}

// ==================== 脚本管理 ====================

function ManagePage() {
  const [query, setQuery] = useState("")
  const [editMode, setEditMode] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [refresh, setRefresh] = useState(0)
  const [scripts, setScripts] = useState<ScriptInfo[]>([])
  const [scriptsLoading, setScriptsLoading] = useState(true)
  const { showToast, toastProps } = useToast()

  useEffect(() => {
    setScriptsLoading(true)
    setTimeout(() => {
      setScripts(scanScripts())
      setScriptsLoading(false)
    }, 50)
  }, [refresh])

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    if (!keyword) {
      return scripts
    }
    return scripts.filter(
      (s) =>
        keywordMatches(s.displayName, keyword) ||
        keywordMatches(s.folderName, keyword)
    )
  }, [scripts, query])

  // 一次性构建 文件夹→分组 映射，避免每行重复全量扫描
  const groupNameMap = useMemo(() => buildGroupNameMap(), [refresh])

  const selectedScripts = scripts.filter((s) => selected.has(s.folderName))
  const allSelected =
    filtered.length > 0 && filtered.every((s) => selected.has(s.folderName))

  function refreshScripts() {
    setSelected(new Set())
    setRefresh((v) => v + 1)
  }

  function toggleOne(script: ScriptInfo) {
    const next = new Set(selected)
    if (next.has(script.folderName)) {
      next.delete(script.folderName)
    } else {
      next.add(script.folderName)
    }
    setSelected(next)
  }

  function toggleAll() {
    const next = new Set(selected)
    if (allSelected) {
      filtered.forEach((s) => next.delete(s.folderName))
    } else {
      filtered.forEach((s) => next.add(s.folderName))
    }
    setSelected(next)
  }

  async function doRename(script: ScriptInfo) {
    const name = await inputPrompt({
      title: t("重命名脚本"),
      message: t("输入新的脚本名称"),
      defaultValue: script.folderName,
      placeholder: script.folderName,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameScript(script, name.trim())
      refreshScripts()
      showToast(t("已重命名"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doMoveToGroup(script: ScriptInfo) {
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast(t("没有可移动的分组"), true)
      return
    }
    const ordered = orderGroupsForMove(named, resolveConfig().groupOrder)
    const index = await Dialog.actionSheet({
      title: t("移动到分组"),
      message: `把「${script.displayName}」移动到哪个分组？`,
      // 不传 cancelButton：与首页脚本名菜单一致，取消由系统独立显示在底部
      actions: ordered.map((g) => ({ label: g.name })),
    })
    if (index == null) {
      return
    }
    const target = ordered[index]
    try {
      moveScriptToGroup(script, target.name)
      refreshScripts()
      showToast(`已移动到「${target.name}」`)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doChangeVersion(script: ScriptInfo) {
    if (!(await ensureVersionNotOverridden(script))) {
      return
    }
    const version = await inputPrompt({
      title: t("修改版本号"),
      message: t("输入新的版本号（格式 x.y.z，例如 1.0.1）"),
      defaultValue: script.version,
      placeholder: script.version,
      keyboardType: "numbersAndPunctuation",
    })
    if (version == null || !version.trim()) {
      return
    }
    try {
      setScriptVersion(script, version.trim())
      refreshScripts()
      showToast(t("版本号已更新"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doShare(list: ScriptInfo[]) {
    if (list.length === 0) {
      showToast(t("请先选择脚本"), true)
      return
    }
    try {
      await shareScripts(list)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doDelete(list: ScriptInfo[]) {
    if (list.length === 0) {
      showToast(t("请先选择脚本"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("删除确认"),
      message: `确定删除 ${list.length} 个脚本？此操作不可恢复。`,
      actions: [{ label: t("删除"), destructive: true }],
    })
    if (index !== 0) {
      return
    }
    try {
      for (const script of list) {
        deleteScript(script)
      }
      refreshScripts()
      showToast(t("已删除"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 复制该脚本的 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]） */
  async function copyScriptShareLink(script: ScriptInfo) {
    const link = buildScriptImportLink(script)
    if (!link) {
      showToast(t("该脚本没有发布链接，请先发布"), true)
      return
    }
    try {
      await Pasteboard.setString(link)
      showToast(t("导入链接已复制"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function rowActions(script: ScriptInfo) {
    const group = groupNameForScript(script.folderName)
    const actions: Array<{ label: string; destructive?: boolean }> = [
      { label: t("重命名") },
      { label: t("移动到其他分组") },
    ]
    if (resolveConfig().githubPublishEnabled && hasPublishedLink(script)) {
      actions.push({ label: t("分享(链接)") })
      actions.push({ label: t("分享(文件)") })
    } else {
      actions.push({ label: t("分享") })
    }
    actions.push({ label: t("修改版本号") })
    actions.push({ label: t("删除"), destructive: true })

    const index = await Dialog.actionSheet({
      title: script.displayName,
      message: `版本 ${script.version} · ${formatDate(script.modifiedAt)} · ${formatBytes(script.byteSize)} · 分组 ${group ?? t("未分组")}`,
      actions,
    })
    if (index == null) {
      return
    }
    const action = actions[index]
    if (!action) {
      return
    }
    switch (action.label) {
      case t("重命名"):
        await doRename(script)
        break
      case t("移动到其他分组"):
        await doMoveToGroup(script)
        break
      case t("分享(链接)"):
        await copyScriptShareLink(script)
        break
      case t("分享(文件)"):
      case t("分享"):
        await doShare([script])
        break
      case t("修改版本号"):
        await doChangeVersion(script)
        break
      case t("删除"):
        await doDelete([script])
        break
    }
  }

  /** 左划操作已改用 trailingSwipeActions（重命名/移到其他分组） */

  const toolbar = editMode ? (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button
          title={allSelected ? t("取消全选") : t("全选")}
          action={toggleAll}
        />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("完成")} action={() => setEditMode(false)} />
      </ToolbarItem>
    </Toolbar>
  ) : (
    <Toolbar>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("选择")} action={() => setEditMode(true)} />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle={t("脚本管理")}
      navigationBarTitleDisplayMode="inline"
      scrollDismissesKeyboard="immediately"
      toolbar={toolbar}
      toast={toastProps}
    >
      <Section>
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索脚本名")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
      </Section>

      {editMode ? (
        <Section
          header={<Text font="headline">批量操作</Text>}
          footer={
            <Text font="footnote">
              已选 {selectedScripts.length} 个脚本；点击行可勾选/取消
            </Text>
          }
        >
          <HStack
            spacing={10}
            contentShape="rect"
            onTapGesture={toggleAll}
          >
            <Image
              systemName={allSelected ? "checkmark.circle.fill" : "circle"}
              foregroundStyle={allSelected ? "systemBlue" : "secondaryLabel"}
            />
            <Text font="body">{allSelected ? t("取消全选") : t("全选")}</Text>
            <Spacer />
            <Text font="caption" foregroundStyle="secondaryLabel">
              已选 {selected.size} 个
            </Text>
          </HStack>
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => doDelete(selectedScripts)}
          >
            <Spacer />
            <Image systemName="trash" foregroundStyle="systemRed" />
            <Text font="body" foregroundStyle="systemRed">
              删除选中 ({selectedScripts.length})
            </Text>
            <Spacer />
          </HStack>
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => doShare(selectedScripts)}
          >
            <Spacer />
            <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              分享选中 ({selectedScripts.length})
            </Text>
            <Spacer />
          </HStack>
        </Section>
      ) : null}

      <Section
        header={<Text font="headline">脚本列表（{filtered.length}）</Text>}
        footer={
          <Text font="footnote">
            {editMode ? t("勾选脚本后可用下方按钮批量删除/分享") : t("点击脚本可重命名、分享、修改版本号或删除")}
          </Text>
        }
      >
        {scriptsLoading ? (
          <EmptyState message={t("正在加载脚本…")} />
        ) : filtered.length === 0 ? (
          <EmptyState message={t("没有找到脚本")} />
        ) : (
          filtered.map((script) => {
            const isOn = selected.has(script.folderName)
            const group = groupNameMap.get(script.folderName) ?? null
            return (
              <HStack
                key={script.folderName}
                spacing={10}
                contentShape="rect"
                onTapGesture={() => {
                  if (editMode) {
                    toggleOne(script)
                  } else {
                    rowActions(script)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    if (!editMode) {
                      setEditMode(true)
                    }
                    toggleOne(script)
                  },
                }}
                trailingSwipeActions={{
                  allowsFullSwipe: true,
                  actions: [
                    <Button
                      title={t("重命名")}
                      tint="systemBlue"
                      action={() => doRename(script)}
                    />,
                    <Button
                      title={t("移到其他分组")}
                      tint="orange"
                      action={() => doMoveToGroup(script)}
                    />,
                  ],
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName="chevron.left.forwardslash.chevron.right"
                    color="tintColor"
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{script.displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    v{script.version} · {formatDate(script.modifiedAt)}
                    {group ? ` · ${group}` : t(" · 默认")}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 入口 ====================

async function run() {
  await Navigation.present({
    element: <MainPage />,
    modalPresentationStyle: "overFullScreen",
  })
  Script.exit()
}

// 被 home_screen_default_ui.tsx 作为首页标签复用时，不应自动运行入口
if (Script.env !== "home_screen") {
  run()
}