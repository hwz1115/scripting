import { Path, fetch } from "scripting"

// ==================== 常量 ====================

export const APP_NAME = "脚本管理工具"
export const BACKUP_DIR_NAME = "ScriptBackups"

const CONFIG_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "script-manager-config.json"
)

const GITHUB_CONFIG_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "script-manager-github.json"
)

// ==================== 类型 ====================

export type Destination = "iphone" | "icloud" | "github_publish" | "github_backup"
export type BackupScopeKey = "recent" | "all" | "group" | "select"

export type AppConfig = {
  /** 备份目的地，默认 iPhone，记住上次选择 */
  destination: Destination
  /** 备份范围，记住上次选择 */
  scope: BackupScopeKey
  /** 是否启用 Github备份（设置里勾选后才显示该入口与配置） */
  githubBackupEnabled: boolean
  /** 是否启用 Github发布（设置里勾选后才显示该入口与配置，仅开发者需要） */
  githubPublishEnabled: boolean
  /** 是否记住首页「备份/恢复」的展开状态（默认勾选=记住） */
  rememberExpandState: boolean
  /** 首页「备份/恢复」当前展开与否（勾选「记住展开状态」时生效） */
  backupRestoreExpanded: boolean
  /** 置顶脚本的文件夹名列表（置顶的脚本排在列表最上方） */
  pinnedScripts: string[]
  /** 脚本列表排序方式：最新修改 / 最近使用 / 名称 A-Z / 名称 Z-A / 按分组（按分组顺序，同分组内按最近使用） / 按脚本作者（填了用户名则把自己的脚本固定最前，其余按作者名 A-Z 分组） / 按运行次数（统计累计运行次数） */
  scriptSort: "modified" | "recent" | "name" | "name_desc" | "group" | "author" | "usage"
  /** 自己的用户名（脚本作者名），用于「按脚本作者」排序时把自己脚本固定排最前；不填也能使用该排序，只是不把脚本置顶 */
  authorName: string
  /** 分组自定义顺序（分组名列表），用于「按分组」排序时按此顺序显示分组；不在列表中的分组排在后面（按名称） */
  groupOrder: string[]
  /** 搜索时是否保留不匹配的脚本（默认开启：全部显示、匹配的排在前面；关闭则只显示匹配项） */
  searchKeepAll: boolean
  /** 搜索时关键词是否匹配脚本作者名（默认关闭：只匹配脚本名；勾选后也能匹配作者名） */
  searchMatchAuthor: boolean
  /** 界面语言：中文 / English（默认中文） */
  language: "zh" | "en"
  /** 版本变化自动备份：脚本版本号变化时自动备份到当前备份目标（默认关闭） */
  autoBackupOnUpgrade: boolean
  /** 是否隐藏首页「恢复备份」模块（设置里勾选后首页不显示，默认否） */
  hideRestoreModule: boolean
  /** 首页脚本名称下方是否显示脚本作者（默认勾选=显示） */
  showScriptAuthor: boolean
  /** 首页脚本名称下方是否显示分组名（默认勾选=显示） */
  showScriptGroupName: boolean
  /** 最近使用时间映射（folderName → 最近一次运行的毫秒时间戳），用于「按最近使用」排序 */
  recentUsedAt: Record<string, number>
  /** 最近运行记录（folderName 列表，只保留最近 50 次，最新的在前）：通过本工具运行脚本一次记一条，兼容旧版本遗留数据，
   *  持久保存在配置文件中，关闭脚本/Scripting 后不丢失；用于「按运行次数」排序（统计最近 50 次内出现次数） */
  recentRunLog: string[]
  /** 上次记录的脚本版本号映射（folderName → version），用于检测版本变化 */
  scriptVersionRecord: Record<string, string>
  /** 上次记录的脚本内容指纹映射（folderName → 目录指纹），用于检测“内容更新但版本号未变”的变化 */
  scriptContentRecord: Record<string, string>
  /** 智能体（AI 维护流程）最近修改脚本的标记（folderName → 毫秒时间戳）：
   * 自动备份扫描时把时间窗内的脚本当作“手动修改”处理，只备份它并忽略同批自动更新 */
  agentModifiedAt: Record<string, number>
  /** 仓库监控更新页刚发起导入的脚本标记（folderName → 毫秒时间戳）：
   * 用于「刚导入且版本号与本地一致（同版本内容刷新）」时不触发自动备份，只吸收基线 */
  channelImportedAt: Record<string, number>
  /** 脚本分组快照（folderName → 分组名）：覆盖导入/恢复时用于把脚本恢复回原分组，
   * 避免 Scripting 导入覆盖后写回 settings.json 导致脚本从分组中丢失 */
  scriptGroupSnapshot: Record<string, string>
  /** 上次发布时各脚本的版本号映射（folderName → version），用于检测「云端与本地不同步」 */
  publishedVersions: Record<string, string>
  /** 最近一次发布成功时各脚本的本地内容指纹（folderName → scriptContentFingerprint），
   * 用于检测「版本号没变但本地内容与云端发布不同」（微调内容未重新发布时显示橙色普通云） */
  publishedFingerprints: Record<string, string>
  /** 无发布记录指纹的历史发布脚本：从云端包下载计算的内容指纹缓存（folderName → scriptContentFingerprint），
   * 作为 publishedFingerprints 的兜底基线，用于检测「本地内容与云端发布内容不同」 */
  cloudFingerprints: Record<string, string>
  /** 已发布脚本的云端版本缓存（folderName → version，从 remoteResource 下载读取，用于无发布记录的历史发布脚本） */
  cloudVersions: Record<string, string>
  /** 最近一次发布时填写的更新说明（folderName → 说明），本地记录 */
  publishedChangelogs: Record<string, string>
  /** 已发布脚本的云端更新说明缓存（folderName → 说明，从 remoteResource 下载读取） */
  cloudChangelogs: Record<string, string>
  /** 各脚本最近一次成功/尝试拉取云端元数据（版本/指纹/说明）的时间戳（folderName → 毫秒），
   * 用于「本地版本与云端缓存不一致」时重新下载云端包确认的节流，避免每次打开都重复下载 */
  cloudCheckedAt: Record<string, number>
  /** 仓库监控：是否启用（监控 GitHub 仓库里 .scripting 文件的变化并提示） */
  channelMonitorEnabled: boolean
  /** 仓库监控：是否发送「有更新」系统通知（默认开启；关闭后监控仍检查，但不再通过通知提示有脚本更新） */
  channelMonitorNotificationEnabled: boolean
  /** 仓库监控：检查间隔数值（配合单位） */
  channelMonitorInterval: number
  /** 仓库监控：检查间隔单位（分/小时/天） */
  channelMonitorIntervalUnit: "minute" | "hour" | "day"
  /** 仓库监控：监控的仓库链接列表（url + 可编辑备注名） */
  channelMonitorLinks: ChannelMonitorLink[]
  /** 仓库监控：各仓库最近一次扫描的 文件路径→sha 快照（url → path → sha），用于检测变化 */
  channelMonitorSnapshots: Record<string, Record<string, string>>
  /** 仓库监控：是否已建立过基线（首次扫描只记录不提示） */
  channelMonitorBaselineReady: boolean
  /** 仓库监控：排除关键词（脚本名称包含任一关键词时，即使有更新也不提示、不列入更新页） */
  channelMonitorExcludeKeywords: string[]
  /** 仓库监控：已自动提示过的变化签名（同一批变化只提示一次，跨实例/重启后不重复弹窗与通知） */
  channelMonitorNotifiedSig: string
  /** 仓库监控：已忽略更新的脚本路径列表（格式 `仓库url|脚本路径`；忽略后该脚本再发布新版本也不提示，直到在设置里恢复提醒） */
  channelMonitorIgnoredPaths: string[]
  /** 脚本管理工具最近移动脚本到分组的期望记录（folderName → 目标分组名 + 时间戳）：
   * Scripting 应用会在内存缓存 settings.json 并在更新 remoteScriptStates 时整体写回、覆盖移动结果；
   * 记录期望后，显示层优先用期望分组，且每次刷新自动把期望纠偏写回 settings.json */
  groupMoveTargets: Record<string, { group: string; at: number }>
  /** 首页长按「脚本管理」标题时勾选的分组过滤名单：null=不过滤显示全部；数组=只显示勾选分组内的脚本（未分组用 "" 表示，置顶脚本始终显示） */
  homeGroupFilter: string[] | null
  /** 首页分组展示顺序（分组名列表，上方在前）：null=未设置（沿用默认/设置页顺序）；数组=首页按分组排序时按此正序展示 */
  homeGroupOrder: string[] | null
}

/** GitHub 配置：发布仓库（公开，可自动创建）+ 备份仓库（私密，可自动创建） */
export type GithubConfig = {
  /** 发布专用 Personal Access Token（需要 repo 权限）；留空则自动回退到备份 Token */
  publishToken: string
  /** 发布专用仓库所有者；留空则自动回退到备份所有者 */
  publishOwner: string
  /** 发布仓库名，如 scripting-releases（必填） */
  repo: string
  /** 发布分支，默认 main */
  branch: string
  /** 发布仓库内目录（相对路径，留空=根目录） */
  path: string
  /** 备份专用 Personal Access Token（需要 repo 权限）；留空则自动回退到发布 Token */
  backupToken: string
  /** 备份专用仓库所有者；留空则自动回退到发布所有者 */
  backupOwner: string
  /** 备份仓库名（私密），如 scripting-backups（必填） */
  backupRepo: string
  /** 备份分支，默认 main */
  backupBranch: string
  /** 备份仓库内目录（相对路径，留空=根目录） */
  backupPath: string
  /** 兼容旧版：共用 Token（新版本分别填写 publishToken/backupToken） */
  token: string
  /** 兼容旧版：共用仓库所有者 */
  owner: string
}

export const DEFAULT_GITHUB_CONFIG: GithubConfig = {
  publishToken: "",
  publishOwner: "",
  repo: "",
  branch: "main",
  path: "",
  backupToken: "",
  backupOwner: "",
  backupRepo: "",
  backupBranch: "main",
  backupPath: "",
  token: "",
  owner: "",
}

export type ScriptInfo = {
  /** 文件夹名（脚本目录名） */
  folderName: string
  /** script.json 里的显示名 */
  displayName: string
  /** script.json 里的作者名（author.name/author，可能没有） */
  authorName?: string
  path: string
  version: string
  modifiedAt: number
  byteSize: number
}

export type GroupInfo = {
  /** "" 表示根目录默认分组 */
  key: string
  name: string
  path: string
  scripts: ScriptInfo[]
}

export type BackupItem = {
  name: string
  path: string
  isZip: boolean
  modifiedAt: number
  byteSize: number
  scriptCount: number
}

/** 备份内待恢复的脚本 */
export type CandidateScript = {
  folderName: string
  sourcePath: string
  /** 脚本版本号（读 script.json，可能缺失） */
  version?: string
  /** 脚本修改时间（读 script.json 的 mtime，可能缺失） */
  modifiedAt?: number
}

// ==================== 仓库监控类型 ====================

/** 仓库监控：一个被监控的仓库链接 */
export type ChannelMonitorLink = {
  /** GitHub 仓库地址，如 https://github.com/vvvvvveng/Scripting-releases */
  url: string
  /** 显示用备注名（可修改），默认自动取 所有者/仓库名 */
  name: string
}

/** 仓库监控：仓库里扫描到的 .scripting 文件 */
export type ChannelRepoFile = {
  path: string
  sha: string
  size: number
}

/** 仓库监控：一个文件的变化 */
export type ChannelChange = {
  type: "added" | "updated" | "removed"
  path: string
  size?: number
  /** 变化后的 blob sha（added/updated 有值；用于区分「同一文件的新发布」与「同一批变化的重复检测」） */
  sha?: string
  /** 本地同名脚本版本号（存在同名脚本且能读到 script.json 时为其 version） */
  localVersion?: string
  /** 云端 .scripting 包内版本号（成功下载并解析时为其 version） */
  cloudVersion?: string
}

/** 仓库监控：单个仓库一次检查结果 */
export type ChannelCheckResult = {
  name: string
  url: string
  /** 本次相对基线的变化（首次建立基线/无变化时为空数组） */
  changes: ChannelChange[]
  /** 扫描到的 .scripting 脚本数量 */
  scriptCount: number
  /** 检查是否成功（网络/仓库不存在等失败时为 false） */
  ok: boolean
  error?: string
  /** 被排除关键词过滤掉的变化数（不提示、不列入更新页；仅用于告知用户为何没检测到） */
  excludedCount?: number
  /** 被「忽略全部」按路径忽略的变化数（同一脚本再发布新版本也不提示，直到在设置里恢复） */
  ignoredCount?: number
  /** 本地同名脚本版本 高于 云端版本而被过滤的变化数（快照仍全量记录，仅不提示） */
  versionFilteredCount?: number
}

/** 仓库监控：一次全量检查的汇总 */
export type ChannelCheckSummary = {
  results: ChannelCheckResult[]
  /** 所有仓库变化总数 */
  totalChanges: number
  /** 本次是否刚建立基线（首次启用扫描） */
  newBaseline: boolean
}

// ==================== 基础工具 ====================

export function pathExists(path: string): boolean {
  try {
    return FileManager.existsSync(path)
  } catch {
    return false
  }
}

export function isDirectory(path: string): boolean {
  try {
    return FileManager.isDirectorySync(path)
  } catch {
    return false
  }
}

export function listChildren(path: string): string[] {
  if (!pathExists(path)) {
    return []
  }
  try {
    return FileManager.readDirectorySync(path).map((item) =>
      Path.isAbsolute(item) ? item : Path.join(path, item)
    )
  } catch {
    return []
  }
}

export function statTime(path: string): number {
  try {
    const stat = FileManager.statSync(path)
    return stat.modificationDate || stat.creationDate || Date.now()
  } catch {
    return Date.now()
  }
}

export function statSize(path: string): number {
  try {
    return FileManager.statSync(path).size || 0
  } catch {
    return 0
  }
}

export function summarizeDirectory(path: string): { fileCount: number; byteSize: number } {
  let fileCount = 0
  let byteSize = 0
  for (const item of listChildren(path)) {
    if (isDirectory(item)) {
      const child = summarizeDirectory(item)
      fileCount += child.fileCount
      byteSize += child.byteSize
    } else {
      fileCount += 1
      byteSize += statSize(item)
    }
  }
  return { fileCount, byteSize }
}

/**
 * 计算脚本目录的内容指纹：递归列出每个文件的相对路径 + 大小 + 修改时间，
 * 排序后拼接。用于判断脚本内容是否仍在变化（如智能体修改尚未写完 / iCloud 还在同步），
 * 连续两次指纹一致可认为内容已稳定，此时再备份才不会备份到旧内容。
 */
export function scriptDirFingerprint(dir: string): string {
  const parts: string[] = []
  const walk = (d: string, rel: string) => {
    for (const item of listChildren(d)) {
      const name = Path.basename(item)
      const childRel = rel ? rel + "/" + name : name
      if (isDirectory(item)) {
        walk(item, childRel)
      } else {
        let size = 0
        let mtime = 0
        try {
          const stat = FileManager.statSync(item)
          size = stat.size || 0
          mtime = stat.modificationDate || 0
        } catch {}
        parts.push(`${childRel}|${size}|${mtime}`)
      }
    }
  }
  walk(dir, "")
  return parts.sort().join("\n")
}

/**
 * 计算脚本目录的「内容指纹」：递归每个文件的 相对路径|内容MD5（排序后拼接）。
 * 与 scriptDirFingerprint（依赖 mtime，用于判断内容是否还在变化）不同，这里基于文件内容哈希，
 * 用于检测「版本号没变但本地内容与云端发布内容不同」：发布成功时记录一次，之后实时重算并比较。
 * script.json 不参与指纹：Scripting 应用从云端安装/更新脚本时会规范化重写它
 *（补全 author.email/homepage、添加 contributors、移除 changelog 等），导致「云端包」与
 *「本地安装后」的 script.json 天然不同；版本号差异由 isCloudDesynced 单独判断。
 * 这里只比较实际脚本文件（index.tsx 等）的内容。
 */
export function scriptContentFingerprint(dir: string): string {
  const parts: string[] = []
  const walk = (d: string, rel: string) => {
    for (const item of listChildren(d)) {
      const name = Path.basename(item)
      const childRel = rel ? rel + "/" + name : name
      if (isDirectory(item)) {
        walk(item, childRel)
      } else {
        if (childRel === "script.json") continue
        try {
          const data = Data.fromFile(item)
          parts.push(
            `${childRel}|${data ? Crypto.md5(data).toHexString() : "0"}`
          )
        } catch {
          parts.push(`${childRel}|0`)
        }
      }
    }
  }
  walk(dir, "")
  return parts.sort().join("\n")
}

export function copyDirectory(source: string, destination: string) {
  FileManager.createDirectorySync(destination, true)
  for (const item of listChildren(source)) {
    const target = Path.join(destination, Path.basename(item))
    if (isDirectory(item)) {
      copyDirectory(item, target)
    } else {
      FileManager.copyFileSync(item, target)
    }
  }
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) {
    return `${bytes} B`
  }
  const units = ["KB", "MB", "GB"]
  let value = bytes / 1024
  let index = 0
  while (value >= 1024 && index < units.length - 1) {
    value /= 1024
    index += 1
  }
  return `${value.toFixed(value >= 10 ? 1 : 2)} ${units[index]}`
}

export function formatDate(value: number): string {
  try {
    return new Date(value).toLocaleString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })
  } catch {
    return String(value)
  }
}

export function timestampForName(): string {
  const date = new Date()
  const pad = (v: number) => String(v).padStart(2, "0")
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}_${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
}

/** 清洗为合法文件名（保留中文/字母/数字/._- 及括号；括号与本地文件夹名保持一致） */
export function safeFileName(name: string): string {
  const cleaned = name
    .trim()
    .split("")
    .map((char) => {
      if (
        /^[A-Za-z0-9_.\- ()（）]$/.test(char) ||
        /[\u4e00-\u9fff]/.test(char)
      ) {
        return char
      }
      return "_"
    })
    .join("")
    .replace(/[. ]+$/g, "")
  return cleaned || "备份"
}

/** 若路径已存在，返回追加 (2)/(3)… 的新路径 */
export function uniquePath(basePath: string): string {
  if (!pathExists(basePath)) {
    return basePath
  }
  const dir = Path.dirname(basePath)
  const lower = basePath.toLowerCase()
  const ext = lower.endsWith(".zip")
    ? ".zip"
    : lower.endsWith(".scripting")
    ? ".scripting"
    : ""
  const stem = ext ? basePath.slice(0, -ext.length) : basePath
  let index = 2
  while (pathExists(`${stem} (${index})${ext}`)) {
    index += 1
  }
  return `${stem} (${index})${ext}`
}

// ==================== 配置（记住上次勾选） ====================

export function resolveConfig(): AppConfig {
  const def: AppConfig = {
    destination: "iphone",
    scope: "recent",
    githubBackupEnabled: false,
    githubPublishEnabled: false,
    rememberExpandState: true,
    backupRestoreExpanded: true,
    pinnedScripts: [],
    scriptSort: "usage",
    authorName: "",
    groupOrder: [],
    searchKeepAll: true,
    searchMatchAuthor: false,
    language: "zh",
    autoBackupOnUpgrade: false,
    hideRestoreModule: false,
    showScriptAuthor: true,
    showScriptGroupName: true,
    recentUsedAt: {},
    recentRunLog: [],
    scriptVersionRecord: {},
    scriptContentRecord: {},
    agentModifiedAt: {},
    channelImportedAt: {},
    scriptGroupSnapshot: {},
    publishedVersions: {},
    publishedFingerprints: {},
    cloudFingerprints: {},
    cloudVersions: {},
    publishedChangelogs: {},
    cloudChangelogs: {},
    cloudCheckedAt: {},
    channelMonitorEnabled: false,
    channelMonitorNotificationEnabled: true,
    channelMonitorInterval: 12,
    channelMonitorIntervalUnit: "hour",
    channelMonitorLinks: DEFAULT_CHANNEL_MONITOR_LINKS,
    channelMonitorSnapshots: {},
    channelMonitorBaselineReady: false,
    channelMonitorExcludeKeywords: DEFAULT_CHANNEL_EXCLUDE_KEYWORDS,
    channelMonitorNotifiedSig: "",
    channelMonitorIgnoredPaths: [],
    groupMoveTargets: {},
    homeGroupFilter: null,
    homeGroupOrder: null,
  }
  if (!pathExists(CONFIG_PATH)) {
    return def
  }
  try {
    const raw = JSON.parse(FileManager.readAsStringSync(CONFIG_PATH)) as Partial<AppConfig> & {
      developer?: boolean
    }
    return {
      destination:
        raw.destination === "icloud"
          ? "icloud"
          : raw.destination === "github_publish"
          ? "github_publish"
          : raw.destination === "github_backup"
          ? "github_backup"
          : "iphone",
      scope:
        raw.scope === "all" ||
        raw.scope === "group" ||
        raw.scope === "select"
          ? raw.scope
          : "recent",
      githubBackupEnabled: raw.githubBackupEnabled === true,
      // 兼容旧版「我是开发者」开关：勾选过即视为启用 Github发布
      githubPublishEnabled:
        raw.githubPublishEnabled === true || raw.developer === true,
      rememberExpandState: raw.rememberExpandState !== false,
      backupRestoreExpanded: raw.backupRestoreExpanded !== false,
      pinnedScripts: Array.isArray(raw.pinnedScripts)
        ? raw.pinnedScripts.filter((x): x is string => typeof x === "string")
        : [],
      scriptSort:
        raw.scriptSort === "recent"
          ? "recent"
          : raw.scriptSort === "name_desc"
            ? "name_desc"
            : raw.scriptSort === "name"
              ? "name"
              : raw.scriptSort === "group"
                ? "group"
                : raw.scriptSort === "author"
                  ? "author"
                  : raw.scriptSort === "modified"
                    ? "modified"
                    : "usage",
      authorName: typeof raw.authorName === "string" ? raw.authorName : "",
      groupOrder: Array.isArray(raw.groupOrder)
        ? raw.groupOrder.filter((x): x is string => typeof x === "string")
        : [],
      searchKeepAll: raw.searchKeepAll !== false,
      searchMatchAuthor: raw.searchMatchAuthor === true,
      language: raw.language === "en" ? "en" : "zh",
      autoBackupOnUpgrade: raw.autoBackupOnUpgrade === true,
      hideRestoreModule: raw.hideRestoreModule === true,
      showScriptAuthor: raw.showScriptAuthor !== false,
      showScriptGroupName: raw.showScriptGroupName !== false,
      recentUsedAt:
        raw.recentUsedAt && typeof raw.recentUsedAt === "object"
          ? raw.recentUsedAt
          : {},
      recentRunLog: Array.isArray(raw.recentRunLog)
        ? raw.recentRunLog
            .filter((x): x is string => typeof x === "string")
            .slice(0, 50)
        : [],

      scriptVersionRecord:
        raw.scriptVersionRecord && typeof raw.scriptVersionRecord === "object"
          ? raw.scriptVersionRecord
          : {},
      scriptContentRecord:
        raw.scriptContentRecord && typeof raw.scriptContentRecord === "object"
          ? raw.scriptContentRecord
          : {},
      agentModifiedAt:
        raw.agentModifiedAt && typeof raw.agentModifiedAt === "object"
          ? raw.agentModifiedAt
          : {},
      channelImportedAt:
        raw.channelImportedAt && typeof raw.channelImportedAt === "object"
          ? raw.channelImportedAt
          : {},
      scriptGroupSnapshot:
        raw.scriptGroupSnapshot && typeof raw.scriptGroupSnapshot === "object"
          ? raw.scriptGroupSnapshot
          : {},
      publishedVersions:
        raw.publishedVersions && typeof raw.publishedVersions === "object"
          ? raw.publishedVersions
          : {},
      publishedFingerprints:
        raw.publishedFingerprints && typeof raw.publishedFingerprints === "object"
          ? raw.publishedFingerprints
          : {},
      cloudFingerprints:
        raw.cloudFingerprints && typeof raw.cloudFingerprints === "object"
          ? raw.cloudFingerprints
          : {},
      cloudVersions:
        raw.cloudVersions && typeof raw.cloudVersions === "object"
          ? raw.cloudVersions
          : {},
      publishedChangelogs:
        raw.publishedChangelogs && typeof raw.publishedChangelogs === "object"
          ? raw.publishedChangelogs
          : {},
      cloudChangelogs:
        raw.cloudChangelogs && typeof raw.cloudChangelogs === "object"
          ? raw.cloudChangelogs
          : {},
      cloudCheckedAt:
        raw.cloudCheckedAt && typeof raw.cloudCheckedAt === "object"
          ? raw.cloudCheckedAt
          : {},
      channelMonitorEnabled: raw.channelMonitorEnabled === true,
      channelMonitorNotificationEnabled:
        raw.channelMonitorNotificationEnabled !== false,
      channelMonitorInterval:
        typeof raw.channelMonitorInterval === "number" &&
        raw.channelMonitorInterval > 0
          ? raw.channelMonitorInterval
          : 12,
      channelMonitorIntervalUnit:
        raw.channelMonitorIntervalUnit === "hour" ||
        raw.channelMonitorIntervalUnit === "day"
          ? raw.channelMonitorIntervalUnit
          : "hour",
      channelMonitorLinks: normalizeChannelMonitorLinks(
        raw.channelMonitorLinks
      ),
      channelMonitorSnapshots:
        raw.channelMonitorSnapshots &&
        typeof raw.channelMonitorSnapshots === "object"
          ? raw.channelMonitorSnapshots
          : {},
      channelMonitorBaselineReady: raw.channelMonitorBaselineReady === true,
      channelMonitorExcludeKeywords:
        raw.channelMonitorExcludeKeywords === undefined
          ? DEFAULT_CHANNEL_EXCLUDE_KEYWORDS
          : normalizeChannelExcludeKeywords(raw.channelMonitorExcludeKeywords),
      channelMonitorNotifiedSig:
        typeof raw.channelMonitorNotifiedSig === "string"
          ? raw.channelMonitorNotifiedSig
          : "",
      channelMonitorIgnoredPaths: normalizeChannelIgnoredPaths(
        raw.channelMonitorIgnoredPaths
      ),
      groupMoveTargets:
        raw.groupMoveTargets && typeof raw.groupMoveTargets === "object"
          ? raw.groupMoveTargets
          : {},
      homeGroupFilter:
        raw.homeGroupFilter == null
          ? null
          : Array.isArray(raw.homeGroupFilter)
            ? raw.homeGroupFilter.filter((x): x is string => typeof x === "string")
            : null,
      homeGroupOrder:
        raw.homeGroupOrder == null
          ? null
          : Array.isArray(raw.homeGroupOrder)
            ? raw.homeGroupOrder.filter((x): x is string => typeof x === "string")
            : null,
    }
  } catch {
    return def
  }
}

export function saveConfig(config: AppConfig) {
  try {
    FileManager.writeAsStringSync(CONFIG_PATH, JSON.stringify(config, null, 2))
  } catch {
    // ignore
  }
}

/** 标记某脚本刚被智能体（AI 维护流程）修改：供自动备份识别“手动修改”，时间戳由调用方决定 */
export function markAgentModified(folderName: string, at = Date.now()) {
  const cfg = resolveConfig()
  saveConfig({ ...cfg, agentModifiedAt: { ...cfg.agentModifiedAt, [folderName]: at } })
}

// ==================== 配置（GitHub） ====================

export function resolveGithubConfig(): GithubConfig {
  if (!pathExists(GITHUB_CONFIG_PATH)) {
    return { ...DEFAULT_GITHUB_CONFIG }
  }
  try {
    const raw = JSON.parse(
      FileManager.readAsStringSync(GITHUB_CONFIG_PATH)
    ) as Partial<GithubConfig>
    const legacyToken = typeof raw.token === "string" ? raw.token : ""
    const legacyOwner = typeof raw.owner === "string" ? raw.owner : ""
    return {
      publishToken: typeof raw.publishToken === "string" ? raw.publishToken : "",
      publishOwner: typeof raw.publishOwner === "string" ? raw.publishOwner : "",
      repo: typeof raw.repo === "string" ? raw.repo : "",
      branch: (typeof raw.branch === "string" && raw.branch.trim()) ? raw.branch.trim() : "main",
      path: typeof raw.path === "string" ? raw.path : "",
      backupToken: typeof raw.backupToken === "string" ? raw.backupToken : "",
      backupOwner: typeof raw.backupOwner === "string" ? raw.backupOwner : "",
      backupRepo: typeof raw.backupRepo === "string" ? raw.backupRepo : "",
      backupBranch: (typeof raw.backupBranch === "string" && raw.backupBranch.trim()) ? raw.backupBranch.trim() : "main",
      backupPath: typeof raw.backupPath === "string" ? raw.backupPath : "",
      // 兼容旧版：保留共用字段，便于旧配置升级后自动生效
      token: legacyToken,
      owner: legacyOwner,
    }
  } catch {
    return { ...DEFAULT_GITHUB_CONFIG }
  }
}

/**
 * 解析发布实际生效的配置：发布专用优先，其次备份专用，最后旧版共用（fallback）。
 * 返回对象的 token/owner 即为发布时真正使用的凭据。
 */
export function resolvePublishGithubConfig(config: GithubConfig): GithubConfig {
  return {
    ...config,
    token: config.publishToken || config.backupToken || config.token,
    owner: config.publishOwner || config.backupOwner || config.owner,
  }
}

/**
 * 解析备份实际生效的配置：备份专用优先，其次发布专用，最后旧版共用（fallback）。
 * 返回对象的 token/owner 即为备份时真正使用的凭据。
 */
export function resolveBackupGithubConfig(config: GithubConfig): GithubConfig {
  return {
    ...config,
    token: config.backupToken || config.publishToken || config.token,
    owner: config.backupOwner || config.publishOwner || config.owner,
  }
}

export function saveGithubConfig(config: GithubConfig) {
  try {
    FileManager.writeAsStringSync(
      GITHUB_CONFIG_PATH,
      JSON.stringify(config, null, 2)
    )
  } catch {
    // ignore
  }
}

/** GitHub 发布配置是否已填全（token+owner+repo 必填） */
export function isGithubConfigured(config: GithubConfig): boolean {
  return !!(config.token.trim() && config.owner.trim() && config.repo.trim())
}

/** GitHub 备份配置是否已填全（token+owner+backupRepo 必填） */
export function isGithubBackupConfigured(config: GithubConfig): boolean {
  return !!(config.token.trim() && config.owner.trim() && config.backupRepo.trim())
}

// ==================== 备份目录 ====================

export function backupRootFor(destination: Destination): string {
  const base =
    destination === "icloud"
      ? FileManager.iCloudDocumentsDirectory
      : FileManager.documentsDirectory
  return Path.join(base, BACKUP_DIR_NAME)
}

export function ensureBackupRoot(destination: Destination): string {
  const root = backupRootFor(destination)
  if (!pathExists(root)) {
    FileManager.createDirectorySync(root, true)
  }
  return root
}

// ==================== 扫描脚本 ====================

/**
 * 解析脚本的 script.json：Scripting 生成的 JSON 可能带尾随逗号（`,}` / `,]`），
 * 标准 JSON.parse 会抛错，这里先按标准解析，失败则去掉尾随逗号重试。
 */
export function parseScriptJson(raw: string): any {
  try {
    return JSON.parse(raw)
  } catch {
    const cleaned = raw.replace(/,\s*([}\]])/g, "$1")
    return JSON.parse(cleaned)
  }
}

/** 从 script.json 对象里提取作者名（author 可为字符串或 { name: ... }） */
function extractAuthor(obj: any): string | undefined {
  const a = obj?.author
  if (typeof a === "string") {
    return a.trim() || undefined
  }
  if (a && typeof a === "object") {
    const n = (a as { name?: unknown }).name
    return typeof n === "string" && n.trim() ? n.trim() : undefined
  }
  return undefined
}

export function readScriptMeta(dir: string): { name?: string; version?: string; author?: string } {
  try {
    const raw = FileManager.readAsStringSync(Path.join(dir, "script.json"))
    const obj = parseScriptJson(raw)
    return {
      name: typeof obj?.name === "string" ? obj.name : undefined,
      version: typeof obj?.version === "string" ? obj.version : undefined,
      author: extractAuthor(obj),
    }
  } catch {
    return {}
  }
}

/** 单个脚本目录 → ScriptInfo（目录不含 script.json 时返回 null） */
export function scriptInfoFromDir(dir: string): ScriptInfo | null {
  if (!pathExists(Path.join(dir, "script.json"))) {
    return null
  }
  const meta = readScriptMeta(dir)
  const name = Path.basename(dir)
  return {
    folderName: name,
    displayName: meta.name || name,
    authorName: meta.author,
    path: dir,
    version: meta.version || "0.0.0",
    modifiedAt: statTime(dir),
    byteSize: summarizeDirectory(dir).byteSize,
  }
}

/** 扫描某目录下直接包含 script.json 的脚本文件夹 */
export function scanScripts(dir: string = FileManager.scriptsDirectory): ScriptInfo[] {
  const result: ScriptInfo[] = []
  for (const child of listChildren(dir)) {
    if (!isDirectory(child)) continue
    const info = scriptInfoFromDir(child)
    if (info) {
      result.push(info)
    }
  }
  return result.sort((a, b) => b.modifiedAt - a.modifiedAt)
}

/** 按文件夹分组：根目录脚本归「默认分组」，子文件夹（含嵌套）里有脚本的作为分组 */
export function scanGroups(): GroupInfo[] {
  const root = FileManager.scriptsDirectory
  const groups: GroupInfo[] = []
  const rootScripts = scanScripts(root)
  if (rootScripts.length > 0) {
    groups.push({ key: "", name: "默认分组", path: root, scripts: rootScripts })
  }
  for (const child of listChildren(root)) {
    if (!isDirectory(child)) continue
    // 本身是脚本（含 script.json）则跳过
    if (pathExists(Path.join(child, "script.json"))) continue
    const found = scanScriptDirsInTree(child)
    if (found.length > 0) {
      groups.push({
        key: child,
        name: Path.basename(child),
        path: child,
        scripts: found
          .map((f) => scriptInfoFromDir(f.sourcePath))
          .filter((s): s is ScriptInfo => s !== null)
          .sort((a, b) => b.modifiedAt - a.modifiedAt),
      })
    }
  }
  return groups
}

/**
 * 读取 .scripting/settings.json 并返回解包后的 JSON 对象。
 * 自愈：Scripting 应用在整体写回 settings.json 时可能把它写成双重序列化
 * （整个文件是一个 JSON 字符串），导致 JSON.parse 得到字符串而非对象、
 * 分组读不到（移动分组只剩「内置脚本」）。这里检测到字符串后自动解包并修复写回；
 * 文件尾部若残留多余字符（写入中断/叠加写入）则截到最后一个 } 重试解析。
 * 解析失败返回 null（调用方决定是否尝试下一个候选路径）。
 */
function readScriptingSettingsObj(settingsPath: string): {
  groups?: Array<{ name?: string; icon?: string; scripts?: string[] }>
} | null {
  try {
    const raw = FileManager.readAsStringSync(settingsPath)
    let obj: unknown = null
    let healed = false
    try {
      obj = JSON.parse(raw)
    } catch {
      // 尾部多余字符/中断写入：截到最后一个 } 重试
      const lastBrace = raw.lastIndexOf("}")
      if (lastBrace > 0) {
        try {
          obj = JSON.parse(raw.slice(0, lastBrace + 1))
          healed = true
        } catch {
          return null
        }
      } else {
        return null
      }
    }
    // 双重序列化自愈：第一层解析出来是字符串 → 整个文件是序列化过的 JSON 文本
    if (typeof obj === "string") {
      const inner: unknown = JSON.parse(obj)
      if (inner && typeof inner === "object" && !Array.isArray(inner)) {
        obj = inner
        healed = true
      } else {
        return null
      }
    }
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) {
      return null
    }
    // 自愈后把正常单层序列化写回，避免后续每次读取都要解包/截断
    if (healed) {
      try {
        FileManager.writeAsStringSync(settingsPath, JSON.stringify(obj, null, 2))
      } catch {
        // 写回失败忽略，下次读取仍会执行自愈
      }
    }
    return obj as { groups?: Array<{ name?: string; icon?: string; scripts?: string[] }> }
  } catch {
    return null
  }
}

/**
 * 读取 Scripting 应用的分组（.scripting/settings.json 的 groups 字段）。
 * 脚本存储为 WebDAV 时，settings.json 与 scriptsDirectory 同级的 .scripting 目录下；
 * 本地存储时在 appGroupDocumentsDirectory 下。取第一个能读到 groups 的文件。
 * @param preloadedScripts 可选的已扫描脚本列表，避免内部再次全量 scanScripts（WebDAV 下很慢）
 */
export function readScriptingGroups(preloadedScripts?: ScriptInfo[]): GroupInfo[] {
  const candidates = [
    Path.join(Path.dirname(FileManager.scriptsDirectory), ".scripting", "settings.json"),
    Path.join(FileManager.appGroupDocumentsDirectory, ".scripting", "settings.json"),
  ]

  // 脚本显示名 → ScriptInfo 映射（含目录名兜底）
  const allScripts = preloadedScripts ?? scanScripts()
  const byDisplayName = new Map<string, ScriptInfo>()
  const byFolderName = new Map<string, ScriptInfo>()
  for (const script of allScripts) {
    byDisplayName.set(script.displayName, script)
    byFolderName.set(script.folderName, script)
  }

  for (const settingsPath of candidates) {
    if (!pathExists(settingsPath)) {
      continue
    }
    try {
      const obj = readScriptingSettingsObj(settingsPath)
      const defs = obj?.groups
      if (!Array.isArray(defs) || defs.length === 0) {
        continue
      }
      const groups: GroupInfo[] = []
      for (const def of defs) {
        const name = def.name?.trim() || "未命名分组"
        const scripts: ScriptInfo[] = []
        const seen = new Set<string>()
        for (const scriptName of def.scripts || []) {
          const info = byDisplayName.get(scriptName) || byFolderName.get(scriptName)
          if (info && !seen.has(info.folderName)) {
            seen.add(info.folderName)
            scripts.push(info)
          }
        }
        groups.push({
          key: name,
          name,
          path: FileManager.scriptsDirectory,
          scripts,
        })
      }
      return groups
    } catch {
      // 尝试下一个候选路径
    }
  }
  return []
}

/**
 * 构建 脚本文件夹名 → 所在分组名 的映射（脚本可能属于多个分组，取第一个）。
 * 不在任何命名分组的脚本返回 null（表示默认分组）。
 * 若脚本最近被脚本管理工具移动过（期望分组记录未过期），优先返回期望分组，
 * 避免 Scripting 应用内存缓存覆盖 settings.json 后显示回弹。
 */
export function groupNameForScript(folderName: string): string | null {
  const expected = expectedGroupFor(folderName)
  if (expected != null) {
    return expected
  }
  for (const group of readScriptingGroups()) {
    if (group.scripts.some((s) => s.folderName === folderName)) {
      return group.name
    }
  }
  return null
}

/** 读取脚本最近被脚本管理工具移动到的期望分组（未过期才生效，过期返回 null） */
function expectedGroupFor(folderName: string): string | null {
  const target = resolveConfig().groupMoveTargets?.[folderName]
  if (!target || typeof target.group !== "string" || !target.group) {
    return null
  }
  if (Date.now() - target.at > GROUP_TARGET_TTL_MS) {
    return null
  }
  return target.group
}

/** 期望分组记录的有效期：移动后 7 天内显示层优先期望分组并自动纠偏 settings.json */
const GROUP_TARGET_TTL_MS = 7 * 24 * 60 * 60 * 1000

/**
 * 一次性构建 文件夹名 → 分组名 映射（只扫描一次），
 * 供列表批量渲染使用，避免每行重复全量扫描。
 * @param preloadedScripts 可选的已扫描脚本列表，避免内部再次全量 scanScripts
 */
export function buildGroupNameMap(preloadedScripts?: ScriptInfo[]): Map<string, string> {
  const map = new Map<string, string>()
  for (const group of readScriptingGroups(preloadedScripts)) {
    for (const s of group.scripts) {
      if (!map.has(s.folderName)) {
        map.set(s.folderName, group.name)
      }
    }
  }
  // 期望分组覆盖：最近被脚本管理工具移动过的脚本以期望分组为准（防回弹）
  const targets = resolveConfig().groupMoveTargets || {}
  for (const [folderName, target] of Object.entries(targets)) {
    if (
      target &&
      typeof target.group === "string" &&
      target.group &&
      Date.now() - target.at <= GROUP_TARGET_TTL_MS
    ) {
      map.set(folderName, target.group)
    }
  }
  return map
}

/**
 * 把脚本移动到指定分组：从其他所有分组移除，再加入目标分组。
 * 分组信息保存在 Scripting 的 .scripting/settings.json。
 */
export function moveScriptToGroup(
  script: ScriptInfo,
  targetGroupName: string
): void {
  const candidates = [
    Path.join(Path.dirname(FileManager.scriptsDirectory), ".scripting", "settings.json"),
    Path.join(FileManager.appGroupDocumentsDirectory, ".scripting", "settings.json"),
  ]
  let settingsPath: string | null = null
  for (const candidate of candidates) {
    if (pathExists(candidate)) {
      settingsPath = candidate
      break
    }
  }
  if (!settingsPath) {
    throw new Error("未找到分组配置文件（.scripting/settings.json）")
  }

  const raw = readScriptingSettingsObj(settingsPath)
  if (!raw) {
    throw new Error("分组配置读取失败，无法移动")
  }
  const defs = raw?.groups
  if (!Array.isArray(defs) || defs.length === 0) {
    throw new Error("分组配置为空，无法移动")
  }

  const match = defs.find((def) => (def.name?.trim() || "未命名分组") === targetGroupName)
  if (!match) {
    throw new Error(`找不到分组「${targetGroupName}」`)
  }

  const targetScripts = match.scripts || (match.scripts = [])
  const scriptKey = script.displayName || script.folderName

  // 目标分组已包含该脚本：无需操作
  if (targetScripts.some((s) => s === scriptKey)) {
    throw new Error(`「${script.displayName}」已经在分组「${targetGroupName}」中`)
  }

  // 从其他所有分组移除
  for (const def of defs) {
    if (def === match) {
      continue
    }
    if (Array.isArray(def.scripts)) {
      const idx = def.scripts.indexOf(scriptKey)
      if (idx >= 0) {
        def.scripts.splice(idx, 1)
      }
    }
  }

  // 加入目标分组
  targetScripts.push(scriptKey)
  FileManager.writeAsStringSync(settingsPath, JSON.stringify(raw, null, 2))

  // 记录期望分组：显示层优先使用，且后续自动纠偏 settings.json 防回弹；
  // 同时更新分组快照，供覆盖导入/恢复后把脚本恢复回原分组
  const cfg = resolveConfig()
  saveConfig({
    ...cfg,
    scriptGroupSnapshot: {
      ...(cfg.scriptGroupSnapshot ?? {}),
      [script.folderName]: targetGroupName,
    },
    groupMoveTargets: {
      ...cfg.groupMoveTargets,
      [script.folderName]: { group: targetGroupName, at: Date.now() },
    },
  })
}

/**
 * 自动纠偏期望分组：把脚本管理工具最近移动过的脚本重新写回目标分组。
 * Scripting 应用会在内存缓存 settings.json 并在更新 remoteScriptStates 时整体写回、
 * 覆盖脚本管理工具写入的 groups；每次刷新页面时调用本函数把期望分组重新写回 settings.json。
 * @param preloadedScripts 可选的已扫描脚本列表，避免内部再次全量 scanScripts
 */
export function enforceGroupMoveTargets(preloadedScripts?: ScriptInfo[]): void {
  const targets = resolveConfig().groupMoveTargets || {}
  const folderNames = Object.keys(targets).filter(
    (folderName) =>
      targets[folderName] &&
      typeof targets[folderName].group === "string" &&
      targets[folderName].group &&
      Date.now() - targets[folderName].at <= GROUP_TARGET_TTL_MS
  )
  if (folderNames.length === 0) {
    return
  }
  const allScripts = preloadedScripts ?? scanScripts()
  const byFolder = new Map(allScripts.map((s) => [s.folderName, s]))
  const currentGroups = buildGroupNameMapFromSettings(allScripts)
  for (const folderName of folderNames) {
    const script = byFolder.get(folderName)
    const target = targets[folderName]
    if (!target) {
      continue
    }
    if (!script) {
      // 脚本已不存在：清除期望记录
      clearGroupMoveTarget(folderName)
      continue
    }
    if (currentGroups.get(folderName) === target.group) {
      continue
    }
    try {
      // 重新写回 settings.json（内部会刷新期望记录时间戳）
      moveScriptToGroup(script, target.group)
    } catch {
      // 目标分组可能已删除等，忽略
    }
  }
}

/** 清除某脚本的期望分组记录（脚本已删除或不再需要防回弹时） */
export function clearGroupMoveTarget(folderName: string): void {
  const cfg = resolveConfig()
  if (!cfg.groupMoveTargets?.[folderName]) {
    return
  }
  const groupMoveTargets = { ...cfg.groupMoveTargets }
  delete groupMoveTargets[folderName]
  saveConfig({ ...cfg, groupMoveTargets })
}

/** 只读：从 settings.json 构建 文件夹名 → 分组名 映射（不带期望分组覆盖，供纠偏判断用） */
function buildGroupNameMapFromSettings(preloadedScripts?: ScriptInfo[]): Map<string, string> {
  const map = new Map<string, string>()
  for (const group of readScriptingGroups(preloadedScripts)) {
    for (const s of group.scripts) {
      if (!map.has(s.folderName)) {
        map.set(s.folderName, group.name)
      }
    }
  }
  return map
}

/** 刚导入覆盖脚本后恢复分组的有效窗口（与 index.tsx 的 IMPORTED_WINDOW_MS 一致，10 分钟） */
const IMPORTED_GROUP_RESTORE_WINDOW_MS = 10 * 60 * 1000

/**
 * 记录脚本当前所在分组到配置快照（folderName → 分组名）。
 * 只在“分组还正常”的时机调用（覆盖导入/恢复发起前），避免把分组丢失后的状态写进快照。
 */
export function snapshotScriptGroups(
  folderNames: string[],
  preloadedScripts?: ScriptInfo[]
): void {
  const names = folderNames.filter((n) => n)
  if (names.length === 0) return
  const map = buildGroupNameMapFromSettings(preloadedScripts)
  const cfg = resolveConfig()
  const next = { ...(cfg.scriptGroupSnapshot ?? {}) }
  let changed = false
  for (const folderName of names) {
    const group = map.get(folderName)
    if (group != null && next[folderName] !== group) {
      next[folderName] = group
      changed = true
    }
  }
  if (changed) {
    saveConfig({ ...cfg, scriptGroupSnapshot: next })
  }
}

/**
 * 把脚本恢复回快照中的分组。
 * Scripting 应用导入覆盖脚本后会更新 remoteScriptStates 并整体写回 settings.json，
 * 可能把脚本从 groups 中移除/覆盖掉；据此把脚本重新加回原分组（同时写入期望记录防回弹）。
 * 脚本不存在、分组已被删除、已在原分组等情况静默跳过。
 */
export function restoreScriptGroupFromSnapshot(
  folderName: string,
  preloadedScripts?: ScriptInfo[]
): void {
  const cfg = resolveConfig()
  const group = cfg.scriptGroupSnapshot?.[folderName]
  if (!group) return
  const allScripts = preloadedScripts ?? scanScripts()
  const script = allScripts.find((s) => s.folderName === folderName)
  if (!script) return
  if (buildGroupNameMapFromSettings(allScripts).get(folderName) === group) return
  try {
    moveScriptToGroup(script, group)
  } catch {
    // 目标分组可能已被删除，忽略
  }
}

/**
 * 恢复「刚导入覆盖」脚本的分组：遍历 channelImportedAt 窗口内的脚本，
 * 若快照里有原分组且当前已丢失则写回。列表刷新时调用（enforceGroupMoveTargets 之后）。
 */
export function restoreImportedScriptGroups(preloadedScripts?: ScriptInfo[]): void {
  const cfg = resolveConfig()
  const now = Date.now()
  const recent = Object.entries(cfg.channelImportedAt ?? {})
    .filter(([, at]) => now - at <= IMPORTED_GROUP_RESTORE_WINDOW_MS)
    .map(([name]) => name)
  if (recent.length === 0) return
  for (const folderName of recent) {
    restoreScriptGroupFromSnapshot(folderName, preloadedScripts)
  }
}

// ==================== 备份 ====================

/**
 * 备份脚本到指定目的地：单个脚本打包为 `<名称>.scripting`（Scripting 官方分发格式，可直接导入运行），
 * 多个脚本打包为一个 `<名称>.zip`（zip 根目录下直接是各脚本文件夹）。
 */
export async function backupScripts(
  scripts: ScriptInfo[],
  destination: Destination,
  zipName: string
): Promise<string> {
  const root = ensureBackupRoot(destination)
  const safe = safeFileName(zipName) || "临时备份"
  const ext = scripts.length === 1 ? ".scripting" : ".zip"
  const finalPath = uniquePath(Path.join(root, `${safe}${ext}`))

  if (scripts.length === 1) {
    await FileManager.zip(scripts[0].path, finalPath, true)
    return finalPath
  }

  const staging = Path.join(FileManager.temporaryDirectory, `backup-stage-${Date.now()}`)
  FileManager.createDirectorySync(staging, true)
  try {
    for (const script of scripts) {
      copyDirectory(script.path, Path.join(staging, script.folderName))
    }
    await FileManager.zip(staging, finalPath, false)
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
  return finalPath
}

// ==================== 恢复 ====================

export function scanBackups(destination: Destination): BackupItem[] {
  const root = backupRootFor(destination)
  if (!pathExists(root)) {
    return []
  }
  const items: BackupItem[] = []
  for (const child of listChildren(root)) {
    const name = Path.basename(child)
    if (isDirectory(child)) {
      items.push({
        name,
        path: child,
        isZip: false,
        modifiedAt: statTime(child),
        byteSize: summarizeDirectory(child).byteSize,
        scriptCount: 0,
      })
    } else if (name.toLowerCase().endsWith(".zip") || name.toLowerCase().endsWith(".scripting")) {
      // 不解压统计（解压每个压缩包会卡住列表加载），脚本数在用户点开时由 inspectBackup 惰性计算
      const lower = name.toLowerCase()
      const extLen = lower.endsWith(".scripting") ? 10 : 4
      items.push({
        name: name.slice(0, -extLen),
        path: child,
        isZip: true,
        modifiedAt: statTime(child),
        byteSize: statSize(child),
        scriptCount: 0,
      })
    }
  }
  return items.sort((a, b) => b.modifiedAt - a.modifiedAt)
}

/** 删除本地备份（zip 文件或文件夹），返回是否成功 */
export function deleteLocalBackup(item: BackupItem): boolean {
  try {
    if (pathExists(item.path)) {
      FileManager.removeSync(item.path)
    }
    return true
  } catch {
    return false
  }
}

/** 分享选中的本地备份：zip/scripting 文件直接分享；目录先打包为 .scripting 再分享 */
export async function shareLocalBackups(items: BackupItem[]): Promise<void> {
  if (items.length === 0) {
    return
  }
  const staging = Path.join(
    FileManager.temporaryDirectory,
    `share-backup-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const files: string[] = []
  try {
    for (const item of items) {
      if (item.isZip) {
        files.push(item.path)
      } else {
        const zipPath = Path.join(
          staging,
          `${safeFileName(item.name)}.scripting`
        )
        await FileManager.zip(item.path, zipPath, false)
        files.push(zipPath)
      }
    }
    await ShareSheet.present(files)
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

/** 重命名本地备份（zip/scripting 文件保留原扩展名），改名后需重新 scanBackups */
export function renameLocalBackup(item: BackupItem, newName: string): void {
  const clean = newName.trim()
  if (!clean) {
    throw new Error("名称不能为空")
  }
  if (/[\/\\:]/.test(clean)) {
    throw new Error("名称不能包含 / \\ : 字符")
  }
  const dir = Path.dirname(item.path)
  let dest: string
  if (item.isZip) {
    const lower = item.path.toLowerCase()
    const ext = lower.endsWith(".scripting") ? ".scripting" : ".zip"
    dest = Path.join(dir, `${safeFileName(clean)}${ext}`)
  } else {
    dest = Path.join(dir, safeFileName(clean))
  }
  if (dest === item.path) {
    return
  }
  if (pathExists(dest)) {
    throw new Error(`已存在同名备份「${clean}」`)
  }
  FileManager.renameSync(item.path, dest)
}

// ---------- 备份脚本数：懒加载 + 本地缓存 ----------
// 列表加载不解压；脚本数由 RestorePage 后台逐个计算并缓存，
// 缓存文件是备份根目录下的隐藏 json（scanBackups 只扫目录和 .zip，不会误判）。

const BACKUP_COUNT_CACHE_NAME = ".script-manager-cache.json"

interface BackupCountCache {
  [path: string]: { modifiedAt: number; count: number }
}

function readBackupCountCache(destination: Destination): BackupCountCache {
  const cachePath = Path.join(backupRootFor(destination), BACKUP_COUNT_CACHE_NAME)
  try {
    if (pathExists(cachePath)) {
      return JSON.parse(
        FileManager.readAsStringSync(cachePath)
      ) as BackupCountCache
    }
  } catch {}
  return {}
}

/** 读缓存脚本数：缓存命中且修改时间一致才返回，否则 null（需要重新计算） */
export function getBackupScriptCount(
  destination: Destination,
  item: BackupItem
): number | null {
  const entry = readBackupCountCache(destination)[item.path]
  if (entry && entry.modifiedAt === item.modifiedAt) {
    return entry.count
  }
  return null
}

/** 实际计算一个备份里的脚本数（zip 需解压到临时目录，计算后清理） */
export function computeBackupScriptCount(item: BackupItem): number {
  if (item.isZip) {
    const tempDir = Path.join(
      FileManager.temporaryDirectory,
      `count-${Date.now()}-${Math.floor(Math.random() * 10000)}`
    )
    try {
      FileManager.createDirectorySync(tempDir, true)
      FileManager.unzipSync(item.path, tempDir)
      return scanScriptDirsInTree(tempDir).length
    } finally {
      if (pathExists(tempDir)) {
        try { FileManager.removeSync(tempDir) } catch {}
      }
    }
  }
  return scanScriptDirsInTree(item.path).length
}

/** 写入脚本数缓存 */
export function saveBackupScriptCount(
  destination: Destination,
  item: BackupItem,
  count: number
): void {
  const cache = readBackupCountCache(destination)
  cache[item.path] = { modifiedAt: item.modifiedAt, count }
  try {
    FileManager.writeAsStringSync(
      Path.join(backupRootFor(destination), BACKUP_COUNT_CACHE_NAME),
      JSON.stringify(cache)
    )
  } catch {}
}

/** 解开一个备份并找出其中的脚本（zip 解到临时目录，返回 tempDir 供调用方清理） */
export function inspectBackup(
  item: BackupItem
): { candidates: CandidateScript[]; tempDir: string | null } | null {
  try {
    if (item.isZip) {
      const tempDir = Path.join(
        FileManager.temporaryDirectory,
        `restore-${Date.now()}-${Math.floor(Math.random() * 10000)}`
      )
      FileManager.createDirectorySync(tempDir, true)
      FileManager.unzipSync(item.path, tempDir)
      return { candidates: scanScriptDirsInTree(tempDir), tempDir }
    }
    return { candidates: scanScriptDirsInTree(item.path), tempDir: null }
  } catch {
    return null
  }
}

/** 递归查找目录树里所有含 script.json 的脚本文件夹 */
export function scanScriptDirsInTree(root: string): CandidateScript[] {
  const found: CandidateScript[] = []
  function walk(dir: string, depth: number) {
    if (depth > 6) return
    const metaPath = Path.join(dir, "script.json")
    if (pathExists(metaPath)) {
      let version: string | undefined
      try {
        const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
        if (typeof obj?.version === "string") {
          version = obj.version
        }
      } catch {
        version = undefined
      }
      found.push({
        folderName: Path.basename(dir),
        sourcePath: dir,
        version,
        modifiedAt: statTime(metaPath),
      })
      return
    }
    for (const child of listChildren(dir)) {
      if (isDirectory(child)) {
        walk(child, depth + 1)
      }
    }
  }
  walk(root, 0)
  return found
}

export async function restoreScripts(
  candidates: CandidateScript[],
  overwrite: boolean
): Promise<{ restored: string[]; skipped: string[] }> {
  const root = FileManager.scriptsDirectory
  const restored: string[] = []
  const skipped: string[] = []
  // 覆盖恢复会替换脚本目录；提前扫描一次用于记录原分组快照
  const hasOverwriteTarget = candidates.some((c) =>
    pathExists(Path.join(root, c.folderName))
  )
  const allScripts = hasOverwriteTarget ? scanScripts() : []
  const toSnapshot: string[] = []
  const toRestore: string[] = []
  for (const candidate of candidates) {
    const dest = Path.join(root, candidate.folderName)
    // 恢复前记住目标脚本原有的发布链接（remoteResource），
    // 若备份是发布前做的（不带 remoteResource），恢复后写回，避免丢失「已发布」图标
    const prevRemote = pathExists(dest) ? readRemoteResourceAtDir(dest) : null
    if (pathExists(dest)) {
      if (!overwrite) {
        skipped.push(candidate.folderName)
        continue
      }
      toSnapshot.push(candidate.folderName)
      FileManager.removeSync(dest)
    }
    copyDirectory(candidate.sourcePath, dest)
    // 备份里本身没有发布链接但目标原本有：恢复后补回，保持「已发布」标识
    if (prevRemote && !readRemoteResourceAtDir(dest)) {
      writeRemoteResourceAtDir(dest, prevRemote)
    }
    restored.push(candidate.folderName)
    toRestore.push(candidate.folderName)
  }
  // 覆盖恢复后写回原分组：目录被替换后 settings.json 里的分组引用可能匹配不上/被清掉，
  // 用覆盖前快照把脚本重新加回原分组（恢复时用覆盖后的当前脚本列表，避免显示名变化导致引用失效）
  if (toSnapshot.length > 0) {
    snapshotScriptGroups(toSnapshot, allScripts)
  }
  if (toRestore.length > 0) {
    const current = scanScripts()
    for (const folderName of toRestore) {
      restoreScriptGroupFromSnapshot(folderName, current)
    }
  }
  return { restored, skipped }
}

// ==================== 脚本管理 ====================

/**
 * 重命名脚本后同步 Scripting 的 .scripting/settings.json 里的分组引用。
 * 分组 scripts 数组里存的是脚本显示名（displayName）或目录名，改名后旧引用会失效，
 * 导致脚本从所属分组中丢失；这里把所有分组的旧引用统一替换为新目录名。
 * 路径选取与 moveScriptToGroup 一致：优先 scriptsDirectory 同级的 .scripting，其次 appGroupDocumentsDirectory。
 */
function replaceGroupRefAfterRename(oldRefs: string[], newRef: string): void {
  const candidates = [
    Path.join(Path.dirname(FileManager.scriptsDirectory), ".scripting", "settings.json"),
    Path.join(FileManager.appGroupDocumentsDirectory, ".scripting", "settings.json"),
  ]
  for (const settingsPath of candidates) {
    if (!pathExists(settingsPath)) {
      continue
    }
    try {
      const obj = readScriptingSettingsObj(settingsPath)
      const defs = obj?.groups
      if (!Array.isArray(defs) || defs.length === 0) {
        continue
      }
      let changed = false
      for (const def of defs) {
        if (!Array.isArray(def.scripts)) {
          continue
        }
        for (let i = 0; i < def.scripts.length; i++) {
          if (oldRefs.includes(def.scripts[i])) {
            def.scripts[i] = newRef
            changed = true
          }
        }
      }
      if (changed) {
        FileManager.writeAsStringSync(settingsPath, JSON.stringify(obj, null, 2))
      }
      return
    } catch {
      // settings.json 解析失败则尝试下一个候选路径
    }
  }
}

export function renameScript(script: ScriptInfo, newName: string): void {
  const clean = newName.trim()
  if (!clean) {
    throw new Error("名称不能为空")
  }
  if (/[\/\\:]/.test(clean)) {
    throw new Error("名称不能包含 / \\ : 字符")
  }
  if (clean === script.folderName) {
    return
  }
  const dest = Path.join(FileManager.scriptsDirectory, clean)
  if (pathExists(dest)) {
    throw new Error(`已存在同名脚本「${clean}」`)
  }
  FileManager.renameSync(script.path, dest)
  // 同步更新 script.json 里的 name 和 localizedNames（主界面用 localizedNames 显示）
  try {
    const metaPath = Path.join(dest, "script.json")
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    if (typeof obj === "object" && obj !== null) {
      obj.name = clean
      if (obj.localizedNames && typeof obj.localizedNames === "object") {
        obj.localizedNames.zh = clean
      }
      if (obj.localizedDescriptions && typeof obj.localizedDescriptions === "object") {
        // localizedDescriptions 保持不变，只改名字
      }
      FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
    }
  } catch {
    // 元信息更新失败不阻断重命名
  }
  // 同步分组引用：改名后 Scripting 的 settings.json 里分组仍引用旧显示名/旧目录名，
  // 不更新会导致该脚本从所属分组中丢失；把旧引用全部替换为新名
  replaceGroupRefAfterRename([script.displayName, script.folderName], clean)
  // 迁移以 folderName 为 key 的配置记录：期望分组、运行记录、最近使用时间，避免改名后排序/统计功能失效
  const cfg = resolveConfig()
  const patch: Partial<AppConfig> = {}
  // 期望分组记录
  const targets = cfg.groupMoveTargets || {}
  if (targets[script.folderName]) {
    const moved = targets[script.folderName]
    const rest = { ...targets }
    delete rest[script.folderName]
    rest[clean] = moved
    patch.groupMoveTargets = rest
  }
  // 最近 50 次运行记录（用于「按运行次数」排序）：把旧目录名替换为新目录名
  if (cfg.recentRunLog && cfg.recentRunLog.length > 0) {
    patch.recentRunLog = cfg.recentRunLog.map((f) =>
      f === script.folderName ? clean : f
    )
  }
  // 最近使用时间（用于「按最近使用」排序及同分组内排序）：把旧 key 迁移到新 key
  if (cfg.recentUsedAt && cfg.recentUsedAt[script.folderName] != null) {
    const used = { ...cfg.recentUsedAt }
    used[clean] = used[script.folderName]
    delete used[script.folderName]
    patch.recentUsedAt = used
  }
  if (Object.keys(patch).length > 0) {
    saveConfig({ ...cfg, ...patch })
  }
}

export function setScriptVersion(script: ScriptInfo, version: string): void {
  const clean = version.trim()
  if (!clean) {
    throw new Error("版本号不能为空")
  }
  if (!/^\d+\.\d+\.\d+$/.test(clean)) {
    throw new Error("版本号格式应为 x.y.z，例如 1.0.1")
  }
  const metaPath = Path.join(script.path, "script.json")
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error("script.json 格式错误")
  }
  obj.version = clean
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/**
 * 把脚本 script.json 的 author.name 设为指定名称（首页菜单「填入作者」功能）。
 * 返回覆盖前的作者名（无作者时返回 undefined），是否覆盖由调用方先确认；
 * 写入时保留原有 email/homepage 字段，只覆盖名称。
 */
/** 取 contributors 条目里的贡献者名：对象取 name，字符串直接用；空/无效条目返回空串。 */
function contributorNameOf(c: unknown): string {
  if (c && typeof c === "object") {
    const n = (c as { name?: unknown }).name
    if (typeof n === "string" && n.trim()) {
      return n.trim()
    }
  } else if (typeof c === "string" && c.trim()) {
    return c.trim()
  }
  return ""
}

export function setScriptAuthorName(
  script: ScriptInfo,
  name: string
): { old: string | undefined } {
  const clean = name.trim()
  if (!clean) {
    throw new Error("作者名不能为空")
  }
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error("script.json 不存在")
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error("script.json 格式错误")
  }
  const old = extractAuthor(obj)
  const prev =
    obj.author && typeof obj.author === "object" ? obj.author : {}
  obj.author = { ...prev, name: clean }
  // 覆盖作者名后，删除 contributors 中与新作者同名的条目（作者不该同时挂在贡献者列表）
  if (Array.isArray(obj.contributors)) {
    const filtered = obj.contributors.filter(
      (c: unknown) => contributorNameOf(c) !== clean
    )
    if (filtered.length !== obj.contributors.length) {
      obj.contributors = filtered
    }
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
  return { old }
}

/**
 * 把脚本 script.json 的 contributors 数组追加当前用户为贡献者（首页菜单「填入贡献者」）。
 * Scripting 高级菜单认识的标准字段是顶层 contributors（author 对象数组），不是 author.coAuthor。
 * 保留已有 contributors 与 author（name/email/homepage）不动，只追加；同名贡献者不重复追加。
 */
export function setScriptCoAuthor(
  script: ScriptInfo,
  name: string
): { contributors: number } {
  const clean = name.trim()
  if (!clean) {
    throw new Error("贡献者名不能为空")
  }
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error("script.json 不存在")
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error("script.json 格式错误")
  }
  const list = Array.isArray(obj.contributors) ? obj.contributors : []
  // 过滤与作者同名的条目（作者不该同时挂在贡献者列表），避免写回时保留脏数据
  const authorName =
    obj.author && typeof obj.author === "object"
      ? typeof (obj.author as { name?: unknown }).name === "string"
        ? ((obj.author as { name?: unknown }).name as string).trim()
        : ""
      : ""
  const filtered = authorName
    ? list.filter((c: unknown) => contributorNameOf(c) !== authorName)
    : list
  const exists = filtered.some((c: unknown) => contributorNameOf(c) === clean)
  if (!exists) {
    filtered.push({ name: clean, email: null, homepage: null })
  }
  obj.contributors = filtered
  // 清理旧版写入的 author.coAuthor（Scripting 不识别该字段），避免残留
  if (obj.author && typeof obj.author === "object") {
    const a = obj.author as Record<string, unknown>
    if ("coAuthor" in a) {
      delete a.coAuthor
    }
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
  return { contributors: obj.contributors.length }
}

/**
 * 把脚本 script.json 的 contributors 中指定名字的贡献者移除（首页菜单「移除我的贡献」）。
 * 只移除指定名字，保留其他贡献者与 author；返回是否真的移除了（不在列表则 removed=false）。
 */
export function removeScriptContributor(
  script: ScriptInfo,
  name: string
): { removed: boolean; contributors: number } {
  const clean = name.trim()
  if (!clean) {
    throw new Error("贡献者名不能为空")
  }
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error("script.json 不存在")
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error("script.json 格式错误")
  }
  const list = Array.isArray(obj.contributors) ? obj.contributors : []
  const filtered = list.filter((c: unknown) => {
    if (c && typeof c === "object") {
      return (c as { name?: unknown }).name !== clean
    }
    return c !== clean
  })
  obj.contributors = filtered
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
  return {
    removed: filtered.length < list.length,
    contributors: filtered.length,
  }
}

/**
 * 清空脚本 script.json 的 author 与 contributors（首页菜单「填入作者」里的「清空作者名」）。
 * 删除整个 author 字段并清空 contributors，返回删除前的作者名（无作者时返回 undefined）。
 */
export function clearScriptAuthor(
  script: ScriptInfo
): { old: string | undefined } {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error("script.json 不存在")
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error("script.json 格式错误")
  }
  const old = extractAuthor(obj)
  delete obj.author
  delete obj.contributors
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
  return { old }
}

/** 读 script.json 的 contributors 里的所有贡献者名（无则空数组，不含旧 author.coAuthor）。
 *  若 contributors 中存在与 author.name 同名的条目（作者不该同时挂在贡献者列表），自动从文件删除并写回。 */
export function readScriptContributors(dir: string): string[] {
  try {
    const metaPath = Path.join(dir, "script.json")
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    const list = Array.isArray(obj?.contributors) ? obj.contributors : []
    const authorName =
      obj?.author && typeof obj.author === "object"
        ? typeof (obj.author as { name?: unknown }).name === "string"
          ? ((obj.author as { name?: unknown }).name as string).trim()
          : ""
        : ""
    const names: string[] = []
    const filtered: unknown[] = []
    for (const c of list) {
      const n = contributorNameOf(c)
      if (n && authorName && n === authorName) {
        // 与作者同名的贡献者条目：删除（作者不该同时挂在贡献者列表）
        continue
      }
      if (n) {
        names.push(n)
      }
      filtered.push(c)
    }
    if (filtered.length !== list.length) {
      obj.contributors = filtered
      FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
    }
    return names
  } catch {
    return []
  }
}

/** 读 contributors + 兼容旧版 author.coAuthor 的所有协助者名 */
export function readScriptCoAuthors(dir: string): string[] {
  try {
    const raw = FileManager.readAsStringSync(Path.join(dir, "script.json"))
    const obj = parseScriptJson(raw)
    const list = Array.isArray(obj?.contributors) ? obj.contributors : []
    const names: string[] = []
    for (const c of list) {
      if (c && typeof c === "object") {
        const n = (c as { name?: unknown }).name
        if (typeof n === "string" && n.trim()) {
          names.push(n.trim())
        }
      } else if (typeof c === "string" && c.trim()) {
        names.push(c.trim())
      }
    }
    // 兼容旧版写入的 author.coAuthor
    const a = obj?.author
    if (a && typeof a === "object") {
      const c = (a as { coAuthor?: unknown }).coAuthor
      if (typeof c === "string" && c.trim()) {
        names.push(c.trim())
      }
    }
    return names
  } catch {
    return []
  }
}

/** 读取指定脚本目录 script.json 里的 remoteResource（更新链接）信息，无则返回 null。
 *  供 getScriptRemoteResource 与恢复流程共用（恢复时需按路径读取）。 */
function readRemoteResourceAtDir(
  dir: string
): { url: string; hash?: string; autoUpdateInterval?: number } | null {
  const metaPath = Path.join(dir, "script.json")
  if (!pathExists(metaPath)) {
    return null
  }
  try {
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    const remote = obj?.remoteResource
    if (!remote || typeof remote !== "object") {
      return null
    }
    return {
      url: typeof remote.url === "string" ? remote.url : "",
      hash: typeof remote.hash === "string" ? remote.hash : undefined,
      autoUpdateInterval:
        typeof remote.autoUpdateInterval === "number" ? remote.autoUpdateInterval : undefined,
    }
  } catch {
    return null
  }
}

/** 把 remoteResource（更新链接）写回指定脚本目录的 script.json，仅当该目录存在 script.json。 */
function writeRemoteResourceAtDir(
  dir: string,
  remote: { url: string; hash?: string; autoUpdateInterval?: number }
): void {
  const metaPath = Path.join(dir, "script.json")
  if (!pathExists(metaPath)) {
    return
  }
  try {
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    if (typeof obj !== "object" || obj === null) {
      return
    }
    obj.remoteResource = {
      url: remote.url,
      ...(remote.hash != null ? { hash: remote.hash } : {}),
      ...(remote.autoUpdateInterval != null ? { autoUpdateInterval: remote.autoUpdateInterval } : {}),
    }
    FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
  } catch {}
}

/**
 * 读取脚本 script.json 里的 remoteResource（更新链接）信息。
 * 若脚本配置了自动更新（autoUpdateInterval），Scripting 会定期从远程拉取 script.json
 * 覆盖本地文件，导致手动修改的版本号被还原。返回 null 表示没有远程更新链接。
 */
export function getScriptRemoteResource(
  script: ScriptInfo
): { url: string; hash?: string; autoUpdateInterval?: number } | null {
  return readRemoteResourceAtDir(script.path)
}

/**
 * 下载脚本云端 .scripting 包（remoteResource.url），读取其 script.json 的版本号、更新说明（changelog）
 * 以及云端包的内容指纹（scriptContentFingerprint），用于检测「云端与本地不同步」、展示云端更新说明，
 * 以及作为无发布记录指纹脚本的小黄云兜底基线。仅读取不覆盖本地；失败返回 null。
 */
export async function fetchScriptCloudMeta(
  script: ScriptInfo
): Promise<
  | {
      version: string | null
      changelog: string | null
      fingerprint: string | null
    }
  | null
> {
  const remote = getScriptRemoteResource(script)
  if (!remote?.url) {
    return null
  }
  try {
    const res = await fetch(remote.url)
    if (!res.ok) {
      return null
    }
    const bytes = await res.bytes()
    const staging = Path.join(
      FileManager.temporaryDirectory,
      `cloud-ver-${Date.now()}-${Math.floor(Math.random() * 10000)}`
    )
    FileManager.createDirectorySync(staging, true)
    try {
      const zipPath = Path.join(staging, "cloud.scripting")
      FileManager.writeAsBytesSync(zipPath, bytes)
      const inner = Path.join(staging, "inner")
      FileManager.createDirectorySync(inner, true)
      FileManager.unzipSync(zipPath, inner)
      const candidates = scanScriptDirsInTree(inner)
      if (candidates.length === 0) {
        return null
      }
      const first = candidates[0]
      let changelog: string | null = null
      let fingerprint: string | null = null
      try {
        const metaPath = Path.join(first.sourcePath, "script.json")
        const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
        if (typeof obj?.changelog === "string" && obj.changelog.trim()) {
          changelog = obj.changelog
        }
      } catch {}
      try {
        fingerprint = scriptContentFingerprint(first.sourcePath)
      } catch {}
      return { version: first.version || null, changelog, fingerprint }
    } finally {
      if (pathExists(staging)) {
        try {
          FileManager.removeSync(staging)
        } catch {}
      }
    }
  } catch {
    return null
  }
}

/** 写入脚本 script.json 的更新说明字段（changelog），随发布包一起分发；空说明则移除字段 */
export function setScriptChangelog(script: ScriptInfo, changelog: string): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  const text = (changelog ?? "").trim()
  if (text) {
    obj.changelog = text
  } else {
    delete obj.changelog
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/** 读取脚本 script.json 的更新说明（changelog），无则返回 null */
export function readScriptChangelog(script: ScriptInfo): string | null {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    return null
  }
  try {
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    if (typeof obj?.changelog === "string" && obj.changelog.trim()) {
      return obj.changelog
    }
  } catch {}
  return null
}

const CHANGELOG_MARKER_START = "// ===== 更新说明检查（脚本管理工具注入，勿删） ====="
const CHANGELOG_MARKER_END = "// ===== 更新说明检查结束 ====="

/**
 * 向被发布脚本的 index.tsx 注入「更新说明检查」代码（顶部 IIFE）：
 * 更新到新版本后首次运行时自动弹出该版本的更新说明（App Store 更新日志风格自定义页面），
 * 并提供「不再显示本次更新说明」按钮与「历史更新记录」按钮（可查看最多 10 个版本的
 * 历史更新说明，左右翻页；历史记录写入 changelog_history/{scriptName}.json）。
 * 说明文本、版本号、脚本名全部直接嵌入代码常量；UI 组件通过动态 import("scripting") 获取，
 * 不读 script.json（Scripting 应用会重写它并丢掉自定义字段），也不依赖裸全局 Script（需要 import from "scripting"）。
 * notifyAuthor=true 时本次发布勾选「作者本人也提示更新」，作者本人（脚本管理工具设置里用户名==脚本作者）也会弹更新说明；
 * 默认 false：作者本人不弹（其他人正常弹）。
 * 延迟 600ms 再 present，避免被脚本主体页面的 Navigation.present 覆盖。
 * 重复注入会自动移除旧块后替换。找不到 index.tsx 返回 false。
 */
export function injectChangelogChecker(script: ScriptInfo, changelog: string, notifyAuthor?: boolean): boolean {
  const entry = Path.join(script.path, "index.tsx")
  if (!pathExists(entry)) {
    return false
  }
  let source = FileManager.readAsStringSync(entry)
  const startIdx = source.indexOf(CHANGELOG_MARKER_START)
  const endIdx = source.indexOf(CHANGELOG_MARKER_END)
  if (startIdx >= 0 && endIdx >= 0 && endIdx > startIdx) {
    source = source.slice(0, startIdx) + source.slice(endIdx + CHANGELOG_MARKER_END.length)
  }
  const noteLiteral = JSON.stringify((changelog ?? "").trim())
  const versionLiteral = JSON.stringify(String(script.version ?? ""))
  const nameLiteral = JSON.stringify(String(script.displayName ?? ""))
  const folderNameLiteral = JSON.stringify(String(script.folderName ?? ""))
  const authorLiteral = JSON.stringify(String((script.authorName ?? "").trim()))
  const notifyAuthorLiteral = JSON.stringify(notifyAuthor === true)
  // 每次发布生成唯一发布序号：去重键用「版本号@发布序号」，即使版本号一致，重新发布也会重新提示
  const publishIdLiteral = JSON.stringify(
    "p" + Date.now() + "-" + Math.floor(Math.random() * 100000)
  )
  const block =
    CHANGELOG_MARKER_START +
    "\n" +
    `;(async () => {
  try {
    const note = ${noteLiteral}
    if (!note) return
    const version = ${versionLiteral}
    const scriptName = ${nameLiteral}
    const folderName = ${folderNameLiteral}
    if (!version) return
    const scriptAuthor = ${authorLiteral}
    const notifyAuthor = ${notifyAuthorLiteral}
    const publishId = ${publishIdLiteral}
    const base = FileManager.appGroupDocumentsDirectory || ""
    if (!base) return
    // 记录历史更新说明（changelog_history/{scriptName}.json，按版本号降序，最多 20 条，同版本去重）
    const histDir = base + "/changelog_history"
    try { await FileManager.createDirectory(histDir, true) } catch (e) {}
    const histPath = histDir + "/" + scriptName + ".json"
    let history: { version: string; note: string }[] = []
    try {
      const raw = JSON.parse(await FileManager.readAsString(histPath))
      if (Array.isArray(raw)) history = raw
    } catch (e) {}
    try {
      history = history.filter((h) => h && h.version !== version)
      history.push({ version, note })
      const verNums = (v: string) => {
        const p = String(v || "").split(".").map((n) => parseInt(n, 10) || 0)
        while (p.length < 3) p.push(0)
        return p
      }
      history.sort((a, b) => {
        const pa = verNums(a.version)
        const pb = verNums(b.version)
        for (let i = 0; i < 3; i++) {
          if (pa[i] !== pb[i]) return pb[i] - pa[i]
        }
        return 0
      })
      history = history.slice(0, 20)
      await FileManager.writeAsString(histPath, JSON.stringify(history))
    } catch (e) {}
    const seenDir = base + "/changelog_seen"
    try { await FileManager.createDirectory(seenDir, true) } catch (e) {}
    const statePath = seenDir + "/" + scriptName + ".json"
    let seen: Record<string, boolean> = {}
    try { seen = JSON.parse(await FileManager.readAsString(statePath)) || {} } catch (e) {}
    if (seen[version]) return
    // 作者本人不提示：本机脚本管理工具发布过该版本（本机即作者/发布者设备），或设置里填写的用户名与脚本作者一致，
    // 且本次发布未勾选「作者本人也提示更新」时，不弹更新说明
    try {
      const mgrCfgPath = base + "/script-manager-config.json"
      const mgrCfg = JSON.parse(await FileManager.readAsString(mgrCfgPath)) || {}
      const mgrName = String(mgrCfg.authorName || "").trim()
      const published = mgrCfg.publishedVersions || {}
      if (!notifyAuthor && ((scriptAuthor && mgrName && mgrName === scriptAuthor) || published[folderName] === version)) {
        return
      }
    } catch (e) {}
    // 同一发布实例只提示一次（按 版本号@发布序号 去重）：即使版本号一致，重新发布也会重新提示
    const seenKey = version + "@" + publishId
    if (seen[seenKey]) return
    await new Promise<void>((resolve) => setTimeout(() => resolve(), 600))
    const { Navigation, NavigationStack, ScrollView, VStack, HStack, Text, Button, Divider, Spacer, Image, useState } = await import("scripting")
    const markSeen = async () => {
      try {
        seen[seenKey] = true
        await FileManager.writeAsString(statePath, JSON.stringify(seen))
      } catch (e) {}
    }
    function ChangelogView(props: { note: string; version: string; scriptName: string; history: { version: string; note: string }[] }) {
      const dismiss = Navigation.useDismiss()
      const [pageIndex, setPageIndex] = useState(0)
      const total = props.history.length
      const current = total > 0 ? props.history[Math.min(pageIndex, total - 1)] : null
      const atFirst = pageIndex <= 0
      const atLast = pageIndex >= total - 1
      const navButton = (icon: string, label: string, disabled: boolean, action: () => void) => (
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 48, height: 52 }}
          background={{ style: { color: "label", opacity: 0.08 }, shape: { type: "rect", cornerRadius: 12 } }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={() => { if (!disabled) action() }}
        >
          <Image systemName={icon} foregroundStyle={disabled ? "secondaryLabel" : "tintColor"} />
          <Text font="caption2" foregroundStyle={disabled ? "secondaryLabel" : "tintColor"}>{label}</Text>
        </VStack>
      )
      return (
        <NavigationStack>
          <VStack navigationTitle={props.scriptName + " · 更新说明"} navigationBarTitleDisplayMode="inline" navigationBarBackButtonHidden spacing={0}>
            {total === 0 ? (
              <VStack alignment="center" spacing={8} padding={32} frame={{ maxHeight: "infinity" }}>
                <Text font="subheadline" foregroundStyle="secondaryLabel">暂无历史更新记录</Text>
              </VStack>
            ) : current ? (
              <>
                <HStack alignment="center" padding={{ top: 14, horizontal: 16, bottom: 10 }}>
                  <Text font="headline" bold>版本 {current.version}</Text>
                  <Spacer />
                  <Text font="caption2" foregroundStyle="secondaryLabel">第 {pageIndex + 1} / {total} 页</Text>
                </HStack>
                <Divider />
                <ScrollView frame={{ maxHeight: "infinity" }}>
                  <VStack alignment="leading" spacing={10} padding={{ horizontal: 16, bottom: 16 }}>
                    <Text font="body" multilineTextAlignment="leading">{current.note}</Text>
                  </VStack>
                </ScrollView>
              </>
            ) : null}
            <Divider />
            <VStack spacing={12} alignment="center" padding={{ horizontal: 16, vertical: 12 }} background={{ style: { color: "secondarySystemBackground", opacity: 0.95 }, shape: { type: "rect", cornerRadius: 20 } }}>
              <HStack spacing={10} alignment="center" padding={{ horizontal: 10, vertical: 8 }}>
                {navButton("backward.end.fill", "首页", atFirst, () => setPageIndex(0))}
                {navButton("chevron.left", "上页", atFirst, () => setPageIndex(pageIndex - 1))}
                {navButton("chevron.right", "下页", atLast, () => setPageIndex(pageIndex + 1))}
                {navButton("forward.end.fill", "尾页", atLast, () => setPageIndex(total - 1))}
              </HStack>
              <HStack spacing={12} alignment="center" padding={{ horizontal: 6, vertical: 2 }}>
                <Button action={() => { markSeen(); dismiss() }} buttonStyle="bordered" controlSize="large">
                  <Text font="footnote" foregroundStyle="secondaryLabel">此版不再显示</Text>
                </Button>
                <Button action={() => dismiss()} buttonStyle="borderedProminent" controlSize="large">
                  <Text font="footnote" bold>稍候再看说明</Text>
                </Button>
              </HStack>
            </VStack>
          </VStack>
        </NavigationStack>
      )
    }
    await Navigation.present({
      element: <ChangelogView note={note} version={version} scriptName={scriptName} history={history} />,
    })
  } catch (e) {}
})();\n` +
    CHANGELOG_MARKER_END +
    "\n\n"
  FileManager.writeAsStringSync(entry, block + source)
  return true
}

/** 移除脚本 index.tsx 里的更新说明检查代码（无则不动） */
export function removeChangelogChecker(script: ScriptInfo): void {
  const entry = Path.join(script.path, "index.tsx")
  if (!pathExists(entry)) {
    return
  }
  const source = FileManager.readAsStringSync(entry)
  const startIdx = source.indexOf(CHANGELOG_MARKER_START)
  const endIdx = source.indexOf(CHANGELOG_MARKER_END)
  if (startIdx >= 0 && endIdx >= 0 && endIdx > startIdx) {
    FileManager.writeAsStringSync(
      entry,
      source.slice(0, startIdx) + source.slice(endIdx + CHANGELOG_MARKER_END.length)
    )
  }
}

/**
 * 关闭脚本的自动更新：保留更新链接（url/hash），只移除 autoUpdateInterval 开关。
 * 用于修改版本号后防止 Scripting 按间隔从远程拉取覆盖本地改动的版本号，
 * 同时保留链接，之后可重新开启自动更新。
 */
export function disableScriptAutoUpdate(script: ScriptInfo): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  const remote = obj.remoteResource
  if (remote && typeof remote === "object") {
    // 只关开关，不删链接
    delete remote.autoUpdateInterval
  } else {
    obj.remoteResource = null
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/**
 * 彻底移除脚本的更新链接与自动更新配置（remoteResource 置为 null）。
 * 用于发布失败回滚时恢复“从未配置过更新链接”的原状。
 */
function clearScriptRemoteResource(script: ScriptInfo): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  obj.remoteResource = null
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

export function deleteScript(script: ScriptInfo): void {
  if (!pathExists(script.path)) {
    return
  }
  FileManager.removeSync(script.path)
}

/** 打包脚本为 .scripting 文件并通过系统分享面板分享（staging 位于临时目录，分享完成后清理） */
export async function shareScripts(scripts: ScriptInfo[]): Promise<void> {
  if (scripts.length === 0) {
    return
  }
  const staging = Path.join(FileManager.temporaryDirectory, `share-${Date.now()}`)
  FileManager.createDirectorySync(staging, true)
  const name =
    scripts.length === 1
      ? `${scripts[0].folderName}_${scripts[0].version}`
      : `${scripts[0].folderName}等${scripts.length}个脚本`
  const filePath = Path.join(staging, `${safeFileName(name)}.scripting`)
  try {
    if (scripts.length === 1) {
      await FileManager.zip(scripts[0].path, filePath, true)
    } else {
      const inner = Path.join(staging, "scripts")
      FileManager.createDirectorySync(inner, true)
      for (const script of scripts) {
        copyDirectory(script.path, Path.join(inner, script.folderName))
      }
      await FileManager.zip(inner, filePath, false)
    }
    await ShareSheet.present([filePath])
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

/**
 * 打包单个脚本为 .scripting 并返回压缩包实际大小（与备份/分享产物一致），失败返回 null。
 * 行菜单显示脚本大小时用它，避免“目录内文件大小之和”与备份 zip 大小不一致。
 */
export async function scriptZipSize(script: ScriptInfo): Promise<number | null> {
  const staging = Path.join(FileManager.temporaryDirectory, `size-${Date.now()}`)
  FileManager.createDirectorySync(staging, true)
  const filePath = Path.join(staging, `${safeFileName(script.folderName)}.scripting`)
  try {
    await FileManager.zip(script.path, filePath, true)
    return statSize(filePath)
  } catch {
    return null
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

// ==================== GitHub 发布 ====================

/** 简单 HTTP 封装（GitHub API 使用） */
async function githubHttp(
  url: string,
  init: {
    method?: string
    headers?: Record<string, string>
    body?: string
  } = {}
): Promise<{ status: number; data: any; text: string }> {
  const r = await fetch(url, {
    method: init.method || "GET",
    headers: { ...(init.headers || {}) },
    body: init.body,
  })
  const text = await r.text()
  let data: any = null
  try {
    data = JSON.parse(text)
  } catch {}
  return { status: r.status, data, text }
}

// ==================== 仓库监控 ====================

/** 默认监控仓库（工具作者的发布仓库），首次启用时自动加入配置 */
export const DEFAULT_CHANNEL_MONITOR_LINK =
  "https://github.com/vvvvvveng/Scripting-releases"

export const DEFAULT_CHANNEL_MONITOR_LINKS: ChannelMonitorLink[] = [
  {
    url: DEFAULT_CHANNEL_MONITOR_LINK,
    name: "WWWeng🐝的脚本仓库",
  },
]

/**
 * 仓库监控默认排除关键词：仓库里的「测试脚本_请勿下载_」等脚本名称含「请勿下载」，默认不提示更新。
 * 仅当用户配置里未设置过该字段时生效（用户保存过自己的关键词列表后以用户为准）。
 */
export const DEFAULT_CHANNEL_EXCLUDE_KEYWORDS = ["请勿下载"]

/**
 * 解析 GitHub 仓库地址，返回规范化 URL；无法解析返回 null。
 * 支持：https://github.com/owner/repo、github.com/owner/repo、owner/repo、结尾带 / 或 .git。
 */
export function normalizeRepoUrl(input: string): string | null {
  const raw = (input || "").trim().replace(/\/+$/, "")
  if (!raw) return null
  let m = raw.match(
    /^(?:https?:\/\/)?(?:www\.)?github\.com\/([^/?#]+)\/([^/?#]+)$/i
  )
  if (!m) {
    m = raw.match(/^([^/?#]+)\/([^/?#]+)$/)
  }
  if (!m) return null
  const owner = m[1].replace(/\.git$/i, "")
  const repo = m[2].replace(/\.git$/i, "")
  if (!owner || !repo) return null
  return `https://github.com/${owner}/${repo}`
}

/** 仓库显示名：默认取 所有者/仓库名，如 vvvvvveng/Scripting-releases */
export function repoDisplayName(url: string): string {
  const norm = normalizeRepoUrl(url)
  if (!norm) return url
  return norm.replace(/^https?:\/\/github\.com\//i, "")
}

/**
 * 规范化监控链接列表：过滤无效/重复项；全空时补默认仓库。
 * 备注名为空时自动取 所有者/仓库名。
 */
export function normalizeChannelMonitorLinks(
  links?: unknown
): ChannelMonitorLink[] {
  const arr = Array.isArray(links) ? links : []
  const list: ChannelMonitorLink[] = []
  const seen = new Set<string>()
  for (const item of arr) {
    if (!item || typeof item !== "object") continue
    const anyItem = item as Record<string, unknown>
    const url = normalizeRepoUrl(String(anyItem.url ?? ""))
    if (!url || seen.has(url)) continue
    seen.add(url)
    const auto = repoDisplayName(url)
    list.push({
      url,
      name: String(anyItem.name ?? "").trim() || auto,
    })
  }
  if (list.length === 0) {
    list.push({ ...DEFAULT_CHANNEL_MONITOR_LINKS[0] })
  }
  return list
}

/**
 * 规范化排除关键词列表：过滤空串、去重、统一 trim。
 */
export function normalizeChannelExcludeKeywords(keywords?: unknown): string[] {
  const arr = Array.isArray(keywords) ? keywords : []
  const out: string[] = []
  const seen = new Set<string>()
  for (const k of arr) {
    const s = String(k ?? "").trim()
    if (!s || seen.has(s)) continue
    seen.add(s)
    out.push(s)
  }
  return out
}

/**
 * 规范化已忽略脚本路径列表：过滤空串、去重、统一 trim（格式 `仓库url|脚本路径`）。
 */
export function normalizeChannelIgnoredPaths(paths?: unknown): string[] {
  const arr = Array.isArray(paths) ? paths : []
  const out: string[] = []
  const seen = new Set<string>()
  for (const p of arr) {
    const s = String(p ?? "").trim()
    if (!s || seen.has(s)) continue
    seen.add(s)
    out.push(s)
  }
  return out
}

/**
 * 判断脚本路径是否命中排除关键词（去掉扩展名后的名称部分含任一关键词即排除）。
 */
export function isChannelScriptExcluded(
  path: string,
  keywords: string[]
): boolean {
  if (!Array.isArray(keywords) || keywords.length === 0) return false
  const name = String(path ?? "").replace(/\.scripting$/i, "")
  return keywords.some((k) => name.includes(k))
}

/** 仓库监控：检查间隔换算为秒（默认 12 小时） */
export function channelMonitorIntervalSeconds(
  value: number,
  unit: "minute" | "hour" | "day"
): number {
  const base = Number.isFinite(value) && value > 0 ? value : 12
  if (unit === "day") return Math.round(base * 86400)
  if (unit === "hour") return Math.round(base * 3600)
  return Math.round(base * 60)
}

/**
 * 拉取仓库里所有 .scripting 文件（git/trees 递归接口，一次请求；公开仓库无需 Token）。
 * 依次尝试 main → HEAD → master 分支。失败抛错。
 */
export async function fetchChannelRepoScripts(
  url: string
): Promise<ChannelRepoFile[]> {
  const norm = normalizeRepoUrl(url)
  if (!norm) throw new Error("无法解析仓库地址")
  const parts = norm.replace(/^https?:\/\/github\.com\//i, "").split("/")
  if (parts.length !== 2) throw new Error("无法解析仓库地址")
  const [owner, repo] = parts
  // 若配置过 GitHub Token 则带上（提高 API 限额），没有也能匿名读取公开仓库
  const gh = resolveGithubConfig()
  const token = gh.publishToken || gh.backupToken || gh.token || ""
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  if (token) headers.Authorization = `Bearer ${token}`
  let lastError: Error | null = null
  for (const branch of ["main", "HEAD", "master"]) {
    const { status, data } = await githubHttp(
      `https://api.github.com/repos/${owner}/${repo}/git/trees/${encodeURIComponent(
        branch
      )}?recursive=1`,
      { headers }
    )
    if (status === 200 && data && Array.isArray(data.tree)) {
      return (data.tree as any[])
        .filter(
          (x) =>
            x &&
            x.type === "blob" &&
            typeof x.path === "string" &&
            x.path.toLowerCase().endsWith(".scripting")
        )
        .map((x) => ({
          path: x.path as string,
          sha: String(x.sha ?? ""),
          size: typeof x.size === "number" ? x.size : 0,
        }))
    }
    lastError = new Error(`HTTP ${status}: ${data?.message ?? ""}`)
  }
  throw lastError ?? new Error("获取仓库文件列表失败")
}

/** 只更新仓库监控相关配置字段（不覆盖其它字段） */
export function updateChannelMonitorConfig(patch: Partial<AppConfig>) {
  saveConfig({ ...resolveConfig(), ...patch })
}

/** 版本号比较：a > b 返回 1，a < b 返回 -1，相等返回 0（支持 "3.5.0" 格式；解析失败视为相等） */
export function compareVersions(a: string, b: string): number {
  const pa = (a || "").split(".").map((s) => parseInt(s.trim(), 10) || 0)
  const pb = (b || "").split(".").map((s) => parseInt(s.trim(), 10) || 0)
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const x = pa[i] ?? 0
    const y = pb[i] ?? 0
    if (x !== y) return x > y ? 1 : -1
  }
  return 0
}

/**
 * 本地同名脚本版本：云端 .scripting 文件名去掉后缀后，在 scriptsDirectory 下找同名脚本目录读 version。
 * 本地不存在同名脚本返回 null。
 */
export function localScriptVersionForChannelPath(remotePath: string): string | null {
  const base = Path.basename(remotePath).replace(/\.scripting$/i, "")
  if (!base) return null
  const dir = Path.join(FileManager.scriptsDirectory, base)
  if (!pathExists(Path.join(dir, "script.json"))) return null
  return readScriptMeta(dir).version ?? null
}

/**
 * 读取云端 .scripting 包内的版本号：下载（Contents API + raw accept，公开仓库匿名即可，配置过 Token 则带上）
 * → 解压到临时目录 → 找 script.json 读 version。失败（下载/解压/解析）返回 null。
 */
export async function fetchChannelCloudVersion(
  url: string,
  remotePath: string
): Promise<string | null> {
  try {
    const norm = normalizeRepoUrl(url)
    if (!norm) return null
    const parts = norm.replace(/^https?:\/\/github\.com\//i, "").split("/")
    if (parts.length !== 2) return null
    const [owner, repo] = parts
    const gh = resolveGithubConfig()
    const token = gh.publishToken || gh.backupToken || gh.token || ""
    const headers: Record<string, string> = {
      Accept: "application/vnd.github.raw",
      "X-GitHub-Api-Version": "2022-11-28",
    }
    if (token) headers.Authorization = `Bearer ${token}`
    const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${remotePath
      .split("/")
      .map(encodeURIComponent)
      .join("/")}`
    const res = await fetch(apiUrl, { headers })
    if (!res.ok) return null
    const bytes = await res.bytes()
    const staging = Path.join(
      FileManager.temporaryDirectory,
      `channel-cloud-${Date.now()}-${Math.floor(Math.random() * 10000)}`
    )
    FileManager.createDirectorySync(staging, true)
    try {
      const zipPath = Path.join(staging, "cloud.scripting")
      FileManager.writeAsBytesSync(zipPath, bytes)
      const inner = Path.join(staging, "inner")
      FileManager.createDirectorySync(inner, true)
      FileManager.unzipSync(zipPath, inner)
      const candidates = scanScriptDirsInTree(inner)
      if (candidates.length === 0) return null
      return readScriptMeta(candidates[0].sourcePath).version ?? null
    } finally {
      if (pathExists(staging)) {
        try { FileManager.removeSync(staging) } catch {}
      }
    }
  } catch {
    return null
  }
}

/**
 * 执行一次仓库监控全量检查：遍历所有监控仓库，拉取 .scripting 文件列表并对比基线快照。
 * 首次扫描（未建立基线）只记录快照不产生变化；之后新增/更新/删除都会记录到 changes。
 * 变化检测依赖 blob sha：文件内容变了 sha 就变，无需下载文件本体。
 * 调用方决定如何提示（应用内弹窗/系统通知）。
 */
export async function runChannelMonitorCheck(): Promise<ChannelCheckSummary> {
  const cfg = resolveConfig()
  if (!cfg.channelMonitorEnabled) {
    return { results: [], totalChanges: 0, newBaseline: false }
  }
  const links =
    Array.isArray(cfg.channelMonitorLinks) && cfg.channelMonitorLinks.length > 0
      ? cfg.channelMonitorLinks
      : DEFAULT_CHANNEL_MONITOR_LINKS
  const snapshots = { ...(cfg.channelMonitorSnapshots ?? {}) }
  const baselineReady = cfg.channelMonitorBaselineReady === true
  const results: ChannelCheckResult[] = []
  for (const link of links) {
    const snapshot = snapshots[link.url] ?? {}
    try {
      const files = await fetchChannelRepoScripts(link.url)
      const changes: ChannelChange[] = []
      for (const f of files) {
        const prevSha = snapshot[f.path]
        if (!baselineReady || prevSha == null) {
          // 未建立基线（首次扫描）不把全部文件当「新增」提示
          if (baselineReady) {
            changes.push({ type: "added", path: f.path, size: f.size, sha: f.sha })
          }
        } else if (prevSha !== f.sha) {
          changes.push({ type: "updated", path: f.path, size: f.size, sha: f.sha })
        }
      }
      // 更新快照（快照始终全量记录，排除关键词只影响提示与更新页，不影响基线对比）。
      // 已从仓库删除的文件不再提示（用户要求不显示「已从仓库删除」），快照更新时自然移除其路径。
      const next: Record<string, string> = {}
      for (const f of files) next[f.path] = f.sha
      snapshots[link.url] = next
      const kw = Array.isArray(cfg.channelMonitorExcludeKeywords)
        ? cfg.channelMonitorExcludeKeywords
        : []
      const ignoredPaths = new Set(
        Array.isArray(cfg.channelMonitorIgnoredPaths)
          ? cfg.channelMonitorIgnoredPaths
          : []
      )
      // 排除关键词过滤（名称命中关键词不提示）
      const notExcluded = changes.filter((c) => !isChannelScriptExcluded(c.path, kw))
      // 被「全部忽略」按路径忽略（同一脚本再发布新版本也不提示，直到在设置里恢复提醒）
      const ignored = notExcluded.filter((c) =>
        ignoredPaths.has(`${link.url}|${c.path}`)
      )
      const visibleChanges = notExcluded.filter(
        (c) => !ignoredPaths.has(`${link.url}|${c.path}`)
      )
      // 版本感知过滤：仅当本地同名脚本版本「高于」云端版本时不提示（如本地已先于仓库发布改了版本号）。
      // 版本相同但内容不同（.scripting 的 blob sha 已变，例如作者勾选「作者更新提示」重新发布、
      // 注入的更新说明检查代码使包内容变化而版本号未变，或同版本微调后重新发布）仍会正常提示——
      // 变化检测以 GitHub 的内容哈希（blob sha）为准，不单纯依赖版本号判断。
      // 快照仍全量记录（上方已更新），避免 sha 变化导致重复检测；下载/解析失败保守保留提示（fail-open）。
      const versionVisible: ChannelChange[] = []
      let versionFilteredCount = 0
      for (const c of visibleChanges) {
        const localVersion = localScriptVersionForChannelPath(c.path)
        const cloudVersion = await fetchChannelCloudVersion(link.url, c.path)
        // 把本地/云端版本号带进变化对象，供「可更新的脚本」页显示「旧版本 → 新版本」提示
        c.localVersion = localVersion ?? undefined
        c.cloudVersion = cloudVersion ?? undefined
        if (localVersion != null) {
          if (
            cloudVersion != null &&
            compareVersions(localVersion, cloudVersion) > 0
          ) {
            versionFilteredCount += 1
            continue
          }
        }
        versionVisible.push(c)
      }
      results.push({
        name: link.name,
        url: link.url,
        changes: versionVisible,
        scriptCount: files.length,
        ok: true,
        excludedCount: changes.length - notExcluded.length,
        ignoredCount: ignored.length,
        versionFilteredCount,
      })
    } catch (error) {
      results.push({
        name: link.name,
        url: link.url,
        changes: [],
        scriptCount: 0,
        ok: false,
        error: error instanceof Error ? error.message : String(error),
      })
    }
  }
  const newBaseline = !baselineReady
  if (newBaseline) {
    updateChannelMonitorConfig({
      channelMonitorSnapshots: snapshots,
      channelMonitorBaselineReady: true,
    })
  } else {
    updateChannelMonitorConfig({ channelMonitorSnapshots: snapshots })
  }
  const totalChanges = results.reduce((n, r) => n + r.changes.length, 0)
  const summary: ChannelCheckSummary = { results, totalChanges, newBaseline }
  saveLastChannelCheck(summary)
  return summary
}

/**
 * 发布成功后把刚发布的文件吸收进仓库监控基线快照：
 * 仅当本次发布未勾选「作者提示」时调用——作者自己发布脚本会改变仓库里 .scripting 的 blob sha，
 * 若不吸收基线，仓库监控（默认就监控作者自己的发布仓库）会把这次发布当成「有更新」并自动弹出更新页/通知，
 * 即「不勾选作者提示却依然收到更新提示」。
 * 只更新与发布仓库（owner/repo）匹配的监控链接中、本次发布文件路径的快照；其它仓库/文件的变化不受影响。
 * GitHub API 可能尚未传播刚上传的 sha：若目标文件都没取到与旧基线不同的新 sha，稍等后重试一次；
 * 拉取失败静默跳过，不阻断发布流程。
 */
export async function absorbPublishedIntoChannelBaseline(
  owner: string,
  repo: string,
  dir: string,
  folderNames: string[]
): Promise<void> {
  const names = Array.isArray(folderNames) ? folderNames.filter(Boolean) : []
  if (!owner || !repo || names.length === 0) return
  const cfg = resolveConfig()
  const links = Array.isArray(cfg.channelMonitorLinks)
    ? cfg.channelMonitorLinks
    : []
  if (links.length === 0) return
  const dirPrefix = String(dir ?? "").trim().replace(/^\/+|\/+$/g, "")
  const targetPaths = names.map((n) => {
    const zipName = `${safeFileName(n)}.scripting`
    return dirPrefix ? `${dirPrefix}/${zipName}` : zipName
  })
  const snapshots = { ...(cfg.channelMonitorSnapshots ?? {}) }
  let updated = false
  for (const link of links) {
    const norm = normalizeRepoUrl(link.url)
    if (!norm) continue
    const parts = norm.replace(/^https?:\/\/github\.com\//i, "").split("/")
    if (parts.length < 2) continue
    if (
      parts[0].toLowerCase() !== String(owner).toLowerCase() ||
      parts[1].toLowerCase() !== String(repo).toLowerCase()
    ) {
      continue
    }
    const prev = { ...(snapshots[link.url] ?? {}) }
    let files: ChannelRepoFile[] = []
    try {
      files = await fetchChannelRepoScripts(link.url)
    } catch {
      continue
    }
    // GitHub API 可能尚未传播刚上传的 sha：目标文件都没取到新 sha 时稍等重试一次
    const freshEnough = targetPaths.some((p) => {
      const f = files.find((x) => x.path === p)
      return f != null && !!f.sha && f.sha !== prev[p]
    })
    if (!freshEnough) {
      try {
        await new Promise<void>((r) => setTimeout(() => r(), 2000))
        files = await fetchChannelRepoScripts(link.url)
      } catch {
        // 重试失败按首次结果处理（能吸收多少吸收多少）
      }
    }
    let changed = false
    for (const p of targetPaths) {
      const f = files.find((x) => x.path === p)
      if (f && f.sha) {
        prev[p] = f.sha
        changed = true
      }
    }
    if (changed) {
      snapshots[link.url] = prev
      updated = true
    }
  }
  if (updated) {
    updateChannelMonitorConfig({ channelMonitorSnapshots: snapshots })
  }
}

// ==================== 仓库监控：最近检查结果持久化 ====================

const CHANNEL_LAST_CHECK_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "channel-monitor-last-check.json"
)

// 最近一次「有更新」的检查结果单独缓存：last-check 会在每次定时检查（含无更新的）时被覆盖，
// 若长按重开更新页读 last-check，几分钟内就会被无更新的检查结果冲掉。
// 这个文件只在检测到更新（弹更新页/发通知）时写入，供 5 分钟内长按右上角图标再次打开更新页。
const CHANNEL_LAST_UPDATE_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "channel-monitor-last-update.json"
)

/** 最近一次仓库监控检查结果（供通知点击后打开更新页使用） */
export type ChannelLastCheck = {
  /** 检查完成时间戳（毫秒） */
  checkedAt: number
  summary: ChannelCheckSummary
}

/** 持久化最近一次仓库监控检查结果 */
export function saveLastChannelCheck(summary: ChannelCheckSummary) {
  try {
    const data: ChannelLastCheck = { checkedAt: Date.now(), summary }
    FileManager.writeAsStringSync(
      CHANNEL_LAST_CHECK_PATH,
      JSON.stringify(data)
    )
  } catch {
    // ignore
  }
}

/** 读取最近一次仓库监控检查结果；没有或读取失败返回 null */
export function readLastChannelCheck(): ChannelLastCheck | null {
  try {
    if (!pathExists(CHANNEL_LAST_CHECK_PATH)) return null
    const raw = JSON.parse(
      FileManager.readAsStringSync(CHANNEL_LAST_CHECK_PATH)
    ) as Partial<ChannelLastCheck>
    if (!raw || !raw.summary || !Array.isArray(raw.summary.results)) {
      return null
    }
    return {
      checkedAt: typeof raw.checkedAt === "number" ? raw.checkedAt : 0,
      summary: raw.summary as ChannelCheckSummary,
    }
  } catch {
    return null
  }
}

/** 持久化最近一次「有更新」的检查结果（弹更新页/发通知时调用，无更新检查不会覆盖） */
export function saveLastChannelUpdate(summary: ChannelCheckSummary) {
  try {
    const data: ChannelLastCheck = { checkedAt: Date.now(), summary }
    FileManager.writeAsStringSync(
      CHANNEL_LAST_UPDATE_PATH,
      JSON.stringify(data)
    )
  } catch {
    // ignore
  }
}

/** 读取最近一次「有更新」的检查结果；没有或读取失败返回 null */
export function readLastChannelUpdate(): ChannelLastCheck | null {
  try {
    if (!pathExists(CHANNEL_LAST_UPDATE_PATH)) return null
    const raw = JSON.parse(
      FileManager.readAsStringSync(CHANNEL_LAST_UPDATE_PATH)
    ) as Partial<ChannelLastCheck>
    if (!raw || !raw.summary || !Array.isArray(raw.summary.results)) {
      return null
    }
    return {
      checkedAt: typeof raw.checkedAt === "number" ? raw.checkedAt : 0,
      summary: raw.summary as ChannelCheckSummary,
    }
  } catch {
    return null
  }
}

/**
 * 清除最近检查结果中的 removed 记录：用户已在更新页看到「已从仓库删除」，
 * 下次打开更新页不再重复显示（不重新检查，仅移除持久化结果里的 removed 条目）。
 */
export function dismissChannelRemoved() {
  try {
    const last = readLastChannelCheck()
    if (!last) return
    let removedCount = 0
    const results = last.summary.results.map((r) => ({
      ...r,
      changes: r.changes.filter((c) => {
        if (c.type === "removed") {
          removedCount += 1
          return false
        }
        return true
      }),
    }))
    if (removedCount === 0) return
    const totalChanges = results.reduce((n, r) => n + r.changes.length, 0)
    saveLastChannelCheck({ ...last.summary, results, totalChanges })
  } catch {
    // ignore
  }
}

/**
 * 全部忽略：清零最近检查结果（totalChanges → 0）。
 * 配合 channelMonitorNotifiedSig 持久化签名，用户点「全部忽略」后：
 * ① 监控循环同一批变化不再提示/弹更新页；
 * ② 通知点击路径读到 totalChanges=0，也不会再重新打开更新页。
 */
export function dismissChannelUpdates() {
  try {
    const last = readLastChannelCheck()
    if (!last) return
    const results = last.summary.results.map((r) => ({
      ...r,
      changes: [] as ChannelChange[],
    }))
    saveLastChannelCheck({
      ...last.summary,
      results,
      totalChanges: 0,
    })
  } catch {
    // ignore
  }
  // 全部忽略后清掉「有更新」缓存：长按重开更新页不应再打开这批已被忽略的更新
  try {
    if (pathExists(CHANNEL_LAST_UPDATE_PATH)) {
      FileManager.removeSync(CHANNEL_LAST_UPDATE_PATH)
    }
  } catch {
    // ignore
  }
}

// ==================== 仓库监控：更新脚本 ====================

/** 解析仓库链接为 { owner, repo }；解析失败返回 null */
export function repoParts(
  url: string
): { owner: string; repo: string } | null {
  const norm = normalizeRepoUrl(url)
  if (!norm) return null
  const parts = norm.replace(/^https?:\/\/github\.com\//i, "").split("/")
  if (parts.length !== 2 || !parts[0] || !parts[1]) return null
  return { owner: parts[0], repo: parts[1] }
}

/**
 * 生成仓库内某个文件的 raw 下载地址（https://raw.githubusercontent.com/…）。
 * 依次尝试 main → master 分支，找到能下载的分支即返回；找不到返回 null。
 */
export async function resolveRawScriptUrl(
  url: string,
  filePath: string
): Promise<string | null> {
  const parts = repoParts(url)
  if (!parts) return null
  for (const branch of ["main", "master"]) {
    const rawUrl = `https://raw.githubusercontent.com/${parts.owner}/${parts.repo}/${branch}/${filePath}`
    try {
      const r = await fetch(rawUrl, { method: "HEAD" })
      if (r.status === 200) {
        return rawUrl
      }
    } catch {
      // 继续尝试下一个分支
    }
  }
  return null
}

/**
 * 生成仓库内某个文件的一次性 raw 下载地址：用分支最新 commit sha 作 ref
 * （形如 https://raw.githubusercontent.com/{owner}/{repo}/{commitSha}/{path}）。
 *
 * 为什么不用分支 raw 链接：GitHub raw CDN 的缓存键忽略 query string（实测 ?t= 无效），
 * 且 Cache-Control: max-age=300（最多缓存 5 分钟）。仓库监控检测（Contents API）是实时的，
 * 但发布后分支 raw 链接在缓存窗口内仍返回旧包，从「可更新的脚本」页导入会装成低一个版本。
 * commit sha 每次发布都不同，生成的 URL 全局唯一，CDN 必然回源拿到该 commit 的最新内容，
 * 因此导入的版本号一定与检测到的一致。
 *
 * 依次尝试 main → master 分支：HEAD 探测文件存在 → branches API 取最新 commit sha。
 * 失败（网络/API 限流/解析失败）返回 null，调用方可回退到 resolveRawScriptUrl。
 */
export async function resolveFreshRawScriptUrl(
  url: string,
  filePath: string
): Promise<string | null> {
  const parts = repoParts(url)
  if (!parts) return null
  const gh = resolveGithubConfig()
  const token = gh.publishToken || gh.backupToken || gh.token || ""
  for (const branch of ["main", "master"]) {
    try {
      const probe = `https://raw.githubusercontent.com/${parts.owner}/${parts.repo}/${branch}/${filePath}`
      const r = await fetch(probe, { method: "HEAD" })
      if (r.status !== 200) continue
      const { status, data } = await githubHttp(
        `https://api.github.com/repos/${parts.owner}/${parts.repo}/branches/${encodeURIComponent(
          branch
        )}`,
        {
          headers: {
            Accept: "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
        }
      )
      if (status !== 200) return null
      const sha = data?.commit?.sha
      if (typeof sha === "string" && sha) {
        return `https://raw.githubusercontent.com/${parts.owner}/${parts.repo}/${sha}/${filePath}`
      }
      return null
    } catch {
      // 继续尝试下一个分支
    }
  }
  return null
}

/** 校验 GitHub Token 是否有效，返回登录名 */
export async function githubVerify(token: string): Promise<string> {
  const { status, data } = await githubHttp(
    "https://api.github.com/user",
    {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github+json",
      },
    }
  )
  if (status !== 200) {
    throw new Error(`GitHub Token 无效 (${status}): ${data?.message || ""}`)
  }
  return data.login as string
}

/**
 * 确保仓库存在：不存在时自动创建（默认公开）。
 * 通过 GET /repos/{owner}/{repo} 判断，404 时 POST /user/repos 创建。
 * 返回 { empty, confirmed }：empty=仓库是否为空；confirmed=是否成功查到分支状态（非猜测）。
 *
 * 注意：POST /user/repos 返回 422 通常意味着仓库名已被占用（仓库已存在），
 * 此时视为仓库存在且非空，直接继续上传流程。
 */
export async function ensureGithubRepo(
  token: string,
  owner: string,
  repo: string,
  isPrivate: boolean = false
): Promise<{ empty: boolean; confirmed: boolean }> {
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  let repoExists = false

  const check = await githubHttp(
    `https://api.github.com/repos/${owner}/${repo}`,
    { headers }
  )
  if (check.status === 200) {
    repoExists = true
  }
  // GET 返回 403/404 可能是 token 无读私有仓库权限
  // 无法判断 → 先尝试上传，上传失败再报错

  if (!repoExists) {
    // 仓库可能不存在 → 尝试创建
    const created = await githubHttp(
      "https://api.github.com/user/repos",
      {
        method: "POST",
        headers,
        body: JSON.stringify({
          name: repo,
          private: isPrivate,
          auto_init: true,
          description: isPrivate
            ? "脚本管理工具自动创建的私密备份仓库"
            : "脚本管理工具自动创建的公开发布仓库",
        }),
      }
    )
    if (created.status === 201) {
      // 创建成功 → auto_init 已初始化，非空
      return { empty: false, confirmed: true }
    }
    if (created.status === 422) {
      // 422 = 仓库名已被占用（已存在），视为已存在，继续
      repoExists = true
    } else {
      throw new Error(
        `自动创建仓库 ${owner}/${repo} 失败 (${created.status}): ${created.data?.message || ""}`
      )
    }
  }

  // 仓库已存在：尝试检查分支判断是否为空
  try {
    const branches = await githubHttp(
      `https://api.github.com/repos/${owner}/${repo}/branches`,
      { headers }
    )
    if (branches.status === 200 && Array.isArray(branches.data)) {
      return { empty: branches.data.length === 0, confirmed: true }
    }
  } catch {
    // fall through
  }
  // 无法确认分支状态（无读权限）→ 返回 confirmed=false，上传时不指定 branch
  return { empty: false, confirmed: false }
}

const LARGE_FILE_LIMIT = 1024 * 1024 // Contents API 单文件上限约 1MB

/**
 * 当 zip > 1MB 时改用 Git Data API（blob+tree+commit）上传，
 * 规避 Contents API PUT 的 1MB 限制（最大支持 ~100MB base64）。
 */
async function gitPushLarge(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  remotePath: string,
  localPath: string,
  skipBranch: boolean
): Promise<string> {
  const base64 = (Data.fromFile(localPath) as Data).toBase64String()
  const apiBase = `https://api.github.com/repos/${owner}/${repo}`
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }

  // 1. 创建 blob
  const blobRes = await githubHttp(`${apiBase}/git/blobs`, {
    method: "POST",
    headers,
    body: JSON.stringify({ content: base64, encoding: "base64" }),
  })
  if (blobRes.status !== 201) {
    throw new Error(`创建 blob 失败 (${blobRes.status}): ${blobRes.data?.message || ""}`)
  }
  const blobSha = blobRes.data.sha as string

  if (skipBranch || !branch.trim()) {
    // 空仓库：创建 tree + commit + ref
    const treeRes = await githubHttp(`${apiBase}/git/trees`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        tree: [{ path: remotePath, mode: "100644", type: "blob", sha: blobSha }],
      }),
    })
    if (treeRes.status !== 201) {
      throw new Error(`创建 tree 失败 (${treeRes.status}): ${treeRes.data?.message || ""}`)
    }
    const commitRes = await githubHttp(`${apiBase}/git/commits`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        message: `Add ${remotePath}`,
        tree: treeRes.data.sha,
      }),
    })
    if (commitRes.status !== 201) {
      throw new Error(`创建 commit 失败 (${commitRes.status}): ${commitRes.data?.message || ""}`)
    }
    await githubHttp(`${apiBase}/git/refs`, {
      method: "POST",
      headers,
      body: JSON.stringify({ ref: "refs/heads/main", sha: commitRes.data.sha }),
    })
    return `https://raw.githubusercontent.com/${owner}/${repo}/main/${remotePath}`
  }

  // 已有分支：读当前 commit → tree → 创建新 tree → commit → 更新 ref
  const refRes = await githubHttp(`${apiBase}/git/refs/heads/${branch}`, {
    headers,
  })
  if (refRes.status !== 200) {
    throw new Error(`读取分支 ref 失败 (${refRes.status}): ${refRes.data?.message || ""}`)
  }
  const commitSha = (refRes.data.object as any).sha as string
  const commitRes = await githubHttp(`${apiBase}/git/commits/${commitSha}`, {
    headers,
  })
  const treeSha = commitRes.data.tree.sha as string

  const newTreeRes = await githubHttp(`${apiBase}/git/trees`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      base_tree: treeSha,
      tree: [{ path: remotePath, mode: "100644", type: "blob", sha: blobSha }],
    }),
  })
  if (newTreeRes.status !== 201) {
    throw new Error(`创建 tree 失败 (${newTreeRes.status}): ${newTreeRes.data?.message || ""}`)
  }

  const newCommitRes = await githubHttp(`${apiBase}/git/commits`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      message: `Add ${remotePath}`,
      tree: newTreeRes.data.sha,
      parents: [commitSha],
    }),
  })
  if (newCommitRes.status !== 201) {
    throw new Error(`创建 commit 失败 (${newCommitRes.status}): ${newCommitRes.data?.message || ""}`)
  }

  const updateRefRes = await githubHttp(`${apiBase}/git/refs/heads/${branch}`, {
    method: "PATCH",
    headers,
    body: JSON.stringify({ sha: newCommitRes.data.sha, force: false }),
  })
  if (updateRefRes.status !== 200) {
    throw new Error(`更新 ref 失败 (${updateRefRes.status}): ${updateRefRes.data?.message || ""}`)
  }

  return `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${remotePath}`
}

/**
 * 把 zip 二进制内容通过 Contents API 上传到 GitHub 仓库。
 * < 1MB 用 Contents API PUT（快速）；>= 1MB 用 Git Data API（支持大文件）。
 * 返回 raw 下载链接。
 */
async function githubPushZip(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  dir: string,
  remotePath: string,
  zipPath: string,
  skipBranch: boolean = false
): Promise<string> {
  const size = statSize(zipPath)

  // >= 1MB：使用 Git Data API 上传大文件
  if (size >= LARGE_FILE_LIMIT) {
    return gitPushLarge(token, owner, repo, branch, remotePath, zipPath, skipBranch)
  }

  // < 1MB：Contents API（原有快速路径）
  const base64 = (Data.fromFile(zipPath) as Data).toBase64String()
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${remotePath}`

  // 先 GET 检查文件是否已存在，拿到 sha 才能覆盖
  let sha: string | undefined
  const existing = await githubHttp(url, {
    headers: {
      Authorization: headers.Authorization,
      Accept: headers.Accept,
    },
  })
  if (existing.status === 200 && existing.data?.sha) {
    sha = existing.data.sha
  } else if (existing.status !== 404) {
    // 仓库不存在等错误：交给上层 ensureGithubRepo 处理，这里允许 404（文件不存在）
  }

  const body: any = {
    message: sha ? `Update ${remotePath}` : `Add ${remotePath}`,
    content: base64,
  }
  if (sha) {
    body.sha = sha
  }
  // skipBranch=true 时：空仓库没有分支，不能指定 branch（GitHub 会自动创建默认分支）
  if (!skipBranch && branch.trim()) {
    body.branch = branch.trim()
  }

  const { status, data } = await githubHttp(url, {
    method: "PUT",
    headers,
    body: JSON.stringify(body),
  })
  if (status !== 200 && status !== 201) {
    const hint = status === 422
      ? "（可能是仓库为空或文件过大，已自动处理空仓库；若仍失败请检查 Token 是否有 repo 权限、文件名是否合法）"
      : ""
    throw new Error(`推送 ${remotePath} 失败 (${status}): ${data?.message || ""}${hint}`)
  }

  const branchName = (skipBranch ? "main" : branch.trim()) || "main"
  // remotePath 已包含目录前缀，直接拼接；与 gitPushLarge 的 raw 链接保持一致
  return `https://raw.githubusercontent.com/${owner}/${repo}/${branchName}/${remotePath}`
}

/** 更新脚本 script.json 里的 remoteResource（更新链接），hash 为 zip 包的 MD5。
 *  autoUpdateInterval 缺省时只保留链接、不开启自动更新（开关保持关闭）。 */
export function updateScriptRemoteResource(
  script: ScriptInfo,
  url: string,
  hash: string,
  autoUpdateInterval?: number
): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  obj.remoteResource = {
    url,
    hash,
    ...(autoUpdateInterval != null ? { autoUpdateInterval } : {}),
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/** 计算 zip 包的 MD5（Scripting 更新链接的 hash 字段） */
export function zipMd5(zipPath: string): string {
  const data = Data.fromFile(zipPath)
  if (!data) {
    throw new Error("无法读取文件内容")
  }
  return Crypto.md5(data).toHexString()
}

/**
 * 发布前给 script.json 补齐作者名：仅当脚本原本没写作者（author 缺失或为空）
 * 且提供了作者名时写入；已有作者或未提供作者名时不动。
 * 解析/写入失败静默跳过，不阻断发布主流程。
 */
export function ensureScriptAuthor(script: ScriptInfo, authorName: string): void {
  const name = authorName?.trim()
  if (!name) return
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) return
  try {
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    if (typeof obj !== "object" || obj === null) return
    if (extractAuthor(obj)) return // 已写作者，不改
    // 与 Scripting 原生 script.json 的 author 对象格式保持一致
    obj.author = { name, email: null, homepage: null }
    FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
  } catch {
    // 解析/写入失败不阻断发布
  }
}

/**
 * 把选中的脚本逐个发布（打包 .scripting → 上传 GitHub → 同步 remoteResource）。
 * 仓库不存在时自动创建（默认公开）。
 * 发布前先把更新链接写入 script.json 再打包，确保发布的 zip 自带 remoteResource，
 * 安装方即可获得自动更新链接；上传成功后本机 hash 修正为本次 zip 的真实 MD5。
 * opts.autoUpdate=false 时发布包不携带 autoUpdateInterval（安装方不自动检测更新，仅可手动检查）。
 * 返回每个脚本的 raw 链接。
 */
export async function publishScriptsToGithub(
  scripts: ScriptInfo[],
  config: GithubConfig,
  opts?: { autoUpdate?: boolean }
): Promise<Array<{ folderName: string; url: string; zipPath: string }>> {
  if (!isGithubConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 发布配置（Token/所有者/仓库名）")
  }
  // 首次使用自动创建发布仓库（默认公开）；拿到仓库状态
  const repoState = await ensureGithubRepo(config.token, config.owner, config.repo, false)
  const skipBranch = !repoState.confirmed || repoState.empty

  const results: Array<{ folderName: string; url: string; zipPath: string }> = []
  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-publish-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const dir = config.path.trim().replace(/^\/+|\/+$/g, "")
  try {
    for (let i = 0; i < scripts.length; i++) {
      const script = scripts[i]
      const zipName = `${safeFileName(script.folderName)}.scripting`
      const remotePath = dir ? `${dir}/${zipName}` : zipName
      const branchName = (skipBranch ? "main" : config.branch.trim()) || "main"
      // 发布链接带时间戳参数：GitHub raw 有 CDN 缓存（发布后几分钟内仍返回旧包），
      // 每次发布用新的 ?t= 穿透缓存，保证 Scripting 自动更新/手动导入拿到的永远是本次最新包
      const url = `https://raw.githubusercontent.com/${config.owner}/${config.repo}/${branchName}/${remotePath}?t=${Date.now()}`
      const zipPath = Path.join(staging, zipName)
      // 先把更新链接写进 script.json 再打包：确保发布的 zip 自带 remoteResource，
      // 别人安装后即可获得自动更新链接。首次发布 hash 为空占位，后续用上一次的 hash。
      // 记录原始 remoteResource，上传失败时恢复，避免本机留下失效链接。
      const prev = getScriptRemoteResource(script)
      // 设置页填了用户名时，给原本没写作者的脚本补齐作者名（写了/没填用户名则不动）
      ensureScriptAuthor(script, resolveConfig().authorName)
      // 打包前按发布勾选决定是否给安装方开启自动检测更新：
      // 勾选（默认）→ 内嵌 autoUpdateInterval=3600，安装方会自动检测到更新；
      // 不勾选 → 不带 autoUpdateInterval（保留 url/hash），安装方仅可手动检查更新时发现。
      updateScriptRemoteResource(
        script,
        url,
        prev?.hash ?? "",
        opts?.autoUpdate === false ? undefined : 3600
      )
      try {
        await FileManager.zip(script.path, zipPath, true)
        await githubPushZip(
          config.token,
          config.owner,
          config.repo,
          config.branch,
          dir,
          remotePath,
          zipPath,
          skipBranch
        )
      } catch (error) {
        if (prev) {
          // 严格恢复原状：interval 原来没有就不补，避免失败回滚把开关打开
          updateScriptRemoteResource(script, prev.url, prev.hash ?? "", prev.autoUpdateInterval)
        } else {
          // 之前没有更新链接：彻底移除，恢复原状（不留失效链接）
          clearScriptRemoteResource(script)
        }
        throw error
      }
      // 上传成功后，把本机 script.json 的 hash 修正为本次 zip 的真实 MD5；
      // interval 沿用发布前的状态（之前没开自动更新就不开），避免“突然自动打开开关”。
      // 注意：zip 在打包时已内嵌 autoUpdateInterval=3600，下载方导入后自动更新默认开启。
      const hash = zipMd5(zipPath)
      updateScriptRemoteResource(script, url, hash, prev?.autoUpdateInterval)
      results.push({ folderName: script.folderName, url, zipPath })
    }
    return results
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

/**
 * 列出 GitHub 私密备份仓库 backupPath 目录下的所有 zip 备份文件。
 * 通过 Contents API 读取目录列表，仅返回 .zip 文件，按名称倒序。
 */
export async function listGithubBackups(
  config: GithubConfig
): Promise<{ name: string; path: string; size: number }[]> {
  if (!isGithubBackupConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 备份配置（Token/所有者/备份仓库名）")
  }
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const dir = config.backupPath.trim().replace(/^\/+|\/+$/g, "")
  const url = dir
    ? `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${dir
        .split("/")
        .map(encodeURIComponent)
        .join("/")}`
    : `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents`
  const res = await githubHttp(url, { headers })
  if (res.status !== 200) {
    throw new Error(
      `读取备份仓库失败 (${res.status}): ${res.data?.message || res.text || ""}`
    )
  }
  const list = Array.isArray(res.data) ? res.data : []
  return list
    .filter(
      (item: any) =>
        item &&
        item.type === "file" &&
        item.name &&
        (item.name.toLowerCase().endsWith(".zip") ||
          item.name.toLowerCase().endsWith(".scripting"))
    )
    .map((item: any) => ({
      name: item.name as string,
      path: item.path as string,
      size: (item.size as number) || 0,
    }))
    .sort((a, b) => b.name.localeCompare(a.name))
}

/**
 * 备份按时间倒序（最新备份在最上面）：
 * 优先取 manifest 记录的上传时间；没有记录时尝试解析文件名里的 YYYYMMDD_HHMMSS 时间编号；
 * 都拿不到就回退到按名称倒序（与 listGithubBackups 默认一致）。
 */
export function sortGithubBackupsByTime(
  list: { name: string; path: string; size: number }[],
  manifest: GithubBackupManifest | null
): { name: string; path: string; size: number }[] {
  function timeOf(item: { name: string; path: string }): number {
    const meta = manifest?.backups[item.path]
    if (meta && typeof meta.createdAt === "number" && Number.isFinite(meta.createdAt)) {
      return meta.createdAt
    }
    // 文件名中的 YYYYMMDD_HHMMSS 时间编号（timestampForName 格式，如 前缀_20260814_041023）
    const m = item.name.match(/(\d{8})_(\d{6})/)
    if (m) {
      const day = m[1]
      const time = m[2]
      const ts = new Date(
        Number(day.slice(0, 4)),
        Number(day.slice(4, 6)) - 1,
        Number(day.slice(6, 8)),
        Number(time.slice(0, 2)),
        Number(time.slice(2, 4)),
        Number(time.slice(4, 6))
      ).getTime()
      if (!Number.isNaN(ts)) {
        return ts
      }
    }
    return 0
  }
  return [...list].sort((a, b) => {
    const ta = timeOf(a)
    const tb = timeOf(b)
    if (ta !== tb) {
      return tb - ta
    }
    return b.name.localeCompare(a.name)
  })
}

/**
 * 从 GitHub 私密备份仓库下载指定 zip 到临时目录，返回本地 zip 路径。
 * 私有仓库的 raw.githubusercontent.com 不接受 Authorization，
 * 改用 Contents API + Accept: application/vnd.github.raw 获取原始内容。
 */
export async function downloadGithubBackup(
  config: GithubConfig,
  remotePath: string
): Promise<string> {
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github.raw",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${remotePath
    .split("/")
    .map(encodeURIComponent)
    .join("/")}`
  const res = await fetch(url, { headers })
  if (!res.ok) {
    throw new Error(`下载备份失败 (${res.status}): ${remotePath}`)
  }
  const bytes = await res.bytes()
  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-restore-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const localPath = Path.join(staging, Path.basename(remotePath) || "backup.zip")
  FileManager.writeAsBytesSync(localPath, bytes)
  return localPath
}

/**
 * 删除 GitHub 备份仓库中的指定 zip（通过 Contents API）。
 */
export async function deleteGithubBackup(
  config: GithubConfig,
  remotePath: string
): Promise<void> {
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${remotePath
    .split("/")
    .map(encodeURIComponent)
    .join("/")}`
  const get = await githubHttp(url, { headers })
  if (get.status !== 200) {
    throw new Error(
      `读取待删除文件失败 (${get.status}): ${get.data?.message || get.text || ""}`
    )
  }
  const sha = get.data?.sha as string
  if (!sha) {
    throw new Error("无法获取文件 sha，删除失败")
  }
  const del = await githubHttp(url, {
    method: "DELETE",
    headers,
    body: JSON.stringify({ message: "删除备份", sha }),
  })
  if (del.status !== 200) {
    throw new Error(
      `删除失败 (${del.status}): ${del.data?.message || del.text || ""}`
    )
  }
  // 同步从 manifest 移除条目（失败不影响删除本身）
  try {
    await removeFromGithubBackupManifest(config, remotePath)
  } catch (e) {
    logError("Github备份元数据", e)
  }
}

/**
 * 下载一个或多个 GitHub 备份 zip 到临时目录并调起系统分享面板，完成后清理临时目录。
 */
export async function shareGithubBackups(
  config: GithubConfig,
  items: { name: string; path: string; size: number }[]
): Promise<void> {
  if (items.length === 0) {
    return
  }
  const downloaded: string[] = []
  try {
    for (const item of items) {
      downloaded.push(await downloadGithubBackup(config, item.path))
    }
    await ShareSheet.present(downloaded)
  } finally {
    for (const zipPath of downloaded) {
      const dir = Path.dirname(zipPath)
      if (pathExists(dir)) {
        try {
          FileManager.removeSync(dir)
        } catch {
          // ignore
        }
      }
    }
  }
}

/**
 * 重命名 GitHub 备份 zip：下载旧文件 → 上传到新路径 → 删除旧路径 → 迁移 manifest 条目。
 * GitHub Contents API 没有 rename 接口，因此用「下载-上传-删除」实现。
 */
export async function renameGithubBackup(
  config: GithubConfig,
  item: { name: string; path: string; size: number },
  newName: string
): Promise<void> {
  if (!isGithubBackupConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 备份配置（Token/所有者/备份仓库名）")
  }
  const clean = newName.trim()
  if (!clean) {
    throw new Error("名称不能为空")
  }
  if (/[\/\\:]/.test(clean)) {
    throw new Error("名称不能包含 / \\ : 字符")
  }
  const safe = safeFileName(clean) || "备份"
  const ext = item.name.toLowerCase().endsWith(".scripting") ? ".scripting" : ".zip"
  const dir = config.backupPath.trim().replace(/^\/+|\/+$/g, "")
  const newRemotePath = dir ? `${dir}/${safe}${ext}` : `${safe}${ext}`
  if (newRemotePath === item.path) {
    return
  }
  // 先确认新路径不存在（防止覆盖已有备份）
  const existing = await listGithubBackups(config)
  if (existing.some((b) => b.path === newRemotePath)) {
    throw new Error(`已存在同名备份「${clean}」`)
  }
  // 保留旧 manifest 条目的脚本数与创建时间，重命名后迁移到新路径
  const manifest = await readGithubBackupManifest(config)
  const oldMeta = manifest?.backups[item.path]

  const zipPath = await downloadGithubBackup(config, item.path)
  try {
    const repoState = await ensureGithubRepo(config.token, config.owner, config.backupRepo, true)
    const skipBranch = !repoState.confirmed || repoState.empty
    await githubPushZip(
      config.token,
      config.owner,
      config.backupRepo,
      config.backupBranch,
      dir,
      newRemotePath,
      zipPath,
      skipBranch
    )
    // 删除旧文件（内部会自动移除旧 manifest 条目）
    await deleteGithubBackup(config, item.path)
    // 若有旧元数据，写入新路径（脚本数/创建时间/名单保持不变）
    if (oldMeta) {
      try {
        await updateGithubBackupManifest(
          config,
          newRemotePath,
          `${safe}${ext}`,
          oldMeta.scriptCount,
          oldMeta.createdAt,
          oldMeta.scripts
        )
      } catch (e) {
        logError("Github备份元数据", e)
      }
    }
  } finally {
    const dirPath = Path.dirname(zipPath)
    if (pathExists(dirPath)) {
      try {
        FileManager.removeSync(dirPath)
      } catch {
        // ignore
      }
    }
  }
}

// ==================== GitHub 仓库文件管理（发布/备份仓库通用） ====================

/** 仓库里的一个文件（.scripting / .zip 已过滤） */
export type GithubRepoFile = { name: string; path: string; size: number }

/** 仓库操作参数：token/owner/repo/branch/dir 均为解析后的实际生效值 */
export type GithubRepoParams = {
  token: string
  owner: string
  repo: string
  branch: string
  dir: string
}

/** 列出仓库某目录下的 .scripting / .zip 文件（Contents API 单层；dir 为空表示根目录），按名称升序 */
export async function listGithubRepoFiles(
  p: GithubRepoParams
): Promise<GithubRepoFile[]> {
  const headers = {
    Authorization: `Bearer ${p.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const dir = p.dir.trim().replace(/^\/+|\/+$/g, "")
  const url = dir
    ? `https://api.github.com/repos/${p.owner}/${p.repo}/contents/${dir
        .split("/")
        .map(encodeURIComponent)
        .join("/")}`
    : `https://api.github.com/repos/${p.owner}/${p.repo}/contents`
  const res = await githubHttp(url, { headers })
  if (res.status !== 200) {
    throw new Error(
      `读取仓库失败 (${res.status}): ${res.data?.message || res.text || ""}`
    )
  }
  const list = Array.isArray(res.data) ? res.data : []
  return list
    .filter(
      (item: any) =>
        item &&
        item.type === "file" &&
        item.name &&
        (item.name.toLowerCase().endsWith(".zip") ||
          item.name.toLowerCase().endsWith(".scripting"))
    )
    .map((item: any) => ({
      name: item.name as string,
      path: item.path as string,
      size: (item.size as number) || 0,
    }))
    .sort((a, b) => a.name.localeCompare(b.name))
}

/**
 * 获取仓库文件的最新修改时间戳（ms）。
 * GitHub Contents API 不返回文件时间，因此逐个文件查 commits API（path 过滤 + per_page=1），
 * 取最近一次相关 commit 的提交（committer）时间。单文件失败返回 null，调用方可跳过。
 */
export async function getGithubRepoFileModifiedAt(
  p: GithubRepoParams,
  filePath: string
): Promise<number | null> {
  const headers = {
    Authorization: `Bearer ${p.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const url = `https://api.github.com/repos/${p.owner}/${p.repo}/commits?path=${encodeURIComponent(
    filePath
  )}&per_page=1`
  try {
    const res = await githubHttp(url, { headers })
    if (res.status !== 200) {
      return null
    }
    const list = Array.isArray(res.data) ? res.data : []
    const date = list[0]?.commit?.committer?.date as string | undefined
    if (!date) {
      return null
    }
    const t = Date.parse(date)
    return Number.isFinite(t) ? t : null
  } catch {
    return null
  }
}

/** 批量获取仓库文件的最新修改时间（path → ms 时间戳）；失败的单个文件不包含在结果中 */
export async function getGithubRepoFilesModifiedAt(
  p: GithubRepoParams,
  files: GithubRepoFile[]
): Promise<Record<string, number>> {
  const map: Record<string, number> = {}
  await Promise.all(
    files.map(async (f) => {
      const t = await getGithubRepoFileModifiedAt(p, f.path)
      if (t != null) {
        map[f.path] = t
      }
    })
  )
  return map
}

/** 从仓库下载文件到临时目录（私有仓库走 Contents API + raw accept），返回本地文件路径 */
export async function downloadGithubRepoFile(
  p: GithubRepoParams,
  remotePath: string
): Promise<string> {
  const headers = {
    Authorization: `Bearer ${p.token}`,
    Accept: "application/vnd.github.raw",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const url = `https://api.github.com/repos/${p.owner}/${p.repo}/contents/${remotePath
    .split("/")
    .map(encodeURIComponent)
    .join("/")}`
  const res = await fetch(url, { headers })
  if (!res.ok) {
    throw new Error(`下载失败 (${res.status}): ${remotePath}`)
  }
  const bytes = await res.bytes()
  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-repo-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const localPath = Path.join(staging, Path.basename(remotePath) || "file")
  FileManager.writeAsBytesSync(localPath, bytes)
  return localPath
}

/** 删除仓库文件（Contents API：GET 拿 sha → DELETE） */
export async function deleteGithubRepoFile(
  p: GithubRepoParams,
  remotePath: string
): Promise<void> {
  const headers = {
    Authorization: `Bearer ${p.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  const url = `https://api.github.com/repos/${p.owner}/${p.repo}/contents/${remotePath
    .split("/")
    .map(encodeURIComponent)
    .join("/")}`
  const get = await githubHttp(url, { headers })
  if (get.status !== 200) {
    throw new Error(
      `读取待删除文件失败 (${get.status}): ${get.data?.message || get.text || ""}`
    )
  }
  const sha = get.data?.sha as string
  if (!sha) {
    throw new Error("无法获取文件 sha，删除失败")
  }
  const del = await githubHttp(url, {
    method: "DELETE",
    headers,
    body: JSON.stringify({ message: "删除文件", sha }),
  })
  if (del.status !== 200) {
    throw new Error(
      `删除失败 (${del.status}): ${del.data?.message || del.text || ""}`
    )
  }
}

/**
 * 重命名仓库文件：下载旧文件 → 上传到新路径 → 删除旧路径。
 * GitHub Contents API 没有 rename 接口，因此用「下载-上传-删除」实现。
 */
export async function renameGithubRepoFile(
  p: GithubRepoParams,
  item: GithubRepoFile,
  newName: string
): Promise<void> {
  const clean = newName.trim()
  if (!clean) {
    throw new Error("名称不能为空")
  }
  if (/[\/\\:]/.test(clean)) {
    throw new Error("名称不能包含 / \\ : 字符")
  }
  const safe = safeFileName(clean) || "文件"
  const ext = item.name.toLowerCase().endsWith(".scripting") ? ".scripting" : ".zip"
  const dir = p.dir.trim().replace(/^\/+|\/+$/g, "")
  const newRemotePath = dir ? `${dir}/${safe}${ext}` : `${safe}${ext}`
  if (newRemotePath === item.path) {
    return
  }
  // 先确认新路径不存在（防止覆盖已有文件）
  const existing = await listGithubRepoFiles(p)
  if (existing.some((f) => f.path === newRemotePath)) {
    throw new Error(`已存在同名文件「${clean}」`)
  }
  const localPath = await downloadGithubRepoFile(p, item.path)
  try {
    const repoState = await ensureGithubRepo(p.token, p.owner, p.repo, false)
    const skipBranch = !repoState.confirmed || repoState.empty
    await githubPushZip(
      p.token,
      p.owner,
      p.repo,
      p.branch,
      dir,
      newRemotePath,
      localPath,
      skipBranch
    )
    await deleteGithubRepoFile(p, item.path)
  } finally {
    const dirPath = Path.dirname(localPath)
    if (pathExists(dirPath)) {
      try {
        FileManager.removeSync(dirPath)
      } catch {
        // ignore
      }
    }
  }
}

/**
 * 把选中的脚本备份到 GitHub 私密备份仓库：单个脚本打包为 `.scripting`，多个脚本打包为一个 zip 上传（不更新 remoteResource）。
 * 备份仓库不存在时自动创建（私密）。返回 zip 的 raw 链接。
 */
export async function backupScriptsToGithub(
  scripts: ScriptInfo[],
  config: GithubConfig,
  zipName: string
): Promise<{ name: string; url: string; zipPath: string }> {
  if (!isGithubBackupConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 备份配置（Token/所有者/备份仓库名）")
  }
  // 首次使用自动创建备份仓库（私密）；拿到仓库状态
  const repoState = await ensureGithubRepo(config.token, config.owner, config.backupRepo, true)
  const skipBranch = !repoState.confirmed || repoState.empty

  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-backup-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const safe = safeFileName(zipName) || "GitHub备份"
  const ext = scripts.length === 1 ? ".scripting" : ".zip"
  const zipPath = Path.join(staging, `${safe}${ext}`)
  try {
    if (scripts.length === 1) {
      await FileManager.zip(scripts[0].path, zipPath, true)
    } else {
      const inner = Path.join(staging, "scripts")
      FileManager.createDirectorySync(inner, true)
      for (const script of scripts) {
        copyDirectory(script.path, Path.join(inner, script.folderName))
      }
      await FileManager.zip(inner, zipPath, false)
    }
    const dir = config.backupPath.trim().replace(/^\/+|\/+$/g, "")
    const remotePath = dir ? `${dir}/${safe}${ext}` : `${safe}${ext}`
    const url = await githubPushZip(
      config.token,
      config.owner,
      config.backupRepo,
      config.backupBranch,
      dir,
      remotePath,
      zipPath,
      skipBranch
    )
    // 备份成功后把脚本数与时间写入仓库根目录的 manifest（失败不影响备份本身）
    try {
      await updateGithubBackupManifest(
        config,
        remotePath,
        `${safe}${ext}`,
        scripts.length,
        Date.now(),
        scripts.map((s) => ({ name: s.folderName, version: s.version }))
      )
    } catch (e) {
      logError("Github备份元数据", e)
    }
    return { name: safe, url, zipPath }
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

/**
 * 把本地备份（zip/scripting 文件或未压缩目录）原样上传到 GitHub 备份仓库。
 * 恢复备份页「备份到Github」按钮复用：文件直接上传，目录先打包为 .zip；
 * 成功后把脚本数与时间写入仓库 manifest（失败不影响上传本身）。
 * scriptCount 可传页面已统计的脚本数（如缓存），缺省或 <=0 时现算。
 */
export async function uploadLocalBackupToGithub(
  item: BackupItem,
  config: GithubConfig,
  scriptCount?: number
): Promise<{ name: string; url: string }> {
  if (!isGithubBackupConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 备份配置（Token/所有者/备份仓库名）")
  }
  // 与备份脚本一致：首次使用自动创建备份仓库（私密）；拿到仓库状态
  const repoState = await ensureGithubRepo(config.token, config.owner, config.backupRepo, true)
  const skipBranch = !repoState.confirmed || repoState.empty

  // 压缩包扩展名：zip/scripting 文件保持原格式；未压缩目录统一打包为 .zip
  const lower = item.path.toLowerCase()
  const ext = item.isZip
    ? lower.endsWith(".scripting")
      ? ".scripting"
      : ".zip"
    : ".zip"
  const safe = safeFileName(item.name) || "GitHub备份"

  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-upload-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  let zipPath = item.path
  try {
    if (!item.isZip) {
      zipPath = Path.join(staging, `${safe}${ext}`)
      await FileManager.zip(item.path, zipPath, false)
    }
    const dir = config.backupPath.trim().replace(/^\/+|\/+$/g, "")
    const remotePath = dir ? `${dir}/${safe}${ext}` : `${safe}${ext}`
    const url = await githubPushZip(
      config.token,
      config.owner,
      config.backupRepo,
      config.backupBranch,
      dir,
      remotePath,
      zipPath,
      skipBranch
    )
    // 脚本数：优先用调用方传入的缓存值，缺失时现算（失败不影响上传）；写入 manifest
    let count = scriptCount && scriptCount > 0 ? scriptCount : item.scriptCount
    if (count <= 0) {
      try {
        count = computeBackupScriptCount(item)
      } catch {
        count = -1
      }
    }
    // 提取脚本名单（用于恢复页秒开列表；失败不影响上传）
    let scriptsMeta: GithubBackupScriptMeta[] | undefined
    try {
      const inspected = inspectBackup(item)
      if (inspected) {
        scriptsMeta = inspected.candidates.map((c) => ({
          name: c.folderName,
          version: c.version,
        }))
        if (inspected.tempDir && pathExists(inspected.tempDir)) {
          try {
            FileManager.removeSync(inspected.tempDir)
          } catch {}
        }
      }
    } catch {
      scriptsMeta = undefined
    }
    try {
      await updateGithubBackupManifest(config, remotePath, `${safe}${ext}`, count, Date.now(), scriptsMeta)
    } catch (e) {
      logError("Github备份元数据", e)
    }
    return { name: safe, url }
  } finally {
    if (pathExists(staging) && staging !== zipPath) {
      try {
        FileManager.removeSync(staging)
      } catch {}
    }
  }
}

// ==================== GitHub 备份元数据（manifest） ====================
// 在备份仓库根目录维护一个隐藏文件 .script-manager-meta.json，
// 记录每个备份 zip 的脚本数与备份时间；恢复页直接读取它，避免逐个下载统计。

export type GithubBackupScriptMeta = {
  /** 脚本文件夹名 */
  name: string
  /** 版本号（script.json，可能缺失） */
  version?: string
}

export type GithubBackupMeta = {
  name: string
  path: string
  scriptCount: number
  createdAt: number
  /** zip 内脚本名单（上传时写入，查看列表免下载解压） */
  scripts?: GithubBackupScriptMeta[]
}

export type GithubBackupManifest = {
  updatedAt: number
  backups: Record<string, GithubBackupMeta>
}

const GITHUB_MANIFEST_NAME = ".script-manager-meta.json"

/** UTF-8 字符串 → base64（manifest 内容小，自己编码避免依赖 Data.fromFile 的文件缓存） */
function utf8ToBase64(str: string): string {
  const bytes: number[] = []
  for (let i = 0; i < str.length; i++) {
    let code = str.codePointAt(i)!
    if (code > 0xffff) i++
    if (code < 0x80) bytes.push(code)
    else if (code < 0x800)
      bytes.push(0xc0 | (code >> 6), 0x80 | (code & 63))
    else if (code < 0x10000)
      bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63))
    else
      bytes.push(
        0xf0 | (code >> 18),
        0x80 | ((code >> 12) & 63),
        0x80 | ((code >> 6) & 63),
        0x80 | (code & 63)
      )
  }
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  let out = ""
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i]
    const b1 = bytes[i + 1]
    const b2 = bytes[i + 2]
    out += chars[b0 >> 2]
    out += chars[((b0 & 3) << 4) | (b1 !== undefined ? b1 >> 4 : 0)]
    out += b1 !== undefined ? chars[((b1 & 15) << 2) | (b2 !== undefined ? b2 >> 6 : 0)] : "="
    out += b2 !== undefined ? chars[b2 & 63] : "="
  }
  return out
}

/** 读取远端 manifest（不存在或解析失败返回 null）。URL 带时间戳参数避免 fetch/HTTP 缓存返回旧内容 */
export async function readGithubBackupManifest(
  config: GithubConfig
): Promise<GithubBackupManifest | null> {
  if (!isGithubBackupConfigured(config)) {
    return null
  }
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github.raw",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${GITHUB_MANIFEST_NAME}?ts=${Date.now()}`
  // GitHub 最终一致性：PUT 后立即 GET 可能短暂 404/旧内容，404 时重试
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await githubHttp(url, { headers })
    if (res.status === 404) {
      if (attempt < 2) {
        await new Promise<void>((resolve) => setTimeout(() => resolve(), 400))
        continue
      }
      return null
    }
    if (res.status !== 200) {
      return null
    }
    try {
      return JSON.parse(res.text) as GithubBackupManifest
    } catch {
      return null
    }
  }
  return null
}

/** 把 manifest 写入仓库根目录（自编码 base64 + Contents API PUT，不依赖临时文件读取） */
async function writeGithubBackupManifest(
  config: GithubConfig,
  manifest: GithubBackupManifest
): Promise<void> {
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${GITHUB_MANIFEST_NAME}`

  // 先 GET 拿 sha（文件存在才能覆盖）；URL 带时间戳避免 fetch 缓存返回旧 sha
  let sha: string | undefined
  const existing = await githubHttp(`${url}?ts=${Date.now()}`, { headers })
  if (existing.status === 200 && existing.data?.sha) {
    sha = existing.data.sha
  }

  const body: any = {
    message: sha ? "Update backup metadata" : "Add backup metadata",
    content: utf8ToBase64(JSON.stringify(manifest)),
  }
  if (sha) {
    body.sha = sha
  }
  // 仓库可能为空时不能带 branch（GitHub 会自动创建默认分支）
  const repoState = await ensureGithubRepo(
    config.token,
    config.owner,
    config.backupRepo,
    true
  )
  const skipBranch = !repoState.confirmed || repoState.empty
  if (!skipBranch && config.backupBranch.trim()) {
    body.branch = config.backupBranch.trim()
  }

  const { status, data } = await githubHttp(url, {
    method: "PUT",
    headers,
    body: JSON.stringify(body),
  })
  if (status !== 200 && status !== 201) {
    throw new Error(`写入备份元数据失败 (${status}): ${data?.message || ""}`)
  }
  // GitHub 最终一致性：等待写入传播，避免紧接着的读取拿到旧内容
  await new Promise<void>((resolve) => setTimeout(() => resolve(), 1000))
}

/** 备份上传成功后，把 zip 的脚本数、时间与脚本名单写入 manifest */
export async function updateGithubBackupManifest(
  config: GithubConfig,
  remotePath: string,
  name: string,
  scriptCount: number,
  createdAt: number,
  scripts?: GithubBackupScriptMeta[]
): Promise<void> {
  const manifest =
    (await readGithubBackupManifest(config)) || {
      updatedAt: Date.now(),
      backups: {},
    }
  manifest.backups[remotePath] = {
    name,
    path: remotePath,
    scriptCount,
    createdAt,
    ...(scripts && scripts.length > 0 ? { scripts } : {}),
  }
  manifest.updatedAt = Date.now()
  await writeGithubBackupManifest(config, manifest)
}

/** 删除备份后，把对应条目从 manifest 移除 */
export async function removeFromGithubBackupManifest(
  config: GithubConfig,
  remotePath: string
): Promise<void> {
  const manifest = await readGithubBackupManifest(config)
  if (!manifest || !manifest.backups[remotePath]) {
    return
  }
  delete manifest.backups[remotePath]
  manifest.updatedAt = Date.now()
  await writeGithubBackupManifest(config, manifest)
}

// ==================== 错误日志 ====================

const ERROR_LOG_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "script-manager-errors.json"
)

/** 单条错误日志 */
export type ErrorLogItem = {
  /** 时间戳（ms） */
  time: number
  /** 操作名，如「Github备份」「Github发布」「本地备份」 */
  operation: string
  /** 错误信息 */
  message: string
}

const MAX_ERROR_LOGS = 50

/** 记录一条错误日志（追加到本地文件，最多保留 50 条） */
export function logError(operation: string, error: unknown): void {
  try {
    const message = error instanceof Error ? error.message : String(error)
    const logs = resolveErrorLogs()
    logs.unshift({
      time: Date.now(),
      operation,
      message,
    })
    const trimmed = logs.slice(0, MAX_ERROR_LOGS)
    FileManager.writeAsStringSync(
      ERROR_LOG_PATH,
      JSON.stringify(trimmed, null, 2)
    )
  } catch {
    // 日志记录失败不影响主流程
  }
}

/** 读取全部错误日志（最新的在前） */
export function resolveErrorLogs(): ErrorLogItem[] {
  if (!pathExists(ERROR_LOG_PATH)) {
    return []
  }
  try {
    const raw = JSON.parse(FileManager.readAsStringSync(ERROR_LOG_PATH))
    if (!Array.isArray(raw)) {
      return []
    }
    return raw
      .filter(
        (item): item is ErrorLogItem =>
          typeof item === "object" &&
          item !== null &&
          typeof item.time === "number" &&
          typeof item.operation === "string" &&
          typeof item.message === "string"
      )
      .sort((a, b) => b.time - a.time)
  } catch {
    return []
  }
}

/** 清空全部错误日志 */
export function clearErrorLogs(): void {
  try {
    if (pathExists(ERROR_LOG_PATH)) {
      FileManager.removeSync(ERROR_LOG_PATH)
    }
  } catch {
    // ignore
  }
}
