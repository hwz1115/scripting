import {
  Button,
  HStack,
  Image,
  Link,
  List,
  Navigation,
  NavigationLink,
  NavigationStack,
  Path,
  Picker,
  Script,
  Section,
  Spacer,
  Text,
  TextField,
  Toggle,
  Toolbar,
  ToolbarItem,
  VStack,
  ZStack,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "scripting"
import {
  APP_NAME,
  AppConfig,
  BackupItem,
  BackupScopeKey,
  CandidateScript,
  Destination,
  GroupInfo,
  GithubConfig,
  GithubBackupManifest,
  ScriptInfo,
  backupRootFor,
  backupScripts,
  backupScriptsToGithub,
  clearErrorLogs,
  computeBackupScriptCount,
  deleteGithubBackup,
  deleteLocalBackup,
  deleteScript,
  disableScriptAutoUpdate,
  downloadGithubBackup,
  formatBytes,
  formatDate,
  githubVerify,
  buildGroupNameMap,
  getBackupScriptCount,
  getScriptRemoteResource,
  groupNameForScript,
  inspectBackup,
  isGithubBackupConfigured,
  isGithubConfigured,
  listGithubBackups,
  logError,
  moveScriptToGroup,
  pathExists,
  publishScriptsToGithub,
  renameScript,
  resolveConfig,
  resolveGithubConfig,
  resolvePublishGithubConfig,
  resolveBackupGithubConfig,
  restoreScripts,
  safeFileName,
  saveBackupScriptCount,
  saveConfig,
  saveGithubConfig,
  scanBackups,
  readGithubBackupManifest,
  readScriptingGroups,
  renameGithubBackup,
  renameLocalBackup,
  resolveErrorLogs,
  scanGroups,
  scanScripts,
  scanScriptDirsInTree,
  setScriptVersion,
  shareGithubBackups,
  shareLocalBackups,
  shareScripts,
  timestampForName,
} from "./manager"

// Dialog 全局模块：alert / confirm / prompt / actionSheet（与其他脚本一致，类型宽松处理）
declare const Dialog: any
// confirm 为全局确认框（返回 Promise<boolean>），类型宽松处理避免与全局声明冲突时用 any
declare const confirm: any
type PromptOptions = {
  title: string
  message?: string
  defaultValue?: string
  obscureText?: boolean
  selectAll?: boolean
  placeholder?: string
  cancelLabel?: string
  confirmLabel?: string
  keyboardType?: string
}
function inputPrompt(options: PromptOptions): Promise<string | null> {
  return Dialog.prompt(options)
}

/**
 * 修改版本号前检查脚本是否开启自动更新：带 remoteResource 的脚本由 Scripting 管理远程更新，
 * 本地修改的版本号在下一次应用云端更新时会被云端版本替换。这里给用户两个选择：
 * 「直接修改」保留更新链接，改动仅本地生效；「修改并关闭自动更新」则彻底避免被云端覆盖。
 * 返回 false 表示用户取消。
 */
async function ensureVersionNotOverridden(script: ScriptInfo): Promise<boolean> {
  const remote = getScriptRemoteResource(script)
  if (!remote || remote.autoUpdateInterval == null) {
    return true
  }
  const index = await Dialog.actionSheet({
    title: "该脚本开启了自动更新",
    message:
      `「${script.displayName}」配置了远程自动更新（约每 ${remote.autoUpdateInterval} 秒检查一次）。` +
      `修改的版本号会保留到下一次应用云端更新为止（应用后版本号会被替换为云端版本）。` +
      `也可以选择同时关闭自动更新（保留更新链接，之后可重新开启），避免后续被云端覆盖。`,
    actions: [
      { label: "取消" },
      { label: "直接修改" },
      { label: "修改并关闭自动更新" },
    ],
    cancelButton: false,
  })
  if (index == null || index === 0) {
    return false
  }
  if (index === 2) {
    disableScriptAutoUpdate(script)
  }
  return true
}

// ==================== 通用小组件 ====================

function useToast() {
  const [toast, setToast] = useState<{
    msg: string
    isError: boolean
  }>({ msg: "", isError: false })
  const showToast = (msg: string, isError = false) => setToast({ msg, isError })
  const toastProps = {
    isPresented: toast.msg !== "",
    onChanged: (v: boolean) => {
      if (!v) setToast({ msg: "", isError: false })
    },
    content: (
      <HStack spacing={6} alignment="center">
        <Image
          systemName={toast.isError ? "exclamationmark.triangle.fill" : "checkmark.circle.fill"}
          foregroundStyle={toast.isError ? "systemRed" : "systemGreen"}
        />
        <Text font="body" foregroundStyle="white">
          {toast.msg}
        </Text>
      </HStack>
    ),
    position: "top" as const,
    duration: 2,
  }
  return { toast, showToast, toastProps }
}

function RowIcon({
  systemName,
  color = "tintColor",
  small = false,
  leftPad = 0,
}: {
  systemName: string
  color?: any
  small?: boolean
  leftPad?: number
}) {
  return (
    <Image
      systemName={systemName}
      foregroundStyle={color}
      imageScale={small ? "small" : undefined}
      padding={leftPad !== 0 ? { leading: leftPad } : undefined}
    />
  )
}

function Chevron({ color = "tertiaryLabel" }: { color?: any }) {
  return <Image systemName="chevron.right" foregroundStyle={color} />
}

function EmptyState({ message }: { message: string }) {
  return (
    <VStack alignment="center" spacing={8} padding={{ vertical: 16 }}>
      <Image systemName="tray" foregroundStyle="secondaryLabel" />
      <Text foregroundStyle="secondaryLabel">{message}</Text>
    </VStack>
  )
}

/** 名称比较：拉丁字母/数字开头的排前面（A-Z），中文按拼音排序，大小写不敏感 */
function compareNames(a: string, b: string): number {
  const la = a.toLowerCase()
  const lb = b.toLowerCase()
  const aLatin = /^[a-z0-9]/.test(la)
  const bLatin = /^[a-z0-9]/.test(lb)
  if (aLatin !== bLatin) {
    return aLatin ? -1 : 1
  }
  return la.localeCompare(lb, "zh-Hans-CN") || a.localeCompare(b, "zh-Hans-CN")
}

/** 脚本排序比较：按名称 A-Z，或按最新修改（倒序） */
function compareScripts(
  a: ScriptInfo,
  b: ScriptInfo,
  mode: "modified" | "name"
): number {
  if (mode === "name") {
    return (
      compareNames(a.displayName, b.displayName) ||
      compareNames(a.folderName, b.folderName)
    )
  }
  return b.modifiedAt - a.modifiedAt
}

/**
 * 关键字匹配：关键字需作为独立“词”出现（前后不能是字母/数字/下划线），
 * 避免搜 “tg” 误匹配到 “ChatGPT反代” 这类名字里嵌着子串的脚本。
 * 中文字符视为词边界，因此 “tg” 能匹配 “TG频道 / 我的tg / v2rayTG”。
 */
function keywordMatches(text: string, keyword: string): boolean {
  const kw = keyword.trim().toLowerCase()
  if (!kw) return true
  const escaped = kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
  return new RegExp(
    `(^|[^a-z0-9_])${escaped}|${escaped}([^a-z0-9_]|$)`,
    "i"
  ).test(text)
}

/** 生成 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]，urls 值为 URL 编码的 JSON 数组） */
function buildImportLinkFromUrl(url: string): string {
  const urls = JSON.stringify([url])
  return `https://scripting.fun/import_scripts?urls=${encodeURIComponent(urls)}`
}

/** 生成脚本的 Scripting 导入链接，无发布链接返回 null */
function buildScriptImportLink(script: ScriptInfo): string | null {
  const remote = getScriptRemoteResource(script)
  if (!remote?.url) {
    return null
  }
  return buildImportLinkFromUrl(remote.url)
}

/** 脚本是否已发布（script.json 里有远程链接） */
function hasPublishedLink(script: ScriptInfo): boolean {
  return getScriptRemoteResource(script)?.url != null
}

/** 脚本是否由本工具发布到本人 GitHub 仓库（remoteResource 为 raw.githubusercontent.com 的 .scripting 链接，且 owner 为当前发布账号） */
function isPublishedByTool(script: ScriptInfo): boolean {
  const url = getScriptRemoteResource(script)?.url
  if (
    !url ||
    !url.startsWith("https://raw.githubusercontent.com/") ||
    !url.endsWith(".scripting")
  ) {
    return false
  }
  const gh = resolvePublishGithubConfig(resolveGithubConfig())
  if (!gh.owner) {
    return false
  }
  return url.startsWith(`https://raw.githubusercontent.com/${gh.owner}/`)
}

/** 备份数据变更订阅：恢复页删除/重命名备份后，通知首页刷新备份计数 */
let backupChangeListeners: Array<() => void> = []
function subscribeBackupChange(fn: () => void): () => void {
  backupChangeListeners.push(fn)
  return () => {
    backupChangeListeners = backupChangeListeners.filter((f) => f !== fn)
  }
}
function notifyBackupChange() {
  backupChangeListeners.forEach((fn) => fn())
}

/** 确认恢复单个脚本（存在同名时提示覆盖），供主页面与恢复页共用 */
async function confirmRestoreOne(candidate: CandidateScript): Promise<boolean> {
  const exists = pathExists(
    Path.join(FileManager.scriptsDirectory, candidate.folderName)
  )
  const index = await Dialog.actionSheet({
    title: "恢复脚本",
    message: exists
      ? `将恢复脚本「${candidate.folderName}」，目录中已存在同名脚本，恢复会覆盖当前版本。`
      : `将恢复脚本「${candidate.folderName}」到 Scripting 脚本目录。`,
    actions: [
      { label: "取消" },
      { label: exists ? "覆盖并恢复" : "恢复", destructive: exists },
    ],
    cancelButton: false,
  })
  return index === 1
}

// ==================== 主页面 ====================

export function MainPage() {
  const dismiss = Navigation.useDismiss()
  const [config, setConfigState] = useState<AppConfig>(resolveConfig)
  const [selectedGroup, setSelectedGroup] = useState<GroupInfo | null>(null)
  const [selectedScripts, setSelectedScripts] = useState<ScriptInfo[]>([])
  const [busy, setBusy] = useState(false)
  const [backupVersion, setBackupVersion] = useState(0)
  const [backupCount, setBackupCount] = useState(0)
  // 订阅备份变更（恢复页删除/重命名备份后触发），返回主页时刷新「N 个备份」
  useEffect(() => {
    const unsub = subscribeBackupChange(() => setBackupVersion((v) => v + 1))
    return unsub
  }, [])
  const [scriptCount, setScriptCount] = useState(0)
  const [scriptList, setScriptList] = useState<ScriptInfo[]>([])
  const [showBackupRestore, setShowBackupRestore] = useState(() => {
    const saved = resolveConfig()
    return saved.rememberExpandState ? saved.backupRestoreExpanded : true
  })
  const [searchText, setSearchText] = useState("")
  const [multiSelect, setMultiSelect] = useState<Set<string>>(new Set())
  // 一次性构建 脚本文件夹名 → 分组名 映射，复用已扫描的 scriptList，避免重复全量扫描（会非常卡）
  const groupNameMap = useMemo(() => buildGroupNameMap(scriptList), [scriptList])
  // 置顶脚本集合（文件夹名）
  const pinnedSet = useMemo(
    () => new Set(config.pinnedScripts),
    [config.pinnedScripts]
  )
  // 按排序方式排序：置顶的脚本始终排在最上方（按置顶顺序，最后置顶的排最前），其余按「最新修改 / 名称 A-Z」排序
  const sortedScripts = useMemo(() => {
    const pinnedByOrder = config.pinnedScripts
      .map((folderName) =>
        scriptList.find((s) => s.folderName === folderName)
      )
      .filter((s): s is ScriptInfo => Boolean(s))
    const cmp = (a: ScriptInfo, b: ScriptInfo) =>
      compareScripts(a, b, config.scriptSort)
    const rest = scriptList
      .filter((s) => !pinnedSet.has(s.folderName))
      .sort(cmp)
    return [...pinnedByOrder, ...rest]
  }, [scriptList, config.pinnedScripts, pinnedSet, config.scriptSort])
  // 搜索时按「关键字匹配 → 置顶 → 其他」三段展示；无关键字时直接展示排序后的列表
  const visibleScripts = useMemo(() => {
    const keyword = searchText.trim().toLowerCase()
    if (!keyword) {
      return sortedScripts
    }
    const matched = sortedScripts.filter((s) =>
      keywordMatches(s.displayName, keyword)
    )
    const pinnedRest = sortedScripts.filter(
      (s) => !keywordMatches(s.displayName, keyword) && pinnedSet.has(s.folderName)
    )
    const others = sortedScripts.filter(
      (s) => !keywordMatches(s.displayName, keyword) && !pinnedSet.has(s.folderName)
    )
    return [...matched, ...pinnedRest, ...others]
  }, [sortedScripts, searchText, pinnedSet])
  const { showToast, toastProps } = useToast()

  // 异步统计首页数量，避免首次渲染同步扫描（解压 zip / 读 script.json）卡住主线程
  useEffect(() => {
    setTimeout(() => {
      setBackupCount(scanBackups(config.destination).length)
      const list = scanScripts()
      setScriptCount(list.length)
      setScriptList(list)
    }, 50)
  }, [config.destination, backupVersion])

  /** 点击运行脚本（调用 Script.run 运行目标脚本，singleMode 终止其他实例） */
  function runScript(script: ScriptInfo) {
    Script.run({
      name: script.folderName,
      singleMode: true,
    }).catch(() => {})
  }

  /** 置顶 / 取消置顶脚本（保存在配置里，置顶脚本排在列表最上方，最后置顶的排在最前） */
  function togglePin(script: ScriptInfo) {
    const wasPinned = config.pinnedScripts.includes(script.folderName)
    updateConfig({
      pinnedScripts: wasPinned
        ? config.pinnedScripts.filter((f) => f !== script.folderName)
        : [script.folderName, ...config.pinnedScripts],
    })
    showToast(wasPinned ? "已取消置顶" : "已置顶")
  }

  // 单击行：350ms 内再次点击判定为双击（快速置顶），否则延迟弹出行菜单
  const lastTapTimeRef = useRef(0)
  const tapMenuTimerRef = useRef(0)
  function handleScriptTap(script: ScriptInfo) {
    if (multiSelect.size > 0) {
      toggleMultiSelect(script)
      return
    }
    const now = Date.now()
    if (now - lastTapTimeRef.current < 350) {
      if (tapMenuTimerRef.current) {
        clearTimeout(tapMenuTimerRef.current)
        tapMenuTimerRef.current = 0
      }
      lastTapTimeRef.current = 0
      togglePin(script)
      return
    }
    lastTapTimeRef.current = now
    tapMenuTimerRef.current = setTimeout(() => {
      tapMenuTimerRef.current = 0
      lastTapTimeRef.current = 0
      showScriptMenu(script)
    }, 350)
  }

  /** 脚本行菜单：重命名 / 移动分组 / 分享 / 修改版本号 / 删除（备份/发布按设置开关显示） */
  async function showScriptMenu(script: ScriptInfo) {
    const group = groupNameMap.get(script.folderName) ?? null
    const actions: Array<{ label: string; destructive?: boolean }> = [
      { label: "删除", destructive: true },
      { label: "修改版本号" },
      { label: "移动到其他分组" },
      { label: "重命名" },
    ]
    const handlers: Array<() => void | Promise<void>> = [
      () => deleteOneScript(script),
      () => changeVersionWithPrompt(script),
      () => moveScriptGroupWithPrompt(script),
      () => renameScriptWithPrompt(script),
    ]
    if (config.githubPublishEnabled) {
      actions.push({ label: "发布" })
      handlers.push(() => startGithubPublish([script]))
    }
    if (config.githubBackupEnabled) {
      actions.push({ label: "备份" })
      handlers.push(() => backupScriptsFromMenu([script]))
    }
    if (config.githubPublishEnabled && hasPublishedLink(script)) {
      actions.push({ label: "分享(链接)" })
      handlers.push(() => copyScriptShareLink(script))
      actions.push({ label: "分享(文件)" })
      handlers.push(() => shareOneScript(script))
    } else {
      actions.push({ label: "分享" })
      handlers.push(() => shareOneScript(script))
    }

    const index = await Dialog.actionSheet({
      title: script.displayName,
      message: `版本 ${script.version} · ${formatDate(script.modifiedAt)} · ${formatBytes(script.byteSize)} · 分组 ${group ?? "默认"}`,
      actions,
    })
    if (index == null) {
      return
    }
    await handlers[index]()
  }

  /** 长按进入多选并勾选/取消脚本 */
  function toggleMultiSelect(script: ScriptInfo) {
    setMultiSelect((prev) => {
      const next = new Set(prev)
      if (next.has(script.folderName)) {
        next.delete(script.folderName)
      } else {
        next.add(script.folderName)
      }
      return next
    })
  }

  /** 分享当前勾选的脚本 */
  async function shareSelected() {
    if (multiSelect.size === 0) {
      showToast("请先勾选脚本", true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    try {
      await shareScripts(scripts)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 删除当前勾选的脚本 */
  async function deleteSelected() {
    if (multiSelect.size === 0) {
      showToast("请先勾选脚本", true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    const index = await Dialog.actionSheet({
      title: "删除确认",
      message: `确定删除 ${scripts.length} 个脚本？此操作不可恢复。`,
      actions: [{ label: "取消" }, { label: "删除", destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    try {
      for (const script of scripts) {
        deleteScript(script)
      }
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      setMultiSelect(new Set())
      showToast("已删除")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 按当前备份位置备份脚本（菜单 / 多选快捷备份） */
  async function backupScriptsFromMenu(scripts: ScriptInfo[]) {
    if (scripts.length === 0) {
      showToast("没有可备份的脚本", true)
      return
    }
    if (config.destination === "github_publish") {
      await startGithubPublish(scripts)
    } else if (config.destination === "github_backup") {
      await startGithubBackup(scripts, scripts.length > 1 ? "临时备份" : undefined)
    } else {
      await startBackup(undefined, scripts, undefined, scripts.length > 1 ? "临时备份" : undefined)
    }
  }

  async function renameScriptWithPrompt(script: ScriptInfo) {
    const name = await inputPrompt({
      title: "重命名脚本",
      message: "输入新的脚本名称",
      defaultValue: script.folderName,
      placeholder: script.folderName,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameScript(script, name.trim())
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      showToast("已重命名")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function moveScriptGroupWithPrompt(script: ScriptInfo) {
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast("没有可移动的分组", true)
      return
    }
    const index = await Dialog.actionSheet({
      title: "移动到分组",
      message: `把「${script.displayName}」移动到哪个分组？`,
      actions: [{ label: "取消" }, ...named.map((g) => ({ label: g.name }))],
      cancelButton: false,
    })
    if (index == null || index === 0) {
      return
    }
    const target = named[index - 1]
    try {
      moveScriptToGroup(script, target.name)
      setScriptList(scanScripts())
      showToast(`已移动到「${target.name}」`)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function shareOneScript(script: ScriptInfo) {
    try {
      await shareScripts([script])
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 复制该脚本的 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]） */
  async function copyScriptShareLink(script: ScriptInfo) {
    const link = buildScriptImportLink(script)
    if (!link) {
      showToast("该脚本没有发布链接，请先发布", true)
      return
    }
    try {
      await Pasteboard.setString(link)
      showToast("导入链接已复制")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function changeVersionWithPrompt(script: ScriptInfo) {
    if (!(await ensureVersionNotOverridden(script))) {
      return
    }
    const version = await inputPrompt({
      title: "修改版本号",
      message: "输入新的版本号（格式 x.y.z，例如 1.0.1）",
      defaultValue: script.version,
      placeholder: script.version,
      keyboardType: "numbersAndPunctuation",
    })
    if (version == null || !version.trim()) {
      return
    }
    try {
      setScriptVersion(script, version.trim())
      setScriptList(scanScripts())
      showToast("版本号已更新")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function deleteOneScript(script: ScriptInfo) {
    const index = await Dialog.actionSheet({
      title: "删除确认",
      message: `确定删除「${script.displayName}」？此操作不可恢复。`,
      actions: [{ label: "取消" }, { label: "删除", destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    try {
      deleteScript(script)
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      showToast("已删除")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  function updateConfig(patch: Partial<AppConfig>) {
    setConfigState((prev) => {
      const next = { ...prev, ...patch }
      saveConfig(next)
      return next
    })
  }

  function handleDestinationChanged(value: string | number) {
    const dest = String(value) as Destination
    if (dest === "icloud" && !FileManager.isiCloudEnabled) {
      showToast("iCloud 不可用，请先在系统设置中登录 iCloud 并授权 Scripting", true)
      return
    }
    if (dest === "github_publish" && !config.githubPublishEnabled) {
      showToast("请在设置中勾选「Github发布」以使用此功能", true)
      return
    }
    // 发布模式仅支持「最新/名称」，若之前选了分组/全部则重置为最新
    if (dest === "github_publish" && (config.scope === "group" || config.scope === "all")) {
      updateConfig({ destination: dest, scope: "recent" })
      return
    }
    updateConfig({ destination: dest })
  }

  /** 弹出「按名称」脚本选择页（modal，选完直接开始备份/发布） */
  function openScriptPicker() {
    const isPublish = config.destination === "github_publish"
    Navigation.present(
      <ScriptPickerPage
        initial={[]}
        pickerMode={isPublish ? "github" : "backup"}
        onSelect={(scripts) => {
          setSelectedScripts(scripts)
          if (scripts.length === 0) return
          if (config.destination === "github_publish") {
            startGithubPublish(scripts)
          } else if (config.destination === "github_backup") {
            startGithubBackup(scripts)
          } else {
            startBackup("select", scripts)
          }
        }}
      />
    )
  }

  /** 弹出「按分组」选择页（modal，选完直接开始备份/发布对应分组） */
  function openGroupPicker() {
    Navigation.present(
      <GroupPickerPage
        onSelect={(group) => {
          setSelectedGroup(group)
          if (group.scripts.length === 0) {
            showToast("该分组没有可备份的脚本", true)
            return
          }
          if (config.destination === "github_backup") {
            startGithubBackup(group.scripts, group.name)
          } else {
            startBackup("group", group.scripts, group.name)
          }
        }}
      />
    )
  }

  /** 执行某个备份范围对应的动作：最新/全部直接备份，按名称/按分组弹选择页 */
  function runScopeAction(scope: BackupScopeKey) {
    if (config.destination === "github_publish") {
      // GitHub 发布模式：仅「最新/名称」两个范围
      if (scope === "recent") {
        startGithubPublish(scanScripts().slice(0, 1))
      } else if (scope === "select") {
        openScriptPicker()
      }
    } else if (config.destination === "github_backup") {
      // GitHub 备份模式：打包 zip 上传到私密备份仓库
      if (scope === "recent" || scope === "all") {
        startGithubBackup(
          scope === "recent" ? scanScripts().slice(0, 1) : scanScripts(),
          scope === "all" ? "全部" : undefined
        )
      } else if (scope === "select") {
        openScriptPicker()
      } else if (scope === "group") {
        openGroupPicker()
      }
    } else {
      // 本地备份模式：保持原有逻辑
      if (scope === "recent" || scope === "all") {
        startBackup(scope)
      } else if (scope === "select") {
        openScriptPicker()
      } else if (scope === "group") {
        openGroupPicker()
      }
    }
  }

  /** 发布脚本到 GitHub（公开仓库，可自动创建）：打包上传并把更新链接写回脚本自身 script.json */
  async function startGithubPublish(scripts: ScriptInfo[]) {
    if (busy) {
      return
    }
    const gh = resolvePublishGithubConfig(resolveGithubConfig())
    if (!isGithubConfigured(gh)) {
      showToast("请先到右上角「设置」配置 GitHub 发布（Token/所有者/仓库名）", true)
      return
    }
    const index = await Dialog.actionSheet({
      title: "发布到 GitHub",
      message: `将 ${scripts.length} 个脚本打包为 .scripting 上传到 ${gh.owner}/${gh.repo}（仓库不存在将自动创建，默认公开），并更新每个脚本的远程更新链接（remoteResource），其他设备即可通过该链接拉取新版本。`, actions: [
        { label: "取消" },
        { label: "发布并更新链接", destructive: false },
      ],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    setBusy(true)
    try {
      const results = await publishScriptsToGithub(scripts, gh)
      const links = results.map((r) => buildImportLinkFromUrl(r.url))
      await Pasteboard.setString(links.join("\n"))
      showToast(
        `已发布 ${results.length} 个脚本并同步更新链接，更新链接已复制`
      )
      console.log(
        "GitHub 发布完成:",
        links
      )
    } catch (error) {
      logError("Github发布", error)
      showToast(
        error instanceof Error ? error.message : String(error),
        true
      )
    } finally {
      setBusy(false)
    }
  }

  /** 备份脚本到 GitHub 私密备份仓库（可自动创建）：打包 zip 上传，不更新更新链接 */
  async function startGithubBackup(scripts: ScriptInfo[], nameHint?: string) {
    if (busy) {
      return
    }
    const gh = resolveBackupGithubConfig(resolveGithubConfig())
    if (!isGithubBackupConfigured(gh)) {
      showToast("请先到右上角「设置」配置 GitHub 备份（Token/所有者/备份仓库名）", true)
      return
    }
    let zipName: string
    if (nameHint) {
      // 分组/全部备份：默认「前缀_时间编号」
      const def = `${safeFileName(nameHint)}_${timestampForName()}`
      const input = await inputPrompt({
        title: "备份名称",
        message: `将 ${scripts.length} 个脚本打包为一个 zip 上传到 GitHub 私密仓库，默认命名为「${nameHint}+时间编号」`,
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || def
    } else if (scripts.length === 1) {
      const script = scripts[0]
      const def = `${script.displayName}_${script.version}`
      const input = await inputPrompt({
        title: "备份名称",
        message: "单个脚本备份为 .scripting 格式上传到 GitHub 私密仓库，默认使用「脚本名+版本号」",
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || def
    } else {
      const def = `脚本备份_${timestampForName()}`
      const input = await inputPrompt({
        title: "备份名称",
        message: `将 ${scripts.length} 个脚本打包为一个 zip 上传到 GitHub 私密仓库`,
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || "脚本备份"
    }
    setBusy(true)
    try {
      const result = await backupScriptsToGithub(scripts, gh, zipName)
      showToast(`已备份 ${scripts.length} 个脚本到 ${gh.owner}/${gh.backupRepo}`)
      console.log("GitHub 备份完成:", result.url)
    } catch (error) {
      logError("Github备份", error)
      showToast(
        error instanceof Error ? error.message : String(error),
        true
      )
    } finally {
      setBusy(false)
    }
  }

  /** 计算当前范围要备份的脚本 */
  async function resolveBackupScripts(
    scope: BackupScopeKey = config.scope
  ): Promise<ScriptInfo[] | null> {
    if (scope === "all") {
      return scanScripts()
    }
    if (scope === "recent") {
      return scanScripts().slice(0, 1)
    }
    if (scope === "select") {
      const pickable = selectedScripts.filter((s) => pathExists(s.path))
      if (pickable.length === 0) {
        showToast("请先选择要备份的脚本", true)
        return null
      }
      return pickable
    }
    // 按分组
    if (!selectedGroup) {
      showToast("请先选择要备份的分组", true)
      return null
    }
    return selectedGroup.scripts
  }

  async function startBackup(
    scope?: BackupScopeKey,
    scriptsOverride?: ScriptInfo[],
    groupName?: string,
    multiDefaultName?: string
  ) {
    if (busy) {
      return
    }
    setBusy(true)
    try {
      const scripts = scriptsOverride ?? (await resolveBackupScripts(scope))
      if (!scripts) {
        return
      }
      if (scripts.length === 0) {
        showToast("没有可备份的脚本", true)
        return
      }

      let zipName: string
      if (groupName) {
        // 按分组备份：默认「分组名_时间戳编号」
        const def = `${safeFileName(groupName)}_${timestampForName()}`
        const input = await inputPrompt({
          title: "备份名称",
          message: `将 ${scripts.length} 个脚本打包为一个 zip 上传到 iPhone/iCloud，默认命名为「分组名+时间编号」`,
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || def
      } else if (scripts.length === 1) {
        const script = scripts[0]
        const def = `${script.displayName}_${script.version}`
        const input = await inputPrompt({
          title: "备份名称",
          message: "单个备份默认使用「脚本名+版本号」",
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || def
      } else {
        const isAll = scope === "all"
        const baseName = isAll ? "全部" : (multiDefaultName ?? "脚本备份")
        const def = `${baseName}_${timestampForName()}`
        const input = await inputPrompt({
          title: "备份名称",
          message: `将 ${scripts.length} 个脚本打包为一个 zip 上传到 iPhone/iCloud，留空则命名为「${baseName}_时间码」`,
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || (isAll ? def : (multiDefaultName ?? "临时备份"))
      }

      const finalPath = await backupScripts(scripts, config.destination, zipName)
      showToast(`已备份 ${scripts.length} 个脚本`)
      setBackupVersion((v) => v + 1)
      console.log("备份完成:", finalPath)
    } catch (error) {
      logError("本地备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setBusy(false)
    }
  }

  /** 从外部 zip 恢复 */
  async function importFromZip() {
    const files = await DocumentPicker.pickFiles({
      allowsMultipleSelection: false,
    })
    if (!files || files.length === 0) {
      return
    }
    const file = files[0]
    const tempDir = Path.join(
      FileManager.temporaryDirectory,
      `import-restore-${Date.now()}`
    )
    FileManager.createDirectorySync(tempDir, true)
    try {
      const lower = file.toLowerCase()
      if (lower.endsWith(".zip") || lower.endsWith(".scripting")) {
        FileManager.unzipSync(file, tempDir)
      } else {
        // 单个文件夹：直接按脚本目录树扫描
        const name = Path.basename(file)
        FileManager.copyFileSync(file, Path.join(tempDir, name))
      }
      const candidates = scanScriptDirsInTree(tempDir)
      if (candidates.length === 0) {
        showToast("所选文件中没有找到脚本（缺少 script.json）", true)
        return
      }
      if (candidates.length === 1) {
        const ok = await confirmRestoreOne(candidates[0])
        if (ok) {
          await restoreScripts([candidates[0]], true)
          showToast("已恢复")
        }
      } else {
        const result = await Navigation.present(
          <ScriptSelectionPage candidates={candidates} />
        )
        if (result?.restored != null) {
          showToast(`已恢复 ${result.restored} 个脚本`)
        }
      }
    } catch (error) {
      logError("从zip恢复", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (pathExists(tempDir)) {
        FileManager.removeSync(tempDir)
      }
    }
  }

  return (
    <NavigationStack>
      <List
        navigationTitle={APP_NAME}
        navigationBarTitleDisplayMode="inline"
        toast={toastProps}
        safeAreaInset={{
          bottom: {
            alignment: "center",
            spacing: 8,
            content: multiSelect.size > 0 ? (
              <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setMultiSelect(new Set())}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    取消
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={deleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    删除
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() =>
                    backupScriptsFromMenu(
                      scriptList.filter((s) => multiSelect.has(s.folderName))
                    )
                  }
                >
                  <Image systemName="arrow.down.circle" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    备份
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={shareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    分享
                  </Text>
                </VStack>
              </HStack>
              </VStack>
            ) : (
              <></>
            ),
          },
        }}
        toolbar={
          <Toolbar>
            {Script.env !== "home_screen" ? (
              <ToolbarItem placement="topBarLeading">
                <Button title="关闭" action={dismiss} />
              </ToolbarItem>
            ) : null}
            <ToolbarItem placement="topBarLeading">
              <Button
                action={() => {
                  const next = !showBackupRestore
                  setShowBackupRestore(next)
                  if (config.rememberExpandState) {
                    updateConfig({ backupRestoreExpanded: next })
                  }
                }}
              >
                <Image
                  systemName={showBackupRestore ? "chevron.up" : "chevron.down"}
                />
              </Button>
            </ToolbarItem>
            <ToolbarItem placement="topBarTrailing">
              <Button
                action={async () => {
                  // 打开设置页；关闭后立即刷新配置，无需重新打开脚本即可生效
                  await Navigation.present(<SettingsPage />)
                  setConfigState(resolveConfig())
                }}
              >
                <Image systemName="gearshape" />
              </Button>
            </ToolbarItem>
          </Toolbar>
        }
      >
        {showBackupRestore ? (
          <Section
            header={<Text font="headline">备份</Text>}
            footer={
              config.destination === "github_publish" ? (
                <Text font="footnote">
                  {(() => {
                    const gh = resolvePublishGithubConfig(resolveGithubConfig())
                    return `发布到仓库：${(gh.owner && gh.repo) ? `${gh.owner}/${gh.repo}` : "未配置，请在设置中填写 GitHub 发布参数"}${gh.path ? ` / ${gh.path}` : ""}（${gh.branch || "main"} 分支，公开，可自动创建）`
                  })()}
                </Text>
              ) : config.destination === "github_backup" ? (
                <Text font="footnote">
                  {(() => {
                    const gh = resolveBackupGithubConfig(resolveGithubConfig())
                    return `备份到仓库：${(gh.owner && gh.backupRepo) ? `${gh.owner}/${gh.backupRepo}` : "未配置，请在设置中填写 GitHub 备份参数"}${gh.backupPath ? ` / ${gh.backupPath}` : ""}（${gh.backupBranch || "main"} 分支，私密，可自动创建）`
                  })()}
                </Text>
              ) : (
                <Text font="footnote">
                  备份目录：{backupRootFor(config.destination)}
                </Text>
              )
            }
          >
            <Picker
              title="备份到"
              value={config.destination}
              onChanged={handleDestinationChanged}
              pickerStyle="segmented"
            >
              <Text tag="iphone">iPhone</Text>
              <Text tag="icloud">iCloud</Text>
              {config.githubBackupEnabled && <Text tag="github_backup">Github备份</Text>}
              {config.githubPublishEnabled && <Text tag="github_publish">Github发布</Text>}
            </Picker>

            <Picker
              title="备份范围"
              value={config.scope}
              onChanged={(value: string) => {
                const scope = String(value) as BackupScopeKey
                updateConfig({ scope })
                runScopeAction(scope)
              }}
              pickerStyle="segmented"
            >
              <Text tag="recent">最新</Text>
              <Text tag="select">名称</Text>
              {config.destination !== "github_publish" && <Text tag="group">分组</Text>}
              {config.destination !== "github_publish" && <Text tag="all">全部</Text>}
            </Picker>

            <HStack
              spacing={8}
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => runScopeAction(config.scope)}
            >
              <Spacer />
              <Image
                systemName={config.destination === "github_publish" ? "arrow.up.doc.fill" : "externaldrive.fill.badge.checkmark"}
                foregroundStyle="tintColor"
              />
              <Text font="body" foregroundStyle="tintColor">
                {busy
                  ? config.destination === "github_publish" ? "正在发布…" : "正在备份…"
                  : config.destination === "github_publish" ? "开始发布" : "开始备份"}
              </Text>
              <Spacer />
            </HStack>
          </Section>
        ) : null}

        {showBackupRestore && config.destination !== "github_publish" ? (
          <Section
            header={<Text font="headline">恢复</Text>}
            footer={
              <Text font="footnote">
                {config.destination === "github_backup"
                  ? "从 GitHub 私密备份仓库下载 .scripting 恢复脚本"
                  : "从备份目录或外部 .scripting 文件恢复脚本"}
              </Text>
            }
          >
            <NavigationLink
              destination={
                config.destination === "github_backup" ? (
                  <GithubRestorePage />
                ) : (
                  <RestorePage destination={config.destination} />
                )
              }
            >
              <HStack spacing={10}>
                <RowIcon systemName="tray.and.arrow.down" />
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">恢复备份</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {config.destination === "github_backup"
                      ? "Github备份仓库"
                      : `${backupCount} 个备份`}
                  </Text>
                </VStack>
                <Spacer />
              </HStack>
            </NavigationLink>

            {config.destination !== "github_backup" && (
              <HStack
                spacing={8}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={importFromZip}
              >
                <Spacer />
                <Image systemName="folder.badge.plus" foregroundStyle="tintColor" />
                <Text font="body" foregroundStyle="tintColor">从文件恢复</Text>
                <Spacer />
              </HStack>
            )}
          </Section>
        ) : null}

        <Section
          header={
            <HStack spacing={8} alignment="center">
              <Text font="headline">脚本管理（{scriptList.length}）</Text>
              <Spacer />
              <Picker
                value={config.scriptSort}
                onChanged={(value: string | number) => {
                  updateConfig({
                    scriptSort: String(value) === "name" ? "name" : "modified",
                  })
                }}
                pickerStyle="menu"
                padding={{ trailing: -12 }}
                label={
                  <HStack spacing={4}>
                    <Image
                      systemName="arrow.up.arrow.down"
                      foregroundStyle="secondaryLabel"
                    />
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      {config.scriptSort === "name" ? "按名称 A-Z" : "按最新修改"}
                    </Text>
                  </HStack>
                }
              >
                <Text tag="modified">按最新修改</Text>
                <Text tag="name">按名称 A-Z</Text>
              </Picker>
            </HStack>
          }
          footer={
            <VStack alignment="leading" spacing={2}>
              <Text font="footnote"> </Text>
              <Text font="footnote">注：</Text>
              <Text font="footnote">
                ①单击行弹出菜单（删除/版本号/移动分组/重命名/备份/分享）
              </Text>
              <Text font="footnote">②双击单项快速置顶，再次双击取消置顶</Text>
              <Text font="footnote">
                ③点击右侧按钮(三角图标)直接运行该脚本
              </Text>
              <Text font="footnote">④长按任意脚本可多选备份、分享或删除</Text>
              <Text font="footnote">
                ⑤搜索时未匹配到关键词，则置顶项在最上方，若匹配到关键词，则这些项会出现在置顶项上方
              </Text>
              <Text font="footnote">
                ⑥点击左上角按钮可隐藏备份相关板块
              </Text>
              <HStack spacing={4}>
                <Text font="footnote">
                  ⑦自己已发布到仓库的脚本会有该特殊标识
                </Text>
                <Image
                  systemName="checkmark.seal.fill"
                  foregroundStyle="systemGreen"
                  imageScale="small"
                />
              </HStack>
            </VStack>
          }
        >
          {scriptList.length > 0 ? (
            <HStack spacing={8}>
              <TextField
                value={searchText}
                onChanged={setSearchText}
                prompt="搜索脚本名"
                label={
                  <Image
                    systemName="magnifyingglass"
                    foregroundStyle="secondaryLabel"
                  />
                }
              />
              {searchText.length > 0 ? (
                <HStack
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setSearchText("")}
                >
                  <Image
                    systemName="xmark.circle.fill"
                    foregroundStyle="secondaryLabel"
                  />
                </HStack>
              ) : null}
            </HStack>
          ) : null}
          {scriptList.length === 0 ? (
            <EmptyState message="正在加载脚本…" />
          ) : (
            visibleScripts.map((script) => {
              const checked = multiSelect.has(script.folderName)
              const group = groupNameMap.get(script.folderName) ?? null
              const isPinned = pinnedSet.has(script.folderName)
              return (
                <HStack
                  key={script.folderName}
                  spacing={10}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => handleScriptTap(script)}
                  onLongPressGesture={{
                    minDuration: 400,
                    perform: () => toggleMultiSelect(script),
                  }}
                >
                  {multiSelect.size > 0 ? (
                    <Image
                      systemName={checked ? "checkmark.circle.fill" : "circle"}
                      foregroundStyle={
                        checked ? "systemBlue" : "secondaryLabel"
                      }
                    />
                  ) : (
                    <RowIcon
                      systemName="chevron.left.forwardslash.chevron.right"
                      color="tintColor"
                    />
                  )}
                  <VStack alignment="leading" spacing={2}>
                    <Text font="body">{script.displayName}</Text>
                    <HStack spacing={4}>
                      {isPublishedByTool(script) ? (
                        <Image
                          systemName="checkmark.seal.fill"
                          foregroundStyle="systemGreen"
                          imageScale="small"
                        />
                      ) : null}
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        v{script.version} · {group ?? "默认"}
                      </Text>
                    </HStack>
                  </VStack>
                  <Spacer />
                  {isPinned && multiSelect.size === 0 ? (
                    <Image
                      systemName="pin.fill"
                      foregroundStyle="secondaryLabel"
                      imageScale="small"
                      padding={{ top: 2, trailing: 8 }}
                    />
                  ) : null}
                  <Image
                    systemName="play.circle.fill"
                    foregroundStyle="tintColor"
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => runScript(script)}
                  />
                </HStack>
              )
            })
          )}
        </Section>
      </List>
    </NavigationStack>
  )
}

// ==================== 设置页 ====================

function SettingsPage() {
  const dismiss = Navigation.useDismiss()
  const savedConfig = useMemo(resolveConfig, [])
  const savedGithub = useMemo(resolveGithubConfig, [])
  const [githubBackupEnabled, setGithubBackupEnabled] = useState(
    savedConfig.githubBackupEnabled
  )
  const [githubPublishEnabled, setGithubPublishEnabled] = useState(
    savedConfig.githubPublishEnabled
  )
  const [rememberExpandState, setRememberExpandState] = useState(
    savedConfig.rememberExpandState
  )
  // 发布与备份可分别配置账号；savedGithub.token/owner 为旧版共用字段，作为兼容回退
  const [publishToken, setPublishToken] = useState(
    savedGithub.publishToken || savedGithub.token
  )
  const [publishOwner, setPublishOwner] = useState(
    savedGithub.publishOwner || savedGithub.owner
  )
  const [repo, setRepo] = useState(savedGithub.repo)
  const [branch, setBranch] = useState(savedGithub.branch)
  const [path, setPath] = useState(savedGithub.path)
  const [backupToken, setBackupToken] = useState(
    savedGithub.backupToken || savedGithub.token
  )
  const [backupOwner, setBackupOwner] = useState(
    savedGithub.backupOwner || savedGithub.owner
  )
  const [backupRepo, setBackupRepo] = useState(savedGithub.backupRepo)
  const [backupBranch, setBackupBranch] = useState(savedGithub.backupBranch)
  const [backupPath, setBackupPath] = useState(savedGithub.backupPath)
  const [checking, setChecking] = useState(false)
  const [savedUI, setSavedUI] = useState(false)
  const [errorLogs, setErrorLogs] = useState(resolveErrorLogs)
  const { showToast, toastProps } = useToast()

  function collect(): GithubConfig {
    return {
      publishToken: publishToken.trim(),
      publishOwner: publishOwner.trim(),
      repo: repo.trim(),
      branch: branch.trim() || "main",
      path: path.trim(),
      backupToken: backupToken.trim(),
      backupOwner: backupOwner.trim(),
      backupRepo: backupRepo.trim(),
      backupBranch: backupBranch.trim() || "main",
      backupPath: backupPath.trim(),
      // 兼容旧字段：保存时同步两套字段，旧版字段与各自专用字段保持一致
      token: (publishToken.trim() || backupToken.trim()).trim(),
      owner: (publishOwner.trim() || backupOwner.trim()).trim(),
    }
  }

  function save() {
    const gh = collect()
    saveGithubConfig(gh)
    const next: AppConfig = {
      ...savedConfig,
      githubBackupEnabled,
      githubPublishEnabled,
      rememberExpandState,
    }
    // 关闭对应开关后，首页若停留在该 Github 目的地则回到 iPhone，避免显示已隐藏的选项
    if (!githubBackupEnabled && next.destination === "github_backup") {
      next.destination = "iphone"
    }
    if (!githubPublishEnabled && next.destination === "github_publish") {
      next.destination = "iphone"
    }
    saveConfig(next)
    // 保存动效：按钮变为「已保存」，随后自动关闭设置页，主页面立即生效
    withAnimation(() => {
      setSavedUI(true)
    })
    showToast("已保存设置")
    setTimeout(() => {
      dismiss("saved")
    }, 600)
  }

  async function verify() {
    const gh = collect()
    // 优先验证发布 Token，未填则回退到备份 Token
    const token = gh.publishToken || gh.backupToken
    if (!token) {
      showToast("请先填写 GitHub Token", true)
      return
    }
    setChecking(true)
    try {
      const login = await githubVerify(token)
      if (gh.publishToken) {
        if (!gh.publishOwner) {
          setPublishOwner(login)
        }
        saveGithubConfig({ ...gh, publishOwner: gh.publishOwner || login })
      } else {
        if (!gh.backupOwner) {
          setBackupOwner(login)
        }
        saveGithubConfig({ ...gh, backupOwner: gh.backupOwner || login })
      }
      showToast(`Token 有效：@${login}`)
    } catch (error) {
      logError("验证Token", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setChecking(false)
    }
  }

  return (
    <List
      navigationTitle="设置"
      navigationBarTitleDisplayMode="inline"
      toast={toastProps}
      toolbar={
        <Toolbar>
          <ToolbarItem placement="topBarTrailing">
            <Button
              title={checking ? "验证中…" : "验证 Token"}
              action={() => verify()}
            />
          </ToolbarItem>
        </Toolbar>
      }
    >
      {githubBackupEnabled ? (
        <Section
          header={<Text font="headline">GitHub 备份</Text>}
          footer={
            <Text font="footnote">
              首页「备份到 → Github备份」把脚本打包为 zip 上传到私密备份仓库，仅用于备份，不影响脚本更新链接。备份仓库不存在时会自动创建，默认私密。备份 Token 与所有者可独立于发布设置；若留空则自动沿用发布账号
            </Text>
          }
        >
          <TextField
            title="Token（备份）"
            value={backupToken}
            onChanged={setBackupToken}
            prompt="GitHub Personal Access Token"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            填 GitHub 个人访问令牌。获取：GitHub 网页 → 右上角头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限 → 生成后复制 ghp_… 粘贴到这里。备份可用独立 Token（与发布不同账号）；留空自动沿用发布 Token
          </Text>
          <TextField
            title="仓库所有者（备份）"
            value={backupOwner}
            onChanged={setBackupOwner}
            prompt="如 vvvvvveng"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            备份仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。备份可用独立所有者（不同账号）；留空自动沿用发布所有者
          </Text>
          <TextField
            title="备份仓库名（必填）"
            value={backupRepo}
            onChanged={setBackupRepo}
            prompt="如 scripting-backups"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            必填：存放备份 zip 的仓库名（私密）。若不存在，首次备份时会自动创建私密仓库，其他人不可见
          </Text>
          <TextField
            title="备份分支"
            value={backupBranch}
            onChanged={setBackupBranch}
            prompt="main"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            备份到的分支，一般用默认的 main，留空自动填 main
          </Text>
          <TextField
            title="仓库内目录"
            value={backupPath}
            onChanged={setBackupPath}
            prompt="留空为根目录，如 backups"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            备份 zip 放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 backups
          </Text>
        </Section>
      ) : null}

      {githubPublishEnabled ? (
        <Section
          header={<Text font="headline">GitHub 发布</Text>}
          footer={
            <Text font="footnote">
              首页「备份到 → Github发布」即可把脚本打包为 .scripting 上传到公开仓库并同步更新脚本的远程更新链接（remoteResource）。发布仓库不存在时会自动创建，默认公开。发布 Token 与所有者可独立于备份设置；若留空则自动沿用备份账号
            </Text>
          }
        >
          <TextField
            title="Token（发布）"
            value={publishToken}
            onChanged={setPublishToken}
            prompt="GitHub Personal Access Token"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            填 GitHub 个人访问令牌，与备份可用不同账号。获取方式同备份：GitHub 网页 → 头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限。留空自动沿用备份 Token
          </Text>
          <TextField
            title="仓库所有者（发布）"
            value={publishOwner}
            onChanged={setPublishOwner}
            prompt="如 vvvvvveng"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            发布仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。发布可用独立所有者（不同账号）；留空自动沿用备份所有者
          </Text>
          <TextField
            title="发布仓库名（必填）"
            value={repo}
            onChanged={setRepo}
            prompt="如 scripting-releases"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            必填：接收发布文件的仓库名（公开）。若不存在，首次发布时会自动创建公开仓库，无需手动建仓
          </Text>
          <TextField
            title="发布分支"
            value={branch}
            onChanged={setBranch}
            prompt="main"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            发布到的分支，一般用默认的 main，留空自动填 main。如仓库默认分支是 master 就填 master
          </Text>
          <TextField
            title="仓库内目录"
            value={path}
            onChanged={setPath}
            prompt="留空为根目录，如 releases"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            发布文件放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 releases。脚本会在该目录下按脚本名生成 .scripting 文件
          </Text>
        </Section>
      ) : null}

      <Section
        header={<Text font="headline">通用</Text>}
      >
        <Toggle
          title="Github备份"
          value={githubBackupEnabled}
          onChanged={setGithubBackupEnabled}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          勾选后显示「Github备份」配置与首页「备份到」入口（把脚本打包 zip 上传到私密仓库备份）
        </Text>
        <Toggle
          title="Github发布"
          value={githubPublishEnabled}
          onChanged={setGithubPublishEnabled}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          只有开发者才用得上：勾选后显示「Github发布」配置与首页「备份到」入口（把脚本作为可更新版本发布到公开仓库）
        </Text>
        <Toggle
          title="记住展开状态"
          value={rememberExpandState}
          onChanged={setRememberExpandState}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          勾选后记住首页左上角「备份 / 恢复」的展开 / 收起状态，下次打开仍保持（默认勾选）
        </Text>
      </Section>

      <Section>
        <HStack
          spacing={8}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={save}
        >
          <Spacer />
          <Image
            systemName={savedUI ? "checkmark.circle.fill" : "checkmark.circle"}
            foregroundStyle={savedUI ? "systemGreen" : "tintColor"}
          />
          <Text font="body" foregroundStyle={savedUI ? "systemGreen" : "tintColor"}>
            {savedUI ? "已保存 ✓" : "保存设置"}
          </Text>
          <Spacer />
        </HStack>
      </Section>

      <Section
        header={<Text font="headline">反馈</Text>}
        footer={
          <Text font="footnote">
            使用中遇到问题或有功能建议？欢迎到 WWWeng🐝的仓库提 Issue，或发邮件联系
          </Text>
        }
      >
        <Link url="https://github.com/vvvvvveng/Scripting-releases/tree/main">
          <HStack spacing={10}>
            <Image systemName="link" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              我的仓库
            </Text>
            <Spacer />
          </HStack>
        </Link>
        <Link url="https://t.me/WWWengShare">
          <HStack spacing={10}>
            <Image systemName="paperplane" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              我的频道
            </Text>
            <Spacer />
          </HStack>
        </Link>
        <Link url="mailto:skype-lavish-yeast@duck.com">
          <HStack spacing={10}>
            <Image systemName="envelope" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              我的邮箱
            </Text>
            <Spacer />
          </HStack>
        </Link>
      </Section>

      <Section
        header={<Text font="headline">错误记录</Text>}
        footer={
          <Text font="footnote">
            最近失败的备份 / 发布 / 恢复等操作会记录在这里（最多保留 50 条），方便排查问题
          </Text>
        }
      >
        {errorLogs.length === 0 ? (
          <EmptyState message="暂无错误记录" />
        ) : (
          errorLogs.slice(0, 20).map((log, index) => (
            <VStack key={`${log.time}-${index}`} alignment="leading" spacing={3}>
              <HStack spacing={8}>
                <Text font="caption" foregroundStyle="secondaryLabel">
                  {formatDate(log.time)}
                </Text>
                <Text font="caption" foregroundStyle="systemOrange">
                  {log.operation}
                </Text>
              </HStack>
              <Text font="caption" foregroundStyle="secondaryLabel">
                {log.message}
              </Text>
            </VStack>
          ))
        )}
        {errorLogs.length > 0 && (
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => {
              clearErrorLogs()
              setErrorLogs([])
              showToast("已清空错误记录")
            }}
          >
            <Spacer />
            <Image systemName="trash" foregroundStyle="systemRed" />
            <Text font="body" foregroundStyle="systemRed">清空错误记录</Text>
            <Spacer />
          </HStack>
        )}
      </Section>
    </List>
  )
}

// ==================== 分组选择 ====================

function GroupPickerPage({ onSelect }: { onSelect: (group: GroupInfo) => void }) {
  const dismiss = Navigation.useDismiss()
  const groups = useMemo(() => readScriptingGroups(), [])

  return (
    <List
      navigationTitle="选择分组"
      navigationBarTitleDisplayMode="inline"
    >
      <Section
        header={<Text font="headline">脚本分组</Text>}
        footer={
          <Text font="footnote">
            来自 Scripting 应用的分组（.scripting/settings.json），点击分组直接备份该组全部脚本
          </Text>
        }
      >
        {groups.length === 0 ? (
          <EmptyState message="没有可备份的分组" />
        ) : (
          groups.map((group) => (
            <HStack
              key={group.key}
              spacing={10}
              contentShape="rect"
              onTapGesture={() => {
                dismiss()
                onSelect(group)
              }}
            >
              <RowIcon systemName="folder.fill" />
              <Text font="body">{group.name}</Text>
              <Spacer />
              <Text font="caption" foregroundStyle="secondaryLabel">
                {group.scripts.length} 个脚本
              </Text>
              <Chevron />
            </HStack>
          ))
        )}
      </Section>
    </List>
  )
}

// ==================== 备份（按名称选择脚本） ====================

function ScriptPickerPage({
  initial,
  onSelect,
  pickerMode = "backup",
}: {
  initial: ScriptInfo[]
  onSelect: (scripts: ScriptInfo[]) => void
  pickerMode?: "backup" | "github"
}) {
  const dismiss = Navigation.useDismiss()
  const [allScripts, setAllScripts] = useState<ScriptInfo[]>([])
  const [scriptsLoading, setScriptsLoading] = useState(true)
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(initial.map((s) => s.folderName))
  )
  const [sortMode, setSortMode] = useState<"modified" | "name">(() =>
    resolveConfig().scriptSort === "name" ? "name" : "modified"
  )
  const { showToast, toastProps } = useToast()

  useEffect(() => {
    setTimeout(() => {
      setAllScripts(scanScripts())
      setScriptsLoading(false)
    }, 50)
  }, [])

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? allScripts.filter(
          (s) =>
            keywordMatches(s.displayName, keyword) ||
            keywordMatches(s.folderName, keyword)
        )
      : [...allScripts]
    list.sort((a, b) => compareScripts(a, b, sortMode))
    return list
  }, [allScripts, query, sortMode])

  function toggleOne(script: ScriptInfo) {
    const next = new Set(selected)
    if (next.has(script.folderName)) {
      next.delete(script.folderName)
    } else {
      next.add(script.folderName)
    }
    setSelected(next)
  }

  const isGithub = pickerMode === "github"
  const allSelected =
    filtered.length > 0 && filtered.every((s) => selected.has(s.folderName))

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      const allOn =
        filtered.length > 0 && filtered.every((s) => next.has(s.folderName))
      if (allOn) {
        filtered.forEach((s) => next.delete(s.folderName))
      } else {
        filtered.forEach((s) => next.add(s.folderName))
      }
      return next
    })
  }

  function clearSelection() {
    setSelected(new Set())
  }

  function done() {
    const picked = allScripts.filter((s) => selected.has(s.folderName))
    if (picked.length === 0) {
      showToast("请至少选择一个脚本", true)
      return
    }
    dismiss()
    onSelect(picked)
  }

  /** 点击单个脚本：直接开始备份/发布该脚本 */
  function backupOne(script: ScriptInfo) {
    dismiss()
    onSelect([script])
  }

  return (
    <List
      navigationTitle={isGithub ? "选择要发布的脚本" : "选择要备份的脚本"}
      navigationBarTitleDisplayMode="inline"
      toast={toastProps}
      toolbar={
        <Toolbar>
          <ToolbarItem placement="topBarTrailing">
            <Button title="取消" action={() => dismiss()} />
          </ToolbarItem>
        </Toolbar>
      }
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content:
            selected.size > 0 ? (
              <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => dismiss()}
                >
                  <Image systemName="chevron.left" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    返回
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={clearSelection}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    取消
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName="checklist"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? "取消全选" : "全选"}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={done}
                >
                  <Image systemName="checkmark.circle" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {isGithub ? "发布" : "备份"}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
            ) : (
              <></>
            ),
        },
      }}
    >
      <Section
        header={
          <HStack spacing={8} alignment="center">
            <Text font="headline">脚本列表（共 {allScripts.length} 个脚本）</Text>
            <Spacer />
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const next = String(value) === "name" ? "name" : "modified"
                setSortMode(next)
                saveConfig({ ...resolveConfig(), scriptSort: next })
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name" ? "按名称 A-Z" : "按最新修改"}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">按最新修改</Text>
              <Text tag="name">按名称 A-Z</Text>
            </Picker>
          </HStack>
        }
        footer={
          <VStack
            alignment="leading"
            spacing={2}
            padding={{ top: 8, bottom: 24 }}
          >
            <Text font="caption" foregroundStyle="secondaryLabel">
              点击脚本名：直接开始备份/发布该脚本
            </Text>
            <Text font="caption" foregroundStyle="secondaryLabel">
              长按脚本名：进入多选模式，可勾选多个后统一备份/发布
            </Text>
          </VStack>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt="搜索脚本名"
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {scriptsLoading ? (
          <EmptyState message="正在加载脚本…" />
        ) : filtered.length === 0 ? (
          <EmptyState message="未找到匹配的脚本" />
        ) : (
          filtered.map((script) => {
            const isOn = selected.has(script.folderName)
            return (
              <HStack
                key={script.folderName}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(script)
                  } else {
                    backupOne(script)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => toggleOne(script),
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName="chevron.left.forwardslash.chevron.right"
                    color="tintColor"
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{script.displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    v{script.version} · {script.folderName}
                  </Text>
                </VStack>
                <Spacer />
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（备份列表） ====================

function RestorePage({ destination }: { destination: Destination }) {
  const [query, setQuery] = useState("")
  const [items, setItems] = useState<BackupItem[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [scriptCounts, setScriptCounts] = useState<Map<string, number>>(new Map())
  const { showToast, toastProps } = useToast()

  /** 列表加载完成后，后台逐个统计备份脚本数（缓存命中直接显示，否则解压统计后写缓存） */
  function countScriptsInBackground(list: BackupItem[]) {
    const counts = new Map<string, number>()
    let index = 0
    function next() {
      if (index >= list.length) {
        return
      }
      const item = list[index]
      index += 1
      const cached = getBackupScriptCount(destination, item)
      if (cached != null) {
        counts.set(item.path, cached)
        setScriptCounts(new Map(counts))
        next()
        return
      }
      // 逐个让出主线程，避免一次性解压全部卡住 UI
      setTimeout(() => {
        try {
          const count = computeBackupScriptCount(item)
          counts.set(item.path, count)
          saveBackupScriptCount(destination, item, count)
        } catch {
          counts.set(item.path, -1)
        }
        setScriptCounts(new Map(counts))
        next()
      }, 30)
    }
    next()
  }

  useEffect(() => {
    setScriptCounts(new Map())
    setLoading(true)
    setTimeout(() => {
      const list = scanBackups(destination)
      setItems(list)
      setLoading(false)
      countScriptsInBackground(list)
    }, 50)
  }, [destination])

  const visibleItems = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    if (!keyword) {
      return items
    }
    return items.filter((item) => keywordMatches(item.name, keyword))
  }, [items, query])

  const selectedItems = items.filter((item) => selected.has(item.path))
  const allSelected =
    visibleItems.length > 0 && visibleItems.every((item) => selected.has(item.path))

  function refresh() {
    setScriptCounts(new Map())
    setLoading(true)
    setTimeout(() => {
      const list = scanBackups(destination)
      setItems(list)
      setLoading(false)
      countScriptsInBackground(list)
    }, 50)
  }

  function toggleOne(item: BackupItem) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(item.path)) {
        next.delete(item.path)
      } else {
        next.add(item.path)
      }
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      if (allSelected) {
        visibleItems.forEach((item) => next.delete(item.path))
      } else {
        visibleItems.forEach((item) => next.add(item.path))
      }
      return next
    })
  }

  async function doDeleteSelected() {
    if (selectedItems.length === 0) {
      showToast("请先选择要删除的备份", true)
      return
    }
    const index = await Dialog.actionSheet({
      title: "删除备份",
      message: `确定删除 ${selectedItems.length} 个备份？此操作不可恢复。`,
      actions: [{ label: "取消" }, { label: "删除", destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    let okCount = 0
    for (const item of selectedItems) {
      if (deleteLocalBackup(item)) {
        okCount += 1
      }
    }
    if (okCount > 0) {
      showToast(`已删除 ${okCount} 个备份`)
      notifyBackupChange()
    } else {
      showToast("删除失败", true)
    }
    setSelected(new Set())
    refresh()
  }

  async function doShareSelected() {
    if (selectedItems.length === 0) {
      showToast("请先选择要分享的备份", true)
      return
    }
    try {
      await shareLocalBackups(selectedItems)
    } catch (error) {
      logError("分享备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doRenameSelected() {
    if (selectedItems.length === 0) {
      showToast("请先选择要重命名的备份", true)
      return
    }
    if (selectedItems.length > 1) {
      showToast("重命名仅支持单选备份", true)
      return
    }
    const item = selectedItems[0]
    const name = await inputPrompt({
      title: "重命名备份",
      message: "输入新的备份名称",
      defaultValue: item.name,
      placeholder: item.name,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameLocalBackup(item, name.trim())
      showToast("已重命名")
      setSelected(new Set())
      refresh()
    } catch (error) {
      logError("重命名备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function openBackup(item: BackupItem) {
    if (refreshing) {
      return
    }
    setRefreshing(true)
    try {
      const inspected = inspectBackup(item)
      if (!inspected) {
        showToast("无法读取该备份", true)
        return
      }
      const { candidates, tempDir } = inspected
      if (candidates.length === 0) {
        showToast("该备份中没有找到脚本（缺少 script.json）", true)
        cleanupTemp(tempDir)
        return
      }
      if (candidates.length === 1) {
        const ok = await confirmRestoreOne(candidates[0])
        if (ok) {
          await restoreScripts([candidates[0]], true)
          showToast("已恢复")
          refresh()
        }
        cleanupTemp(tempDir)
        return
      }
      // 多个脚本：让用户选择单个或全部恢复（支持搜索、全选）
      const result = await Navigation.present(
        <ScriptSelectionPage candidates={candidates} />
      )
      if (result?.restored != null) {
        showToast(`已恢复 ${result.restored} 个脚本`)
        refresh()
      }
      cleanupTemp(tempDir)
    } catch (error) {
      logError("恢复备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setRefreshing(false)
    }
  }

  function cleanupTemp(tempDir: string | null) {
    if (tempDir && pathExists(tempDir)) {
      try {
        FileManager.removeSync(tempDir)
      } catch {
        // ignore
      }
    }
  }

  const toolbar = (
    <Toolbar>
      <ToolbarItem placement="topBarTrailing">
        <Button title="刷新" action={refresh} />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle="恢复备份"
      navigationBarTitleDisplayMode="inline"
      toolbar={toolbar}
      toast={toastProps}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: selected.size > 0 ? (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 1 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                {items.length === 1 || !allSelected ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => {
                      setSelected(new Set())
                    }}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      取消
                    </Text>
                  </VStack>
                ) : null}
                {items.length > 1 ? (
                  <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName={allSelected ? "checkmark.circle.fill" : "checkmark.circle"}
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? "取消全选" : "全选"}
                  </Text>
                </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doDeleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    删除
                  </Text>
                </VStack>
                {selectedItems.length === 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doRenameSelected}
                  >
                    <Image systemName="pencil" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      重命名
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doShareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    分享
                  </Text>
                </VStack>
              </HStack>
            </VStack>
          ) : (
            <></>
          ),
        },
      }}
    >
      <Section
        header={
          <Text font="headline">
            备份列表（本地 {destination === "icloud" ? "iCloud" : "iPhone"}）· 共{" "}
            {items.length} 个
          </Text>
        }
        footer={
          <Text font="footnote">备份目录：{backupRootFor(destination)}</Text>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt="搜索备份"
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {loading ? (
          <EmptyState message="正在读取备份…" />
        ) : visibleItems.length === 0 ? (
          <EmptyState message="暂无备份，先到首页开始备份吧" />
        ) : (
          visibleItems.map((item) => {
            const isOn = selected.has(item.path)
            return (
              <HStack
                key={item.path}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(item)
                  } else {
                    openBackup(item)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    toggleOne(item)
                  },
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName={
                      item.path.toLowerCase().endsWith(".zip")
                        ? "doc.zipper"
                        : "chevron.left.forwardslash.chevron.right"
                    }
                    color="tintColor"
                    small={!item.path.toLowerCase().endsWith(".zip")}
                    leftPad={
                      item.path.toLowerCase().endsWith(".zip") ? 0 : -3
                    }
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{item.name}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {formatDate(item.modifiedAt)} · {formatBytes(item.byteSize)}
                    {selected.size > 0
                      ? ""
                      : ` · ${
                          scriptCounts.has(item.path)
                            ? scriptCounts.get(item.path)! >= 0
                              ? `${scriptCounts.get(item.path)} 个脚本`
                              : "未知"
                            : "统计中…"
                        }`}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（Github 备份仓库） ====================

/** 从 GitHub 私密备份仓库列出并下载 zip 恢复脚本 */
function GithubRestorePage() {
  const [query, setQuery] = useState("")
  const [items, setItems] = useState<{ name: string; path: string; size: number }[]>([])
  const [manifest, setManifest] = useState<GithubBackupManifest | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const { showToast, toastProps } = useToast()
  const gh = useMemo(
    () => resolveBackupGithubConfig(resolveGithubConfig()),
    []
  )

  const visibleItems = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    if (!keyword) {
      return items
    }
    return items.filter((item) => keywordMatches(item.name, keyword))
  }, [items, query])

  const selectedItems = items.filter((item) => selected.has(item.path))
  const allSelected =
    visibleItems.length > 0 && visibleItems.every((item) => selected.has(item.path))

  async function reload() {
    setLoading(true)
    try {
      const [list, meta] = await Promise.all([
        listGithubBackups(gh),
        readGithubBackupManifest(gh),
      ])
      setItems(list)
      setManifest(meta)
    } catch (error) {
      logError("Github备份列表", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setLoading(false)
    }
  }

  // 进入页面时拉取一次列表
  useEffect(() => {
    reload()
  }, [])

  function toggleOne(item: { name: string; path: string; size: number }) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(item.path)) {
        next.delete(item.path)
      } else {
        next.add(item.path)
      }
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      if (allSelected) {
        visibleItems.forEach((item) => next.delete(item.path))
      } else {
        visibleItems.forEach((item) => next.add(item.path))
      }
      return next
    })
  }

  async function doDeleteSelected() {
    if (selectedItems.length === 0) {
      showToast("请先选择要删除的备份", true)
      return
    }
    const index = await Dialog.actionSheet({
      title: "删除备份",
      message: `确定删除 ${selectedItems.length} 个远端备份？此操作不可恢复。`,
      actions: [{ label: "取消" }, { label: "删除", destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    let okCount = 0
    for (const item of selectedItems) {
      try {
        await deleteGithubBackup(gh, item.path)
        okCount += 1
      } catch (error) {
        logError("Github备份删除", error)
      }
    }
    if (okCount > 0) {
      showToast(`已删除 ${okCount} 个备份`)
      notifyBackupChange()
    } else {
      showToast("删除失败", true)
    }
    setSelected(new Set())
    reload()
  }

  async function doShareSelected() {
    if (selectedItems.length === 0) {
      showToast("请先选择要分享的备份", true)
      return
    }
    try {
      await shareGithubBackups(gh, selectedItems)
    } catch (error) {
      logError("分享Github备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doRenameSelected() {
    if (selectedItems.length === 0) {
      showToast("请先选择要重命名的备份", true)
      return
    }
    if (selectedItems.length > 1) {
      showToast("重命名仅支持单选备份", true)
      return
    }
    const item = selectedItems[0]
    const lower = item.name.toLowerCase()
    const base = lower.endsWith(".scripting")
      ? item.name.slice(0, -10)
      : lower.endsWith(".zip")
        ? item.name.slice(0, -4)
        : item.name
    const name = await inputPrompt({
      title: "重命名备份",
      message: "输入新的备份名称",
      defaultValue: base,
      placeholder: base,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      await renameGithubBackup(gh, item, name.trim())
      showToast("已重命名")
      setSelected(new Set())
      reload()
    } catch (error) {
      logError("重命名Github备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 下载远端 zip → 解开 → 恢复（单脚本确认 / 多脚本选择） */
  async function openGithubBackup(item: { name: string; path: string; size: number }) {
    if (refreshing) {
      return
    }
    setRefreshing(true)
    showToast(`正在下载 ${item.name}…`)
    let tempDir: string | null = null
    try {
      const zipPath = await downloadGithubBackup(gh, item.path)
      const inspected = inspectBackup({
        name: item.name,
        path: zipPath,
        isZip: true,
        modifiedAt: Date.now(),
        byteSize: item.size,
        scriptCount: 0,
      })
      if (!inspected) {
        showToast("无法读取该备份", true)
        return
      }
      tempDir = inspected.tempDir
      const candidates = inspected.candidates
      if (candidates.length === 0) {
        showToast("该备份中没有找到脚本（缺少 script.json）", true)
        return
      }
      if (candidates.length === 1) {
        const ok = await confirmRestoreOne(candidates[0])
        if (ok) {
          await restoreScripts([candidates[0]], true)
          showToast("已恢复")
        }
        return
      }
      const result = await Navigation.present(
        <ScriptSelectionPage candidates={candidates} />
      )
      if (result?.restored != null) {
        showToast(`已恢复 ${result.restored} 个脚本`)
      }
    } catch (error) {
      logError("Github备份恢复", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (tempDir && pathExists(tempDir)) {
        try {
          FileManager.removeSync(tempDir)
        } catch {}
      }
      setRefreshing(false)
    }
  }

  const toolbar = (
    <Toolbar>
      <ToolbarItem placement="topBarTrailing">
        <Button
          title={refreshing ? "加载中…" : "刷新"}
          action={() => reload()}
        />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle="恢复备份"
      navigationBarTitleDisplayMode="inline"
      toast={toastProps}
      toolbar={toolbar}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: selected.size > 0 ? (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 1 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                {items.length === 1 || !allSelected ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => {
                      setSelected(new Set())
                    }}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      取消
                    </Text>
                  </VStack>
                ) : null}
                {items.length > 1 ? (
                  <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName={allSelected ? "checkmark.circle.fill" : "checkmark.circle"}
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? "取消全选" : "全选"}
                  </Text>
                </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doDeleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    删除
                  </Text>
                </VStack>
                {selectedItems.length === 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doRenameSelected}
                  >
                    <Image systemName="pencil" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      重命名
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doShareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    分享
                  </Text>
                </VStack>
              </HStack>
            </VStack>
          ) : (
            <></>
          ),
        },
      }}
    >
      <Section
        header={
          <Text font="headline">备份列表（Github备份仓库 · 共 {items.length} 个）</Text>
        }
        footer={
          <VStack alignment="leading" spacing={4}>
            <Text font="footnote">
              {gh.backupPath
                ? `仓库目录：${gh.backupPath}（${gh.owner}/${gh.backupRepo}）`
                : `仓库：${gh.owner}/${gh.backupRepo}`}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              备份、删除的文件受网络传输影响不会立马成功，耐心等待即可
            </Text>
          </VStack>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt="搜索备份"
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {loading ? (
          <EmptyState message="正在读取备份仓库…" />
        ) : visibleItems.length === 0 ? (
          <EmptyState message="备份仓库里暂无备份，先到首页开始备份吧" />
        ) : (
          visibleItems.map((item) => {
            const isOn = selected.has(item.path)
            const lower = item.name.toLowerCase()
            const displayName = lower.endsWith(".scripting")
              ? item.name.slice(0, -10)
              : lower.endsWith(".zip")
                ? item.name.slice(0, -4)
                : item.name
            return (
              <HStack
                key={item.path}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(item)
                  } else {
                    openGithubBackup(item)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    toggleOne(item)
                  },
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName={
                      lower.endsWith(".zip")
                        ? "doc.zipper"
                        : "chevron.left.forwardslash.chevron.right"
                    }
                    color="tintColor"
                    small={!lower.endsWith(".zip")}
                    leftPad={lower.endsWith(".zip") ? 0 : -3}
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {formatBytes(item.size)}
                    {manifest?.backups[item.path]
                      ? ` · ${formatDate(manifest.backups[item.path].createdAt)} · ${
                          manifest.backups[item.path].scriptCount
                        } 个脚本`
                      : " · 未知"}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（多脚本选择：搜索 + 全选 + 单恢复/全部恢复） ====================

function ScriptSelectionPage({
  candidates,
}: {
  candidates: CandidateScript[]
}) {
  const dismiss = Navigation.useDismiss()
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [busy, setBusy] = useState(false)
  const [sortMode, setSortMode] = useState<"modified" | "name">(() =>
    resolveConfig().scriptSort === "name" ? "name" : "modified"
  )
  const { showToast, toastProps } = useToast()

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    let list = keyword
      ? candidates.filter((c) => keywordMatches(c.folderName, keyword))
      : [...candidates]
    list.sort((a, b) => {
      if (sortMode === "name") {
        return compareNames(a.folderName, b.folderName)
      }
      return (b.modifiedAt ?? 0) - (a.modifiedAt ?? 0)
    })
    return list
  }, [candidates, query, sortMode])

  const allSelected =
    filtered.length > 0 && filtered.every((c) => selected.has(c.folderName))

  function toggleOne(candidate: CandidateScript) {
    const next = new Set(selected)
    if (next.has(candidate.folderName)) {
      next.delete(candidate.folderName)
    } else {
      next.add(candidate.folderName)
    }
    setSelected(next)
  }

  function toggleAll() {
    const next = new Set(selected)
    if (allSelected) {
      filtered.forEach((c) => next.delete(c.folderName))
    } else {
      filtered.forEach((c) => next.add(c.folderName))
    }
    setSelected(next)
  }

  async function doRestore(restoreAll: boolean) {
    if (busy) {
      return
    }
    const targets = restoreAll
      ? candidates
      : candidates.filter((c) => selected.has(c.folderName))
    if (targets.length === 0) {
      showToast("请先选择要恢复的脚本", true)
      return
    }

    const conflicts = targets.filter((c) =>
      pathExists(Path.join(FileManager.scriptsDirectory, c.folderName))
    )
    if (conflicts.length > 0) {
      const names = conflicts.map((c) => c.folderName).join("、")
      const index = await Dialog.actionSheet({
        title: "覆盖确认",
        message: `以下 ${conflicts.length} 个脚本已存在，恢复将覆盖当前版本：\n${names}`,
        actions: [{ label: "取消" }, { label: "覆盖并恢复", destructive: true }],
        cancelButton: false,
      })
      if (index !== 1) {
        return
      }
    }

    setBusy(true)
    try {
      const { restored } = await restoreScripts(targets, true)
      dismiss({ restored: restored.length })
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
      setBusy(false)
    }
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="选择要恢复的脚本"
        navigationBarTitleDisplayMode="inline"
        toast={toastProps}
        safeAreaInset={{
          bottom: {
            alignment: "center",
            spacing: 8,
            content: (
              <VStack alignment="center" padding={{ bottom: 10 }}>
                <HStack
                  spacing={10}
                  alignment="center"
                  padding={{ horizontal: 10, vertical: 8 }}
                  background={{
                    style: { color: "secondarySystemBackground", opacity: 0.95 },
                    shape: { type: "rect", cornerRadius: 20 },
                  }}
                >
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => dismiss(null)}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      取消
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={toggleAll}
                  >
                    <Image
                      systemName="checklist"
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    />
                    <Text
                      font="caption2"
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    >
                      {allSelected ? "取消全选" : "全选"}
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => doRestore(true)}
                  >
                    <Image systemName="checkmark.circle" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      全部
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => doRestore(false)}
                  >
                    <Image systemName="arrow.uturn.backward" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {busy ? "恢复中…" : `恢复 (${selected.size})`}
                    </Text>
                  </VStack>
                </HStack>
              </VStack>
            ),
          },
        }}
      >
        <Section
          header={
            <HStack spacing={8} alignment="center">
              <Text font="headline">这个备份里有 {candidates.length} 个脚本</Text>
              <Spacer />
              <Picker
                value={sortMode}
                onChanged={(value: string | number) => {
                  const next = String(value) === "name" ? "name" : "modified"
                  setSortMode(next)
                  saveConfig({ ...resolveConfig(), scriptSort: next })
                }}
                pickerStyle="menu"
                padding={{ trailing: -12 }}
                label={
                  <HStack spacing={4}>
                    <Image
                      systemName="arrow.up.arrow.down"
                      foregroundStyle="secondaryLabel"
                    />
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      {sortMode === "name" ? "按名称 A-Z" : "按最新修改"}
                    </Text>
                  </HStack>
                }
              >
                <Text tag="modified">按最新修改</Text>
                <Text tag="name">按名称 A-Z</Text>
              </Picker>
            </HStack>
          }
        />

        <Section>
          <HStack spacing={8}>
            <TextField
              value={query}
              onChanged={setQuery}
              prompt="搜索脚本名"
              label={
                <Image
                  systemName="magnifyingglass"
                  foregroundStyle="secondaryLabel"
                />
              }
            />
            {query.length > 0 ? (
              <HStack
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => setQuery("")}
              >
                <Image
                  systemName="xmark.circle.fill"
                  foregroundStyle="secondaryLabel"
                />
              </HStack>
            ) : null}
          </HStack>
        </Section>

        <Section header={<Text font="headline">脚本列表</Text>}>
          {filtered.length === 0 ? (
            <EmptyState message="未找到匹配的脚本" />
          ) : (
            filtered.map((candidate) => {
              const isOn = selected.has(candidate.folderName)
              const metaLine = [
                candidate.version ? `v${candidate.version}` : null,
                candidate.modifiedAt ? formatDate(candidate.modifiedAt) : null,
              ]
                .filter(Boolean)
                .join(" · ")
              return (
                <HStack
                  key={candidate.folderName}
                  spacing={10}
                  contentShape="rect"
                  onTapGesture={() => toggleOne(candidate)}
                >
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                  <VStack alignment="leading" spacing={2}>
                    <Text font="body">{candidate.folderName}</Text>
                    {metaLine ? (
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        {metaLine}
                      </Text>
                    ) : null}
                  </VStack>
                  <Spacer />
                </HStack>
              )
            })
          )}
        </Section>
      </List>
    </NavigationStack>
  )
}

// ==================== 脚本管理 ====================

function ManagePage() {
  const [query, setQuery] = useState("")
  const [editMode, setEditMode] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [refresh, setRefresh] = useState(0)
  const [scripts, setScripts] = useState<ScriptInfo[]>([])
  const [scriptsLoading, setScriptsLoading] = useState(true)
  const { showToast, toastProps } = useToast()

  useEffect(() => {
    setScriptsLoading(true)
    setTimeout(() => {
      setScripts(scanScripts())
      setScriptsLoading(false)
    }, 50)
  }, [refresh])

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    if (!keyword) {
      return scripts
    }
    return scripts.filter(
      (s) =>
        keywordMatches(s.displayName, keyword) ||
        keywordMatches(s.folderName, keyword)
    )
  }, [scripts, query])

  // 一次性构建 文件夹→分组 映射，避免每行重复全量扫描
  const groupNameMap = useMemo(() => buildGroupNameMap(), [refresh])

  const selectedScripts = scripts.filter((s) => selected.has(s.folderName))
  const allSelected =
    filtered.length > 0 && filtered.every((s) => selected.has(s.folderName))

  function refreshScripts() {
    setSelected(new Set())
    setRefresh((v) => v + 1)
  }

  function toggleOne(script: ScriptInfo) {
    const next = new Set(selected)
    if (next.has(script.folderName)) {
      next.delete(script.folderName)
    } else {
      next.add(script.folderName)
    }
    setSelected(next)
  }

  function toggleAll() {
    const next = new Set(selected)
    if (allSelected) {
      filtered.forEach((s) => next.delete(s.folderName))
    } else {
      filtered.forEach((s) => next.add(s.folderName))
    }
    setSelected(next)
  }

  async function doRename(script: ScriptInfo) {
    const name = await inputPrompt({
      title: "重命名脚本",
      message: "输入新的脚本名称",
      defaultValue: script.folderName,
      placeholder: script.folderName,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameScript(script, name.trim())
      refreshScripts()
      showToast("已重命名")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doMoveToGroup(script: ScriptInfo) {
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast("没有可移动的分组", true)
      return
    }
    const index = await Dialog.actionSheet({
      title: "移动到分组",
      message: `把「${script.displayName}」移动到哪个分组？`,
      actions: [
        { label: "取消" },
        ...named.map((g) => ({ label: g.name })),
      ],
      cancelButton: false,
    })
    if (index == null || index === 0) {
      return
    }
    const target = named[index - 1]
    try {
      moveScriptToGroup(script, target.name)
      refreshScripts()
      showToast(`已移动到「${target.name}」`)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doChangeVersion(script: ScriptInfo) {
    if (!(await ensureVersionNotOverridden(script))) {
      return
    }
    const version = await inputPrompt({
      title: "修改版本号",
      message: "输入新的版本号（格式 x.y.z，例如 1.0.1）",
      defaultValue: script.version,
      placeholder: script.version,
      keyboardType: "numbersAndPunctuation",
    })
    if (version == null || !version.trim()) {
      return
    }
    try {
      setScriptVersion(script, version.trim())
      refreshScripts()
      showToast("版本号已更新")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doShare(list: ScriptInfo[]) {
    if (list.length === 0) {
      showToast("请先选择脚本", true)
      return
    }
    try {
      await shareScripts(list)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doDelete(list: ScriptInfo[]) {
    if (list.length === 0) {
      showToast("请先选择脚本", true)
      return
    }
    const index = await Dialog.actionSheet({
      title: "删除确认",
      message: `确定删除 ${list.length} 个脚本？此操作不可恢复。`,
      actions: [{ label: "取消" }, { label: "删除", destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    try {
      for (const script of list) {
        deleteScript(script)
      }
      refreshScripts()
      showToast("已删除")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 复制该脚本的 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]） */
  async function copyScriptShareLink(script: ScriptInfo) {
    const link = buildScriptImportLink(script)
    if (!link) {
      showToast("该脚本没有发布链接，请先发布", true)
      return
    }
    try {
      await Pasteboard.setString(link)
      showToast("导入链接已复制")
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function rowActions(script: ScriptInfo) {
    const group = groupNameForScript(script.folderName)
    const actions: Array<{ label: string; destructive?: boolean }> = [
      { label: "重命名" },
      { label: "移动到其他分组" },
    ]
    if (resolveConfig().githubPublishEnabled && hasPublishedLink(script)) {
      actions.push({ label: "分享(链接)" })
      actions.push({ label: "分享(文件)" })
    } else {
      actions.push({ label: "分享" })
    }
    actions.push({ label: "修改版本号" })
    actions.push({ label: "删除", destructive: true })

    const index = await Dialog.actionSheet({
      title: script.displayName,
      message: `版本 ${script.version} · ${formatDate(script.modifiedAt)} · ${formatBytes(script.byteSize)} · 分组 ${group ?? "默认"}`,
      actions,
    })
    if (index == null) {
      return
    }
    const action = actions[index]
    if (!action) {
      return
    }
    switch (action.label) {
      case "重命名":
        await doRename(script)
        break
      case "移动到其他分组":
        await doMoveToGroup(script)
        break
      case "分享(链接)":
        await copyScriptShareLink(script)
        break
      case "分享(文件)":
      case "分享":
        await doShare([script])
        break
      case "修改版本号":
        await doChangeVersion(script)
        break
      case "删除":
        await doDelete([script])
        break
    }
  }

  /** 左划操作已改用 trailingSwipeActions（重命名/移到其他分组） */

  const toolbar = editMode ? (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button
          title={allSelected ? "取消全选" : "全选"}
          action={toggleAll}
        />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button title="完成" action={() => setEditMode(false)} />
      </ToolbarItem>
    </Toolbar>
  ) : (
    <Toolbar>
      <ToolbarItem placement="topBarTrailing">
        <Button title="选择" action={() => setEditMode(true)} />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle="脚本管理"
      navigationBarTitleDisplayMode="inline"
      toolbar={toolbar}
      toast={toastProps}
    >
      <Section>
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt="搜索脚本名"
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
      </Section>

      {editMode ? (
        <Section
          header={<Text font="headline">批量操作</Text>}
          footer={
            <Text font="footnote">
              已选 {selectedScripts.length} 个脚本；点击行可勾选/取消
            </Text>
          }
        >
          <HStack
            spacing={10}
            contentShape="rect"
            onTapGesture={toggleAll}
          >
            <Image
              systemName={allSelected ? "checkmark.circle.fill" : "circle"}
              foregroundStyle={allSelected ? "systemBlue" : "secondaryLabel"}
            />
            <Text font="body">{allSelected ? "取消全选" : "全选"}</Text>
            <Spacer />
            <Text font="caption" foregroundStyle="secondaryLabel">
              已选 {selected.size} 个
            </Text>
          </HStack>
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => doDelete(selectedScripts)}
          >
            <Spacer />
            <Image systemName="trash" foregroundStyle="systemRed" />
            <Text font="body" foregroundStyle="systemRed">
              删除选中 ({selectedScripts.length})
            </Text>
            <Spacer />
          </HStack>
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => doShare(selectedScripts)}
          >
            <Spacer />
            <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              分享选中 ({selectedScripts.length})
            </Text>
            <Spacer />
          </HStack>
        </Section>
      ) : null}

      <Section
        header={<Text font="headline">脚本列表（{filtered.length}）</Text>}
        footer={
          <Text font="footnote">
            {editMode ? "勾选脚本后可用下方按钮批量删除/分享" : "点击脚本可重命名、分享、修改版本号或删除"}
          </Text>
        }
      >
        {scriptsLoading ? (
          <EmptyState message="正在加载脚本…" />
        ) : filtered.length === 0 ? (
          <EmptyState message="没有找到脚本" />
        ) : (
          filtered.map((script) => {
            const isOn = selected.has(script.folderName)
            const group = groupNameMap.get(script.folderName) ?? null
            return (
              <HStack
                key={script.folderName}
                spacing={10}
                contentShape="rect"
                onTapGesture={() => {
                  if (editMode) {
                    toggleOne(script)
                  } else {
                    rowActions(script)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    if (!editMode) {
                      setEditMode(true)
                    }
                    toggleOne(script)
                  },
                }}
                trailingSwipeActions={{
                  allowsFullSwipe: true,
                  actions: [
                    <Button
                      title="重命名"
                      tint="systemBlue"
                      action={() => doRename(script)}
                    />,
                    <Button
                      title="移到其他分组"
                      tint="orange"
                      action={() => doMoveToGroup(script)}
                    />,
                  ],
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName="chevron.left.forwardslash.chevron.right"
                    color="tintColor"
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{script.displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    v{script.version} · {formatDate(script.modifiedAt)}
                    {group ? ` · ${group}` : " · 默认"}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 入口 ====================

async function run() {
  await Navigation.present({
    element: <MainPage />,
    modalPresentationStyle: "fullScreen",
  })
  Script.exit()
}

// 被 home_screen_default_ui.tsx 作为首页标签复用时，不应自动运行入口
if (Script.env !== "home_screen") {
  run()
}