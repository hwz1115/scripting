import { Path, Script } from "scripting"
import {
  BackupItem,
  backupScripts,
  clearErrorLogs,
  computeBackupScriptCount,
  getBackupScriptCount,
  groupNameForScript,
  isGithubBackupConfigured,
  isGithubConfigured,
  logError,
  pathExists,
  readScriptingGroups,
  resolveConfig,
  resolveErrorLogs,
  resolveGithubConfig,
  saveBackupScriptCount,
  saveGithubConfig,
  scanBackups,
  scanGroups,
  scanScripts,
  scanScriptDirsInTree,
  statSize,
  zipMd5,
} from "./manager"

/** 冒烟测试：验证模块导入、目录扫描、zip 备份/解压核心链路（不触碰真实脚本目录） */
async function smoke() {
  const log: string[] = []

  try {
    const scripts = scanScripts()
    log.push(`scanScripts: ${scripts.length} 个脚本, 首个=${scripts[0]?.folderName ?? "-"}`)
  } catch (e: any) {
    log.push("scanScripts FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const groups = readScriptingGroups()
    log.push(`readScriptingGroups: ${groups.length} 个分组: ${groups.map((g) => `${g.name}(${g.scripts.length})`).join(", ")}`)
  } catch (e: any) {
    log.push("readScriptingGroups FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const groups = scanGroups()
    log.push(`scanGroups: ${groups.length} 个分组: ${groups.map((g) => g.name).join(", ")}`)
  } catch (e: any) {
    log.push("scanGroups FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const scripts = scanScripts()
    const first = scripts[0]
    const group = first ? groupNameForScript(first.folderName) : null
    log.push(`groupNameForScript: ${first?.folderName ?? "-"} → ${group ?? "默认"}`)
  } catch (e: any) {
    log.push("groupNameForScript FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const github = resolveGithubConfig()
    log.push(`resolveGithubConfig: token=${github.token ? github.token.slice(0, 4) + "***" : "空"} owner=${github.owner || "空"} repo=${github.repo || "空"} backupRepo=${github.backupRepo || "空"} configured=${isGithubConfigured(github)} backupConfigured=${isGithubBackupConfigured(github)}`)
    saveGithubConfig({ ...github, branch: "main", backupBranch: "main" })
    log.push("saveGithubConfig: ok")
  } catch (e: any) {
    log.push("github config FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const config = resolveConfig()
    log.push(`resolveConfig: destination=${config.destination} scope=${config.scope} githubBackupEnabled=${config.githubBackupEnabled} githubPublishEnabled=${config.githubPublishEnabled}`)
  } catch (e: any) {
    log.push("resolveConfig FAIL: " + (e?.message ?? String(e)))
  }

  try {
    clearErrorLogs()
    logError("冒烟测试", new Error("测试错误记录"))
    const logs = resolveErrorLogs()
    log.push(`errorLogs: count=${logs.length} first=${logs[0]?.operation ?? "-"} msg=${logs[0]?.message ?? "-"}`)
    clearErrorLogs()
  } catch (e: any) {
    log.push("errorLogs FAIL: " + (e?.message ?? String(e)))
  }

  const stage = Path.join(FileManager.temporaryDirectory, "smoke-script-root")
  if (pathExists(stage)) FileManager.removeSync(stage)
  FileManager.createDirectorySync(stage, true)
  const fake = Path.join(stage, "冒烟测试脚本")
  FileManager.createDirectorySync(fake, true)
  FileManager.writeAsStringSync(
    Path.join(fake, "script.json"),
    JSON.stringify({ name: "冒烟测试脚本", version: "9.9.9" })
  )
  FileManager.writeAsStringSync(Path.join(fake, "index.tsx"), "// smoke")

  try {
    const zipped = await backupScripts(
      [
        {
          folderName: "冒烟测试脚本",
          displayName: "冒烟测试脚本",
          path: fake,
          version: "9.9.9",
          modifiedAt: Date.now(),
          byteSize: 0,
        },
      ],
      "iphone",
      "smoke_test"
    )
    const zippedExists = pathExists(zipped)
    log.push(`backupScripts: exists=${zippedExists} ${zipped}`)
    if (zippedExists) {
      try {
        log.push(`backupSize: ${statSize(zipped)} bytes`)
      } catch (e: any) {
        log.push("backupSize FAIL: " + (e?.message ?? String(e)))
      }
      const unz = Path.join(FileManager.temporaryDirectory, "smoke-unzip")
      if (pathExists(unz)) FileManager.removeSync(unz)
      FileManager.createDirectorySync(unz, true)
      FileManager.unzipSync(zipped, unz)
      const found = scanScriptDirsInTree(unz)
      log.push(
        `unzip scanScriptDirsInTree: ${found.length} 个脚本: ${found.map((f) => f.folderName).join(", ")}`
      )
      FileManager.removeSync(unz)
      FileManager.removeSync(zipped)
    }
  } catch (e: any) {
    log.push("backup FAIL: " + (e?.message ?? String(e)))
  }

  // 脚本数缓存闭环：目录备份 → 计算 → 写入 → 读回
  try {
    const dirItem: BackupItem = {
      name: "冒烟测试脚本",
      path: fake,
      isZip: false,
      modifiedAt: Date.now(),
      byteSize: 0,
      scriptCount: 0,
    }
    const computed = computeBackupScriptCount(dirItem)
    saveBackupScriptCount("iphone", dirItem, computed)
    const cached = getBackupScriptCount("iphone", dirItem)
    log.push(`backupScriptCount: computed=${computed} cached=${cached} match=${computed === cached}`)
  } catch (e: any) {
    log.push("backupScriptCount FAIL: " + (e?.message ?? String(e)))
  }
  FileManager.removeSync(stage)

  console.log("SMOKE RESULT:")
  for (const line of log) console.log(line)
  const ok = log.every((l) => !l.includes("FAIL"))
  console.log(ok ? "SMOKE PASS" : "SMOKE FAIL")
  Script.exit()
}

smoke()