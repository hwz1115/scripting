import { Path, Script } from "scripting"
import {
  BackupItem,
  backupScripts,
  channelMonitorIntervalSeconds,
  clearErrorLogs,
  computeBackupScriptCount,
  getBackupScriptCount,
  groupNameForScript,
  isGithubBackupConfigured,
  isGithubConfigured,
  logError,
  DEFAULT_CHANNEL_EXCLUDE_KEYWORDS,
  normalizeChannelExcludeKeywords,
  normalizeChannelIgnoredPaths,
  isChannelScriptExcluded,
  normalizeChannelMonitorLinks,
  normalizeRepoUrl,
  pathExists,
  readScriptingGroups,
  repoDisplayName,
  repoParts,
  resolveConfig,
  resolveErrorLogs,
  resolveGithubConfig,
  saveBackupScriptCount,
  saveGithubConfig,
  scanBackups,
  scanGroups,
  scanScripts,
  scanScriptDirsInTree,
  statSize,
  zipMd5,
} from "./manager"

/** 冒烟测试：验证模块导入、目录扫描、zip 备份/解压核心链路（不触碰真实脚本目录） */
async function smoke() {
  const log: string[] = []

  try {
    const scripts = scanScripts()
    log.push(`scanScripts: ${scripts.length} 个脚本, 首个=${scripts[0]?.folderName ?? "-"}`)
  } catch (e: any) {
    log.push("scanScripts FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const groups = readScriptingGroups()
    log.push(`readScriptingGroups: ${groups.length} 个分组: ${groups.map((g) => `${g.name}(${g.scripts.length})`).join(", ")}`)
  } catch (e: any) {
    log.push("readScriptingGroups FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const groups = scanGroups()
    log.push(`scanGroups: ${groups.length} 个分组: ${groups.map((g) => g.name).join(", ")}`)
  } catch (e: any) {
    log.push("scanGroups FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const scripts = scanScripts()
    const first = scripts[0]
    const group = first ? groupNameForScript(first.folderName) : null
    log.push(`groupNameForScript: ${first?.folderName ?? "-"} → ${group ?? "默认"}`)
  } catch (e: any) {
    log.push("groupNameForScript FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const github = resolveGithubConfig()
    log.push(`resolveGithubConfig: token=${github.token ? github.token.slice(0, 4) + "***" : "空"} owner=${github.owner || "空"} repo=${github.repo || "空"} backupRepo=${github.backupRepo || "空"} configured=${isGithubConfigured(github)} backupConfigured=${isGithubBackupConfigured(github)}`)
    saveGithubConfig({ ...github, branch: "main", backupBranch: "main" })
    log.push("saveGithubConfig: ok")
  } catch (e: any) {
    log.push("github config FAIL: " + (e?.message ?? String(e)))
  }

  try {
    const config = resolveConfig()
    log.push(`resolveConfig: destination=${config.destination} scope=${config.scope} githubBackupEnabled=${config.githubBackupEnabled} githubPublishEnabled=${config.githubPublishEnabled}`)
  } catch (e: any) {
    log.push("resolveConfig FAIL: " + (e?.message ?? String(e)))
  }

  try {
    clearErrorLogs()
    logError("冒烟测试", new Error("测试错误记录"))
    const logs = resolveErrorLogs()
    log.push(`errorLogs: count=${logs.length} first=${logs[0]?.operation ?? "-"} msg=${logs[0]?.message ?? "-"}`)
    clearErrorLogs()
  } catch (e: any) {
    log.push("errorLogs FAIL: " + (e?.message ?? String(e)))
  }

  // 频道监控：链接解析 / 规范化 / 间隔换算 / 配置默认值
  try {
    const cases: [string, string | null][] = [
      ["https://github.com/vvvvvveng/Scripting-releases", "https://github.com/vvvvvveng/Scripting-releases"],
      ["github.com/vvvvvveng/Scripting-releases/", "https://github.com/vvvvvveng/Scripting-releases"],
      ["vvvvvveng/Scripting-releases.git", "https://github.com/vvvvvveng/Scripting-releases"],
      ["https://github.com/vvvvvveng", null],
      ["", null],
    ]
    for (const [input, expect] of cases) {
      const got = normalizeRepoUrl(input)
      if (got !== expect) throw new Error(`normalizeRepoUrl(${input}) = ${got}, expect ${expect}`)
    }
    if (repoDisplayName("https://github.com/vvvvvveng/Scripting-releases") !== "vvvvvveng/Scripting-releases")
      throw new Error("repoDisplayName fail")
    const norm = normalizeChannelMonitorLinks([
      { url: "  ", name: "x" },
      { url: "github.com/vvvvvveng/Scripting-releases/", name: "  " },
      { url: "https://github.com/vvvvvveng/Scripting-releases", name: "重复" },
    ])
    if (norm.length !== 1) throw new Error(`normalizeChannelMonitorLinks dedupe fail: ${norm.length}`)
    if (norm[0].name !== "vvvvvveng/Scripting-releases") throw new Error("auto name fail: " + norm[0].name)
    const empty = normalizeChannelMonitorLinks([])
    if (empty.length !== 1 || empty[0].url !== "https://github.com/vvvvvveng/Scripting-releases")
      throw new Error("default link fail")
    if (empty[0].name !== "WWWeng🐝的脚本仓库") throw new Error("default link name fail: " + empty[0].name)
    if (channelMonitorIntervalSeconds(60, "minute") !== 3600) throw new Error("minute fail")
    if (channelMonitorIntervalSeconds(1, "hour") !== 3600) throw new Error("hour fail")
    if (channelMonitorIntervalSeconds(1, "day") !== 86400) throw new Error("day fail")
    if (channelMonitorIntervalSeconds(12, "hour") !== 43200) throw new Error("12h fail")
    const parts = repoParts("https://github.com/vvvvvveng/Scripting-releases")
    if (!parts || parts.owner !== "vvvvvveng" || parts.repo !== "Scripting-releases")
      throw new Error("repoParts fail: " + JSON.stringify(parts))
    if (repoParts("not-a-url") !== null) throw new Error("repoParts invalid fail")
    const cfg = resolveConfig()
    if (!cfg.channelMonitorLinks || cfg.channelMonitorLinks.length === 0)
      throw new Error("resolveConfig default links fail")
    // 排除关键词：规范化 + 命中判定
    const kw = normalizeChannelExcludeKeywords([" 测试 ", "", "测试", "发布"])
    if (kw.length !== 2 || kw[0] !== "测试" || kw[1] !== "发布")
      throw new Error("normalizeChannelExcludeKeywords fail: " + JSON.stringify(kw))
    if (!isChannelScriptExcluded("测试脚本2.scripting", kw))
      throw new Error("exclude keyword hit fail")
    if (isChannelScriptExcluded("脚本管理工具.scripting", kw))
      throw new Error("exclude keyword miss fail")
    if (isChannelScriptExcluded("测试脚本2.scripting", []))
      throw new Error("empty keywords should not exclude")
    // 默认排除关键词含「请勿下载」；resolveConfig 返回数组
    if (
      DEFAULT_CHANNEL_EXCLUDE_KEYWORDS.length !== 1 ||
      DEFAULT_CHANNEL_EXCLUDE_KEYWORDS[0] !== "请勿下载"
    )
      throw new Error("default exclude keywords fail")
    if (!Array.isArray(cfg.channelMonitorExcludeKeywords))
      throw new Error("channelMonitorExcludeKeywords not array")
    // 已忽略脚本路径：规范化 + 默认值
    const ignored = normalizeChannelIgnoredPaths([
      " https://github.com/vvvvvveng/Scripting-releases|脚本A.scripting ",
      "",
      "https://github.com/vvvvvveng/Scripting-releases|脚本A.scripting",
    ])
    if (ignored.length !== 1 || ignored[0] !== "https://github.com/vvvvvveng/Scripting-releases|脚本A.scripting")
      throw new Error("normalizeChannelIgnoredPaths fail: " + JSON.stringify(ignored))
    if (!Array.isArray(cfg.channelMonitorIgnoredPaths))
      throw new Error("channelMonitorIgnoredPaths not array")
    log.push(
      `channelMonitor: normalize ok, defaultLinks=${cfg.channelMonitorLinks[0].url} name=${cfg.channelMonitorLinks[0].name} interval=${cfg.channelMonitorInterval}${cfg.channelMonitorIntervalUnit} baseline=${cfg.channelMonitorBaselineReady} excludeKw=${kw.join(",")}`
    )
  } catch (e: any) {
    log.push("channelMonitor FAIL: " + (e?.message ?? String(e)))
  }

  const stage = Path.join(FileManager.temporaryDirectory, "smoke-script-root")
  if (pathExists(stage)) FileManager.removeSync(stage)
  FileManager.createDirectorySync(stage, true)
  const fake = Path.join(stage, "冒烟测试脚本")
  FileManager.createDirectorySync(fake, true)
  FileManager.writeAsStringSync(
    Path.join(fake, "script.json"),
    JSON.stringify({ name: "冒烟测试脚本", version: "9.9.9" })
  )
  FileManager.writeAsStringSync(Path.join(fake, "index.tsx"), "// smoke")

  try {
    const zipped = await backupScripts(
      [
        {
          folderName: "冒烟测试脚本",
          displayName: "冒烟测试脚本",
          path: fake,
          version: "9.9.9",
          modifiedAt: Date.now(),
          byteSize: 0,
        },
      ],
      "iphone",
      "smoke_test"
    )
    const zippedExists = pathExists(zipped)
    log.push(`backupScripts: exists=${zippedExists} ${zipped}`)
    if (zippedExists) {
      try {
        log.push(`backupSize: ${statSize(zipped)} bytes`)
      } catch (e: any) {
        log.push("backupSize FAIL: " + (e?.message ?? String(e)))
      }
      const unz = Path.join(FileManager.temporaryDirectory, "smoke-unzip")
      if (pathExists(unz)) FileManager.removeSync(unz)
      FileManager.createDirectorySync(unz, true)
      FileManager.unzipSync(zipped, unz)
      const found = scanScriptDirsInTree(unz)
      log.push(
        `unzip scanScriptDirsInTree: ${found.length} 个脚本: ${found.map((f) => f.folderName).join(", ")}`
      )
      FileManager.removeSync(unz)
      FileManager.removeSync(zipped)
    }
  } catch (e: any) {
    log.push("backup FAIL: " + (e?.message ?? String(e)))
  }

  // 脚本数缓存闭环：目录备份 → 计算 → 写入 → 读回
  try {
    const dirItem: BackupItem = {
      name: "冒烟测试脚本",
      path: fake,
      isZip: false,
      modifiedAt: Date.now(),
      byteSize: 0,
      scriptCount: 0,
    }
    const computed = computeBackupScriptCount(dirItem)
    saveBackupScriptCount("iphone", dirItem, computed)
    const cached = getBackupScriptCount("iphone", dirItem)
    log.push(`backupScriptCount: computed=${computed} cached=${cached} match=${computed === cached}`)
  } catch (e: any) {
    log.push("backupScriptCount FAIL: " + (e?.message ?? String(e)))
  }
  FileManager.removeSync(stage)

  console.log("SMOKE RESULT:")
  for (const line of log) console.log(line)
  const ok = log.every((l) => !l.includes("FAIL"))
  console.log(ok ? "SMOKE PASS" : "SMOKE FAIL")
  Script.exit()
}

smoke()