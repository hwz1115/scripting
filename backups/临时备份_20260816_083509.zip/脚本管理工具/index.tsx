// ===== 更新说明检查（脚本管理工具注入，勿删） =====
;(async () => {
  try {
    const note = "①新增仓库监控功能，可监控该仓库下所有新发布或者更新的脚本(可自动检测也可手动触发，可监控多个，支持关键字排除，暂时支持监控.scripting文件)\n②设置页面的Github备份和发布相关设置改为仅首次设置时展开，后续再次进入都为收起状态\n③调整多个脚本同时发布逻辑\n④单脚本发布加入上个脚本发送状态检测(不成功无法继续)\n⑤修复首页脚本管理列表双击切换置顶失败的Bug\r⑥优化发布时更新说明页面显示\r⑦设置页面改为自动保存\n⑧修复部分ios26下按钮提示显示不清问题\n⑨用户更新页面区按钮优化(忽略本次、不再更新、更新选中)，不再更新的脚本会被记录进设置项，后续可恢复"
    if (!note) return
    const version = "3.4.2"
    const scriptName = "脚本管理工具"
    if (!version) return
    const base = FileManager.appGroupDocumentsDirectory || ""
    if (!base) return
    const seenDir = base + "/changelog_seen"
    try { await FileManager.createDirectory(seenDir, true) } catch (e) {}
    const statePath = seenDir + "/" + scriptName + ".json"
    let seen: Record<string, boolean> = {}
    try { seen = JSON.parse(await FileManager.readAsString(statePath)) || {} } catch (e) {}
    if (seen[version]) return
    await new Promise<void>((resolve) => setTimeout(() => resolve(), 600))
    const { Navigation, NavigationStack, ScrollView, VStack, HStack, Text, Button, Divider, Spacer } = await import("scripting")
    const markSeen = async () => {
      try {
        seen[version] = true
        await FileManager.writeAsString(statePath, JSON.stringify(seen))
      } catch (e) {}
    }
    function ChangelogView(props: { note: string; version: string; scriptName: string }) {
      const dismiss = Navigation.useDismiss()
      return (
        <NavigationStack>
          <VStack navigationTitle={props.scriptName + " · 更新说明"} navigationBarTitleDisplayMode="inline" navigationBarBackButtonHidden spacing={0}>
            <ScrollView>
              <VStack alignment="leading" spacing={10} padding={16}>
                <Text font="headline" bold foregroundStyle="secondaryLabel">版本 {props.version}</Text>
                <Divider />
                <Text font="body">{props.note}</Text>
              </VStack>
            </ScrollView>
            <Divider />
            <HStack spacing={10} padding={16}>
              <Button action={() => { markSeen(); dismiss() }} buttonStyle="bordered" controlSize="large">
                <Text font="footnote" foregroundStyle="secondaryLabel">此版不再显示</Text>
              </Button>
              <Button action={() => dismiss()} buttonStyle="borderedProminent" controlSize="large">
                <Text font="footnote" bold>稍候再看说明</Text>
              </Button>
            </HStack>
          </VStack>
        </NavigationStack>
      )
    }
    await Navigation.present({
      element: <ChangelogView note={note} version={version} scriptName={scriptName} />,
    })
  } catch (e) {}
})();
// ===== 更新说明检查结束 =====



















import {
  Button,
  DragGesture,
  HStack,
  Image,
  Link,
  List,
  Navigation,
  NavigationLink,
  NavigationStack,
  Notification,
  Path,
  Picker,
  Rectangle,
  Script,
  ScrollViewProxy,
  ScrollViewReader,
  Section,
  Spacer,
  Text,
  TextField,
  Toggle,
  Toolbar,
  ToolbarItem,
  VStack,
  ZStack,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "scripting"
import {
  APP_NAME,
  AppConfig,
  BackupItem,
  BackupScopeKey,
  CandidateScript,
  ChannelCheckResult,
  ChannelCheckSummary,
  ChannelMonitorLink,
  Destination,
  GroupInfo,
  GithubConfig,
  GithubBackupManifest,
  ScriptInfo,
  backupRootFor,
  backupScripts,
  backupScriptsToGithub,
  clearErrorLogs,
  computeBackupScriptCount,
  deleteGithubBackup,
  deleteLocalBackup,
  deleteScript,
  disableScriptAutoUpdate,
  dismissChannelRemoved,
  dismissChannelUpdates,
  downloadGithubBackup,
  fetchScriptCloudMeta,
  formatBytes,
  formatDate,
  githubVerify,
  buildGroupNameMap,
  channelMonitorIntervalSeconds,
  getBackupScriptCount,
  getScriptRemoteResource,
  groupNameForScript,
  inspectBackup,
  isGithubBackupConfigured,
  isGithubConfigured,
  listGithubBackups,
  logError,
  moveScriptToGroup,
  normalizeChannelExcludeKeywords,
  normalizeChannelIgnoredPaths,
  normalizeChannelMonitorLinks,
  normalizeRepoUrl,
  pathExists,
  publishScriptsToGithub,
  renameScript,
  repoDisplayName,
  repoParts,
  resolveRawScriptUrl,
  resolveConfig,
  resolveGithubConfig,
  resolvePublishGithubConfig,
  resolveBackupGithubConfig,
  restoreScripts,
  runChannelMonitorCheck,
  readLastChannelCheck,
  readScriptChangelog,
  injectChangelogChecker,
  safeFileName,
  saveBackupScriptCount,
  saveConfig,
  saveGithubConfig,
  scanBackups,
  readGithubBackupManifest,
  readScriptingGroups,
  renameGithubBackup,
  renameLocalBackup,
  resolveErrorLogs,
  scanGroups,
  scanScripts,
  scanScriptDirsInTree,
  scriptDirFingerprint,
  scriptInfoFromDir,
  scriptZipSize,
  setScriptVersion,
  setScriptChangelog,
  shareGithubBackups,
  sortGithubBackupsByTime,
  shareLocalBackups,
  shareScripts,
  timestampForName,
  updateChannelMonitorConfig,
} from "./manager"
import { t, tpl, setLanguage, subscribeLanguageChange } from "./lang"

// 初始化界面语言（设置页可切换 中文/English，默认中文）
setLanguage(resolveConfig().language)

// Dialog 全局模块：alert / confirm / prompt / actionSheet（与其他脚本一致，类型宽松处理）
declare const Dialog: any
// 打开系统浏览器统一用 Safari.openURL（全局命名空间，无需 import；运行时无全局 openURL）
// confirm 为全局确认框（返回 Promise<boolean>），类型宽松处理避免与全局声明冲突时用 any
declare const confirm: any
type PromptOptions = {
  title: string
  message?: string
  defaultValue?: string
  obscureText?: boolean
  selectAll?: boolean
  placeholder?: string
  cancelLabel?: string
  confirmLabel?: string
  keyboardType?: string
}
function inputPrompt(options: PromptOptions): Promise<string | null> {
  return Dialog.prompt(options)
}

/** 移动到分组的弹窗里把「内置脚本」排到「取消」正下方（第二位），其余分组保持原顺序 */
function orderGroupsForMove(named: GroupInfo[]): GroupInfo[] {
  return [
    ...named.filter((g) => g.name === "内置脚本"),
    ...named.filter((g) => g.name !== "内置脚本"),
  ]
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/**
 * 仓库监控：检测到变化时发系统通知（列出各仓库变更的脚本，最多各列 10 个）。
 * 变更通知立即送达；点通知会运行本脚本并再次检查。
 */
async function notifyChannelChanges(results: ChannelCheckResult[]) {
  const changed = results.filter((r) => r.ok && r.changes.length > 0)
  if (changed.length === 0) return
  let total = 0
  const lines: string[] = []
  for (const r of changed) {
    const names = r.changes
      .map((c) => c.path.replace(/\.scripting$/i, ""))
      .slice(0, 10)
    lines.push(`${r.name}（${r.changes.length}）: ${names.join("、")}`)
    total += r.changes.length
  }
  try {
    const title =
      changed.length === 1
        ? tpl("「{name}」：{n} 个脚本有更新", {
            name: changed[0].name,
            n: String(total),
          })
        : tpl("仓库监控：{n} 个脚本有更新", {
            n: String(total),
          })
    await Notification.schedule({
      title,
      body: lines.join("\n").slice(0, 500),
      threadIdentifier: "channel-monitor",
    })
  } catch (error) {
    logError("仓库监控通知", error)
  }
}

/**
 * 移除通知中心里已送达的「有更新」通知（threadIdentifier=channel-monitor）。
 * 弹出更新页后调用，避免残留的旧通知被再次点击时重复打开更新页。
 */
async function removeDeliveredChannelUpdateNotifications() {
  try {
    const infos = await Notification.getAllDeliveredsOfCurrentScript()
    const ids = infos
      .map((info) => {
        const tid =
          info.request?.content?.threadIdentifier ?? info.threadIdentifier
        return tid === "channel-monitor" ? info.request?.identifier : null
      })
      .filter((x): x is string => Boolean(x))
    if (ids.length > 0) {
      await Notification.removeDelivereds(ids)
    }
  } catch {
    // ignore
  }
}

/**
 * 仓库监控变化集合签名：把一次检查的变化集编码成字符串，用于「同一批变化只自动弹一次更新页」去重。
 * 用户关闭更新页后，只要仓库没有新变化，定时循环不会再重复弹。
 */
function channelChangesSignature(results: ChannelCheckResult[]): string {
  const parts: string[] = []
  for (const r of results) {
    if (!r.ok) continue
    for (const c of r.changes) {
      // sha 参与签名：同一文件每次新发布（sha 变）视为新一批变化；同一批变化（sha 相同）可去重
      parts.push(`${r.url}|${c.type}|${c.path}|${c.sha ?? ""}`)
    }
  }
  return parts.sort().join("\n")
}

/** 已忽略脚本路径（`仓库url|脚本路径`）的展示：拆成脚本名 + 仓库显示名 */
function ignoredPathDisplay(
  key: string
): { name: string; repo: string } {
  const sep = key.indexOf("|")
  if (sep < 0) return { name: key, repo: "" }
  const url = key.slice(0, sep)
  const path = key.slice(sep + 1)
  return {
    name: path.replace(/\.scripting$/i, ""),
    repo: repoDisplayName(url),
  }
}

/** 判断通知是否为仓库监控通知，是则返回其 threadIdentifier，否则返回 null */
function channelNotificationThreadId(
  info: any
): "channel-monitor" | "channel-monitor-reminder" | null {
  if (!info) return null
  const tid = info.request?.content?.threadIdentifier ?? info.threadIdentifier
  if (tid === "channel-monitor" || tid === "channel-monitor-reminder") {
    return tid
  }
  return null
}

/**
 * 等待脚本内容稳定后再备份：每轮间隔 1.2s 重扫目录，连续两次目录指纹一致才认为内容已稳定，
 * 返回重扫后的最新 ScriptInfo（保证备份到的是刷新后的内容）。
 * 期间若版本又被修改则返回 null（放弃本次自动备份，下一次扫描会按新基线重新触发）。
 */
async function waitForStableScripts(
  changed: ScriptInfo[],
  expected: Record<string, string>
): Promise<ScriptInfo[] | null> {
  let prevFp: string[] | null = null
  let latest: ScriptInfo[] = changed
  for (let attempt = 0; attempt < 4; attempt++) {
    await sleep(1200)
    const fresh = changed
      .map((s) => scriptInfoFromDir(s.path))
      .filter((s): s is ScriptInfo => s !== null)
    if (fresh.length === 0) {
      return null
    }
    // 版本被再次修改：放弃本次，让下一次扫描按新基线重新触发
    const versionMoved = fresh.some(
      (s) => (s.version ?? "") !== (expected[s.folderName] ?? "")
    )
    if (versionMoved) {
      return null
    }
    const fp = fresh.map((s) => scriptDirFingerprint(s.path))
    if (prevFp != null && fp.join("\u0001") === prevFp.join("\u0001")) {
      return fresh
    }
    prevFp = fp
    latest = fresh
  }
  return latest
}

/**
 * 修改版本号前检查脚本是否开启自动更新：带 remoteResource 的脚本由 Scripting 管理远程更新，
 * 本地修改的版本号在下一次应用云端更新时会被云端版本替换。这里给用户两个选择：
 * 「直接修改」保留更新链接，改动仅本地生效；「修改并关闭自动更新」则彻底避免被云端覆盖。
 * 返回 false 表示用户取消。
 */
async function ensureVersionNotOverridden(script: ScriptInfo): Promise<boolean> {
  const remote = getScriptRemoteResource(script)
  if (!remote || remote.autoUpdateInterval == null) {
    return true
  }
  const index = await Dialog.actionSheet({
    title: t("该脚本开启了自动更新"),
    message:
      tpl("「{name}」配置了远程自动更新（约每 {interval} 秒检查一次）。", { name: script.displayName, interval: String(remote.autoUpdateInterval) }) +
      t(`修改的版本号会保留到下一次应用云端更新为止（应用后版本号会被替换为云端版本）。`) +
      t(`也可以选择同时关闭自动更新（保留更新链接，之后可重新开启），避免后续被云端覆盖。`),
    actions: [
      { label: t("取消") },
      { label: t("直接修改") },
      { label: t("修改并关闭自动更新") },
    ],
    cancelButton: false,
  })
  if (index == null || index === 0) {
    return false
  }
  if (index === 2) {
    disableScriptAutoUpdate(script)
  }
  return true
}

// ==================== 通用小组件 ====================

function useToast() {
  const [toast, setToast] = useState<{
    msg: string
    isError: boolean
  }>({ msg: "", isError: false })
  const showToast = (msg: string, isError = false) => setToast({ msg, isError })
  const toastProps = {
    isPresented: toast.msg !== "",
    onChanged: (v: boolean) => {
      if (!v) setToast({ msg: "", isError: false })
    },
    content: (
      <HStack spacing={6} alignment="center">
        <Image
          systemName={toast.isError ? "exclamationmark.triangle.fill" : "checkmark.circle.fill"}
          foregroundStyle={toast.isError ? "systemRed" : "systemGreen"}
        />
        <Text font="body" foregroundStyle="white">
          {toast.msg}
        </Text>
      </HStack>
    ),
    // 强制深色背景：旧系统默认黑底白字，iOS 26 上默认背景变浅色，白字会看不清
    backgroundColor: "black" as const,
    textColor: "white" as const,
    position: "top" as const,
    duration: 2,
  }
  return { toast, showToast, toastProps }
}

function RowIcon({
  systemName,
  color = "tintColor",
  small = false,
  leftPad = 0,
}: {
  systemName: string
  color?: any
  small?: boolean
  leftPad?: number
}) {
  return (
    <Image
      systemName={systemName}
      foregroundStyle={color}
      imageScale={small ? "small" : undefined}
      padding={leftPad !== 0 ? { leading: leftPad } : undefined}
    />
  )
}

function Chevron({ color = "tertiaryLabel" }: { color?: any }) {
  return <Image systemName="chevron.right" foregroundStyle={color} />
}

function EmptyState({ message }: { message: string }) {
  return (
    <VStack alignment="center" spacing={8} padding={{ vertical: 16 }}>
      <Image systemName="tray" foregroundStyle="secondaryLabel" />
      <Text foregroundStyle="secondaryLabel">{message}</Text>
    </VStack>
  )
}

/** 名称比较：拉丁字母/数字开头的排前面（A-Z），中文按拼音排序，大小写不敏感 */
function compareNames(a: string, b: string): number {
  const la = a.toLowerCase()
  const lb = b.toLowerCase()
  const aLatin = /^[a-z0-9]/.test(la)
  const bLatin = /^[a-z0-9]/.test(lb)
  if (aLatin !== bLatin) {
    return aLatin ? -1 : 1
  }
  return la.localeCompare(lb, "zh-Hans-CN") || a.localeCompare(b, "zh-Hans-CN")
}

/** 脚本排序比较：按名称 A-Z / Z-A，或按最新修改（倒序） */
function compareScripts(
  a: ScriptInfo,
  b: ScriptInfo,
  mode: "modified" | "name" | "name_desc"
): number {
  if (mode === "name") {
    return (
      compareNames(a.displayName, b.displayName) ||
      compareNames(a.folderName, b.folderName)
    )
  }
  if (mode === "name_desc") {
    return (
      compareNames(b.displayName, a.displayName) ||
      compareNames(b.folderName, a.folderName)
    )
  }
  return b.modifiedAt - a.modifiedAt
}

/**
 * 关键字匹配：关键字需作为独立“词”出现（前后不能是字母/数字/下划线），
 * 避免搜 “tg” 误匹配到 “ChatGPT反代” 这类名字里嵌着子串的脚本。
 * 中文字符视为词边界，因此 “tg” 能匹配 “TG频道 / 我的tg / v2rayTG”。
 */
function keywordMatches(text: string, keyword: string): boolean {
  const kw = keyword.trim().toLowerCase()
  if (!kw) return true
  const escaped = kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
  return new RegExp(
    `(^|[^a-z0-9_])${escaped}|${escaped}([^a-z0-9_]|$)`,
    "i"
  ).test(text)
}

/** 生成 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]，urls 值为 URL 编码的 JSON 数组） */
function buildImportLinkFromUrl(url: string): string {
  const urls = JSON.stringify([url])
  return `https://scripting.fun/import_scripts?urls=${encodeURIComponent(urls)}`
}

/** 生成脚本的 Scripting 导入链接，无发布链接返回 null */
function buildScriptImportLink(script: ScriptInfo): string | null {
  const remote = getScriptRemoteResource(script)
  if (!remote?.url) {
    return null
  }
  return buildImportLinkFromUrl(remote.url)
}

/** 脚本是否已发布（script.json 里有远程链接） */
function hasPublishedLink(script: ScriptInfo): boolean {
  return getScriptRemoteResource(script)?.url != null
}

/** 脚本是否由本工具发布到本人 GitHub 仓库（remoteResource 为 raw.githubusercontent.com 的 .scripting 链接，且 owner 为当前发布账号） */
function isPublishedByTool(script: ScriptInfo): boolean {
  const url = getScriptRemoteResource(script)?.url
  if (
    !url ||
    !url.startsWith("https://raw.githubusercontent.com/") ||
    !url.endsWith(".scripting")
  ) {
    return false
  }
  const gh = resolvePublishGithubConfig(resolveGithubConfig())
  if (!gh.owner) {
    return false
  }
  return url.startsWith(`https://raw.githubusercontent.com/${gh.owner}/`)
}

/**
 * 脚本是否「云端与本地不同步」：由本工具发布过，且本地版本号与云端版本号不一致。
 * 云端版本优先取「上次发布时记录的版本」（publishedVersions），无发布记录的历史发布脚本
 * 取「下载读取的云端版本缓存」（cloudVersions）。两者都无则视为同步。
 */
function isCloudDesynced(
  script: ScriptInfo,
  publishedVersions: Record<string, string>,
  cloudVersions: Record<string, string>
): boolean {
  if (!isPublishedByTool(script)) {
    return false
  }
  const cloud =
    publishedVersions[script.folderName] ?? cloudVersions[script.folderName]
  return cloud != null && cloud !== (script.version ?? "")
}

/** 备份数据变更订阅：恢复页删除/重命名备份后，通知首页刷新备份计数 */
let backupChangeListeners: Array<() => void> = []
function subscribeBackupChange(fn: () => void): () => void {
  backupChangeListeners.push(fn)
  return () => {
    backupChangeListeners = backupChangeListeners.filter((f) => f !== fn)
  }
}
function notifyBackupChange() {
  backupChangeListeners.forEach((fn) => fn())
}

/** 确认恢复单个脚本（存在同名时提示覆盖），供主页面与恢复页共用 */
async function confirmRestoreOne(candidate: CandidateScript): Promise<boolean> {
  const exists = pathExists(
    Path.join(FileManager.scriptsDirectory, candidate.folderName)
  )
  const index = await Dialog.actionSheet({
    title: t("恢复脚本"),
    message: exists
      ? tpl("将恢复脚本「{name}」，目录中已存在同名脚本，恢复会覆盖当前版本。", { name: candidate.folderName })
      : tpl("将恢复脚本「{name}」到 Scripting 脚本目录。", { name: candidate.folderName }),
    actions: [
      { label: t("取消") },
      { label: exists ? t("覆盖并恢复") : t("恢复"), destructive: exists },
    ],
    cancelButton: false,
  })
  return index === 1
}

// ==================== 主页面 ====================

export function MainPage() {
  const dismiss = Navigation.useDismiss()
  const [config, setConfigState] = useState<AppConfig>(resolveConfig)
  const [selectedGroup, setSelectedGroup] = useState<GroupInfo | null>(null)
  const [selectedScripts, setSelectedScripts] = useState<ScriptInfo[]>([])
  const [busy, setBusy] = useState(false)
  // 当前忙碌操作类型：发布（Github发布）时显示「正在发布…」，其余显示「正在备份…」
  const [busyAction, setBusyAction] = useState<"backup" | "publish">("backup")
  const [backupVersion, setBackupVersion] = useState(0)
  const [backupCount, setBackupCount] = useState(0)
  // 订阅备份变更（恢复页删除/重命名备份后触发），返回主页时刷新「N 个备份」
  useEffect(() => {
    const unsub = subscribeBackupChange(() => setBackupVersion((v) => v + 1))
    return unsub
  }, [])
  // 订阅语言切换：语言变化时强制重渲染以刷新文案
  useEffect(() => {
    const unsub = subscribeLanguageChange(() => setBackupVersion((v) => v + 1))
    return unsub
  }, [])

  /**
   * 仓库监控循环：打开即查 + 按间隔定时检查 + 到点提醒通知 + 后台保活（尽力而为）。
   * 开启状态/间隔/链接变化时重建（关闭后清理定时器与提醒通知）。
   * 首次检查只建立基线不提示；之后检测到 .scripting 变化才发通知 + 弹提示。
   */
  async function runMonitorCycle(): Promise<ChannelCheckSummary | null> {
    const cfg = resolveConfig()
    if (!cfg.channelMonitorEnabled) return null
    const summary = await runChannelMonitorCheck()
    if (summary.newBaseline) {
      // 首次只记录基线，不打扰
      return summary
    }
    if (summary.totalChanges > 0) {
      // 同一批变化只弹一次：签名持久化到配置，跨实例/重启后仍能去重；
      // sha 参与签名，同一文件每次新发布（sha 变）会作为新一批变化正常提示
      const sig = channelChangesSignature(summary.results)
      // 重新读配置再比较：多个实例（首页常驻 + 新打开脚本）并发检查时，
      // 另一实例可能刚把同一批签名写入配置；用函数开头读到的旧配置判断会漏掉去重导致重复弹窗
      const freshCfg = resolveConfig()
      const alreadyNotified =
        sig !== "" &&
        (sig === freshCfg.channelMonitorNotifiedSig ||
          sig === lastAutoPresentSigRef.current)
      if (sig && !alreadyNotified) {
        updateChannelMonitorConfig({ channelMonitorNotifiedSig: sig })
        lastAutoPresentSigRef.current = sig
        notifyChannelChanges(summary.results)
        showToast(
          tpl("仓库监控：发现 {n} 个脚本有更新", {
            n: String(summary.totalChanges),
          })
        )
        // 应用内直接跳转更新页，无需点击通知
        setTimeout(() => {
          Navigation.present({
            element: <ChannelUpdatePage />,
            modalPresentationStyle: "overFullScreen",
          })
          removeDeliveredChannelUpdateNotifications()
        }, 350)
      }
    }
    return summary
  }

  useEffect(() => {
    const cfg = resolveConfig()
    if (!cfg.channelMonitorEnabled) return
    const seconds = Math.max(
      channelMonitorIntervalSeconds(
        cfg.channelMonitorInterval,
        cfg.channelMonitorIntervalUnit
      ),
      60
    )
    // 打开即查 + 定时循环：首查延迟到首屏渲染完成，之后按间隔循环（setTimeout 递归，避免依赖未暴露的 setInterval）
    let timer: ReturnType<typeof setTimeout> | null = null
    const loop = () => {
      runMonitorCycle()
      timer = setTimeout(loop, seconds * 1000)
    }
    const openTimer = setTimeout(loop, 1500)
    // 到点提醒通知：按间隔重复，点通知会运行本脚本并立即检查。
    // 先清掉该脚本已有的 pending 通知，避免多次进入（多实例/重开）叠加出多份重复提醒
    Notification.removeAllPendingsOfCurrentScript().catch(() => {})
    Notification.schedule({
      title: t("仓库监控提醒"),
      body: t("点击检查监控的仓库是否有脚本更新"),
      trigger: new TimeIntervalNotificationTrigger({
        timeInterval: seconds,
        repeats: true,
      }),
      threadIdentifier: "channel-monitor-reminder",
    })
    // 后台保活：仅主应用环境可用；尽力而为，系统仍可能挂起
    if (Script.env === "index") {
      BackgroundKeeper.keepAlive()
    }
    return () => {
      clearTimeout(openTimer)
      if (timer != null) clearTimeout(timer)
      Notification.removeAllPendingsOfCurrentScript()
      if (Script.env === "index") {
        BackgroundKeeper.stopKeepAlive()
      }
    }
  }, [
    config.channelMonitorEnabled,
    config.channelMonitorInterval,
    config.channelMonitorIntervalUnit,
    config.channelMonitorLinks,
  ])

  /**
   * 仓库监控通知点击跳转：点「有更新」通知直接打开更新页；
   * 点「提醒」通知先补查一次，有变化才打开更新页。
   * 全新实例（脚本由点通知启动）走 Notification.current；应用已在运行时走 onResume。
   */
  useEffect(() => {
    async function handleNotificationTap(
      tid: "channel-monitor" | "channel-monitor-reminder" | null
    ) {
      if (!tid) return
      if (tid === "channel-monitor-reminder") {
        try {
          const summary = await runChannelMonitorCheck()
          if (summary.totalChanges === 0) {
            showToast(t("检查完成，没有发现更新"))
            return
          }
        } catch (error) {
          logError("仓库监控", error)
          showToast(
            error instanceof Error ? error.message : String(error),
            true
          )
          return
        }
      }
      const last = readLastChannelCheck()
      if (last && last.summary.totalChanges > 0) {
        // 防御：该批次已被「忽略全部」处理过（签名已持久化）或刚在应用内自动弹过页时不重复弹
        const sig = channelChangesSignature(last.summary.results)
        if (sig && sig === resolveConfig().channelMonitorNotifiedSig) {
          showToast(t("检查完成，没有发现更新"))
          return
        }
        // 稍作延迟再 present：全新实例由通知启动时 MainPage 可能还在呈现动画中，
        // 立即嵌套 present 会导致导航栏/工具栏不渲染，延迟后再弹出更稳定
        setTimeout(() => {
          Navigation.present({
            element: <ChannelUpdatePage />,
            modalPresentationStyle: "overFullScreen",
          })
          removeDeliveredChannelUpdateNotifications()
        }, 350)
      } else {
        showToast(t("检查完成，没有发现更新"))
      }
    }
    const initial = channelNotificationThreadId(Notification.current)
    if (initial) {
      handleNotificationTap(initial)
      return
    }
    if (Script.env === "index") {
      return Script.onResume((event) => {
        handleNotificationTap(channelNotificationThreadId(event.notificationInfo))
      })
    }
  }, [])
  const [scriptCount, setScriptCount] = useState(0)
  const [scriptList, setScriptList] = useState<ScriptInfo[]>([])
  const [showBackupRestore, setShowBackupRestore] = useState(() => {
    const saved = resolveConfig()
    return saved.rememberExpandState ? saved.backupRestoreExpanded : true
  })
  const [searchText, setSearchText] = useState("")
  const [multiSelect, setMultiSelect] = useState<Set<string>>(new Set())
  // 一次性构建 脚本文件夹名 → 分组名 映射，复用已扫描的 scriptList，避免重复全量扫描（会非常卡）
  const groupNameMap = useMemo(() => buildGroupNameMap(scriptList), [scriptList])
  // 置顶脚本集合（文件夹名）
  const pinnedSet = useMemo(
    () => new Set(config.pinnedScripts),
    [config.pinnedScripts]
  )
  // 按排序方式排序：置顶的脚本始终排在最上方（按置顶顺序，最后置顶的排最前），其余按「最新修改 / 名称 A-Z」排序
  const sortedScripts = useMemo(() => {
    const pinnedByOrder = config.pinnedScripts
      .map((folderName) =>
        scriptList.find((s) => s.folderName === folderName)
      )
      .filter((s): s is ScriptInfo => Boolean(s))
    const cmp = (a: ScriptInfo, b: ScriptInfo) =>
      compareScripts(a, b, config.scriptSort)
    const rest = scriptList
      .filter((s) => !pinnedSet.has(s.folderName))
      .sort(cmp)
    return [...pinnedByOrder, ...rest]
  }, [scriptList, config.pinnedScripts, pinnedSet, config.scriptSort])
  // 搜索时按「关键字匹配 → 置顶 → 其他」三段展示；无关键字时直接展示排序后的列表。
  // 设置「搜索不隐藏其他脚本」（默认开启）时搜索仍显示全部；关闭则只显示匹配项。
  const visibleScripts = useMemo(() => {
    const keyword = searchText.trim().toLowerCase()
    if (!keyword) {
      return sortedScripts
    }
    const matched = sortedScripts.filter((s) =>
      keywordMatches(s.displayName, keyword)
    )
    if (!config.searchKeepAll) {
      return matched
    }
    const pinnedRest = sortedScripts.filter(
      (s) => !keywordMatches(s.displayName, keyword) && pinnedSet.has(s.folderName)
    )
    const others = sortedScripts.filter(
      (s) => !keywordMatches(s.displayName, keyword) && !pinnedSet.has(s.folderName)
    )
    return [...matched, ...pinnedRest, ...others]
  }, [sortedScripts, searchText, pinnedSet, config.searchKeepAll])
  const { showToast, toastProps } = useToast()
  // 滚动代理：点击搜索框时滚动到「脚本管理」Section 顶部，让标题行露出来、键盘不遮挡下方脚本名
  const scrollProxyRef = useRef<ScrollViewProxy | null>(null)
  function scrollSearchFieldToTop() {
    setTimeout(() => {
      withAnimation(() => {
        scrollProxyRef.current?.scrollTo("scripts-anchor", "top")
      })
    }, 300)
  }

  // 异步统计首页数量，避免首次渲染同步扫描（解压 zip / 读 script.json）卡住主线程
  function refreshScripts() {
    setTimeout(() => {
      setBackupCount(scanBackups(config.destination).length)
      const list = scanScripts()
      setScriptCount(list.length)
      setScriptList(list)
      checkAutoBackup(list)
      refreshCloudVersions(list)
    }, 50)
  }

  // 点击脚本行 / 点运行按钮时先做一次节流后的全量刷新（版本号 + 内容），
  // 让智能体刚改过的脚本在列表里立即显示新版本，自动备份也能基于最新内容。
  const lastTapRefreshRef = useRef(0)
  function refreshScriptsOnTap() {
    const now = Date.now()
    if (now - lastTapRefreshRef.current < 3000) return
    lastTapRefreshRef.current = now
    refreshScripts()
  }

  // 异步拉取「历史已发布但无发布记录」脚本的云端版本（remoteResource 下载读取），
  // 用于显示「云端与本地不同步」标识与云端更新说明；拉取结果缓存到 cloudVersions/cloudChangelogs，之后不再重复下载。
  function refreshCloudVersions(list: ScriptInfo[]) {
    const cfg = resolveConfig()
    const need = list.filter(
      (s) =>
        isPublishedByTool(s) &&
        cfg.publishedVersions[s.folderName] == null &&
        cfg.cloudVersions[s.folderName] == null
    )
    if (need.length === 0) return
    const patch: Record<string, string> = { ...cfg.cloudVersions }
    const changelogPatch: Record<string, string> = { ...cfg.cloudChangelogs }
    let changed = false
    let done = 0
    for (const s of need) {
      fetchScriptCloudMeta(s).then((meta) => {
        if (meta != null) {
          if (meta.version) {
            patch[s.folderName] = meta.version
            changed = true
          }
          if (meta.changelog) {
            changelogPatch[s.folderName] = meta.changelog
          }
        }
        done += 1
        if (done === need.length) {
          if (changed) {
            updateConfig({ cloudVersions: patch, cloudChangelogs: changelogPatch })
            setBackupVersion((x) => x + 1)
          } else if (Object.keys(changelogPatch).length > 0) {
            updateConfig({ cloudChangelogs: changelogPatch })
            setBackupVersion((x) => x + 1)
          }
        }
      })
    }
  }

  // 自动备份在途标记：一次备份完成前不重复触发。备份被跳过/失败时保留旧基线，下次扫描自动重试
  const autoBackupInflightRef = useRef(false)

  /**
   * 版本变化自动备份：开启后扫描到脚本版本号变化时，自动把变化的脚本固定备份到 iPhone 端。
   * 首次扫描只建立版本基线不备份。
   * 为避免备份到旧内容：检测到变化后先等脚本内容稳定（连续两次目录指纹一致）再打包，
   * 期间版本又被修改则放弃本次，下一次扫描会按新基线重新触发。
   * 注意：版本基线（scriptVersionRecord）只在备份成功后才写入，若备份被跳过或失败，
   * 旧基线会保留，下次扫描仍能检测到版本变化并自动重试，不会出现「记录已更新但没备份」的漏备。
   */
  function checkAutoBackup(list: ScriptInfo[]) {
    const cfg = resolveConfig()
    if (!cfg.autoBackupOnUpgrade) return
    if (autoBackupInflightRef.current) return
    const record = cfg.scriptVersionRecord ?? {}
    const changed = list.filter(
      (s) => record[s.folderName] != null && record[s.folderName] !== (s.version ?? "")
    )
    if (changed.length === 0) {
      // 无版本变化：仅把新出现（尚无基线）的脚本补记基线
      const recordChanged = list.some(
        (s) => record[s.folderName] !== (s.version ?? "")
      )
      if (recordChanged) {
        const next: Record<string, string> = {}
        for (const s of list) {
          next[s.folderName] = s.version ?? ""
        }
        updateConfig({ scriptVersionRecord: next })
      }
      return
    }
    const next: Record<string, string> = {}
    for (const s of list) {
      next[s.folderName] = s.version ?? ""
    }
    const expected: Record<string, string> = {}
    for (const s of changed) {
      expected[s.folderName] = s.version ?? ""
    }
    showToast(tpl("检测到 {n} 个脚本版本变化，正在刷新内容…", { n: String(changed.length) }))
    autoBackupInflightRef.current = true
    setTimeout(async () => {
      try {
        // 先等待内容稳定（刷新完成）再备份，避免备份到旧内容
        const stable = await waitForStableScripts(changed, expected)
        if (stable == null || stable.length === 0) {
          return
        }
        // 固定备份到 iPhone 端（不跟随当前选择组，也不弹窗询问名称）
        const zipName =
          stable.length === 1
            ? `${stable[0].displayName}_${stable[0].version}`
            : tpl("自动备份_{stamp}", { stamp: timestampForName() })
        await backupScripts(stable, "iphone", zipName)
        // 备份成功后才更新版本基线（changed 对应脚本写入新版本，其余脚本保留原记录）
        updateConfig({ scriptVersionRecord: next })
        showToast(tpl("已自动备份 {n} 个脚本到 iPhone", { n: String(stable.length) }))
        setBackupVersion((v) => v + 1)
      } catch (error) {
        logError("自动备份", error)
        showToast(error instanceof Error ? error.message : String(error), true)
      } finally {
        autoBackupInflightRef.current = false
      }
    }, 100)
  }
  useEffect(() => {
    refreshScripts()
  }, [config.destination, backupVersion])
  // 主页标签（home_screen_default_ui）常驻内存，切走再切回不会重建，更新后的内容（如版本号）不会自动出现。
  // 监听 Home tab 事件：切回主页（selected）或再点主页（reselected）时重新扫描，自动更新变化的内容。
  const refreshScriptsRef = useRef(refreshScripts)
  refreshScriptsRef.current = refreshScripts
  useEffect(() => {
    if (Script.env !== "home_screen") return
    return Script.onHomeTabEvent((event) => {
      if (event === "selected" || event === "reselected") {
        refreshScriptsRef.current()
      }
    })
  }, [])

  /** 点击运行脚本（调用 Script.run 运行目标脚本，singleMode 终止其他实例） */
  function runScript(script: ScriptInfo) {
    // 运行前先节流刷新一次，确保列表版本号与自动备份基于最新内容
    refreshScriptsOnTap()
    Script.run({
      name: script.folderName,
      singleMode: true,
    }).catch(() => {})
  }

  /** 置顶 / 取消置顶脚本（保存在配置里，置顶脚本排在列表最上方，最后置顶的排在最前） */
  function togglePin(script: ScriptInfo) {
    const wasPinned = config.pinnedScripts.includes(script.folderName)
    updateConfig({
      pinnedScripts: wasPinned
        ? config.pinnedScripts.filter((f) => f !== script.folderName)
        : [script.folderName, ...config.pinnedScripts],
    })
    showToast(wasPinned ? t("已取消置顶") : t("已置顶"))
  }

  // 单击行：500ms 内再次点击判定为双击（快速置顶），否则延迟弹出行菜单；
  // 菜单刚弹出（500ms 内）又被点掉时，把这次点击当作双击，只置顶，不再连弹两个菜单。
  const lastTapTimeRef = useRef(0)
  const tapMenuTimerRef = useRef(0)
  const menuShownAtRef = useRef(0)
  const menuScriptRef = useRef("")
  // 菜单弹出序号：弹菜单前置位；期间发生双击/新菜单时递增，使旧的（可能还在打包取大小的）菜单不再弹出
  const menuGenRef = useRef(0)
  // 仓库监控：最近一次自动弹出更新页的变化签名（同一批变化只弹一次，避免定时循环反复打扰）。
  // 初始值取持久化的已提示签名，实例重启后同一批变化也不会重复弹
  const lastAutoPresentSigRef = useRef(
    resolveConfig().channelMonitorNotifiedSig ?? ""
  )
  function handleScriptTap(script: ScriptInfo) {
    if (multiSelect.size > 0) {
      toggleMultiSelect(script)
      return
    }
    // 点击（含置顶脚本）时先节流刷新一次：版本号与脚本内容重新从磁盘读取，再弹菜单；
    // 若开了自动备份，刷新完成后才会基于最新内容备份
    refreshScriptsOnTap()
    const now = Date.now()
    // ① 窗口内第二次点击 → 双击：取消待弹菜单，置顶/取消置顶
    if (now - lastTapTimeRef.current < 500) {
      if (tapMenuTimerRef.current) {
        clearTimeout(tapMenuTimerRef.current)
        tapMenuTimerRef.current = 0
      }
      lastTapTimeRef.current = 0
      menuGenRef.current += 1
      togglePin(script)
      return
    }
    // ② 菜单刚弹出又被点掉（第二次点击落在菜单展示动画期间，底层行仍可点）：
    // 同一行的这次点击按双击处理，避免再弹一个菜单
    if (
      script.folderName === menuScriptRef.current &&
      now - menuShownAtRef.current < 500
    ) {
      lastTapTimeRef.current = 0
      menuGenRef.current += 1
      togglePin(script)
      return
    }
    lastTapTimeRef.current = now
    tapMenuTimerRef.current = setTimeout(() => {
      tapMenuTimerRef.current = 0
      lastTapTimeRef.current = 0
      showScriptMenu(script)
    }, 500)
  }

  /** 脚本行菜单：重命名 / 移动分组 / 分享 / 修改版本号 / 删除（备份/发布按设置开关显示） */
  async function showScriptMenu(script: ScriptInfo) {
    // 记录菜单展示时间与脚本，供 handleScriptTap 判断“菜单刚弹出又被点掉”的情况（避免连弹两个菜单）；
    // 弹菜单前可能先打包取大小（await），期间发生双击/新菜单会递增 menuGenRef，此处据此放弃弹出
    const gen = ++menuGenRef.current
    menuShownAtRef.current = Date.now()
    menuScriptRef.current = script.folderName
    // 弹菜单前重新读取最新信息（版本号/时间/大小），智能体改过的脚本立即显示新版本
    const fresh = scriptInfoFromDir(script.path) ?? script
    // 大小显示与备份/分享产物（.scripting 压缩包）保持一致：打包一次取真实大小，失败回退内容大小
    const zipSize = await scriptZipSize(fresh)
    if (menuGenRef.current !== gen) {
      return
    }
    const group = groupNameMap.get(fresh.folderName) ?? null
    const actions: Array<{ label: string; destructive?: boolean }> = [
      { label: t("删除"), destructive: true },
      { label: t("改版本号") },
      { label: t("移动分组") },
      { label: t("重新命名") },
    ]
    const handlers: Array<() => void | Promise<void>> = [
      () => deleteOneScript(fresh),
      () => changeVersionWithPrompt(fresh),
      () => moveScriptGroupWithPrompt(fresh),
      () => renameScriptWithPrompt(fresh),
    ]
    // 一键发布（含更新说明填写入口）放在脚本备份上方
    if (config.githubPublishEnabled) {
      actions.push({ label: t("脚本发布") })
      handlers.push(() => startGithubPublish([fresh]))
    }
    if (config.githubBackupEnabled) {
      actions.push({ label: t("脚本备份") })
      handlers.push(() => backupScriptsFromMenu([fresh]))
    }
    if (config.githubPublishEnabled && hasPublishedLink(fresh)) {
      actions.push({ label: t("分享链接") })
      handlers.push(() => copyScriptShareLink(fresh))
      actions.push({ label: t("分享文件") })
      handlers.push(() => shareOneScript(fresh))
    } else {
      actions.push({ label: t("分享") })
      handlers.push(() => shareOneScript(fresh))
    }

    const index = await Dialog.actionSheet({
      title: fresh.displayName,
      message: tpl("版本 {v} · {date} · {size} · 分组 {group}", { v: fresh.version, date: formatDate(fresh.modifiedAt), size: formatBytes(zipSize ?? fresh.byteSize), group: group ?? t("默认") }),
      actions,
    })
    if (index == null) {
      return
    }
    await handlers[index]()
  }

  /** 长按进入多选并勾选/取消脚本 */
  function toggleMultiSelect(script: ScriptInfo) {
    setMultiSelect((prev) => {
      const next = new Set(prev)
      if (next.has(script.folderName)) {
        next.delete(script.folderName)
      } else {
        next.add(script.folderName)
      }
      return next
    })
  }

  /** 分享当前勾选的脚本 */
  async function shareSelected() {
    if (multiSelect.size === 0) {
      showToast(t("请先勾选脚本"), true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    try {
      await shareScripts(scripts)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 删除当前勾选的脚本 */
  async function deleteSelected() {
    if (multiSelect.size === 0) {
      showToast(t("请先勾选脚本"), true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    const index = await Dialog.actionSheet({
      title: t("删除确认"),
      message: tpl("确定删除 {n} 个脚本？此操作不可恢复。", { n: String(scripts.length) }),
      actions: [{ label: t("取消") }, { label: t("删除"), destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    try {
      for (const script of scripts) {
        deleteScript(script)
      }
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      setMultiSelect(new Set())
      showToast(t("已删除"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 移动当前勾选的脚本到指定分组 */
  async function moveSelectedToGroup() {
    if (multiSelect.size === 0) {
      showToast(t("请先勾选脚本"), true)
      return
    }
    const scripts = scriptList.filter((s) => multiSelect.has(s.folderName))
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast(t("没有可移动的分组"), true)
      return
    }
    const ordered = orderGroupsForMove(named)
    const index = await Dialog.actionSheet({
      title: t("移动到分组"),
      message: tpl("把勾选的 {n} 个脚本移动到哪个分组？", { n: String(scripts.length) }),
      actions: [{ label: t("取消") }, ...ordered.map((g) => ({ label: g.name }))],
      cancelButton: false,
    })
    if (index == null || index === 0) {
      return
    }
    const target = ordered[index - 1]
    try {
      let moved = 0
      for (const script of scripts) {
        try {
          moveScriptToGroup(script, target.name)
          moved++
        } catch {
          // 已在目标分组的脚本跳过
        }
      }
      setScriptList(scanScripts())
      setMultiSelect(new Set())
      if (moved > 0) {
        showToast(tpl("已移动 {n} 个脚本到「{group}」", { n: String(moved), group: target.name }))
      } else {
        showToast(t("没有可移动的脚本"), true)
      }
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 按当前备份位置备份脚本（菜单 / 多选快捷备份） */
  async function backupScriptsFromMenu(scripts: ScriptInfo[]) {
    if (scripts.length === 0) {
      showToast(t("没有可备份的脚本"), true)
      return
    }
    if (config.destination === "github_publish") {
      await startGithubPublish(scripts)
    } else if (config.destination === "github_backup") {
      await startGithubBackup(scripts, scripts.length > 1 ? t("临时备份") : undefined)
    } else {
      await startBackup(undefined, scripts, undefined, scripts.length > 1 ? t("临时备份") : undefined)
    }
  }

  async function renameScriptWithPrompt(script: ScriptInfo) {
    const name = await inputPrompt({
      title: t("重命名脚本"),
      message: t("输入新的脚本名称"),
      defaultValue: script.folderName,
      placeholder: script.folderName,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameScript(script, name.trim())
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      showToast(t("已重命名"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function moveScriptGroupWithPrompt(script: ScriptInfo) {
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast(t("没有可移动的分组"), true)
      return
    }
    const ordered = orderGroupsForMove(named)
    const index = await Dialog.actionSheet({
      title: t("移动到分组"),
      message: tpl("把「{name}」移动到哪个分组？", { name: script.displayName }),
      actions: [{ label: t("取消") }, ...ordered.map((g) => ({ label: g.name }))],
      cancelButton: false,
    })
    if (index == null || index === 0) {
      return
    }
    const target = ordered[index - 1]
    try {
      moveScriptToGroup(script, target.name)
      setScriptList(scanScripts())
      showToast(tpl("已移动到「{group}」", { group: target.name }))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function shareOneScript(script: ScriptInfo) {
    try {
      await shareScripts([script])
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 复制该脚本的 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]） */
  async function copyScriptShareLink(script: ScriptInfo) {
    const link = buildScriptImportLink(script)
    if (!link) {
      showToast(t("该脚本没有发布链接，请先发布"), true)
      return
    }
    try {
      await Pasteboard.setString(link)
      showToast(t("导入链接已复制"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function changeVersionWithPrompt(script: ScriptInfo) {
    if (!(await ensureVersionNotOverridden(script))) {
      return
    }
    const version = await inputPrompt({
      title: t("修改版本号"),
      message: t("输入新的版本号（格式 x.y.z，例如 1.0.1）"),
      defaultValue: script.version,
      placeholder: script.version,
      keyboardType: "numbersAndPunctuation",
    })
    if (version == null || !version.trim()) {
      return
    }
    try {
      setScriptVersion(script, version.trim())
      const list = scanScripts()
      setScriptList(list)
      setScriptCount(list.length)
      // 手动改版本号同样触发「自动备份升级项」检测（本地版本变化 → 自动备份到 iPhone）
      checkAutoBackup(list)
      showToast(t("版本号已更新"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function deleteOneScript(script: ScriptInfo) {
    const index = await Dialog.actionSheet({
      title: t("删除确认"),
      message: tpl("确定删除「{name}」？此操作不可恢复。", { name: script.displayName }),
      actions: [{ label: t("取消") }, { label: t("删除"), destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    try {
      deleteScript(script)
      setScriptList(scanScripts())
      setScriptCount(scanScripts().length)
      showToast(t("已删除"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  function updateConfig(patch: Partial<AppConfig>) {
    setConfigState((prev) => {
      const next = { ...prev, ...patch }
      saveConfig(next)
      return next
    })
  }

  function handleDestinationChanged(value: string | number) {
    const dest = String(value) as Destination
    if (dest === "icloud" && !FileManager.isiCloudEnabled) {
      showToast(t("iCloud 不可用，请先在系统设置中登录 iCloud 并授权 Scripting"), true)
      return
    }
    if (dest === "github_publish" && !config.githubPublishEnabled) {
      showToast(t("请在设置中勾选「Github发布」以使用此功能"), true)
      return
    }
    // 发布模式仅支持「最新/名称」，若之前选了分组/全部则重置为最新
    if (dest === "github_publish" && (config.scope === "group" || config.scope === "all")) {
      updateConfig({ destination: dest, scope: "recent" })
      return
    }
    updateConfig({ destination: dest })
  }

  /** 弹出「按名称」脚本选择页（modal，选完直接开始备份/发布） */
  function openScriptPicker() {
    const isPublish = config.destination === "github_publish"
    Navigation.present(
      <ScriptPickerPage
        initial={[]}
        pickerMode={isPublish ? "github" : "backup"}
        onSelect={(scripts) => {
          setSelectedScripts(scripts)
          if (scripts.length === 0) return
          if (config.destination === "github_publish") {
            startGithubPublish(scripts)
          } else if (config.destination === "github_backup") {
            startGithubBackup(scripts)
          } else {
            startBackup("select", scripts)
          }
        }}
      />
    )
  }

  /** 弹出「按分组」选择页（modal，选完直接开始备份/发布对应分组） */
  function openGroupPicker() {
    Navigation.present(
      <GroupPickerPage
        onSelect={(group) => {
          setSelectedGroup(group)
          if (group.scripts.length === 0) {
            showToast(t("该分组没有可备份的脚本"), true)
            return
          }
          if (config.destination === "github_backup") {
            startGithubBackup(group.scripts, group.name)
          } else {
            startBackup("group", group.scripts, group.name)
          }
        }}
      />
    )
  }

  /** 执行某个备份范围对应的动作：最新/全部直接备份，按名称/按分组弹选择页 */
  function runScopeAction(scope: BackupScopeKey) {
    if (config.destination === "github_publish") {
      // GitHub 发布模式：仅「最新/名称」两个范围
      if (scope === "recent") {
        startGithubPublish(scanScripts().slice(0, 1))
      } else if (scope === "select") {
        openScriptPicker()
      }
    } else if (config.destination === "github_backup") {
      // GitHub 备份模式：打包 zip 上传到私密备份仓库
      if (scope === "recent" || scope === "all") {
        startGithubBackup(
          scope === "recent" ? scanScripts().slice(0, 1) : scanScripts(),
          scope === "all" ? t("全部") : undefined
        )
      } else if (scope === "select") {
        openScriptPicker()
      } else if (scope === "group") {
        openGroupPicker()
      }
    } else {
      // 本地备份模式：保持原有逻辑
      if (scope === "recent" || scope === "all") {
        startBackup(scope)
      } else if (scope === "select") {
        openScriptPicker()
      } else if (scope === "group") {
        openGroupPicker()
      }
    }
  }

  /**
   * 说明为空时的处理：询问保留上次说明 / 不显示说明。
   * 返回 null 取消；"keep" 保留上次（不写 changelog）；"clear" 清空；否则为要写入的新说明。
   */
  async function resolveChangelogPolicy(
    script: ScriptInfo,
    notes: string
  ): Promise<string | null | "keep" | "clear"> {
    if (notes.trim()) {
      return notes.trim()
    }
    const choice = await Dialog.actionSheet({
      title: t("更新说明为空"),
      message: t("本次更新说明留空了：要保留上次发布的说明，还是本次不显示更新说明？"),
      actions: [
        { label: t("取消") },
        { label: t("保留上次更新说明") },
        { label: t("不显示更新说明") },
      ],
      cancelButton: false,
    })
    if (choice == null || choice === 0) {
      return null
    }
    if (choice === 1) {
      return "keep"
    }
    return "clear"
  }

  /**
   * 执行 GitHub 发布核心流程：写入说明（keep 跳过 / clear 清空 / 其它写入）→ 注入更新说明检查代码 →
   * 打包上传 → 记录发布版本与说明。
   */
  async function doGithubPublish(
    scripts: ScriptInfo[],
    gh: GithubConfig,
    notes: string | null | "keep" | "clear"
  ): Promise<boolean> {
    for (const s of scripts) {
      // 说明文本直接嵌入注入代码（不依赖 script.json 的 changelog 字段，避免被 Scripting 重写后丢失）
      let changelogText: string
      if (notes === "keep") {
        // 保留上次说明：取已记录的说明（云端/本地），没有则为空（不弹）
        changelogText =
          config.publishedChangelogs[s.folderName] ??
          readScriptChangelog(s) ??
          ""
      } else if (notes === "clear") {
        changelogText = ""
        try {
          setScriptChangelog(s, "")
        } catch {}
      } else if (notes) {
        changelogText = notes
        try {
          setScriptChangelog(s, notes)
        } catch {}
      } else {
        changelogText = ""
      }
      try {
        injectChangelogChecker(s, changelogText)
      } catch {}
    }
    setBusyAction("publish")
    setBusy(true)
    try {
      const results = await publishScriptsToGithub(scripts, gh)
      // 记录本次发布的版本，用于检测「云端与本地不同步」（本地版本号变化后未重新发布）
      const published: Record<string, string> = { ...config.publishedVersions }
      const changelogs: Record<string, string> = { ...config.publishedChangelogs }
      for (const r of results) {
        const s = scripts.find((x) => x.folderName === r.folderName)
        if (s) {
          published[r.folderName] = s.version ?? ""
          if (notes === "keep") {
            // 保留上次：本地记录不动
          } else if (notes === "clear") {
            delete changelogs[r.folderName]
          } else if (notes) {
            changelogs[r.folderName] = notes
          }
        }
      }
      updateConfig({ publishedVersions: published, publishedChangelogs: changelogs })
      const links = results.map((r) => buildImportLinkFromUrl(r.url))
      await Pasteboard.setString(links.join("\n"))
      showToast(
        tpl("已发布 {n} 个脚本并同步更新链接，更新链接已复制", { n: String(results.length) })
      )
      console.log(
        t("GitHub 发布完成:"),
        links
      )
      return true
    } catch (error) {
      logError("Github发布", error)
      showToast(
        error instanceof Error ? error.message : String(error),
        true
      )
      return false
    } finally {
      setBusy(false)
      setBusyAction("backup")
    }
  }

  /** 发布脚本到 GitHub（公开仓库，可自动创建）：直接进入更新说明编辑页，打包上传并更新链接 */
  async function startGithubPublish(scripts: ScriptInfo[]) {
    if (busy && busyAction === "publish") {
      // 上一次发布尚未完成：明确提示，避免静默失败
      showToast(
        t("请等待上个脚本发布成功，或者去 Github 发布页面使用长按多选发布"),
        true
      )
      return
    }
    if (busy) {
      return
    }
    const gh = resolvePublishGithubConfig(resolveGithubConfig())
    if (!isGithubConfigured(gh)) {
      showToast(t("请先到右上角「设置」配置 GitHub 发布（Token/所有者/仓库名）"), true)
      return
    }
    // 多项发布：不弹更新说明编辑页，直接发布（保留各脚本已有的更新说明，不新增/不清空）
    if (scripts.length > 1) {
      await doGithubPublish(scripts, gh, "keep")
      return
    }
    // 单项发布：进入更新说明编辑页，默认预填云端已有的说明（拉取不到时回退到本地 script.json）
    const current = config.cloudChangelogs[scripts[0].folderName] ?? readScriptChangelog(scripts[0]) ?? ""
    const result = await Navigation.present(
      <ChangelogEditorPage
        initial={current}
        scriptName={scripts[0].displayName}
        version={scripts[0].version}
      />
    )
    if (result == null) {
      return
    }
    const policy = await resolveChangelogPolicy(scripts[0], result)
    if (policy == null) {
      return
    }
    await doGithubPublish(scripts, gh, policy)
  }


  /** 备份脚本到 GitHub 私密备份仓库（可自动创建）：打包 zip 上传，不更新更新链接 */
  async function startGithubBackup(scripts: ScriptInfo[], nameHint?: string) {
    if (busy) {
      return
    }
    const gh = resolveBackupGithubConfig(resolveGithubConfig())
    if (!isGithubBackupConfigured(gh)) {
      showToast(t("请先到右上角「设置」配置 GitHub 备份（Token/所有者/备份仓库名）"), true)
      return
    }
    let zipName: string
    if (nameHint) {
      // 分组/全部备份：默认「前缀_时间编号」
      const def = `${safeFileName(nameHint)}_${timestampForName()}`
      const input = await inputPrompt({
        title: t("备份名称"),
        message: tpl("将 {n} 个脚本打包为一个 zip 上传到 GitHub 私密仓库，默认命名为「{name}+时间编号」", { n: String(scripts.length), name: nameHint }),
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || def
    } else if (scripts.length === 1) {
      const script = scripts[0]
      const def = `${script.displayName}_${script.version}`
      const input = await inputPrompt({
        title: t("备份名称"),
        message: t("单个脚本备份为 .scripting 格式上传到 GitHub 私密仓库，默认使用「脚本名+版本号」"),
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || def
    } else {
      const def = tpl("脚本备份_{stamp}", { stamp: timestampForName() })
      const input = await inputPrompt({
        title: t("备份名称"),
        message: tpl("将 {n} 个脚本打包为一个 zip 上传到 GitHub 私密仓库", { n: String(scripts.length) }),
        defaultValue: def,
        placeholder: def,
      })
      if (input == null) {
        return
      }
      zipName = input.trim() || t("脚本备份")
    }
    setBusy(true)
    try {
      const result = await backupScriptsToGithub(scripts, gh, zipName)
      showToast(tpl("已备份 {n} 个脚本到 {repo}", { n: String(scripts.length), repo: `${gh.owner}/${gh.backupRepo}` }))
      console.log("GitHub 备份完成:", result.url)
    } catch (error) {
      logError("Github备份", error)
      showToast(
        error instanceof Error ? error.message : String(error),
        true
      )
    } finally {
      setBusy(false)
    }
  }

  /** 计算当前范围要备份的脚本 */
  async function resolveBackupScripts(
    scope: BackupScopeKey = config.scope
  ): Promise<ScriptInfo[] | null> {
    if (scope === "all") {
      return scanScripts()
    }
    if (scope === "recent") {
      return scanScripts().slice(0, 1)
    }
    if (scope === "select") {
      const pickable = selectedScripts.filter((s) => pathExists(s.path))
      if (pickable.length === 0) {
        showToast(t("请先选择要备份的脚本"), true)
        return null
      }
      return pickable
    }
    // 按分组
    if (!selectedGroup) {
      showToast(t("请先选择要备份的分组"), true)
      return null
    }
    return selectedGroup.scripts
  }

  async function startBackup(
    scope?: BackupScopeKey,
    scriptsOverride?: ScriptInfo[],
    groupName?: string,
    multiDefaultName?: string
  ) {
    if (busy) {
      return
    }
    setBusy(true)
    try {
      const scripts = scriptsOverride ?? (await resolveBackupScripts(scope))
      if (!scripts) {
        return
      }
      if (scripts.length === 0) {
        showToast(t("没有可备份的脚本"), true)
        return
      }

      let zipName: string
      if (groupName) {
        // 按分组备份：默认「分组名_时间戳编号」
        const def = `${safeFileName(groupName)}_${timestampForName()}`
        const input = await inputPrompt({
          title: t("备份名称"),
          message: tpl("将 {n} 个脚本打包为一个 zip 上传到 iPhone/iCloud，默认命名为「分组名+时间编号」", { n: String(scripts.length) }),
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || def
      } else if (scripts.length === 1) {
        const script = scripts[0]
        const def = `${script.displayName}_${script.version}`
        const input = await inputPrompt({
          title: t("备份名称"),
          message: t("单个备份默认使用「脚本名+版本号」"),
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || def
      } else {
        const isAll = scope === "all"
        const baseName = isAll ? t("全部") : (multiDefaultName ?? t("脚本备份"))
        const def = `${baseName}_${timestampForName()}`
        const input = await inputPrompt({
          title: t("备份名称"),
          message: tpl("将 {n} 个脚本打包为一个 zip 上传到 iPhone/iCloud，留空则命名为「{base}_时间码」", { n: String(scripts.length), base: baseName }),
          defaultValue: def,
          placeholder: def,
        })
        if (input == null) {
          return
        }
        zipName = input.trim() || (isAll ? def : (multiDefaultName ?? t("临时备份")))
      }

      const finalPath = await backupScripts(scripts, config.destination, zipName)
      showToast(tpl("已备份 {n} 个脚本", { n: String(scripts.length) }))
      setBackupVersion((v) => v + 1)
      console.log("备份完成:", finalPath)
    } catch (error) {
      logError("本地备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setBusy(false)
    }
  }

  /** 从外部 zip 恢复 */
  async function importFromZip() {
    const files = await DocumentPicker.pickFiles({
      allowsMultipleSelection: false,
    })
    if (!files || files.length === 0) {
      return
    }
    const file = files[0]
    const tempDir = Path.join(
      FileManager.temporaryDirectory,
      `import-restore-${Date.now()}`
    )
    FileManager.createDirectorySync(tempDir, true)
    try {
      const lower = file.toLowerCase()
      if (lower.endsWith(".zip") || lower.endsWith(".scripting")) {
        FileManager.unzipSync(file, tempDir)
      } else {
        // 单个文件夹：直接按脚本目录树扫描
        const name = Path.basename(file)
        FileManager.copyFileSync(file, Path.join(tempDir, name))
      }
      const candidates = scanScriptDirsInTree(tempDir)
      if (candidates.length === 0) {
        showToast(t("所选文件中没有找到脚本（缺少 script.json）"), true)
        return
      }
      if (candidates.length === 1) {
        const ok = await confirmRestoreOne(candidates[0])
        if (ok) {
          await restoreScripts([candidates[0]], true)
          showToast(t("已恢复"))
        }
      } else {
        const result = await Navigation.present(
          <ScriptSelectionPage candidates={candidates} />
        )
        if (result?.restored != null) {
          showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
        }
      }
    } catch (error) {
      logError("从zip恢复", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (pathExists(tempDir)) {
        FileManager.removeSync(tempDir)
      }
    }
  }

  return (
    <NavigationStack>
      <ScrollViewReader>
        {(proxy) => {
          scrollProxyRef.current = proxy
          return (
      <List
        navigationTitle={APP_NAME}
        navigationBarTitleDisplayMode="inline"
        scrollDismissesKeyboard="immediately"
        toast={toastProps}
        safeAreaInset={{
          bottom: {
            alignment: "center",
            spacing: 8,
            content: multiSelect.size > 0 ? (
              <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setMultiSelect(new Set())}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("取消")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={deleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("删除")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={moveSelectedToGroup}
                >
                  <Image systemName="folder" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("移动")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() =>
                    backupScriptsFromMenu(
                      scriptList.filter((s) => multiSelect.has(s.folderName))
                    )
                  }
                >
                  <Image systemName="arrow.down.circle" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("备份")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={shareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("分享")}
                  </Text>
                </VStack>
              </HStack>
              </VStack>
            ) : (
              <></>
            ),
          },
        }}
        toolbar={
          <Toolbar>
            {Script.env !== "home_screen" ? (
              <ToolbarItem placement="topBarLeading">
                <Button title={t("关闭")} action={dismiss} />
              </ToolbarItem>
            ) : null}
            <ToolbarItem placement="topBarLeading">
              <Button
                action={() => {
                  const next = !showBackupRestore
                  setShowBackupRestore(next)
                  if (config.rememberExpandState) {
                    updateConfig({ backupRestoreExpanded: next })
                  }
                }}
              >
                <Image
                  systemName={showBackupRestore ? "chevron.up" : "chevron.down"}
                />
              </Button>
            </ToolbarItem>
            {config.channelMonitorEnabled ? (
              <ToolbarItem placement="topBarTrailing">
                <Button
                  action={async () => {
                    // 首页「立即监控」：开启仓库监控时显示，点击立即检查一次；无更新时提示
                    const summary = await runMonitorCycle()
                    if (
                      summary &&
                      !summary.newBaseline &&
                      summary.totalChanges === 0
                    ) {
                      showToast(t("检查完成，没有发现更新"))
                    }
                  }}
                >
                  <Image
                    systemName="tray.and.arrow.down"
                    font={15} // 图标大小(pt)，数字越大按钮图标越大；也可用 imageScale="large"
                  />
                </Button>
              </ToolbarItem>
            ) : null}
            <ToolbarItem placement="topBarTrailing">
              <Button
                action={async () => {
                  // 打开设置页；关闭后立即刷新配置，无需重新打开脚本即可生效
                  await Navigation.present(<SettingsPage />)
                  setConfigState(resolveConfig())
                }}
              >
                <Image systemName="gearshape" />
              </Button>
            </ToolbarItem>
          </Toolbar>
        }
      >
        {showBackupRestore ? (
          <Section
            header={<Text font="headline">{t("备份")}</Text>}
            footer={
              config.destination === "github_publish" ? (
                <Text font="footnote">
                  {(() => {
                    const gh = resolvePublishGithubConfig(resolveGithubConfig())
                    const pub =
                      gh.owner && gh.repo
                        ? `${gh.owner}/${gh.repo}`
                        : t("未配置，请在设置中填写 GitHub 发布参数")
                    const pubSuffix = gh.path ? ` / ${gh.path}` : ""
                    return tpl("发布到仓库：{pub}（{branch} 分支，公开，可自动创建）", {
                      pub: pub + pubSuffix,
                      branch: gh.branch || "main",
                    })
                  })()}
                </Text>
              ) : config.destination === "github_backup" ? (
                <Text font="footnote">
                  {(() => {
                    const gh = resolveBackupGithubConfig(resolveGithubConfig())
                    const bak =
                      gh.owner && gh.backupRepo
                        ? `${gh.owner}/${gh.backupRepo}`
                        : t("未配置，请在设置中填写 GitHub 备份参数")
                    const bakSuffix = gh.backupPath ? ` / ${gh.backupPath}` : ""
                    return tpl("备份到仓库：{backup}（{branch} 分支，私密，可自动创建）", {
                      backup: bak + bakSuffix,
                      branch: gh.backupBranch || "main",
                    })
                  })()}
                </Text>
              ) : (
                <Text font="footnote">
                  {tpl("备份目录：{dir}", { dir: backupRootFor(config.destination) })}
                </Text>
              )
            }
          >
            <Picker
              title={t("备份到")}
              value={config.destination}
              onChanged={handleDestinationChanged}
              pickerStyle="segmented"
            >
              <Text tag="iphone">iPhone</Text>
              <Text tag="icloud">iCloud</Text>
              {config.githubBackupEnabled && <Text tag="github_backup">{t("Github备份")}</Text>}
              {config.githubPublishEnabled && <Text tag="github_publish">{t("Github发布")}</Text>}
            </Picker>

            <Picker
              title={t("备份范围")}
              value={config.scope}
              onChanged={(value: string) => {
                const scope = String(value) as BackupScopeKey
                updateConfig({ scope })
                runScopeAction(scope)
              }}
              pickerStyle="segmented"
            >
              <Text tag="recent">{t("最新")}</Text>
              <Text tag="select">{t("名称")}</Text>
              {config.destination !== "github_publish" && <Text tag="group">{t("分组")}</Text>}
              {config.destination !== "github_publish" && <Text tag="all">{t("全部")}</Text>}
            </Picker>

            <HStack
              spacing={8}
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => runScopeAction(config.scope)}
            >
              <Spacer />
              <Image
                systemName={config.destination === "github_publish" ? "arrow.up.doc.fill" : "externaldrive.fill.badge.checkmark"}
                foregroundStyle="tintColor"
              />
              <Text font="body" foregroundStyle="tintColor">
                {busy
                  ? busyAction === "publish" ? t("正在发布…") : t("正在备份…")
                  : config.destination === "github_publish" ? t("开始发布") : t("开始备份")}
              </Text>
              <Spacer />
            </HStack>
          </Section>
        ) : null}

        {showBackupRestore && config.destination !== "github_publish" ? (
          <Section
            header={<Text font="headline">{t("恢复")}</Text>}
            footer={
              <Text font="footnote">
                {config.destination === "github_backup"
                  ? t("从 GitHub 私密备份仓库下载 .scripting 恢复脚本")
                  : t("从备份目录或外部 .scripting 文件恢复脚本")}
              </Text>
            }
          >
            <NavigationLink
              destination={
                config.destination === "github_backup" ? (
                  <GithubRestorePage />
                ) : (
                  <RestorePage destination={config.destination} />
                )
              }
            >
              <HStack spacing={10}>
                <RowIcon systemName="tray.and.arrow.down" />
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{t("恢复备份")}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {config.destination === "github_backup"
                      ? t("Github备份仓库")
                      : tpl("{n} 个备份", { n: String(backupCount) })}
                  </Text>
                </VStack>
                <Spacer />
              </HStack>
            </NavigationLink>

            {config.destination !== "github_backup" && (
              <HStack
                spacing={8}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={importFromZip}
              >
                <Spacer />
                <Image systemName="folder.badge.plus" foregroundStyle="tintColor" />
                <Text font="body" foregroundStyle="tintColor">{t("从文件恢复")}</Text>
                <Spacer />
              </HStack>
            )}
          </Section>
        ) : null}

        <Section
          key="scripts-anchor"
          header={
            <HStack spacing={8} alignment="center">
              <Text font="headline">{tpl("脚本管理（{n}）", { n: String(scriptList.length) })}</Text>
              <Spacer />
              <Picker
                value={config.scriptSort}
                onChanged={(value: string | number) => {
                  const v = String(value)
                  updateConfig({
                    scriptSort: v === "name" || v === "name_desc" ? v : "modified",
                  })
                }}
                pickerStyle="menu"
                padding={{ trailing: -12 }}
                label={
                  <HStack spacing={4}>
                    <Image
                      systemName="arrow.up.arrow.down"
                      foregroundStyle="secondaryLabel"
                    />
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      {config.scriptSort === "name"
                        ? t("按名称 A-Z")
                        : config.scriptSort === "name_desc"
                          ? t("按名称 Z-A")
                          : t("按最新修改")}
                    </Text>
                  </HStack>
                }
              >
                <Text tag="modified">{t("按最新修改")}</Text>
                <Text tag="name">{t("按名称 A-Z")}</Text>
                <Text tag="name_desc">{t("按名称 Z-A")}</Text>
              </Picker>
            </HStack>
          }
          footer={
            <VStack alignment="leading" spacing={2}>
              <Text font="footnote"> </Text>
              <Text font="footnote">{t("注：")}</Text>
              <Text font="footnote">
                {t("①单击行弹出菜单（删除/版本号/移动分组/重命名/备份/分享）")}
              </Text>
              <Text font="footnote">{t("②双击单项快速置顶，再次双击取消置顶")}</Text>
              <Text font="footnote">
                {t("③点击右侧按钮(三角图标)直接运行该脚本")}
              </Text>
              <Text font="footnote">{t("④长按任意脚本可多选备份、分享、移动或删除")}</Text>
              <Text font="footnote">
                {t("⑤搜索时匹配的脚本排在前面；默认不隐藏其他脚本（设置里可关闭，关闭后只显示匹配项）")}
              </Text>
              <Text font="footnote">
                {t("⑥点击左上角按钮可隐藏备份相关板块")}
              </Text>
              <Text font="footnote">
                {t("⑦自己已发布到仓库的脚本会有绿色勾标；本地与云端版本不同步时显示橙色警示标")}
              </Text>
              <Text font="footnote">
                {t("⑧该脚本若被固定到首页，更新后有些功能可能需要长按主页按钮并点击重新加载才会生效")}
              </Text>
            </VStack>
          }
        >
          {scriptList.length > 0 ? (
            <HStack spacing={8}>
              <TextField
                value={searchText}
                onChanged={setSearchText}
                onFocus={scrollSearchFieldToTop}
                prompt={t("搜索脚本名")}
                label={
                  <Image
                    systemName="magnifyingglass"
                    foregroundStyle="secondaryLabel"
                  />
                }
              />
              {searchText.length > 0 ? (
                <HStack
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setSearchText("")}
                >
                  <Image
                    systemName="xmark.circle.fill"
                    foregroundStyle="secondaryLabel"
                  />
                </HStack>
              ) : null}
            </HStack>
          ) : null}
          {scriptList.length === 0 ? (
            <EmptyState message={t("正在加载脚本…")} />
          ) : (
            visibleScripts.map((script) => {
              const checked = multiSelect.has(script.folderName)
              const group = groupNameMap.get(script.folderName) ?? null
              const isPinned = pinnedSet.has(script.folderName)
              return (
                <HStack
                  key={script.folderName}
                  spacing={10}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => handleScriptTap(script)}
                  onLongPressGesture={{
                    minDuration: 400,
                    perform: () => toggleMultiSelect(script),
                  }}
                >
                  {multiSelect.size > 0 ? (
                    <Image
                      systemName={checked ? "checkmark.circle.fill" : "circle"}
                      foregroundStyle={
                        checked ? "systemBlue" : "secondaryLabel"
                      }
                    />
                  ) : (
                    <RowIcon
                      systemName="chevron.left.forwardslash.chevron.right"
                      color="tintColor"
                    />
                  )}
                  <VStack alignment="leading" spacing={2}>
                    <Text font="body">{script.displayName}</Text>
                    <HStack spacing={4}>
                      {isPublishedByTool(script) ? (
                        isCloudDesynced(script, config.publishedVersions, config.cloudVersions) ? (
                          <Image
                            systemName="exclamationmark.icloud.fill"
                            foregroundStyle="systemOrange"
                            imageScale="small"
                          />
                        ) : (
                          <Image
                            systemName="checkmark.seal.fill"
                            foregroundStyle="systemGreen"
                            imageScale="small"
                          />
                        )
                      ) : null}
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        v{script.version} · {group ?? t("默认")}
                      </Text>
                    </HStack>
                  </VStack>
                  <Spacer />
                  {isPinned && multiSelect.size === 0 ? (
                    <Image
                      systemName="pin.fill"
                      foregroundStyle="secondaryLabel"
                      imageScale="small"
                      padding={{ top: 2, trailing: 8 }}
                    />
                  ) : null}
                  <Image
                    systemName="play.circle.fill"
                    foregroundStyle="tintColor"
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => runScript(script)}
                  />
                </HStack>
              )
            })
          )}
        </Section>
      </List>
          )
        }}
      </ScrollViewReader>
    </NavigationStack>
  )
}

// ==================== 设置页 ====================

function SettingsPage() {
  const dismiss = Navigation.useDismiss()
  const savedConfig = useMemo(resolveConfig, [])
  const savedGithub = useMemo(resolveGithubConfig, [])
  const [githubBackupEnabled, setGithubBackupEnabled] = useState(
    savedConfig.githubBackupEnabled
  )
  const [githubPublishEnabled, setGithubPublishEnabled] = useState(
    savedConfig.githubPublishEnabled
  )
  const [rememberExpandState, setRememberExpandState] = useState(
    savedConfig.rememberExpandState
  )
  const [searchKeepAll, setSearchKeepAll] = useState(
    savedConfig.searchKeepAll
  )
  const [autoBackupOnUpgrade, setAutoBackupOnUpgrade] = useState(
    savedConfig.autoBackupOnUpgrade
  )
  const [language, setLanguageState] = useState<"zh" | "en">(
    savedConfig.language
  )
  // 发布与备份可分别配置账号；savedGithub.token/owner 为旧版共用字段，作为兼容回退
  const [publishToken, setPublishToken] = useState(
    savedGithub.publishToken || savedGithub.token
  )
  const [publishOwner, setPublishOwner] = useState(
    savedGithub.publishOwner || savedGithub.owner
  )
  const [repo, setRepo] = useState(savedGithub.repo)
  const [branch, setBranch] = useState(savedGithub.branch)
  const [path, setPath] = useState(savedGithub.path)
  const [backupToken, setBackupToken] = useState(
    savedGithub.backupToken || savedGithub.token
  )
  const [backupOwner, setBackupOwner] = useState(
    savedGithub.backupOwner || savedGithub.owner
  )
  const [backupRepo, setBackupRepo] = useState(savedGithub.backupRepo)
  const [backupBranch, setBackupBranch] = useState(savedGithub.backupBranch)
  const [backupPath, setBackupPath] = useState(savedGithub.backupPath)
  // Github备份/发布 设置项的展开状态：仅在刚打开开关时自动展开，之后默认收起（可点标题展开按钮手动展开）
  const [backupExpanded, setBackupExpanded] = useState(false)
  const [publishExpanded, setPublishExpanded] = useState(false)
  const [checking, setChecking] = useState(false)
  const [errorLogs, setErrorLogs] = useState(resolveErrorLogs)
  // 仓库监控
  const [monitorEnabled, setMonitorEnabled] = useState(
    savedConfig.channelMonitorEnabled
  )
  const [monitorInterval, setMonitorInterval] = useState(
    String(savedConfig.channelMonitorInterval || 12)
  )
  const [monitorUnit, setMonitorUnit] = useState<
    "minute" | "hour" | "day"
  >(savedConfig.channelMonitorIntervalUnit)
  const [monitorLinks, setMonitorLinks] = useState<ChannelMonitorLink[]>(
    normalizeChannelMonitorLinks(savedConfig.channelMonitorLinks)
  )
  const [newMonitorUrl, setNewMonitorUrl] = useState("")
  const [monitorChecking, setMonitorChecking] = useState(false)
  const [excludeKeywords, setExcludeKeywords] = useState<string[]>(
    normalizeChannelExcludeKeywords(
      savedConfig.channelMonitorExcludeKeywords
    )
  )
  const [newExcludeKeyword, setNewExcludeKeyword] = useState("")
  const [monitorIgnoredPaths, setMonitorIgnoredPaths] = useState<string[]>(
    normalizeChannelIgnoredPaths(savedConfig.channelMonitorIgnoredPaths)
  )
  // 仓库监控设置的展开状态：仅首次打开开关时自动展开，之后进入设置页默认收起（标题后有展开按钮）
  const [monitorExpanded, setMonitorExpanded] = useState(false)
  const { showToast, toastProps } = useToast()

  function collect(): GithubConfig {
    return {
      publishToken: publishToken.trim(),
      publishOwner: publishOwner.trim(),
      repo: repo.trim(),
      branch: branch.trim() || "main",
      path: path.trim(),
      backupToken: backupToken.trim(),
      backupOwner: backupOwner.trim(),
      backupRepo: backupRepo.trim(),
      backupBranch: backupBranch.trim() || "main",
      backupPath: backupPath.trim(),
      // 兼容旧字段：保存时同步两套字段，旧版字段与各自专用字段保持一致
      token: (publishToken.trim() || backupToken.trim()).trim(),
      owner: (publishOwner.trim() || backupOwner.trim()).trim(),
    }
  }

  // ---- 自动保存：任意设置变更立即写入配置文件，无需手动点保存 ----
  // AppConfig（通用开关 + 仓库监控等）变更时自动保存
  useEffect(() => {
    const next: AppConfig = {
      ...resolveConfig(),
      githubBackupEnabled,
      githubPublishEnabled,
      rememberExpandState,
      searchKeepAll,
      language,
      autoBackupOnUpgrade,
      channelMonitorEnabled: monitorEnabled,
      channelMonitorInterval: Math.max(
        1,
        parseInt(monitorInterval, 10) || 12
      ),
      channelMonitorIntervalUnit: monitorUnit,
      channelMonitorLinks: normalizeChannelMonitorLinks(monitorLinks),
      channelMonitorExcludeKeywords: normalizeChannelExcludeKeywords(
        excludeKeywords
      ),
    }
    // 关闭对应开关后，首页若停留在该 Github 目的地则回到 iPhone，避免显示已隐藏的选项
    if (!githubBackupEnabled && next.destination === "github_backup") {
      next.destination = "iphone"
    }
    if (!githubPublishEnabled && next.destination === "github_publish") {
      next.destination = "iphone"
    }
    saveConfig(next)
  }, [
    githubBackupEnabled,
    githubPublishEnabled,
    rememberExpandState,
    searchKeepAll,
    language,
    autoBackupOnUpgrade,
    monitorEnabled,
    monitorInterval,
    monitorUnit,
    monitorLinks,
    excludeKeywords,
  ])

  // Github 配置（发布/备份的 Token、仓库、分支、目录等输入框）变更时自动保存
  useEffect(() => {
    saveGithubConfig(collect())
  }, [
    publishToken,
    publishOwner,
    repo,
    branch,
    path,
    backupToken,
    backupOwner,
    backupRepo,
    backupBranch,
    backupPath,
  ])

  async function verify() {
    const gh = collect()
    // 优先验证发布 Token，未填则回退到备份 Token
    const token = gh.publishToken || gh.backupToken
    if (!token) {
      showToast(t("请先填写 GitHub Token"), true)
      return
    }
    setChecking(true)
    try {
      const login = await githubVerify(token)
      if (gh.publishToken) {
        if (!gh.publishOwner) {
          setPublishOwner(login)
        }
        saveGithubConfig({ ...gh, publishOwner: gh.publishOwner || login })
      } else {
        if (!gh.backupOwner) {
          setBackupOwner(login)
        }
        saveGithubConfig({ ...gh, backupOwner: gh.backupOwner || login })
      }
      showToast(tpl("Token 有效：@{login}", { login }))
    } catch (error) {
      logError("验证Token", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setChecking(false)
    }
  }

  // ---- 仓库监控：链接管理 + 立即检查 ----
  function addMonitorLink() {
    const url = normalizeRepoUrl(newMonitorUrl)
    if (!url) {
      showToast(
        t("链接无效，请输入形如 https://github.com/所有者/仓库名 的 GitHub 地址"),
        true
      )
      return
    }
    if (monitorLinks.some((l) => l.url === url)) {
      showToast(t("该仓库已在监控列表中"), true)
      return
    }
    setMonitorLinks([
      ...monitorLinks,
      { url, name: repoDisplayName(url) },
    ])
    setNewMonitorUrl("")
  }

  async function renameMonitorLink(link: ChannelMonitorLink) {
    const name = await inputPrompt({
      title: t("修改备注名"),
      message: link.url,
      defaultValue: link.name,
      placeholder: t("仓库备注名"),
    })
    if (name == null) return
    const trimmed = name.trim()
    setMonitorLinks(
      monitorLinks.map((l) =>
        l.url === link.url
          ? { ...l, name: trimmed || repoDisplayName(link.url) }
          : l
      )
    )
  }

  async function editMonitorLink(link: ChannelMonitorLink) {
    const url = await inputPrompt({
      title: t("修改仓库链接"),
      message: link.name,
      defaultValue: link.url,
      placeholder: "https://github.com/owner/repo",
    })
    if (url == null) return
    const normalized = normalizeRepoUrl(url)
    if (!normalized) {
      showToast(
        t("链接无效，请输入形如 https://github.com/所有者/仓库名 的 GitHub 地址"),
        true
      )
      return
    }
    if (
      monitorLinks.some((l) => l.url === normalized && l.url !== link.url)
    ) {
      showToast(t("该仓库已在监控列表中"), true)
      return
    }
    setMonitorLinks(
      monitorLinks.map((l) =>
        l.url === link.url ? { ...l, url: normalized } : l
      )
    )
    showToast(t("修改成功"))
  }

  function removeMonitorLink(link: ChannelMonitorLink) {
    // 即时删除，不弹确认框（confirm 在本页嵌套模态中不工作，且删除为轻量操作）
    setMonitorLinks(monitorLinks.filter((l) => l.url !== link.url))
    showToast(t("删除成功"))
  }

  function addExcludeKeyword() {
    const kw = newExcludeKeyword.trim()
    if (!kw) {
      showToast(t("请输入排除关键词"), true)
      return
    }
    if (excludeKeywords.some((k) => k === kw)) {
      showToast(t("该关键词已存在"), true)
      return
    }
    setExcludeKeywords([...excludeKeywords, kw])
    setNewExcludeKeyword("")
  }

  async function editExcludeKeyword(kw: string) {
    const value = await inputPrompt({
      title: t("修改排除关键词"),
      defaultValue: kw,
      placeholder: t("如：测试、请勿下载"),
    })
    if (value == null) return
    const trimmed = value.trim()
    if (!trimmed) {
      showToast(t("请输入排除关键词"), true)
      return
    }
    if (excludeKeywords.some((k) => k === trimmed && k !== kw)) {
      showToast(t("该关键词已存在"), true)
      return
    }
    setExcludeKeywords(
      excludeKeywords.map((k) => (k === kw ? trimmed : k))
    )
    showToast(t("修改成功"))
  }

  function removeExcludeKeyword(kw: string) {
    // 即时删除，不弹确认框（confirm 在本页嵌套模态中不工作，且删除为轻量操作）
    setExcludeKeywords(excludeKeywords.filter((k) => k !== kw))
    showToast(t("删除成功"))
  }

  // 恢复「已忽略更新」脚本的提醒：从忽略列表移除该路径，之后该脚本再发新版会正常提示
  function removeIgnoredPath(key: string) {
    const next = monitorIgnoredPaths.filter((k) => k !== key)
    setMonitorIgnoredPaths(next)
    updateChannelMonitorConfig({ channelMonitorIgnoredPaths: next })
    showToast(t("已恢复提醒"))
  }

  async function checkNow() {
    if (!monitorEnabled) {
      showToast(t("请先打开仓库监控开关"), true)
      return
    }
    setMonitorChecking(true)
    try {
      const summary = await runChannelMonitorCheck()
      const okCount = summary.results.filter((r) => r.ok).length
      const failCount = summary.results.length - okCount
      const excludedTotal = summary.results.reduce(
        (n, r) => n + (r.excludedCount ?? 0),
        0
      )
      if (summary.newBaseline) {
        const total = summary.results.reduce(
          (n, r) => n + r.scriptCount,
          0
        )
        showToast(
          tpl("已建立基线：共 {n} 个仓库、{m} 个脚本，之后有变化会提醒", {
            n: String(okCount),
            m: String(total),
          })
        )
      } else if (summary.totalChanges > 0) {
        showToast(
          tpl("发现 {n} 个脚本有更新", {
            n: String(summary.totalChanges),
          })
        )
        notifyChannelChanges(summary.results)
      } else if (failCount > 0) {
        showToast(
          tpl("{n} 个仓库检查失败，请检查链接或网络", {
            n: String(failCount),
          }),
          true
        )
      } else if (excludedTotal > 0) {
        showToast(
          tpl("{n} 个脚本因排除关键词未显示", { n: String(excludedTotal) })
        )
      } else {
        showToast(t("检查完成，没有发现更新"))
      }
    } catch (error) {
      logError("仓库监控", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setMonitorChecking(false)
    }
  }

  return (
    <List
      navigationTitle={t("设置")}
      navigationBarTitleDisplayMode="inline"
      toast={toastProps}
      // 从屏幕左边缘向右划动手势 → 返回上一页（模态页没有系统边缘返回手势，这里手动实现；
      // 用 simultaneousGesture 不抢占列表滚动，只有明确从边缘开始的右滑才触发 dismiss）
      simultaneousGesture={
        DragGesture({ coordinateSpace: "global", minDistance: 20 })
          .onEnded((d) => {
            if (
              d.startLocation.x < 40 &&
              (d.translation.width > 100 || d.velocity.width > 600)
            ) {
              dismiss()
            }
          })
      }
      toolbar={
        <Toolbar>
          <ToolbarItem placement="topBarLeading">
            <Button title={t("关闭")} action={dismiss} />
          </ToolbarItem>
          <ToolbarItem placement="topBarTrailing">
            <Button
              title={checking ? t("验证中…") : t("验证 Token")}
              action={() => verify()}
            />
          </ToolbarItem>
        </Toolbar>
      }
    >
      <Section
        header={
          <HStack
            spacing={8}
            alignment="center"
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => setBackupExpanded(!backupExpanded)}
          >
            <Text font="headline">{t("GitHub 备份")}</Text>
            <Spacer />
            <HStack spacing={4} alignment="center">
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {backupExpanded ? t("收起") : t("展开")}
              </Text>
              <Image
                systemName={backupExpanded ? "chevron.up" : "chevron.down"}
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          </HStack>
        }
        footer={
          <Text font="footnote">
            {t("首页「备份到 → Github备份」把脚本打包为 zip 上传到私密备份仓库，仅用于备份，不影响脚本更新链接。备份仓库不存在时会自动创建，默认私密。备份 Token 与所有者可独立于发布设置；若留空则自动沿用发布账号")}
          </Text>
        }
      >
        <Toggle
          title={t("Github备份")}
          value={githubBackupEnabled}
          onChanged={(v) => {
            setGithubBackupEnabled(v)
            if (v) setBackupExpanded(true)
          }}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("勾选后首页显示「Github备份」入口（可把脚本打包 zip 上传到私密仓库备份）")}
        </Text>
        {githubBackupEnabled && backupExpanded ? (
          <>
          <TextField
            title={t("Token（备份）")}
            value={backupToken}
            onChanged={setBackupToken}
            prompt="GitHub Personal Access Token"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("填 GitHub 个人访问令牌。获取：GitHub 网页 → 右上角头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限 → 生成后复制 ghp_… 粘贴到这里。备份可用独立 Token（与发布不同账号）；留空自动沿用发布 Token")}
          </Text>
          <TextField
            title={t("仓库所有者（备份）")}
            value={backupOwner}
            onChanged={setBackupOwner}
            prompt={t("如 vvvvvveng")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("备份仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。备份可用独立所有者（不同账号）；留空自动沿用发布所有者")}
          </Text>
          <TextField
            title={t("备份仓库名（必填）")}
            value={backupRepo}
            onChanged={setBackupRepo}
            prompt={t("如 scripting-backups")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("必填：存放备份 zip 的仓库名（私密）。若不存在，首次备份时会自动创建私密仓库，其他人不可见")}
          </Text>
          <TextField
            title={t("备份分支")}
            value={backupBranch}
            onChanged={setBackupBranch}
            prompt="main"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("备份到的分支，一般用默认的 main，留空自动填 main")}
          </Text>
          <TextField
            title={t("仓库内目录")}
            value={backupPath}
            onChanged={setBackupPath}
            prompt={t("留空为根目录，如 backups")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("备份 zip 放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 backups")}
          </Text>
          </>
        ) : null}
      </Section>

      <Section
        header={
          <HStack
            spacing={8}
            alignment="center"
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => setPublishExpanded(!publishExpanded)}
          >
            <Text font="headline">{t("GitHub 发布")}</Text>
            <Spacer />
            <HStack spacing={4} alignment="center">
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {publishExpanded ? t("收起") : t("展开")}
              </Text>
              <Image
                systemName={publishExpanded ? "chevron.up" : "chevron.down"}
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          </HStack>
        }
        footer={
          <Text font="footnote">
            {t("首页「备份到 → Github发布」即可把脚本打包为 .scripting 上传到公开仓库并同步更新脚本的远程更新链接（remoteResource）。发布仓库不存在时会自动创建，默认公开。发布 Token 与所有者可独立于备份设置；若留空则自动沿用备份账号")}
          </Text>
        }
      >
        <Toggle
          title={t("Github发布")}
          value={githubPublishEnabled}
          onChanged={(v) => {
            setGithubPublishEnabled(v)
            if (v) setPublishExpanded(true)
          }}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("只有开发者才用得上：勾选后显示「Github发布」入口（可把脚本作为可更新版本发布到公开仓库）")}
        </Text>
        {githubPublishEnabled && publishExpanded ? (
          <>
          <TextField
            title={t("Token（发布）")}
            value={publishToken}
            onChanged={setPublishToken}
            prompt="GitHub Personal Access Token"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("填 GitHub 个人访问令牌，与备份可用不同账号。获取方式同备份：GitHub 网页 → 头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限。留空自动沿用备份 Token")}
          </Text>
          <TextField
            title={t("仓库所有者（发布）")}
            value={publishOwner}
            onChanged={setPublishOwner}
            prompt={t("如 vvvvvveng")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("发布仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。发布可用独立所有者（不同账号）；留空自动沿用备份所有者")}
          </Text>
          <TextField
            title={t("发布仓库名（必填）")}
            value={repo}
            onChanged={setRepo}
            prompt={t("如 scripting-releases")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("必填：接收发布文件的仓库名（公开）。若不存在，首次发布时会自动创建公开仓库，无需手动建仓")}
          </Text>
          <TextField
            title={t("发布分支")}
            value={branch}
            onChanged={setBranch}
            prompt="main"
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("发布到的分支，一般用默认的 main，留空自动填 main。如仓库默认分支是 master 就填 master")}
          </Text>
          <TextField
            title={t("仓库内目录")}
            value={path}
            onChanged={setPath}
            prompt={t("留空为根目录，如 releases")}
          />
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {t("发布文件放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 releases。脚本会在该目录下按脚本名生成 .scripting 文件")}
          </Text>
          </>
        ) : null}
      </Section>

      <Section
        header={
          <HStack
            spacing={8}
            alignment="center"
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => setMonitorExpanded(!monitorExpanded)}
          >
            <Text font="headline">{t("仓库监控")}</Text>
            <Spacer />
            <HStack spacing={4} alignment="center">
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {monitorExpanded ? t("收起") : t("展开")}
              </Text>
              <Image
                systemName={monitorExpanded ? "chevron.up" : "chevron.down"}
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          </HStack>
        }
        footer={
          <Text font="footnote">
            {t("打开后定时检查监控仓库里的 .scripting 脚本是否有更新，有变化时发通知提醒。应用在前台或后台保活期间按间隔自动检查；被系统挂起后，每次打开应用会补查，并按间隔发送提醒通知（点通知立即检查）。开启后首页右上角会增加一个手动检测按钮。首次启用只记录，之后有变化才提示")}
          </Text>
        }
      >
        <Toggle
          title={t("仓库监控")}
          value={monitorEnabled}
          onChanged={(v) => {
            setMonitorEnabled(v)
            // 仅首次打开开关时自动展开，之后默认收起
            if (v) setMonitorExpanded(true)
          }}
        />
        {monitorEnabled ? (
          <>
            {monitorExpanded ? (
              <>
                <HStack spacing={10} alignment="center">
                  <TextField
                    title={t("检查间隔")}
                    value={monitorInterval}
                    onChanged={setMonitorInterval}
                    keyboardType="numberPad"
                    frame={{ maxWidth: 150 }}
                  />
                  <Picker
                    value={monitorUnit}
                    onChanged={(v: string | number) =>
                      setMonitorUnit(
                        String(v) === "hour" || String(v) === "day"
                          ? (String(v) as "hour" | "day")
                          : "minute"
                      )
                    }
                    pickerStyle="menu"
                    label={<Text font="body">{t("单位")}</Text>}
                  >
                    <Text tag="minute">{t("分")}</Text>
                    <Text tag="hour">{t("小时")}</Text>
                    <Text tag="day">{t("天")}</Text>
                  </Picker>
                  <Spacer />
                </HStack>
                <Text font="footnote" foregroundStyle="secondaryLabel">
                  {t("默认 12 小时，最短 1 分钟；按间隔自动检查并发送提醒通知")}
                </Text>

                {monitorLinks.map((link) => (
                  <HStack key={link.url} spacing={10} alignment="center">
                    <VStack
                      alignment="leading"
                      spacing={2}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={() => editMonitorLink(link)}
                    >
                      <Text font="body">{link.name}</Text>
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        {link.url}
                      </Text>
                    </VStack>
                    <Spacer />
                    <HStack
                      spacing={4}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={() => renameMonitorLink(link)}
                    >
                      <Image
                        systemName="pencil"
                        foregroundStyle="tintColor"
                      />
                      <Text font="footnote" foregroundStyle="tintColor">
                        {t("备注")}
                      </Text>
                    </HStack>
                    <HStack
                      spacing={4}
                      contentShape={{ kind: "interaction", shape: "rect" }}
                      onTapGesture={() => removeMonitorLink(link)}
                    >
                      <Image
                        systemName="trash"
                        foregroundStyle="systemRed"
                      />
                      <Text font="footnote" foregroundStyle="systemRed">
                        {t("删除")}
                      </Text>
                    </HStack>
                  </HStack>
                ))}

                <HStack spacing={10} alignment="center">
                  <TextField
                    title={t("添加仓库链接")}
                    value={newMonitorUrl}
                    onChanged={setNewMonitorUrl}
                    prompt="https://github.com/owner/repo"
                  />
                  <HStack
                    spacing={4}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={addMonitorLink}
                  >
                    <Image systemName="plus.circle" foregroundStyle="tintColor" />
                    <Text font="footnote" foregroundStyle="tintColor">
                      {t("添加")}
                    </Text>
                  </HStack>
                </HStack>

                <Text font="body" padding={{ top: 6 }}>
                  {t("排除关键词")}
                </Text>
                <Text font="footnote" foregroundStyle="secondaryLabel">
                  {t("脚本名称包含任一关键词时，即使有更新也不提示、不列入更新页（例如排除「测试」可忽略测试脚本）")}
                </Text>
                {excludeKeywords.length > 0 ? (
                  excludeKeywords.map((kw) => (
                    <HStack key={kw} spacing={10} alignment="center">
                      <HStack
                        spacing={10}
                        alignment="center"
                        contentShape={{ kind: "interaction", shape: "rect" }}
                        onTapGesture={() => editExcludeKeyword(kw)}
                      >
                        <Image
                          systemName="nosign"
                          foregroundStyle="systemRed"
                        />
                        <Text font="body">{kw}</Text>
                      </HStack>
                      <Spacer />
                      <HStack
                        spacing={4}
                        contentShape={{ kind: "interaction", shape: "rect" }}
                        onTapGesture={() => removeExcludeKeyword(kw)}
                      >
                        <Image
                          systemName="xmark.circle"
                          foregroundStyle="systemRed"
                        />
                        <Text font="footnote" foregroundStyle="systemRed">
                          {t("删除")}
                        </Text>
                      </HStack>
                    </HStack>
                  ))
                ) : (
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {t("未设置排除关键词")}
                  </Text>
                )}
                <HStack spacing={10} alignment="center">
                  <TextField
                    title={t("添加排除关键词")}
                    value={newExcludeKeyword}
                    onChanged={setNewExcludeKeyword}
                    prompt={t("如：测试、请勿下载")}
                  />
                  <HStack
                    spacing={4}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={addExcludeKeyword}
                  >
                    <Image systemName="plus.circle" foregroundStyle="tintColor" />
                    <Text font="footnote" foregroundStyle="tintColor">
                      {t("添加")}
                    </Text>
                  </HStack>
                </HStack>
              </>
            ) : null}

            {/* 已忽略更新的脚本：点「忽略全部」后按路径持久化忽略，这里可恢复提醒 */}
            {monitorExpanded ? (
              <>
                <VStack alignment="leading" spacing={4} padding={{ top: 6 }}>
                  <Text font="body">{t("已忽略更新的脚本")}</Text>
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {t("这些脚本再发布新版本也不会提示；点「恢复提醒」后正常提示")}
                  </Text>
                </VStack>
                {monitorIgnoredPaths.length > 0 ? (
                  monitorIgnoredPaths.map((key) => {
                    const d = ignoredPathDisplay(key)
                    return (
                      <HStack key={key} spacing={10} alignment="center">
                        <Image
                          systemName="bell.slash"
                          foregroundStyle="secondaryLabel"
                        />
                        <VStack alignment="leading" spacing={2}>
                          <Text font="body">{d.name}</Text>
                          <Text font="caption" foregroundStyle="secondaryLabel">
                            {d.repo}
                          </Text>
                        </VStack>
                        <Spacer />
                        <HStack
                          spacing={4}
                          contentShape={{ kind: "interaction", shape: "rect" }}
                          onTapGesture={() => removeIgnoredPath(key)}
                        >
                          <Image
                            systemName="bell.badge"
                            foregroundStyle="tintColor"
                          />
                          <Text font="footnote" foregroundStyle="tintColor">
                            {t("恢复提醒")}
                          </Text>
                        </HStack>
                      </HStack>
                    )
                  })
                ) : (
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {t("未忽略任何脚本")}
                  </Text>
                )}
              </>
            ) : null}

            {/* 立即检查：始终显示，不随设置区折叠 */}
            <HStack
              spacing={8}
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={checkNow}
            >
              <Spacer />
              <Image
                systemName={
                  monitorChecking
                    ? "antenna.radiowaves.left.and.right"
                    : "arrow.clockwise"
                }
                foregroundStyle="tintColor"
              />
              <Text font="body" foregroundStyle="tintColor">
                {monitorChecking ? t("检查中…") : t("立即检查")}
              </Text>
              <Spacer />
            </HStack>
          </>
        ) : null}
      </Section>

      <Section
        header={<Text font="headline">{t("通用")}</Text>}
        footer={
          <Text font="footnote">
            {t("所有设置修改后自动保存，无需手动保存")}
          </Text>
        }
      >
        <HStack spacing={10}>
          <Picker
            value={language}
            onChanged={(v: string | number) => {
              const next = String(v) === "en" ? "en" : "zh"
              setLanguageState(next)
              // 语言立即生效（主页面通过订阅强制重渲染）
              setLanguage(next)
            }}
            pickerStyle="menu"
            label={
              // label 保持左侧不动；Picker 撑满整行，让右侧蓝色选中值（中文/English）贴到最右
              <Text font="body" frame={{ minWidth: 210, alignment: "leading" }}>
                {t("语言 / Language")}
              </Text>
            }
            frame={{ maxWidth: "infinity" }}
          >
            <Text tag="zh">中文</Text>
            <Text tag="en">English</Text>
          </Picker>
        </HStack>
        <Toggle
          title={t("记住展开状态")}
          value={rememberExpandState}
          onChanged={setRememberExpandState}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("勾选后记住首页左上角「备份 / 恢复」的展开 / 收起状态，下次打开仍保持（默认勾选）")}
        </Text>
        <Toggle
          title={t("搜索不隐藏其他脚本")}
          value={searchKeepAll}
          onChanged={setSearchKeepAll}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("首页搜索时仍显示全部脚本，匹配的排在前面；关闭后只显示匹配的脚本（默认勾选）")}
        </Text>
        <Toggle
          title={t("自动备份升级项")}
          value={autoBackupOnUpgrade}
          onChanged={setAutoBackupOnUpgrade}
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {t("检测到脚本版本变化后，先刷新脚本内容，内容稳定后才自动备份到 iPhone 端，避免备份到旧内容")}
        </Text>
      </Section>

      <Section
        header={<Text font="headline">{t("反馈")}</Text>}
        footer={
          <Text font="footnote">
            {t("使用中遇到问题或有功能建议？欢迎到 WWWeng🐝的仓库提 Issue，或发邮件联系")}
          </Text>
        }
      >
        <Link url="https://github.com/vvvvvveng/Scripting-releases/tree/main">
          <HStack spacing={10}>
            <Image systemName="link" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              {t("我的仓库")}
            </Text>
            <Spacer />
          </HStack>
        </Link>
        <Link url="https://t.me/WWWengShare">
          <HStack spacing={10}>
            <Image systemName="paperplane" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              {t("我的频道")}
            </Text>
            <Spacer />
          </HStack>
        </Link>
        <Link url="mailto:skype-lavish-yeast@duck.com">
          <HStack spacing={10}>
            <Image systemName="envelope" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              {t("我的邮箱")}
            </Text>
            <Spacer />
          </HStack>
        </Link>
      </Section>

      <Section
        header={<Text font="headline">{t("错误记录")}</Text>}
        footer={
          <Text font="footnote">
            {t("最近失败的备份 / 发布 / 恢复等操作会记录在这里（最多保留 50 条），方便排查问题")}
          </Text>
        }
      >
        {errorLogs.length === 0 ? (
          <EmptyState message={t("暂无错误记录")} />
        ) : (
          errorLogs.slice(0, 20).map((log, index) => (
            <VStack key={`${log.time}-${index}`} alignment="leading" spacing={3}>
              <HStack spacing={8}>
                <Text font="caption" foregroundStyle="secondaryLabel">
                  {formatDate(log.time)}
                </Text>
                <Text font="caption" foregroundStyle="systemOrange">
                  {log.operation}
                </Text>
              </HStack>
              <Text font="caption" foregroundStyle="secondaryLabel">
                {log.message}
              </Text>
            </VStack>
          ))
        )}
        {errorLogs.length > 0 && (
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => {
              clearErrorLogs()
              setErrorLogs([])
              showToast(t("已清空错误记录"))
            }}
          >
            <Spacer />
            <Image systemName="trash" foregroundStyle="systemRed" />
            <Text font="body" foregroundStyle="systemRed">{t("清空错误记录")}</Text>
            <Spacer />
          </HStack>
        )}
      </Section>
    </List>
  )
}

// ==================== 频道更新页 ====================

/** 频道更新页：列出最近一次检查发现的脚本变化，默认全选，可取消部分后点「更新」导入安装新版本 */
function ChannelUpdatePage() {
  const dismiss = Navigation.useDismiss()
  const lastCheck = useMemo(() => readLastChannelCheck(), [])
  // 已从仓库删除的记录不提示：runChannelMonitorCheck 已不再产生 removed；
  // 此处兜底清理历史 last-check 里可能残留的 removed 条目（打开一次后即不再显示）
  useEffect(() => {
    dismissChannelRemoved()
  }, [])
  const excludedTotal = useMemo(() => {
    let n = 0
    for (const r of lastCheck?.summary.results ?? []) {
      n += r.excludedCount ?? 0
    }
    return n
  }, [lastCheck])
  // 本次检查中被「忽略全部」按路径忽略的变化数（同一脚本再发新版也不再提示）
  const ignoredTotal = useMemo(() => {
    let n = 0
    for (const r of lastCheck?.summary.results ?? []) {
      n += r.ignoredCount ?? 0
    }
    return n
  }, [lastCheck])
  const items = useMemo(() => {
    const list: {
      id: string
      name: string
      type: "added" | "updated"
      repoName: string
      repoUrl: string
      path: string
    }[] = []
    for (const r of lastCheck?.summary.results ?? []) {
      if (!r.ok) continue
      const parts = repoParts(r.url)
      if (!parts) continue
      for (const c of r.changes) {
        // 防御：历史 last-check 可能残留 removed，一律不展示（已从仓库删除不提示）
        if (c.type === "removed") continue
        list.push({
          id: `${r.url}|${c.path}`,
          name: c.path.replace(/\.scripting$/i, ""),
          type: c.type,
          repoName: r.name,
          repoUrl: r.url,
          path: c.path,
        })
      }
    }
    return list
  }, [lastCheck])
  // 待处理脚本列表：每更新完一批就从这里移除已处理的项，全部处理完才自动关闭页面；
  // 只处理部分时页面保留，剩余项可继续处理或手动关闭
  const [pendingItems, setPendingItems] = useState<typeof items>(items)
  const [selected, setSelected] = useState<Set<string>>(() =>
    new Set(items.map((item) => item.id))
  )
  const [updating, setUpdating] = useState(false)
  const { showToast, toastProps } = useToast()

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  const allSelected = pendingItems.length > 0 && selected.size === pendingItems.length
  function toggleAll() {
    setSelected(
      allSelected ? new Set() : new Set(pendingItems.map((item) => item.id))
    )
  }

  // 忽略本次：只记录当前批次的签名（同一批变化不再提示/弹页），不写「不再更新」列表；
  // 同一脚本下次再发布（sha 变）仍会正常提醒。同时清零最近检查结果并关闭页面。
  function ignoreThisTime() {
    const sig = channelChangesSignature(lastCheck?.summary.results ?? [])
    if (sig) {
      updateChannelMonitorConfig({ channelMonitorNotifiedSig: sig })
    }
    dismissChannelUpdates()
    showToast(t("已忽略本次更新，不再提示"))
    dismiss()
  }

  // 不再更新：把当前批次涉及的所有脚本路径持久化到「已忽略」列表——同一脚本之后再次发布新版本
  // 也不再提示（直到在设置→仓库监控→已忽略更新的脚本 中恢复提醒）；同时记录批次签名防重复弹窗，
  // 并清零最近检查结果（通知点击路径也不再打开更新页），然后关闭页面
  function ignoreForever() {
    const cfg = resolveConfig()
    const sig = channelChangesSignature(lastCheck?.summary.results ?? [])
    const ignored = new Set(cfg.channelMonitorIgnoredPaths ?? [])
    let addedCount = 0
    for (const r of lastCheck?.summary.results ?? []) {
      if (!r.ok) continue
      for (const c of r.changes) {
        if (c.type === "removed") continue
        const key = `${r.url}|${c.path}`
        if (!ignored.has(key)) {
          ignored.add(key)
          addedCount += 1
        }
      }
    }
    const patch: Partial<AppConfig> = {
      channelMonitorIgnoredPaths: [...ignored],
    }
    if (sig) {
      patch.channelMonitorNotifiedSig = sig
    }
    updateChannelMonitorConfig(patch)
    dismissChannelUpdates()
    showToast(
      addedCount > 0
        ? tpl("已忽略 {n} 个脚本的更新，不再提示；可在设置→仓库监控 中恢复", {
            n: String(addedCount),
          })
        : t("已忽略本次更新，不再提示")
    )
    dismiss()
  }

  async function doUpdate() {
    if (updating) return
    const chosen = pendingItems.filter((item) => selected.has(item.id))
    if (chosen.length === 0) {
      showToast(t("请先选择要更新的脚本"), true)
      return
    }
    setUpdating(true)
    try {
      const urls: string[] = []
      for (const item of chosen) {
        const raw = await resolveRawScriptUrl(item.repoUrl, item.path)
        if (raw) {
          urls.push(raw)
        }
      }
      if (urls.length === 0) {
        showToast(t("获取下载地址失败，请检查网络后重试"), true)
        return
      }
      // 打开 Scripting 官方导入流程（https://scripting.fun/ 中转形式，与「分享(链接)」一致）：
      // 注意不能用 openURL(scripting://…) 直接唤起自定义 scheme（运行时无全局 openURL，且参数可能被二次解码），
      // 统一用 Safari.openURL 打开 https 中转链接，由浏览器原样携带已编码参数并跳回 Scripting 导入。
      const importLink =
        "https://scripting.fun/import_scripts?urls=" +
        encodeURIComponent(JSON.stringify(urls))
      await Safari.openURL(importLink)
      // 只有把列表里的脚本全部处理完才自动关闭；只处理一部分时，已处理的项从列表移除，
      // 剩余项默认全选，方便回来继续一键更新，也可点「关闭」手动退出
      const doneIds = new Set(chosen.map((item) => item.id))
      const remaining = pendingItems.filter(
        (item) => !doneIds.has(item.id)
      )
      showToast(
        remaining.length > 0
          ? tpl("已开始更新 {n} 个脚本，还有 {m} 个待处理", {
              n: String(urls.length),
              m: String(remaining.length),
            })
          : tpl("已开始更新 {n} 个脚本", { n: String(urls.length) })
      )
      if (remaining.length === 0) {
        dismiss()
        return
      }
      setPendingItems(remaining)
      setSelected(new Set(remaining.map((item) => item.id)))
    } catch (error) {
      logError("频道更新", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setUpdating(false)
    }
  }

  // 顶部操作行（关闭 / 全选）：放在页面内容里，不依赖导航栏 toolbar（嵌套模态中 toolbar 不渲染）。
  // 关闭样式与其他页面工具栏关闭按钮一致：纯文字、无图标。
  // 不用 Button / contentShape：实测 Button 仍带白色高亮框，纯 Text 点击无任何背景。
  // 不用 Section 包裹，避免产生白色卡片背景。
  const actionRow = (
    // 关闭/全选操作行：listRowBackground 透明，底色与页面其他区域一致（List 直接子元素默认是带卡片背景的 row）
    <HStack
      spacing={8}
      padding={{ top: 8, bottom: 8 }}
      listRowBackground={<Rectangle fill="rgba(0,0,0,0)" />}
    >
      <Text
        font="body"
        foregroundStyle="tintColor"
        onTapGesture={dismiss}
      >
        {t("关闭")}
      </Text>
      <Spacer />
      <Text
        font="body"
        foregroundStyle="tintColor"
        onTapGesture={toggleAll}
      >
        {allSelected ? t("取消全选") : t("全选")}
      </Text>
    </HStack>
  )

  // 被排除关键词隐藏的脚本提示：让用户明白为什么“新上传的脚本检测不到”
  const excludedRow =
    excludedTotal > 0 ? (
      <HStack spacing={6}>
        <Image
          systemName="eye.slash"
          foregroundStyle="secondaryLabel"
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {tpl("{n} 个脚本因名称含排除关键词未显示，可在设置里调整", {
            n: String(excludedTotal),
          })}
        </Text>
      </HStack>
    ) : null

  // 被「忽略全部」按路径忽略的脚本提示：同一脚本再发新版也不提示，可去设置里恢复提醒
  const ignoredRow =
    ignoredTotal > 0 ? (
      <HStack spacing={6}>
        <Image
          systemName="bell.slash"
          foregroundStyle="secondaryLabel"
        />
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {tpl("{n} 个脚本已忽略更新（再发新版也不再提示），可在设置→仓库监控 中恢复", {
            n: String(ignoredTotal),
          })}
        </Text>
      </HStack>
    ) : null

  // 底部悬浮操作条：与首页长按多选同款胶囊样式（secondarySystemBackground 圆角底栏 + 方形图标胶囊按钮）。
  // 三个按钮依次为「不再更新」「忽略本次」「更新选中」；通过 safeAreaInset 固定在底部，同样不依赖导航栏 toolbar。
  const updateBar = (
    <VStack alignment="center" padding={{ bottom: 10 }}>
      <HStack
        spacing={8}
        alignment="center"
        padding={{ horizontal: 10, vertical: 8 }}
        background={{
          style: { color: "secondarySystemBackground", opacity: 0.95 },
          shape: { type: "rect", cornerRadius: 20 },
        }}
      >
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 70, height: 58 }}
          background={{
            style: { color: "label", opacity: 0.08 },
            shape: { type: "rect", cornerRadius: 14 },
          }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={ignoreForever}
        >
          <Image
            systemName="bell.slash"
            font={17}
            foregroundStyle="secondaryLabel"
          />
          <Text font="caption2" foregroundStyle="secondaryLabel">
            {t("不再更新")}
          </Text>
        </VStack>
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 70, height: 58 }}
          background={{
            style: { color: "label", opacity: 0.08 },
            shape: { type: "rect", cornerRadius: 14 },
          }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={ignoreThisTime}
        >
          <Image
            systemName="eye.slash"
            font={17}
            foregroundStyle="secondaryLabel"
          />
          <Text font="caption2" foregroundStyle="secondaryLabel">
            {t("忽略本次")}
          </Text>
        </VStack>
        <VStack
          spacing={3}
          alignment="center"
          frame={{ width: 70, height: 58 }}
          background={{
            style: { color: "systemBlue", opacity: 0.15 },
            shape: { type: "rect", cornerRadius: 14 },
          }}
          contentShape={{ kind: "interaction", shape: "rect" }}
          onTapGesture={doUpdate}
        >
          <Image
            systemName={
              updating ? "arrow.triangle.2.circlepath" : "arrow.down.circle"
            }
            font={17}
            foregroundStyle="tintColor"
          />
          <Text font="caption2" foregroundStyle="tintColor">
            {updating ? t("更新中…") : t("更新选中")}
          </Text>
        </VStack>
      </HStack>
    </VStack>
  )

  if (pendingItems.length === 0) {
    return (
      <List
        navigationTitle={t("频道更新")}
        navigationBarTitleDisplayMode="inline"
        toast={toastProps}
      >
        {actionRow}
        {excludedRow}
        {ignoredRow}
        <Section>
          <EmptyState message={t("没有可更新的脚本")} />
        </Section>
      </List>
    )
  }

  return (
    <List
      navigationTitle={t("频道更新")}
      navigationBarTitleDisplayMode="inline"
      toast={toastProps}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: updateBar,
        },
      }}
    >
      {actionRow}
      {excludedRow}
      {ignoredRow}
      <Section
        header={<Text font="headline">{t("可更新的脚本")}</Text>}
        footer={
          <Text font="footnote">
            {t(
              "默认全选；点「更新」通过 Scripting 导入安装新版本，未勾选的跳过；全部处理完自动关闭"
            )}
          </Text>
        }
      >
        {pendingItems.length === 0 ? (
          <EmptyState message={t("没有可更新的脚本")} />
        ) : (
          pendingItems.map((item) => (
            <HStack
              key={item.id}
              spacing={10}
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => toggle(item.id)}
            >
              <Image
                systemName={
                  selected.has(item.id)
                    ? "checkmark.circle.fill"
                    : "circle"
                }
                foregroundStyle={
                  selected.has(item.id) ? "systemBlue" : "secondaryLabel"
                }
              />
              <VStack alignment="leading" spacing={2}>
                <Text font="body">{item.name}</Text>
                <Text font="caption" foregroundStyle="secondaryLabel">
                  {item.repoName} · {item.type === "added" ? t("新增") : t("更新")}
                </Text>
              </VStack>
              <Spacer />
              <Chevron />
            </HStack>
          ))
        )}
      </Section>
    </List>
  )
}

// ==================== 分组选择 ====================

function GroupPickerPage({ onSelect }: { onSelect: (group: GroupInfo) => void }) {
  const dismiss = Navigation.useDismiss()
  const groups = useMemo(() => readScriptingGroups(), [])

  return (
    <List
      navigationTitle={t("选择分组")}
      navigationBarTitleDisplayMode="inline"
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
    >
      <Section
        header={<Text font="headline">{t("脚本分组")}</Text>}
        footer={
          <Text font="footnote">
            {t("来自 Scripting 应用的分组（.scripting/settings.json），点击分组直接备份该组全部脚本")}
          </Text>
        }
      >
        {groups.length === 0 ? (
          <EmptyState message={t("没有可备份的分组")} />
        ) : (
          groups.map((group) => (
            <HStack
              key={group.key}
              spacing={10}
              contentShape="rect"
              onTapGesture={() => {
                dismiss()
                onSelect(group)
              }}
            >
              <RowIcon systemName="folder.fill" />
              <Text font="body">{group.name}</Text>
              <Spacer />
              <Text font="caption" foregroundStyle="secondaryLabel">
                {tpl("{n} 个脚本", { n: String(group.scripts.length) })}
              </Text>
              <Chevron />
            </HStack>
          ))
        )}
      </Section>
    </List>
  )
}

// ==================== 备份（按名称选择脚本） ====================

function ScriptPickerPage({
  initial,
  onSelect,
  pickerMode = "backup",
}: {
  initial: ScriptInfo[]
  onSelect: (scripts: ScriptInfo[]) => void
  pickerMode?: "backup" | "github"
}) {
  const dismiss = Navigation.useDismiss()
  const [allScripts, setAllScripts] = useState<ScriptInfo[]>([])
  const [scriptsLoading, setScriptsLoading] = useState(true)
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(initial.map((s) => s.folderName))
  )
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">(() => {
    const s = resolveConfig().scriptSort
    return s === "name" || s === "name_desc" ? s : "modified"
  })
  const { showToast, toastProps } = useToast()

  useEffect(() => {
    setTimeout(() => {
      setAllScripts(scanScripts())
      setScriptsLoading(false)
    }, 50)
  }, [])

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? allScripts.filter(
          (s) =>
            keywordMatches(s.displayName, keyword) ||
            keywordMatches(s.folderName, keyword)
        )
      : [...allScripts]
    list.sort((a, b) => compareScripts(a, b, sortMode))
    return list
  }, [allScripts, query, sortMode])

  function toggleOne(script: ScriptInfo) {
    const next = new Set(selected)
    if (next.has(script.folderName)) {
      next.delete(script.folderName)
    } else {
      next.add(script.folderName)
    }
    setSelected(next)
  }

  const isGithub = pickerMode === "github"
  const allSelected =
    filtered.length > 0 && filtered.every((s) => selected.has(s.folderName))

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      const allOn =
        filtered.length > 0 && filtered.every((s) => next.has(s.folderName))
      if (allOn) {
        filtered.forEach((s) => next.delete(s.folderName))
      } else {
        filtered.forEach((s) => next.add(s.folderName))
      }
      return next
    })
  }

  function clearSelection() {
    setSelected(new Set())
  }

  function done() {
    const picked = allScripts.filter((s) => selected.has(s.folderName))
    if (picked.length === 0) {
      showToast(t("请至少选择一个脚本"), true)
      return
    }
    dismiss()
    onSelect(picked)
  }

  /** 点击单个脚本：直接开始备份/发布该脚本 */
  function backupOne(script: ScriptInfo) {
    dismiss()
    onSelect([script])
  }

  return (
    <List
      navigationTitle={isGithub ? t("选择要发布的脚本") : t("选择要备份的脚本")}
      navigationBarTitleDisplayMode="inline"
      scrollDismissesKeyboard="immediately"
      toast={toastProps}
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
      toolbar={
        <Toolbar>
          <ToolbarItem placement="topBarTrailing">
            <Button title={t("取消")} action={() => dismiss()} />
          </ToolbarItem>
        </Toolbar>
      }
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content:
            selected.size > 0 ? (
              <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => dismiss()}
                >
                  <Image systemName="chevron.left" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("返回")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={clearSelection}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("取消")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName="checklist"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? t("取消全选") : t("全选")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={done}
                >
                  <Image systemName="checkmark.circle" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {isGithub ? t("发布") : t("备份")}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
            ) : (
              <></>
            ),
        },
      }}
    >
      <Section
        header={
          <HStack spacing={8} alignment="center">
            <Text font="headline">{tpl("脚本列表（共 {n} 个脚本）", { n: String(allScripts.length) })}</Text>
            <Spacer />
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const v = String(value)
                const next = v === "name" || v === "name_desc" ? v : "modified"
                setSortMode(next)
                saveConfig({ ...resolveConfig(), scriptSort: next })
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name"
                      ? t("按名称 A-Z")
                      : sortMode === "name_desc"
                        ? t("按名称 Z-A")
                        : t("按最新修改")}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">{t("按最新修改")}</Text>
              <Text tag="name">{t("按名称 A-Z")}</Text>
              <Text tag="name_desc">{t("按名称 Z-A")}</Text>
            </Picker>
          </HStack>
        }
        footer={
          <VStack
            alignment="leading"
            spacing={2}
            padding={{ top: 8, bottom: 24 }}
          >
            <Text font="caption" foregroundStyle="secondaryLabel">
              {t("点击脚本名：直接开始备份/发布该脚本")}
            </Text>
            <Text font="caption" foregroundStyle="secondaryLabel">
              {t("长按脚本名：进入多选模式，可勾选多个后统一备份/发布")}
            </Text>
          </VStack>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索脚本名")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {scriptsLoading ? (
          <EmptyState message={t("正在加载脚本…")} />
        ) : filtered.length === 0 ? (
          <EmptyState message={t("未找到匹配的脚本")} />
        ) : (
          filtered.map((script) => {
            const isOn = selected.has(script.folderName)
            return (
              <HStack
                key={script.folderName}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(script)
                  } else {
                    backupOne(script)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => toggleOne(script),
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName="chevron.left.forwardslash.chevron.right"
                    color="tintColor"
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{script.displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    v{script.version} · {formatDate(script.modifiedAt)}
                  </Text>
                </VStack>
                <Spacer />
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（备份列表） ====================

function RestorePage({ destination }: { destination: Destination }) {
  const [query, setQuery] = useState("")
  const [items, setItems] = useState<BackupItem[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [scriptCounts, setScriptCounts] = useState<Map<string, number>>(new Map())
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">("modified")
  const { showToast, toastProps } = useToast()
  const dismiss = Navigation.useDismiss()

  /** 列表加载完成后，后台逐个统计备份脚本数（缓存命中直接显示，否则解压统计后写缓存） */
  function countScriptsInBackground(list: BackupItem[]) {
    const counts = new Map<string, number>()
    let index = 0
    function next() {
      if (index >= list.length) {
        return
      }
      const item = list[index]
      index += 1
      const cached = getBackupScriptCount(destination, item)
      if (cached != null) {
        counts.set(item.path, cached)
        setScriptCounts(new Map(counts))
        next()
        return
      }
      // 逐个让出主线程，避免一次性解压全部卡住 UI
      setTimeout(() => {
        try {
          const count = computeBackupScriptCount(item)
          counts.set(item.path, count)
          saveBackupScriptCount(destination, item, count)
        } catch {
          counts.set(item.path, -1)
        }
        setScriptCounts(new Map(counts))
        next()
      }, 30)
    }
    next()
  }

  useEffect(() => {
    setScriptCounts(new Map())
    setLoading(true)
    setTimeout(() => {
      const list = scanBackups(destination)
      setItems(list)
      setLoading(false)
      countScriptsInBackground(list)
    }, 50)
  }, [destination])

  const visibleItems = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? items.filter((item) => keywordMatches(item.name, keyword))
      : [...items]
    list.sort((a, b) => {
      if (sortMode === "name") return a.name.localeCompare(b.name)
      if (sortMode === "name_desc") return b.name.localeCompare(a.name)
      return b.modifiedAt - a.modifiedAt
    })
    return list
  }, [items, query, sortMode])

  const selectedItems = items.filter((item) => selected.has(item.path))
  const allSelected =
    visibleItems.length > 0 && visibleItems.every((item) => selected.has(item.path))

  function refresh() {
    setScriptCounts(new Map())
    setLoading(true)
    setTimeout(() => {
      const list = scanBackups(destination)
      setItems(list)
      setLoading(false)
      countScriptsInBackground(list)
    }, 50)
  }

  function toggleOne(item: BackupItem) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(item.path)) {
        next.delete(item.path)
      } else {
        next.add(item.path)
      }
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      if (allSelected) {
        visibleItems.forEach((item) => next.delete(item.path))
      } else {
        visibleItems.forEach((item) => next.add(item.path))
      }
      return next
    })
  }

  async function doDeleteSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要删除的备份"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("删除备份"),
      message: tpl("确定删除 {n} 个备份？此操作不可恢复。", { n: String(selectedItems.length) }),
      actions: [{ label: t("取消") }, { label: t("删除"), destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    let okCount = 0
    for (const item of selectedItems) {
      if (deleteLocalBackup(item)) {
        okCount += 1
      }
    }
    if (okCount > 0) {
      showToast(tpl("已删除 {n} 个备份", { n: String(okCount) }))
      notifyBackupChange()
    } else {
      showToast(t("删除失败"), true)
    }
    setSelected(new Set())
    refresh()
  }

  async function doShareSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要分享的备份"), true)
      return
    }
    try {
      await shareLocalBackups(selectedItems)
    } catch (error) {
      logError("分享备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doRenameSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要重命名的备份"), true)
      return
    }
    if (selectedItems.length > 1) {
      showToast(t("重命名仅支持单选备份"), true)
      return
    }
    const item = selectedItems[0]
    const name = await inputPrompt({
      title: t("重命名备份"),
      message: t("输入新的备份名称"),
      defaultValue: item.name,
      placeholder: item.name,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameLocalBackup(item, name.trim())
      showToast(t("已重命名"))
      setSelected(new Set())
      refresh()
    } catch (error) {
      logError("重命名备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function openBackup(item: BackupItem) {
    if (refreshing) {
      return
    }
    setRefreshing(true)
    try {
      const inspected = inspectBackup(item)
      if (!inspected) {
        showToast(t("无法读取该备份"), true)
        return
      }
      const { candidates, tempDir } = inspected
      if (candidates.length === 0) {
        showToast(t("该备份中没有找到脚本（缺少 script.json）"), true)
        cleanupTemp(tempDir)
        return
      }
      if (candidates.length === 1) {
        const ok = await confirmRestoreOne(candidates[0])
        if (ok) {
          await restoreScripts([candidates[0]], true)
          showToast(t("已恢复"))
          refresh()
        }
        cleanupTemp(tempDir)
        return
      }
      // 多个脚本：让用户选择单个或全部恢复（支持搜索、全选）
      const result = await Navigation.present(
        <ScriptSelectionPage candidates={candidates} />
      )
      if (result?.restored != null) {
        showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
        refresh()
      }
      cleanupTemp(tempDir)
    } catch (error) {
      logError("恢复备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setRefreshing(false)
    }
  }

  function cleanupTemp(tempDir: string | null) {
    if (tempDir && pathExists(tempDir)) {
      try {
        FileManager.removeSync(tempDir)
      } catch {
        // ignore
      }
    }
  }

  const toolbar = (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button title={t("返回")} action={dismiss} />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("刷新")} action={refresh} />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle={t("恢复备份")}
      navigationBarTitleDisplayMode="inline"
      navigationBarBackButtonHidden
      scrollDismissesKeyboard="immediately"
      toolbar={toolbar}
      toast={toastProps}
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: selected.size > 0 ? (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 1 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                {items.length === 1 || !allSelected ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => {
                      setSelected(new Set())
                    }}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      {t("取消")}
                    </Text>
                  </VStack>
                ) : null}
                {items.length > 1 ? (
                  <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName={allSelected ? "checkmark.circle.fill" : "checkmark.circle"}
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? t("取消全选") : t("全选")}
                  </Text>
                </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doDeleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("删除")}
                  </Text>
                </VStack>
                {selectedItems.length === 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doRenameSelected}
                  >
                    <Image systemName="pencil" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("重命名")}
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doShareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("分享")}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
          ) : (
            <></>
          ),
        },
      }}
    >
      <Section
        header={
          <HStack spacing={8} alignment="center">
            <Text font="headline">
              {tpl("备份列表（共 {n} 个）", {
                n: String(items.length),
              })}
            </Text>
            <Spacer />
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const v = String(value)
                setSortMode(v === "name" || v === "name_desc" ? v : "modified")
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name"
                      ? t("按名称 A-Z")
                      : sortMode === "name_desc"
                        ? t("按名称 Z-A")
                        : t("按最新修改")}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">{t("按最新修改")}</Text>
              <Text tag="name">{t("按名称 A-Z")}</Text>
              <Text tag="name_desc">{t("按名称 Z-A")}</Text>
            </Picker>
          </HStack>
        }
        footer={
          <Text font="footnote">{tpl("备份目录：{dir}", { dir: backupRootFor(destination) })}</Text>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索备份")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {loading ? (
          <EmptyState message={t("正在读取备份…")} />
        ) : visibleItems.length === 0 ? (
          <EmptyState message={t("暂无备份，先到首页开始备份吧")} />
        ) : (
          visibleItems.map((item) => {
            const isOn = selected.has(item.path)
            return (
              <HStack
                key={item.path}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(item)
                  } else {
                    openBackup(item)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    toggleOne(item)
                  },
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName={
                      item.path.toLowerCase().endsWith(".zip")
                        ? "doc.zipper"
                        : "chevron.left.forwardslash.chevron.right"
                    }
                    color="tintColor"
                    small={!item.path.toLowerCase().endsWith(".zip")}
                    leftPad={
                      item.path.toLowerCase().endsWith(".zip") ? 0 : -3
                    }
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{item.name}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {formatDate(item.modifiedAt)} · {formatBytes(item.byteSize)}
                    {selected.size > 0
                      ? ""
                      : ` · ${
                          scriptCounts.has(item.path)
                            ? scriptCounts.get(item.path)! >= 0
                              ? tpl("{n} 个脚本", { n: String(scriptCounts.get(item.path) ?? 0) })
                              : t("未知")
                            : t("统计中…")
                        }`}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（Github 备份仓库） ====================

/** 从 GitHub 私密备份仓库列出并下载 zip 恢复脚本 */
function GithubRestorePage() {
  const [query, setQuery] = useState("")
  const [items, setItems] = useState<{ name: string; path: string; size: number }[]>([])
  const [manifest, setManifest] = useState<GithubBackupManifest | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">("modified")
  const { showToast, toastProps } = useToast()
  const dismiss = Navigation.useDismiss()
  const gh = useMemo(
    () => resolveBackupGithubConfig(resolveGithubConfig()),
    []
  )

  const visibleItems = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    const list = keyword
      ? items.filter((item) => keywordMatches(item.name, keyword))
      : [...items]
    if (sortMode === "name") {
      list.sort((a, b) => a.name.localeCompare(b.name))
    } else if (sortMode === "name_desc") {
      list.sort((a, b) => b.name.localeCompare(a.name))
    } else {
      sortGithubBackupsByTime(list, manifest)
    }
    return list
  }, [items, query, sortMode, manifest])

  const selectedItems = items.filter((item) => selected.has(item.path))
  const allSelected =
    visibleItems.length > 0 && visibleItems.every((item) => selected.has(item.path))

  async function reload() {
    setLoading(true)
    try {
      const [list, meta] = await Promise.all([
        listGithubBackups(gh),
        readGithubBackupManifest(gh),
      ])
      setItems(sortGithubBackupsByTime(list, meta))
      setManifest(meta)
    } catch (error) {
      logError("Github备份列表", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      setLoading(false)
    }
  }

  // 进入页面时拉取一次列表
  useEffect(() => {
    reload()
  }, [])

  function toggleOne(item: { name: string; path: string; size: number }) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(item.path)) {
        next.delete(item.path)
      } else {
        next.add(item.path)
      }
      return next
    })
  }

  function toggleAll() {
    setSelected((prev) => {
      const next = new Set(prev)
      if (allSelected) {
        visibleItems.forEach((item) => next.delete(item.path))
      } else {
        visibleItems.forEach((item) => next.add(item.path))
      }
      return next
    })
  }

  async function doDeleteSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要删除的备份"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("删除备份"),
      message: tpl("确定删除 {n} 个远端备份？此操作不可恢复。", { n: String(selectedItems.length) }),
      actions: [{ label: t("取消") }, { label: t("删除"), destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    let okCount = 0
    for (const item of selectedItems) {
      try {
        await deleteGithubBackup(gh, item.path)
        okCount += 1
      } catch (error) {
        logError("Github备份删除", error)
      }
    }
    if (okCount > 0) {
      showToast(tpl("已删除 {n} 个备份", { n: String(okCount) }))
      notifyBackupChange()
    } else {
      showToast(t("删除失败"), true)
    }
    setSelected(new Set())
    reload()
  }

  async function doShareSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要分享的备份"), true)
      return
    }
    try {
      await shareGithubBackups(gh, selectedItems)
    } catch (error) {
      logError("分享Github备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doRenameSelected() {
    if (selectedItems.length === 0) {
      showToast(t("请先选择要重命名的备份"), true)
      return
    }
    if (selectedItems.length > 1) {
      showToast(t("重命名仅支持单选备份"), true)
      return
    }
    const item = selectedItems[0]
    const lower = item.name.toLowerCase()
    const base = lower.endsWith(".scripting")
      ? item.name.slice(0, -10)
      : lower.endsWith(".zip")
        ? item.name.slice(0, -4)
        : item.name
    const name = await inputPrompt({
      title: t("重命名备份"),
      message: t("输入新的备份名称"),
      defaultValue: base,
      placeholder: base,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      await renameGithubBackup(gh, item, name.trim())
      showToast(t("已重命名"))
      setSelected(new Set())
      reload()
    } catch (error) {
      logError("重命名Github备份", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 下载远端 zip → 解开 → 恢复（单脚本确认 / 多脚本选择） */
  async function openGithubBackup(item: { name: string; path: string; size: number }) {
    if (refreshing) {
      return
    }
    setRefreshing(true)
    showToast(tpl("正在下载 {name}…", { name: item.name }))
    let tempDir: string | null = null
    try {
      const zipPath = await downloadGithubBackup(gh, item.path)
      const inspected = inspectBackup({
        name: item.name,
        path: zipPath,
        isZip: true,
        modifiedAt: Date.now(),
        byteSize: item.size,
        scriptCount: 0,
      })
      if (!inspected) {
        showToast(t("无法读取该备份"), true)
        return
      }
      tempDir = inspected.tempDir
      const candidates = inspected.candidates
      if (candidates.length === 0) {
        showToast(t("该备份中没有找到脚本（缺少 script.json）"), true)
        return
      }
      if (candidates.length === 1) {
        const ok = await confirmRestoreOne(candidates[0])
        if (ok) {
          await restoreScripts([candidates[0]], true)
          showToast(t("已恢复"))
        }
        return
      }
      const result = await Navigation.present(
        <ScriptSelectionPage candidates={candidates} />
      )
      if (result?.restored != null) {
        showToast(tpl("已恢复 {n} 个脚本", { n: String(result.restored) }))
      }
    } catch (error) {
      logError("Github备份恢复", error)
      showToast(error instanceof Error ? error.message : String(error), true)
    } finally {
      if (tempDir && pathExists(tempDir)) {
        try {
          FileManager.removeSync(tempDir)
        } catch {}
      }
      setRefreshing(false)
    }
  }

  const toolbar = (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button title={t("返回")} action={dismiss} />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button
          title={refreshing ? t("加载中…") : t("刷新")}
          action={() => reload()}
        />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle={t("恢复备份")}
      navigationBarTitleDisplayMode="inline"
      navigationBarBackButtonHidden
      scrollDismissesKeyboard="immediately"
      toast={toastProps}
      toolbar={toolbar}
      simultaneousGesture={DragGesture({ minDistance: 12, coordinateSpace: "global" }).onEnded((d) => {
        // 从屏幕左边缘向右滑返回上级（不干扰列表滚动/左滑删除）
        if (d.startLocation.x < 50 && d.translation.width > 120) {
          dismiss()
        }
      })}
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: selected.size > 0 ? (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 1 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                {items.length === 1 || !allSelected ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => {
                      setSelected(new Set())
                    }}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                    <Text font="caption2" foregroundStyle="secondaryLabel">
                      {t("取消")}
                    </Text>
                  </VStack>
                ) : null}
                {items.length > 1 ? (
                  <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={toggleAll}
                >
                  <Image
                    systemName={allSelected ? "checkmark.circle.fill" : "checkmark.circle"}
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  />
                  <Text
                    font="caption2"
                    foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                  >
                    {allSelected ? t("取消全选") : t("全选")}
                  </Text>
                </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doDeleteSelected}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("删除")}
                  </Text>
                </VStack>
                {selectedItems.length === 1 ? (
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={doRenameSelected}
                  >
                    <Image systemName="pencil" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("重命名")}
                    </Text>
                  </VStack>
                ) : null}
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={doShareSelected}
                >
                  <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("分享")}
                  </Text>
                </VStack>
              </HStack>
            </VStack>
          ) : (
            <></>
          ),
        },
      }}
    >
      <Section
        header={
          <HStack spacing={8} alignment="center">
            <Text font="headline">{tpl("备份列表（共 {n} 个）", { n: String(items.length) })}</Text>
            <Spacer />
            <Picker
              value={sortMode}
              onChanged={(value: string | number) => {
                const v = String(value)
                setSortMode(v === "name" || v === "name_desc" ? v : "modified")
              }}
              pickerStyle="menu"
              padding={{ trailing: -12 }}
              label={
                <HStack spacing={4}>
                  <Image
                    systemName="arrow.up.arrow.down"
                    foregroundStyle="secondaryLabel"
                  />
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    {sortMode === "name"
                      ? t("按名称 A-Z")
                      : sortMode === "name_desc"
                        ? t("按名称 Z-A")
                        : t("按最新修改")}
                  </Text>
                </HStack>
              }
            >
              <Text tag="modified">{t("按最新修改")}</Text>
              <Text tag="name">{t("按名称 A-Z")}</Text>
              <Text tag="name_desc">{t("按名称 Z-A")}</Text>
            </Picker>
          </HStack>
        }
        footer={
          <VStack alignment="leading" spacing={4}>
            <Text font="footnote">
              {gh.backupPath
                ? tpl("仓库目录：{dir}（{repo}）", { dir: gh.backupPath, repo: `${gh.owner}/${gh.backupRepo}` })
                : tpl("仓库：{repo}", { repo: `${gh.owner}/${gh.backupRepo}` })}
            </Text>
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {t("备份、删除的文件受网络传输影响不会立马成功，耐心等待即可")}
            </Text>
          </VStack>
        }
      >
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索备份")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
        {loading ? (
          <EmptyState message={t("正在读取备份仓库…")} />
        ) : visibleItems.length === 0 ? (
          <EmptyState message={t("备份仓库里暂无备份，先到首页开始备份吧")} />
        ) : (
          visibleItems.map((item) => {
            const isOn = selected.has(item.path)
            const lower = item.name.toLowerCase()
            const displayName = lower.endsWith(".scripting")
              ? item.name.slice(0, -10)
              : lower.endsWith(".zip")
                ? item.name.slice(0, -4)
                : item.name
            return (
              <HStack
                key={item.path}
                spacing={10}
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => {
                  if (selected.size > 0) {
                    toggleOne(item)
                  } else {
                    openGithubBackup(item)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    toggleOne(item)
                  },
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName={
                      lower.endsWith(".zip")
                        ? "doc.zipper"
                        : "chevron.left.forwardslash.chevron.right"
                    }
                    color="tintColor"
                    small={!lower.endsWith(".zip")}
                    leftPad={lower.endsWith(".zip") ? 0 : -3}
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    {formatBytes(item.size)}
                    {manifest?.backups[item.path]
                      ? tpl(" · {date} · {n} 个脚本", {
                          date: formatDate(manifest.backups[item.path].createdAt),
                          n: String(manifest.backups[item.path].scriptCount),
                        })
                      : t(" · 未知")}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 恢复（多脚本选择：搜索 + 全选 + 单恢复/全部恢复） ====================

/** 更新说明全屏编辑器：多行 TextField 方便编排格式，默认预填云端/本地说明，底部悬浮按钮取消/清空/发布 */
function ChangelogEditorPage({
  initial,
  scriptName,
  version,
}: {
  initial: string
  scriptName: string
  version: string
}) {
  const dismiss = Navigation.useDismiss()
  const [text, setText] = useState(initial)
  return (
    <List
      navigationTitle={t("更新说明")}
      navigationBarTitleDisplayMode="inline"
      navigationBarBackButtonHidden
      scrollDismissesKeyboard="immediately"
      safeAreaInset={{
        bottom: {
          alignment: "center",
          spacing: 8,
          content: (
            <VStack alignment="center" padding={{ bottom: 10 }}>
              <HStack
                spacing={10}
                alignment="center"
                padding={{ horizontal: 10, vertical: 8 }}
                background={{
                  style: { color: "secondarySystemBackground", opacity: 0.95 },
                  shape: { type: "rect", cornerRadius: 20 },
                }}
              >
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => dismiss(null)}
                >
                  <Image systemName="xmark.circle" foregroundStyle="secondaryLabel" />
                  <Text font="caption2" foregroundStyle="secondaryLabel">
                    {t("取消")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "systemRed", opacity: 0.15 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => setText("")}
                >
                  <Image systemName="trash" foregroundStyle="systemRed" />
                  <Text font="caption2" foregroundStyle="systemRed">
                    {t("清空")}
                  </Text>
                </VStack>
                <VStack
                  spacing={3}
                  alignment="center"
                  frame={{ width: 48, height: 52 }}
                  background={{
                    style: { color: "label", opacity: 0.08 },
                    shape: { type: "rect", cornerRadius: 12 },
                  }}
                  contentShape={{ kind: "interaction", shape: "rect" }}
                  onTapGesture={() => dismiss(text)}
                >
                  <Image systemName="paperplane" foregroundStyle="tintColor" />
                  <Text font="caption2" foregroundStyle="tintColor">
                    {t("发布")}
                  </Text>
                </VStack>
              </HStack>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {tpl("{name} 更新后首次运行会自动弹出此说明", { name: scriptName })}
              </Text>
            </VStack>
          ),
        },
      }}
    >
      {/* 标题行：撑满宽度居中，listRowBackground 透明使底色与页面其他区域一致（List 直接子元素默认是带卡片背景的 row） */}
      <VStack
        alignment="center"
        spacing={4}
        padding={{ top: 12, bottom: 12 }}
        frame={{ maxWidth: "infinity" }}
        listRowBackground={<Rectangle fill="rgba(0,0,0,0)" />}
      >
        <Text font="headline">
          {scriptName} · {t("更新说明")}
        </Text>
        <Text font="footnote" foregroundStyle="secondaryLabel">
          {tpl("{name} {v}", { name: t("版本"), v: version })}
        </Text>
      </VStack>
      <Section>
        <TextField
          title=""
          value={text}
          onChanged={setText}
          axis="vertical"
          autofocus
          prompt={t("填写本次更新说明，可换行编排格式…")}
        />
      </Section>
    </List>
  )
}

function ScriptSelectionPage({
  candidates,
}: {
  candidates: CandidateScript[]
}) {
  const dismiss = Navigation.useDismiss()
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [busy, setBusy] = useState(false)
  const [sortMode, setSortMode] = useState<"modified" | "name" | "name_desc">(() => {
    const s = resolveConfig().scriptSort
    return s === "name" || s === "name_desc" ? s : "modified"
  })
  const { showToast, toastProps } = useToast()

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    let list = keyword
      ? candidates.filter((c) => keywordMatches(c.folderName, keyword))
      : [...candidates]
    list.sort((a, b) => {
      if (sortMode === "name") {
        return compareNames(a.folderName, b.folderName)
      }
      if (sortMode === "name_desc") {
        return compareNames(b.folderName, a.folderName)
      }
      return (b.modifiedAt ?? 0) - (a.modifiedAt ?? 0)
    })
    return list
  }, [candidates, query, sortMode])

  const allSelected =
    filtered.length > 0 && filtered.every((c) => selected.has(c.folderName))

  function toggleOne(candidate: CandidateScript) {
    const next = new Set(selected)
    if (next.has(candidate.folderName)) {
      next.delete(candidate.folderName)
    } else {
      next.add(candidate.folderName)
    }
    setSelected(next)
  }

  function toggleAll() {
    const next = new Set(selected)
    if (allSelected) {
      filtered.forEach((c) => next.delete(c.folderName))
    } else {
      filtered.forEach((c) => next.add(c.folderName))
    }
    setSelected(next)
  }

  async function doRestore(restoreAll: boolean) {
    if (busy) {
      return
    }
    const targets = restoreAll
      ? candidates
      : candidates.filter((c) => selected.has(c.folderName))
    if (targets.length === 0) {
      showToast(t("请先选择要恢复的脚本"), true)
      return
    }

    const conflicts = targets.filter((c) =>
      pathExists(Path.join(FileManager.scriptsDirectory, c.folderName))
    )
    if (conflicts.length > 0) {
      const names = conflicts.map((c) => c.folderName).join("、")
      const index = await Dialog.actionSheet({
        title: t("覆盖确认"),
        message: tpl("以下 {n} 个脚本已存在，恢复将覆盖当前版本：\n{names}", { n: String(conflicts.length), names }),
        actions: [{ label: t("取消") }, { label: t("覆盖并恢复"), destructive: true }],
        cancelButton: false,
      })
      if (index !== 1) {
        return
      }
    }

    setBusy(true)
    try {
      const { restored } = await restoreScripts(targets, true)
      dismiss({ restored: restored.length })
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
      setBusy(false)
    }
  }

  return (
    <NavigationStack>
      <List
        navigationTitle={t("选择要恢复的脚本")}
        navigationBarTitleDisplayMode="inline"
        scrollDismissesKeyboard="immediately"
        toast={toastProps}
        safeAreaInset={{
          bottom: {
            alignment: "center",
            spacing: 8,
            content: (
              <VStack alignment="center" padding={{ bottom: 10 }}>
                <HStack
                  spacing={10}
                  alignment="center"
                  padding={{ horizontal: 10, vertical: 8 }}
                  background={{
                    style: { color: "secondarySystemBackground", opacity: 0.95 },
                    shape: { type: "rect", cornerRadius: 20 },
                  }}
                >
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => dismiss(null)}
                  >
                    <Image systemName="xmark.circle" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("取消")}
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={toggleAll}
                  >
                    <Image
                      systemName="checklist"
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    />
                    <Text
                      font="caption2"
                      foregroundStyle={allSelected ? "systemBlue" : "tintColor"}
                    >
                      {allSelected ? t("取消全选") : t("全选")}
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => doRestore(true)}
                  >
                    <Image systemName="checkmark.circle" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {t("全部")}
                    </Text>
                  </VStack>
                  <VStack
                    spacing={3}
                    alignment="center"
                    frame={{ width: 48, height: 52 }}
                    background={{
                      style: { color: "label", opacity: 0.08 },
                      shape: { type: "rect", cornerRadius: 12 },
                    }}
                    contentShape={{ kind: "interaction", shape: "rect" }}
                    onTapGesture={() => doRestore(false)}
                  >
                    <Image systemName="arrow.uturn.backward" foregroundStyle="tintColor" />
                    <Text font="caption2" foregroundStyle="tintColor">
                      {busy ? t("恢复中…") : tpl("恢复 ({n})", { n: String(selected.size) })}
                    </Text>
                  </VStack>
                </HStack>
              </VStack>
            ),
          },
        }}
      >
        <Section
          header={
            <HStack spacing={8} alignment="center">
              <Text font="headline">{tpl("这个备份里有 {n} 个脚本", { n: String(candidates.length) })}</Text>
              <Spacer />
              <Picker
                value={sortMode}
                onChanged={(value: string | number) => {
                  const v = String(value)
                  const next = v === "name" || v === "name_desc" ? v : "modified"
                  setSortMode(next)
                  saveConfig({ ...resolveConfig(), scriptSort: next })
                }}
                pickerStyle="menu"
                padding={{ trailing: -12 }}
                label={
                  <HStack spacing={4}>
                    <Image
                      systemName="arrow.up.arrow.down"
                      foregroundStyle="secondaryLabel"
                    />
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      {sortMode === "name"
                        ? t("按名称 A-Z")
                        : sortMode === "name_desc"
                          ? t("按名称 Z-A")
                          : t("按最新修改")}
                    </Text>
                  </HStack>
                }
              >
                <Text tag="modified">{t("按最新修改")}</Text>
                <Text tag="name">{t("按名称 A-Z")}</Text>
                <Text tag="name_desc">{t("按名称 Z-A")}</Text>
              </Picker>
            </HStack>
          }
        />

        <Section>
          <HStack spacing={8}>
            <TextField
              value={query}
              onChanged={setQuery}
              prompt={t("搜索脚本名")}
              label={
                <Image
                  systemName="magnifyingglass"
                  foregroundStyle="secondaryLabel"
                />
              }
            />
            {query.length > 0 ? (
              <HStack
                contentShape={{ kind: "interaction", shape: "rect" }}
                onTapGesture={() => setQuery("")}
              >
                <Image
                  systemName="xmark.circle.fill"
                  foregroundStyle="secondaryLabel"
                />
              </HStack>
            ) : null}
          </HStack>
        </Section>

        <Section header={<Text font="headline">{t("脚本列表")}</Text>}>
          {filtered.length === 0 ? (
            <EmptyState message={t("未找到匹配的脚本")} />
          ) : (
            filtered.map((candidate) => {
              const isOn = selected.has(candidate.folderName)
              const metaLine = [
                candidate.version ? `v${candidate.version}` : null,
                candidate.modifiedAt ? formatDate(candidate.modifiedAt) : null,
              ]
                .filter(Boolean)
                .join(" · ")
              return (
                <HStack
                  key={candidate.folderName}
                  spacing={10}
                  contentShape="rect"
                  onTapGesture={() => toggleOne(candidate)}
                >
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                  <VStack alignment="leading" spacing={2}>
                    <Text font="body">{candidate.folderName}</Text>
                    {metaLine ? (
                      <Text font="caption" foregroundStyle="secondaryLabel">
                        {metaLine}
                      </Text>
                    ) : null}
                  </VStack>
                  <Spacer />
                </HStack>
              )
            })
          )}
        </Section>
      </List>
    </NavigationStack>
  )
}

// ==================== 脚本管理 ====================

function ManagePage() {
  const [query, setQuery] = useState("")
  const [editMode, setEditMode] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [refresh, setRefresh] = useState(0)
  const [scripts, setScripts] = useState<ScriptInfo[]>([])
  const [scriptsLoading, setScriptsLoading] = useState(true)
  const { showToast, toastProps } = useToast()

  useEffect(() => {
    setScriptsLoading(true)
    setTimeout(() => {
      setScripts(scanScripts())
      setScriptsLoading(false)
    }, 50)
  }, [refresh])

  const filtered = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    if (!keyword) {
      return scripts
    }
    return scripts.filter(
      (s) =>
        keywordMatches(s.displayName, keyword) ||
        keywordMatches(s.folderName, keyword)
    )
  }, [scripts, query])

  // 一次性构建 文件夹→分组 映射，避免每行重复全量扫描
  const groupNameMap = useMemo(() => buildGroupNameMap(), [refresh])

  const selectedScripts = scripts.filter((s) => selected.has(s.folderName))
  const allSelected =
    filtered.length > 0 && filtered.every((s) => selected.has(s.folderName))

  function refreshScripts() {
    setSelected(new Set())
    setRefresh((v) => v + 1)
  }

  function toggleOne(script: ScriptInfo) {
    const next = new Set(selected)
    if (next.has(script.folderName)) {
      next.delete(script.folderName)
    } else {
      next.add(script.folderName)
    }
    setSelected(next)
  }

  function toggleAll() {
    const next = new Set(selected)
    if (allSelected) {
      filtered.forEach((s) => next.delete(s.folderName))
    } else {
      filtered.forEach((s) => next.add(s.folderName))
    }
    setSelected(next)
  }

  async function doRename(script: ScriptInfo) {
    const name = await inputPrompt({
      title: t("重命名脚本"),
      message: t("输入新的脚本名称"),
      defaultValue: script.folderName,
      placeholder: script.folderName,
    })
    if (name == null || !name.trim()) {
      return
    }
    try {
      renameScript(script, name.trim())
      refreshScripts()
      showToast(t("已重命名"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doMoveToGroup(script: ScriptInfo) {
    const groups = readScriptingGroups()
    const named = groups.filter((g) => g.key !== "")
    if (named.length === 0) {
      showToast(t("没有可移动的分组"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("移动到分组"),
      message: `把「${script.displayName}」移动到哪个分组？`,
      actions: [
        { label: t("取消") },
        ...named.map((g) => ({ label: g.name })),
      ],
      cancelButton: false,
    })
    if (index == null || index === 0) {
      return
    }
    const target = named[index - 1]
    try {
      moveScriptToGroup(script, target.name)
      refreshScripts()
      showToast(`已移动到「${target.name}」`)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doChangeVersion(script: ScriptInfo) {
    if (!(await ensureVersionNotOverridden(script))) {
      return
    }
    const version = await inputPrompt({
      title: t("修改版本号"),
      message: t("输入新的版本号（格式 x.y.z，例如 1.0.1）"),
      defaultValue: script.version,
      placeholder: script.version,
      keyboardType: "numbersAndPunctuation",
    })
    if (version == null || !version.trim()) {
      return
    }
    try {
      setScriptVersion(script, version.trim())
      refreshScripts()
      showToast(t("版本号已更新"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doShare(list: ScriptInfo[]) {
    if (list.length === 0) {
      showToast(t("请先选择脚本"), true)
      return
    }
    try {
      await shareScripts(list)
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function doDelete(list: ScriptInfo[]) {
    if (list.length === 0) {
      showToast(t("请先选择脚本"), true)
      return
    }
    const index = await Dialog.actionSheet({
      title: t("删除确认"),
      message: `确定删除 ${list.length} 个脚本？此操作不可恢复。`,
      actions: [{ label: t("取消") }, { label: t("删除"), destructive: true }],
      cancelButton: false,
    })
    if (index !== 1) {
      return
    }
    try {
      for (const script of list) {
        deleteScript(script)
      }
      refreshScripts()
      showToast(t("已删除"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  /** 复制该脚本的 Scripting 导入链接（https://scripting.fun/import_scripts?urls=[...]） */
  async function copyScriptShareLink(script: ScriptInfo) {
    const link = buildScriptImportLink(script)
    if (!link) {
      showToast(t("该脚本没有发布链接，请先发布"), true)
      return
    }
    try {
      await Pasteboard.setString(link)
      showToast(t("导入链接已复制"))
    } catch (error) {
      showToast(error instanceof Error ? error.message : String(error), true)
    }
  }

  async function rowActions(script: ScriptInfo) {
    const group = groupNameForScript(script.folderName)
    const actions: Array<{ label: string; destructive?: boolean }> = [
      { label: t("重命名") },
      { label: t("移动到其他分组") },
    ]
    if (resolveConfig().githubPublishEnabled && hasPublishedLink(script)) {
      actions.push({ label: t("分享(链接)") })
      actions.push({ label: t("分享(文件)") })
    } else {
      actions.push({ label: t("分享") })
    }
    actions.push({ label: t("修改版本号") })
    actions.push({ label: t("删除"), destructive: true })

    const index = await Dialog.actionSheet({
      title: script.displayName,
      message: `版本 ${script.version} · ${formatDate(script.modifiedAt)} · ${formatBytes(script.byteSize)} · 分组 ${group ?? t("默认")}`,
      actions,
    })
    if (index == null) {
      return
    }
    const action = actions[index]
    if (!action) {
      return
    }
    switch (action.label) {
      case t("重命名"):
        await doRename(script)
        break
      case t("移动到其他分组"):
        await doMoveToGroup(script)
        break
      case t("分享(链接)"):
        await copyScriptShareLink(script)
        break
      case t("分享(文件)"):
      case t("分享"):
        await doShare([script])
        break
      case t("修改版本号"):
        await doChangeVersion(script)
        break
      case t("删除"):
        await doDelete([script])
        break
    }
  }

  /** 左划操作已改用 trailingSwipeActions（重命名/移到其他分组） */

  const toolbar = editMode ? (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button
          title={allSelected ? t("取消全选") : t("全选")}
          action={toggleAll}
        />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("完成")} action={() => setEditMode(false)} />
      </ToolbarItem>
    </Toolbar>
  ) : (
    <Toolbar>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("选择")} action={() => setEditMode(true)} />
      </ToolbarItem>
    </Toolbar>
  )

  return (
    <List
      navigationTitle={t("脚本管理")}
      navigationBarTitleDisplayMode="inline"
      scrollDismissesKeyboard="immediately"
      toolbar={toolbar}
      toast={toastProps}
    >
      <Section>
        <HStack spacing={8}>
          <TextField
            value={query}
            onChanged={setQuery}
            prompt={t("搜索脚本名")}
            label={
              <Image
                systemName="magnifyingglass"
                foregroundStyle="secondaryLabel"
              />
            }
          />
          {query.length > 0 ? (
            <HStack
              contentShape={{ kind: "interaction", shape: "rect" }}
              onTapGesture={() => setQuery("")}
            >
              <Image
                systemName="xmark.circle.fill"
                foregroundStyle="secondaryLabel"
              />
            </HStack>
          ) : null}
        </HStack>
      </Section>

      {editMode ? (
        <Section
          header={<Text font="headline">批量操作</Text>}
          footer={
            <Text font="footnote">
              已选 {selectedScripts.length} 个脚本；点击行可勾选/取消
            </Text>
          }
        >
          <HStack
            spacing={10}
            contentShape="rect"
            onTapGesture={toggleAll}
          >
            <Image
              systemName={allSelected ? "checkmark.circle.fill" : "circle"}
              foregroundStyle={allSelected ? "systemBlue" : "secondaryLabel"}
            />
            <Text font="body">{allSelected ? t("取消全选") : t("全选")}</Text>
            <Spacer />
            <Text font="caption" foregroundStyle="secondaryLabel">
              已选 {selected.size} 个
            </Text>
          </HStack>
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => doDelete(selectedScripts)}
          >
            <Spacer />
            <Image systemName="trash" foregroundStyle="systemRed" />
            <Text font="body" foregroundStyle="systemRed">
              删除选中 ({selectedScripts.length})
            </Text>
            <Spacer />
          </HStack>
          <HStack
            spacing={8}
            contentShape={{ kind: "interaction", shape: "rect" }}
            onTapGesture={() => doShare(selectedScripts)}
          >
            <Spacer />
            <Image systemName="square.and.arrow.up" foregroundStyle="tintColor" />
            <Text font="body" foregroundStyle="tintColor">
              分享选中 ({selectedScripts.length})
            </Text>
            <Spacer />
          </HStack>
        </Section>
      ) : null}

      <Section
        header={<Text font="headline">脚本列表（{filtered.length}）</Text>}
        footer={
          <Text font="footnote">
            {editMode ? t("勾选脚本后可用下方按钮批量删除/分享") : t("点击脚本可重命名、分享、修改版本号或删除")}
          </Text>
        }
      >
        {scriptsLoading ? (
          <EmptyState message={t("正在加载脚本…")} />
        ) : filtered.length === 0 ? (
          <EmptyState message={t("没有找到脚本")} />
        ) : (
          filtered.map((script) => {
            const isOn = selected.has(script.folderName)
            const group = groupNameMap.get(script.folderName) ?? null
            return (
              <HStack
                key={script.folderName}
                spacing={10}
                contentShape="rect"
                onTapGesture={() => {
                  if (editMode) {
                    toggleOne(script)
                  } else {
                    rowActions(script)
                  }
                }}
                onLongPressGesture={{
                  minDuration: 400,
                  perform: () => {
                    if (!editMode) {
                      setEditMode(true)
                    }
                    toggleOne(script)
                  },
                }}
                trailingSwipeActions={{
                  allowsFullSwipe: true,
                  actions: [
                    <Button
                      title={t("重命名")}
                      tint="systemBlue"
                      action={() => doRename(script)}
                    />,
                    <Button
                      title={t("移到其他分组")}
                      tint="orange"
                      action={() => doMoveToGroup(script)}
                    />,
                  ],
                }}
              >
                {selected.size > 0 ? (
                  <Image
                    systemName={isOn ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={isOn ? "systemBlue" : "secondaryLabel"}
                  />
                ) : (
                  <RowIcon
                    systemName="chevron.left.forwardslash.chevron.right"
                    color="tintColor"
                  />
                )}
                <VStack alignment="leading" spacing={2}>
                  <Text font="body">{script.displayName}</Text>
                  <Text font="caption" foregroundStyle="secondaryLabel">
                    v{script.version} · {formatDate(script.modifiedAt)}
                    {group ? ` · ${group}` : t(" · 默认")}
                  </Text>
                </VStack>
                <Spacer />
                {selected.size === 0 ? <Chevron /> : null}
              </HStack>
            )
          })
        )}
      </Section>
    </List>
  )
}

// ==================== 入口 ====================

async function run() {
  await Navigation.present({
    element: <MainPage />,
    modalPresentationStyle: "overFullScreen",
  })
  Script.exit()
}

// 被 home_screen_default_ui.tsx 作为首页标签复用时，不应自动运行入口
if (Script.env !== "home_screen") {
  run()
}