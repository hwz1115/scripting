import { Path, fetch } from "scripting"

// ==================== 常量 ====================

export const APP_NAME = "脚本管理工具"
export const BACKUP_DIR_NAME = "ScriptBackups"

const CONFIG_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "script-manager-config.json"
)

const GITHUB_CONFIG_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "script-manager-github.json"
)

// ==================== 类型 ====================

export type Destination = "iphone" | "icloud" | "github_publish" | "github_backup"
export type BackupScopeKey = "recent" | "all" | "group" | "select"

export type AppConfig = {
  /** 备份目的地，默认 iPhone，记住上次选择 */
  destination: Destination
  /** 备份范围，记住上次选择 */
  scope: BackupScopeKey
  /** 是否启用 Github备份（设置里勾选后才显示该入口与配置） */
  githubBackupEnabled: boolean
  /** 是否启用 Github发布（设置里勾选后才显示该入口与配置，仅开发者需要） */
  githubPublishEnabled: boolean
  /** 是否记住首页「备份/恢复」的展开状态（默认勾选=记住） */
  rememberExpandState: boolean
  /** 首页「备份/恢复」当前展开与否（勾选「记住展开状态」时生效） */
  backupRestoreExpanded: boolean
  /** 置顶脚本的文件夹名列表（置顶的脚本排在列表最上方） */
  pinnedScripts: string[]
  /** 脚本列表排序方式：最新修改 / 名称 A-Z / 名称 Z-A */
  scriptSort: "modified" | "name" | "name_desc"
  /** 搜索时是否保留不匹配的脚本（默认开启：全部显示、匹配的排在前面；关闭则只显示匹配项） */
  searchKeepAll: boolean
  /** 界面语言：中文 / English（默认中文） */
  language: "zh" | "en"
  /** 版本变化自动备份：脚本版本号变化时自动备份到当前备份目标（默认关闭） */
  autoBackupOnUpgrade: boolean
  /** 上次记录的脚本版本号映射（folderName → version），用于检测版本变化 */
  scriptVersionRecord: Record<string, string>
  /** 上次发布时各脚本的版本号映射（folderName → version），用于检测「云端与本地不同步」 */
  publishedVersions: Record<string, string>
  /** 已发布脚本的云端版本缓存（folderName → version，从 remoteResource 下载读取，用于无发布记录的历史发布脚本） */
  cloudVersions: Record<string, string>
  /** 最近一次发布时填写的更新说明（folderName → 说明），本地记录 */
  publishedChangelogs: Record<string, string>
  /** 已发布脚本的云端更新说明缓存（folderName → 说明，从 remoteResource 下载读取） */
  cloudChangelogs: Record<string, string>
  /** 仓库监控：是否启用（监控 GitHub 仓库里 .scripting 文件的变化并提示） */
  channelMonitorEnabled: boolean
  /** 仓库监控：检查间隔数值（配合单位） */
  channelMonitorInterval: number
  /** 仓库监控：检查间隔单位（分/小时/天） */
  channelMonitorIntervalUnit: "minute" | "hour" | "day"
  /** 仓库监控：监控的仓库链接列表（url + 可编辑备注名） */
  channelMonitorLinks: ChannelMonitorLink[]
  /** 仓库监控：各仓库最近一次扫描的 文件路径→sha 快照（url → path → sha），用于检测变化 */
  channelMonitorSnapshots: Record<string, Record<string, string>>
  /** 仓库监控：是否已建立过基线（首次扫描只记录不提示） */
  channelMonitorBaselineReady: boolean
  /** 仓库监控：排除关键词（脚本名称包含任一关键词时，即使有更新也不提示、不列入更新页） */
  channelMonitorExcludeKeywords: string[]
  /** 仓库监控：已自动提示过的变化签名（同一批变化只提示一次，跨实例/重启后不重复弹窗与通知） */
  channelMonitorNotifiedSig: string
  /** 仓库监控：已忽略更新的脚本路径列表（格式 `仓库url|脚本路径`；忽略后该脚本再发布新版本也不提示，直到在设置里恢复提醒） */
  channelMonitorIgnoredPaths: string[]
}

/** GitHub 配置：发布仓库（公开，可自动创建）+ 备份仓库（私密，可自动创建） */
export type GithubConfig = {
  /** 发布专用 Personal Access Token（需要 repo 权限）；留空则自动回退到备份 Token */
  publishToken: string
  /** 发布专用仓库所有者；留空则自动回退到备份所有者 */
  publishOwner: string
  /** 发布仓库名，如 scripting-releases（必填） */
  repo: string
  /** 发布分支，默认 main */
  branch: string
  /** 发布仓库内目录（相对路径，留空=根目录） */
  path: string
  /** 备份专用 Personal Access Token（需要 repo 权限）；留空则自动回退到发布 Token */
  backupToken: string
  /** 备份专用仓库所有者；留空则自动回退到发布所有者 */
  backupOwner: string
  /** 备份仓库名（私密），如 scripting-backups（必填） */
  backupRepo: string
  /** 备份分支，默认 main */
  backupBranch: string
  /** 备份仓库内目录（相对路径，留空=根目录） */
  backupPath: string
  /** 兼容旧版：共用 Token（新版本分别填写 publishToken/backupToken） */
  token: string
  /** 兼容旧版：共用仓库所有者 */
  owner: string
}

export const DEFAULT_GITHUB_CONFIG: GithubConfig = {
  publishToken: "",
  publishOwner: "",
  repo: "",
  branch: "main",
  path: "",
  backupToken: "",
  backupOwner: "",
  backupRepo: "",
  backupBranch: "main",
  backupPath: "",
  token: "",
  owner: "",
}

export type ScriptInfo = {
  /** 文件夹名（脚本目录名） */
  folderName: string
  /** script.json 里的显示名 */
  displayName: string
  path: string
  version: string
  modifiedAt: number
  byteSize: number
}

export type GroupInfo = {
  /** "" 表示根目录默认分组 */
  key: string
  name: string
  path: string
  scripts: ScriptInfo[]
}

export type BackupItem = {
  name: string
  path: string
  isZip: boolean
  modifiedAt: number
  byteSize: number
  scriptCount: number
}

/** 备份内待恢复的脚本 */
export type CandidateScript = {
  folderName: string
  sourcePath: string
  /** 脚本版本号（读 script.json，可能缺失） */
  version?: string
  /** 脚本修改时间（读 script.json 的 mtime，可能缺失） */
  modifiedAt?: number
}

// ==================== 仓库监控类型 ====================

/** 仓库监控：一个被监控的仓库链接 */
export type ChannelMonitorLink = {
  /** GitHub 仓库地址，如 https://github.com/vvvvvveng/Scripting-releases */
  url: string
  /** 显示用备注名（可修改），默认自动取 所有者/仓库名 */
  name: string
}

/** 仓库监控：仓库里扫描到的 .scripting 文件 */
export type ChannelRepoFile = {
  path: string
  sha: string
  size: number
}

/** 仓库监控：一个文件的变化 */
export type ChannelChange = {
  type: "added" | "updated" | "removed"
  path: string
  size?: number
  /** 变化后的 blob sha（added/updated 有值；用于区分「同一文件的新发布」与「同一批变化的重复检测」） */
  sha?: string
}

/** 仓库监控：单个仓库一次检查结果 */
export type ChannelCheckResult = {
  name: string
  url: string
  /** 本次相对基线的变化（首次建立基线/无变化时为空数组） */
  changes: ChannelChange[]
  /** 扫描到的 .scripting 脚本数量 */
  scriptCount: number
  /** 检查是否成功（网络/仓库不存在等失败时为 false） */
  ok: boolean
  error?: string
  /** 被排除关键词过滤掉的变化数（不提示、不列入更新页；仅用于告知用户为何没检测到） */
  excludedCount?: number
  /** 被「忽略全部」按路径忽略的变化数（同一脚本再发布新版本也不提示，直到在设置里恢复） */
  ignoredCount?: number
}

/** 仓库监控：一次全量检查的汇总 */
export type ChannelCheckSummary = {
  results: ChannelCheckResult[]
  /** 所有仓库变化总数 */
  totalChanges: number
  /** 本次是否刚建立基线（首次启用扫描） */
  newBaseline: boolean
}

// ==================== 基础工具 ====================

export function pathExists(path: string): boolean {
  try {
    return FileManager.existsSync(path)
  } catch {
    return false
  }
}

export function isDirectory(path: string): boolean {
  try {
    return FileManager.isDirectorySync(path)
  } catch {
    return false
  }
}

export function listChildren(path: string): string[] {
  if (!pathExists(path)) {
    return []
  }
  try {
    return FileManager.readDirectorySync(path).map((item) =>
      Path.isAbsolute(item) ? item : Path.join(path, item)
    )
  } catch {
    return []
  }
}

export function statTime(path: string): number {
  try {
    const stat = FileManager.statSync(path)
    return stat.modificationDate || stat.creationDate || Date.now()
  } catch {
    return Date.now()
  }
}

export function statSize(path: string): number {
  try {
    return FileManager.statSync(path).size || 0
  } catch {
    return 0
  }
}

export function summarizeDirectory(path: string): { fileCount: number; byteSize: number } {
  let fileCount = 0
  let byteSize = 0
  for (const item of listChildren(path)) {
    if (isDirectory(item)) {
      const child = summarizeDirectory(item)
      fileCount += child.fileCount
      byteSize += child.byteSize
    } else {
      fileCount += 1
      byteSize += statSize(item)
    }
  }
  return { fileCount, byteSize }
}

/**
 * 计算脚本目录的内容指纹：递归列出每个文件的相对路径 + 大小 + 修改时间，
 * 排序后拼接。用于判断脚本内容是否仍在变化（如智能体修改尚未写完 / iCloud 还在同步），
 * 连续两次指纹一致可认为内容已稳定，此时再备份才不会备份到旧内容。
 */
export function scriptDirFingerprint(dir: string): string {
  const parts: string[] = []
  const walk = (d: string, rel: string) => {
    for (const item of listChildren(d)) {
      const name = Path.basename(item)
      const childRel = rel ? rel + "/" + name : name
      if (isDirectory(item)) {
        walk(item, childRel)
      } else {
        let size = 0
        let mtime = 0
        try {
          const stat = FileManager.statSync(item)
          size = stat.size || 0
          mtime = stat.modificationDate || 0
        } catch {}
        parts.push(`${childRel}|${size}|${mtime}`)
      }
    }
  }
  walk(dir, "")
  return parts.sort().join("\n")
}

export function copyDirectory(source: string, destination: string) {
  FileManager.createDirectorySync(destination, true)
  for (const item of listChildren(source)) {
    const target = Path.join(destination, Path.basename(item))
    if (isDirectory(item)) {
      copyDirectory(item, target)
    } else {
      FileManager.copyFileSync(item, target)
    }
  }
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) {
    return `${bytes} B`
  }
  const units = ["KB", "MB", "GB"]
  let value = bytes / 1024
  let index = 0
  while (value >= 1024 && index < units.length - 1) {
    value /= 1024
    index += 1
  }
  return `${value.toFixed(value >= 10 ? 1 : 2)} ${units[index]}`
}

export function formatDate(value: number): string {
  try {
    return new Date(value).toLocaleString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })
  } catch {
    return String(value)
  }
}

export function timestampForName(): string {
  const date = new Date()
  const pad = (v: number) => String(v).padStart(2, "0")
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}_${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
}

/** 清洗为合法文件名（保留中文/字母/数字/._- 及括号；括号与本地文件夹名保持一致） */
export function safeFileName(name: string): string {
  const cleaned = name
    .trim()
    .split("")
    .map((char) => {
      if (
        /^[A-Za-z0-9_.\- ()（）]$/.test(char) ||
        /[\u4e00-\u9fff]/.test(char)
      ) {
        return char
      }
      return "_"
    })
    .join("")
    .replace(/[. ]+$/g, "")
  return cleaned || "备份"
}

/** 若路径已存在，返回追加 (2)/(3)… 的新路径 */
export function uniquePath(basePath: string): string {
  if (!pathExists(basePath)) {
    return basePath
  }
  const dir = Path.dirname(basePath)
  const lower = basePath.toLowerCase()
  const ext = lower.endsWith(".zip")
    ? ".zip"
    : lower.endsWith(".scripting")
    ? ".scripting"
    : ""
  const stem = ext ? basePath.slice(0, -ext.length) : basePath
  let index = 2
  while (pathExists(`${stem} (${index})${ext}`)) {
    index += 1
  }
  return `${stem} (${index})${ext}`
}

// ==================== 配置（记住上次勾选） ====================

export function resolveConfig(): AppConfig {
  const def: AppConfig = {
    destination: "iphone",
    scope: "recent",
    githubBackupEnabled: false,
    githubPublishEnabled: false,
    rememberExpandState: true,
    backupRestoreExpanded: true,
    pinnedScripts: [],
    scriptSort: "modified",
    searchKeepAll: true,
    language: "zh",
    autoBackupOnUpgrade: false,
    scriptVersionRecord: {},
    publishedVersions: {},
    cloudVersions: {},
    publishedChangelogs: {},
    cloudChangelogs: {},
    channelMonitorEnabled: false,
    channelMonitorInterval: 12,
    channelMonitorIntervalUnit: "hour",
    channelMonitorLinks: DEFAULT_CHANNEL_MONITOR_LINKS,
    channelMonitorSnapshots: {},
    channelMonitorBaselineReady: false,
    channelMonitorExcludeKeywords: DEFAULT_CHANNEL_EXCLUDE_KEYWORDS,
    channelMonitorNotifiedSig: "",
    channelMonitorIgnoredPaths: [],
  }
  if (!pathExists(CONFIG_PATH)) {
    return def
  }
  try {
    const raw = JSON.parse(FileManager.readAsStringSync(CONFIG_PATH)) as Partial<AppConfig> & {
      developer?: boolean
    }
    return {
      destination:
        raw.destination === "icloud"
          ? "icloud"
          : raw.destination === "github_publish"
          ? "github_publish"
          : raw.destination === "github_backup"
          ? "github_backup"
          : "iphone",
      scope:
        raw.scope === "all" ||
        raw.scope === "group" ||
        raw.scope === "select"
          ? raw.scope
          : "recent",
      githubBackupEnabled: raw.githubBackupEnabled === true,
      // 兼容旧版「我是开发者」开关：勾选过即视为启用 Github发布
      githubPublishEnabled:
        raw.githubPublishEnabled === true || raw.developer === true,
      rememberExpandState: raw.rememberExpandState !== false,
      backupRestoreExpanded: raw.backupRestoreExpanded !== false,
      pinnedScripts: Array.isArray(raw.pinnedScripts)
        ? raw.pinnedScripts.filter((x): x is string => typeof x === "string")
        : [],
      scriptSort: raw.scriptSort === "name_desc" ? "name_desc" : raw.scriptSort === "name" ? "name" : "modified",
      searchKeepAll: raw.searchKeepAll !== false,
      language: raw.language === "en" ? "en" : "zh",
      autoBackupOnUpgrade: raw.autoBackupOnUpgrade === true,
      scriptVersionRecord:
        raw.scriptVersionRecord && typeof raw.scriptVersionRecord === "object"
          ? raw.scriptVersionRecord
          : {},
      publishedVersions:
        raw.publishedVersions && typeof raw.publishedVersions === "object"
          ? raw.publishedVersions
          : {},
      cloudVersions:
        raw.cloudVersions && typeof raw.cloudVersions === "object"
          ? raw.cloudVersions
          : {},
      publishedChangelogs:
        raw.publishedChangelogs && typeof raw.publishedChangelogs === "object"
          ? raw.publishedChangelogs
          : {},
      cloudChangelogs:
        raw.cloudChangelogs && typeof raw.cloudChangelogs === "object"
          ? raw.cloudChangelogs
          : {},
      channelMonitorEnabled: raw.channelMonitorEnabled === true,
      channelMonitorInterval:
        typeof raw.channelMonitorInterval === "number" &&
        raw.channelMonitorInterval > 0
          ? raw.channelMonitorInterval
          : 12,
      channelMonitorIntervalUnit:
        raw.channelMonitorIntervalUnit === "hour" ||
        raw.channelMonitorIntervalUnit === "day"
          ? raw.channelMonitorIntervalUnit
          : "hour",
      channelMonitorLinks: normalizeChannelMonitorLinks(
        raw.channelMonitorLinks
      ),
      channelMonitorSnapshots:
        raw.channelMonitorSnapshots &&
        typeof raw.channelMonitorSnapshots === "object"
          ? raw.channelMonitorSnapshots
          : {},
      channelMonitorBaselineReady: raw.channelMonitorBaselineReady === true,
      channelMonitorExcludeKeywords:
        raw.channelMonitorExcludeKeywords === undefined
          ? DEFAULT_CHANNEL_EXCLUDE_KEYWORDS
          : normalizeChannelExcludeKeywords(raw.channelMonitorExcludeKeywords),
      channelMonitorNotifiedSig:
        typeof raw.channelMonitorNotifiedSig === "string"
          ? raw.channelMonitorNotifiedSig
          : "",
      channelMonitorIgnoredPaths: normalizeChannelIgnoredPaths(
        raw.channelMonitorIgnoredPaths
      ),
    }
  } catch {
    return def
  }
}

export function saveConfig(config: AppConfig) {
  try {
    FileManager.writeAsStringSync(CONFIG_PATH, JSON.stringify(config, null, 2))
  } catch {
    // ignore
  }
}

// ==================== 配置（GitHub） ====================

export function resolveGithubConfig(): GithubConfig {
  if (!pathExists(GITHUB_CONFIG_PATH)) {
    return { ...DEFAULT_GITHUB_CONFIG }
  }
  try {
    const raw = JSON.parse(
      FileManager.readAsStringSync(GITHUB_CONFIG_PATH)
    ) as Partial<GithubConfig>
    const legacyToken = typeof raw.token === "string" ? raw.token : ""
    const legacyOwner = typeof raw.owner === "string" ? raw.owner : ""
    return {
      publishToken: typeof raw.publishToken === "string" ? raw.publishToken : "",
      publishOwner: typeof raw.publishOwner === "string" ? raw.publishOwner : "",
      repo: typeof raw.repo === "string" ? raw.repo : "",
      branch: (typeof raw.branch === "string" && raw.branch.trim()) ? raw.branch.trim() : "main",
      path: typeof raw.path === "string" ? raw.path : "",
      backupToken: typeof raw.backupToken === "string" ? raw.backupToken : "",
      backupOwner: typeof raw.backupOwner === "string" ? raw.backupOwner : "",
      backupRepo: typeof raw.backupRepo === "string" ? raw.backupRepo : "",
      backupBranch: (typeof raw.backupBranch === "string" && raw.backupBranch.trim()) ? raw.backupBranch.trim() : "main",
      backupPath: typeof raw.backupPath === "string" ? raw.backupPath : "",
      // 兼容旧版：保留共用字段，便于旧配置升级后自动生效
      token: legacyToken,
      owner: legacyOwner,
    }
  } catch {
    return { ...DEFAULT_GITHUB_CONFIG }
  }
}

/**
 * 解析发布实际生效的配置：发布专用优先，其次备份专用，最后旧版共用（fallback）。
 * 返回对象的 token/owner 即为发布时真正使用的凭据。
 */
export function resolvePublishGithubConfig(config: GithubConfig): GithubConfig {
  return {
    ...config,
    token: config.publishToken || config.backupToken || config.token,
    owner: config.publishOwner || config.backupOwner || config.owner,
  }
}

/**
 * 解析备份实际生效的配置：备份专用优先，其次发布专用，最后旧版共用（fallback）。
 * 返回对象的 token/owner 即为备份时真正使用的凭据。
 */
export function resolveBackupGithubConfig(config: GithubConfig): GithubConfig {
  return {
    ...config,
    token: config.backupToken || config.publishToken || config.token,
    owner: config.backupOwner || config.publishOwner || config.owner,
  }
}

export function saveGithubConfig(config: GithubConfig) {
  try {
    FileManager.writeAsStringSync(
      GITHUB_CONFIG_PATH,
      JSON.stringify(config, null, 2)
    )
  } catch {
    // ignore
  }
}

/** GitHub 发布配置是否已填全（token+owner+repo 必填） */
export function isGithubConfigured(config: GithubConfig): boolean {
  return !!(config.token.trim() && config.owner.trim() && config.repo.trim())
}

/** GitHub 备份配置是否已填全（token+owner+backupRepo 必填） */
export function isGithubBackupConfigured(config: GithubConfig): boolean {
  return !!(config.token.trim() && config.owner.trim() && config.backupRepo.trim())
}

// ==================== 备份目录 ====================

export function backupRootFor(destination: Destination): string {
  const base =
    destination === "icloud"
      ? FileManager.iCloudDocumentsDirectory
      : FileManager.documentsDirectory
  return Path.join(base, BACKUP_DIR_NAME)
}

export function ensureBackupRoot(destination: Destination): string {
  const root = backupRootFor(destination)
  if (!pathExists(root)) {
    FileManager.createDirectorySync(root, true)
  }
  return root
}

// ==================== 扫描脚本 ====================

/**
 * 解析脚本的 script.json：Scripting 生成的 JSON 可能带尾随逗号（`,}` / `,]`），
 * 标准 JSON.parse 会抛错，这里先按标准解析，失败则去掉尾随逗号重试。
 */
export function parseScriptJson(raw: string): any {
  try {
    return JSON.parse(raw)
  } catch {
    const cleaned = raw.replace(/,\s*([}\]])/g, "$1")
    return JSON.parse(cleaned)
  }
}

export function readScriptMeta(dir: string): { name?: string; version?: string } {
  try {
    const raw = FileManager.readAsStringSync(Path.join(dir, "script.json"))
    const obj = parseScriptJson(raw)
    return {
      name: typeof obj?.name === "string" ? obj.name : undefined,
      version: typeof obj?.version === "string" ? obj.version : undefined,
    }
  } catch {
    return {}
  }
}

/** 单个脚本目录 → ScriptInfo（目录不含 script.json 时返回 null） */
export function scriptInfoFromDir(dir: string): ScriptInfo | null {
  if (!pathExists(Path.join(dir, "script.json"))) {
    return null
  }
  const meta = readScriptMeta(dir)
  const name = Path.basename(dir)
  return {
    folderName: name,
    displayName: meta.name || name,
    path: dir,
    version: meta.version || "0.0.0",
    modifiedAt: statTime(dir),
    byteSize: summarizeDirectory(dir).byteSize,
  }
}

/** 扫描某目录下直接包含 script.json 的脚本文件夹 */
export function scanScripts(dir: string = FileManager.scriptsDirectory): ScriptInfo[] {
  const result: ScriptInfo[] = []
  for (const child of listChildren(dir)) {
    if (!isDirectory(child)) continue
    const info = scriptInfoFromDir(child)
    if (info) {
      result.push(info)
    }
  }
  return result.sort((a, b) => b.modifiedAt - a.modifiedAt)
}

/** 按文件夹分组：根目录脚本归「默认分组」，子文件夹（含嵌套）里有脚本的作为分组 */
export function scanGroups(): GroupInfo[] {
  const root = FileManager.scriptsDirectory
  const groups: GroupInfo[] = []
  const rootScripts = scanScripts(root)
  if (rootScripts.length > 0) {
    groups.push({ key: "", name: "默认分组", path: root, scripts: rootScripts })
  }
  for (const child of listChildren(root)) {
    if (!isDirectory(child)) continue
    // 本身是脚本（含 script.json）则跳过
    if (pathExists(Path.join(child, "script.json"))) continue
    const found = scanScriptDirsInTree(child)
    if (found.length > 0) {
      groups.push({
        key: child,
        name: Path.basename(child),
        path: child,
        scripts: found
          .map((f) => scriptInfoFromDir(f.sourcePath))
          .filter((s): s is ScriptInfo => s !== null)
          .sort((a, b) => b.modifiedAt - a.modifiedAt),
      })
    }
  }
  return groups
}

/**
 * 读取 Scripting 应用的分组（.scripting/settings.json 的 groups 字段）。
 * 脚本存储为 WebDAV 时，settings.json 与 scriptsDirectory 同级的 .scripting 目录下；
 * 本地存储时在 appGroupDocumentsDirectory 下。取第一个能读到 groups 的文件。
 * @param preloadedScripts 可选的已扫描脚本列表，避免内部再次全量 scanScripts（WebDAV 下很慢）
 */
export function readScriptingGroups(preloadedScripts?: ScriptInfo[]): GroupInfo[] {
  const candidates = [
    Path.join(Path.dirname(FileManager.scriptsDirectory), ".scripting", "settings.json"),
    Path.join(FileManager.appGroupDocumentsDirectory, ".scripting", "settings.json"),
  ]

  // 脚本显示名 → ScriptInfo 映射（含目录名兜底）
  const allScripts = preloadedScripts ?? scanScripts()
  const byDisplayName = new Map<string, ScriptInfo>()
  const byFolderName = new Map<string, ScriptInfo>()
  for (const script of allScripts) {
    byDisplayName.set(script.displayName, script)
    byFolderName.set(script.folderName, script)
  }

  for (const settingsPath of candidates) {
    if (!pathExists(settingsPath)) {
      continue
    }
    try {
      const raw = FileManager.readAsStringSync(settingsPath)
      const obj = JSON.parse(raw) as { groups?: Array<{ name?: string; icon?: string; scripts?: string[] }> }
      const defs = obj?.groups
      if (!Array.isArray(defs) || defs.length === 0) {
        continue
      }
      const groups: GroupInfo[] = []
      for (const def of defs) {
        const name = def.name?.trim() || "未命名分组"
        const scripts: ScriptInfo[] = []
        const seen = new Set<string>()
        for (const scriptName of def.scripts || []) {
          const info = byDisplayName.get(scriptName) || byFolderName.get(scriptName)
          if (info && !seen.has(info.folderName)) {
            seen.add(info.folderName)
            scripts.push(info)
          }
        }
        groups.push({
          key: name,
          name,
          path: FileManager.scriptsDirectory,
          scripts,
        })
      }
      return groups
    } catch {
      // 尝试下一个候选路径
    }
  }
  return []
}

/**
 * 构建 脚本文件夹名 → 所在分组名 的映射（脚本可能属于多个分组，取第一个）。
 * 不在任何命名分组的脚本返回 null（表示默认分组）。
 */
export function groupNameForScript(folderName: string): string | null {
  for (const group of readScriptingGroups()) {
    if (group.scripts.some((s) => s.folderName === folderName)) {
      return group.name
    }
  }
  return null
}

/**
 * 一次性构建 文件夹名 → 分组名 映射（只扫描一次），
 * 供列表批量渲染使用，避免每行重复全量扫描。
 * @param preloadedScripts 可选的已扫描脚本列表，避免内部再次全量 scanScripts
 */
export function buildGroupNameMap(preloadedScripts?: ScriptInfo[]): Map<string, string> {
  const map = new Map<string, string>()
  for (const group of readScriptingGroups(preloadedScripts)) {
    for (const s of group.scripts) {
      if (!map.has(s.folderName)) {
        map.set(s.folderName, group.name)
      }
    }
  }
  return map
}

/**
 * 把脚本移动到指定分组：从其他所有分组移除，再加入目标分组。
 * 分组信息保存在 Scripting 的 .scripting/settings.json。
 */
export function moveScriptToGroup(
  script: ScriptInfo,
  targetGroupName: string
): void {
  const candidates = [
    Path.join(Path.dirname(FileManager.scriptsDirectory), ".scripting", "settings.json"),
    Path.join(FileManager.appGroupDocumentsDirectory, ".scripting", "settings.json"),
  ]
  let settingsPath: string | null = null
  for (const candidate of candidates) {
    if (pathExists(candidate)) {
      settingsPath = candidate
      break
    }
  }
  if (!settingsPath) {
    throw new Error("未找到分组配置文件（.scripting/settings.json）")
  }

  const raw = JSON.parse(FileManager.readAsStringSync(settingsPath)) as {
    groups?: Array<{ name?: string; icon?: string; scripts?: string[] }>
  }
  const defs = raw?.groups
  if (!Array.isArray(defs) || defs.length === 0) {
    throw new Error("分组配置为空，无法移动")
  }

  const match = defs.find((def) => (def.name?.trim() || "未命名分组") === targetGroupName)
  if (!match) {
    throw new Error(`找不到分组「${targetGroupName}」`)
  }

  const targetScripts = match.scripts || (match.scripts = [])
  const scriptKey = script.displayName || script.folderName

  // 目标分组已包含该脚本：无需操作
  if (targetScripts.some((s) => s === scriptKey)) {
    throw new Error(`「${script.displayName}」已经在分组「${targetGroupName}」中`)
  }

  // 从其他所有分组移除
  for (const def of defs) {
    if (def === match) {
      continue
    }
    if (Array.isArray(def.scripts)) {
      const idx = def.scripts.indexOf(scriptKey)
      if (idx >= 0) {
        def.scripts.splice(idx, 1)
      }
    }
  }

  // 加入目标分组
  targetScripts.push(scriptKey)
  FileManager.writeAsStringSync(settingsPath, JSON.stringify(raw, null, 2))
}

// ==================== 备份 ====================

/**
 * 备份脚本到指定目的地：单个脚本打包为 `<名称>.scripting`（Scripting 官方分发格式，可直接导入运行），
 * 多个脚本打包为一个 `<名称>.zip`（zip 根目录下直接是各脚本文件夹）。
 */
export async function backupScripts(
  scripts: ScriptInfo[],
  destination: Destination,
  zipName: string
): Promise<string> {
  const root = ensureBackupRoot(destination)
  const safe = safeFileName(zipName) || "临时备份"
  const ext = scripts.length === 1 ? ".scripting" : ".zip"
  const finalPath = uniquePath(Path.join(root, `${safe}${ext}`))

  if (scripts.length === 1) {
    await FileManager.zip(scripts[0].path, finalPath, true)
    return finalPath
  }

  const staging = Path.join(FileManager.temporaryDirectory, `backup-stage-${Date.now()}`)
  FileManager.createDirectorySync(staging, true)
  try {
    for (const script of scripts) {
      copyDirectory(script.path, Path.join(staging, script.folderName))
    }
    await FileManager.zip(staging, finalPath, false)
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
  return finalPath
}

// ==================== 恢复 ====================

export function scanBackups(destination: Destination): BackupItem[] {
  const root = backupRootFor(destination)
  if (!pathExists(root)) {
    return []
  }
  const items: BackupItem[] = []
  for (const child of listChildren(root)) {
    const name = Path.basename(child)
    if (isDirectory(child)) {
      items.push({
        name,
        path: child,
        isZip: false,
        modifiedAt: statTime(child),
        byteSize: summarizeDirectory(child).byteSize,
        scriptCount: 0,
      })
    } else if (name.toLowerCase().endsWith(".zip") || name.toLowerCase().endsWith(".scripting")) {
      // 不解压统计（解压每个压缩包会卡住列表加载），脚本数在用户点开时由 inspectBackup 惰性计算
      const lower = name.toLowerCase()
      const extLen = lower.endsWith(".scripting") ? 10 : 4
      items.push({
        name: name.slice(0, -extLen),
        path: child,
        isZip: true,
        modifiedAt: statTime(child),
        byteSize: statSize(child),
        scriptCount: 0,
      })
    }
  }
  return items.sort((a, b) => b.modifiedAt - a.modifiedAt)
}

/** 删除本地备份（zip 文件或文件夹），返回是否成功 */
export function deleteLocalBackup(item: BackupItem): boolean {
  try {
    if (pathExists(item.path)) {
      FileManager.removeSync(item.path)
    }
    return true
  } catch {
    return false
  }
}

/** 分享选中的本地备份：zip/scripting 文件直接分享；目录先打包为 .scripting 再分享 */
export async function shareLocalBackups(items: BackupItem[]): Promise<void> {
  if (items.length === 0) {
    return
  }
  const staging = Path.join(
    FileManager.temporaryDirectory,
    `share-backup-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const files: string[] = []
  try {
    for (const item of items) {
      if (item.isZip) {
        files.push(item.path)
      } else {
        const zipPath = Path.join(
          staging,
          `${safeFileName(item.name)}.scripting`
        )
        await FileManager.zip(item.path, zipPath, false)
        files.push(zipPath)
      }
    }
    await ShareSheet.present(files)
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

/** 重命名本地备份（zip/scripting 文件保留原扩展名），改名后需重新 scanBackups */
export function renameLocalBackup(item: BackupItem, newName: string): void {
  const clean = newName.trim()
  if (!clean) {
    throw new Error("名称不能为空")
  }
  if (/[\/\\:]/.test(clean)) {
    throw new Error("名称不能包含 / \\ : 字符")
  }
  const dir = Path.dirname(item.path)
  let dest: string
  if (item.isZip) {
    const lower = item.path.toLowerCase()
    const ext = lower.endsWith(".scripting") ? ".scripting" : ".zip"
    dest = Path.join(dir, `${safeFileName(clean)}${ext}`)
  } else {
    dest = Path.join(dir, safeFileName(clean))
  }
  if (dest === item.path) {
    return
  }
  if (pathExists(dest)) {
    throw new Error(`已存在同名备份「${clean}」`)
  }
  FileManager.renameSync(item.path, dest)
}

// ---------- 备份脚本数：懒加载 + 本地缓存 ----------
// 列表加载不解压；脚本数由 RestorePage 后台逐个计算并缓存，
// 缓存文件是备份根目录下的隐藏 json（scanBackups 只扫目录和 .zip，不会误判）。

const BACKUP_COUNT_CACHE_NAME = ".script-manager-cache.json"

interface BackupCountCache {
  [path: string]: { modifiedAt: number; count: number }
}

function readBackupCountCache(destination: Destination): BackupCountCache {
  const cachePath = Path.join(backupRootFor(destination), BACKUP_COUNT_CACHE_NAME)
  try {
    if (pathExists(cachePath)) {
      return JSON.parse(
        FileManager.readAsStringSync(cachePath)
      ) as BackupCountCache
    }
  } catch {}
  return {}
}

/** 读缓存脚本数：缓存命中且修改时间一致才返回，否则 null（需要重新计算） */
export function getBackupScriptCount(
  destination: Destination,
  item: BackupItem
): number | null {
  const entry = readBackupCountCache(destination)[item.path]
  if (entry && entry.modifiedAt === item.modifiedAt) {
    return entry.count
  }
  return null
}

/** 实际计算一个备份里的脚本数（zip 需解压到临时目录，计算后清理） */
export function computeBackupScriptCount(item: BackupItem): number {
  if (item.isZip) {
    const tempDir = Path.join(
      FileManager.temporaryDirectory,
      `count-${Date.now()}-${Math.floor(Math.random() * 10000)}`
    )
    try {
      FileManager.createDirectorySync(tempDir, true)
      FileManager.unzipSync(item.path, tempDir)
      return scanScriptDirsInTree(tempDir).length
    } finally {
      if (pathExists(tempDir)) {
        try { FileManager.removeSync(tempDir) } catch {}
      }
    }
  }
  return scanScriptDirsInTree(item.path).length
}

/** 写入脚本数缓存 */
export function saveBackupScriptCount(
  destination: Destination,
  item: BackupItem,
  count: number
): void {
  const cache = readBackupCountCache(destination)
  cache[item.path] = { modifiedAt: item.modifiedAt, count }
  try {
    FileManager.writeAsStringSync(
      Path.join(backupRootFor(destination), BACKUP_COUNT_CACHE_NAME),
      JSON.stringify(cache)
    )
  } catch {}
}

/** 解开一个备份并找出其中的脚本（zip 解到临时目录，返回 tempDir 供调用方清理） */
export function inspectBackup(
  item: BackupItem
): { candidates: CandidateScript[]; tempDir: string | null } | null {
  try {
    if (item.isZip) {
      const tempDir = Path.join(
        FileManager.temporaryDirectory,
        `restore-${Date.now()}-${Math.floor(Math.random() * 10000)}`
      )
      FileManager.createDirectorySync(tempDir, true)
      FileManager.unzipSync(item.path, tempDir)
      return { candidates: scanScriptDirsInTree(tempDir), tempDir }
    }
    return { candidates: scanScriptDirsInTree(item.path), tempDir: null }
  } catch {
    return null
  }
}

/** 递归查找目录树里所有含 script.json 的脚本文件夹 */
export function scanScriptDirsInTree(root: string): CandidateScript[] {
  const found: CandidateScript[] = []
  function walk(dir: string, depth: number) {
    if (depth > 6) return
    const metaPath = Path.join(dir, "script.json")
    if (pathExists(metaPath)) {
      let version: string | undefined
      try {
        const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
        if (typeof obj?.version === "string") {
          version = obj.version
        }
      } catch {
        version = undefined
      }
      found.push({
        folderName: Path.basename(dir),
        sourcePath: dir,
        version,
        modifiedAt: statTime(metaPath),
      })
      return
    }
    for (const child of listChildren(dir)) {
      if (isDirectory(child)) {
        walk(child, depth + 1)
      }
    }
  }
  walk(root, 0)
  return found
}

export async function restoreScripts(
  candidates: CandidateScript[],
  overwrite: boolean
): Promise<{ restored: string[]; skipped: string[] }> {
  const root = FileManager.scriptsDirectory
  const restored: string[] = []
  const skipped: string[] = []
  for (const candidate of candidates) {
    const dest = Path.join(root, candidate.folderName)
    // 恢复前记住目标脚本原有的发布链接（remoteResource），
    // 若备份是发布前做的（不带 remoteResource），恢复后写回，避免丢失「已发布」图标
    const prevRemote = pathExists(dest) ? readRemoteResourceAtDir(dest) : null
    if (pathExists(dest)) {
      if (!overwrite) {
        skipped.push(candidate.folderName)
        continue
      }
      FileManager.removeSync(dest)
    }
    copyDirectory(candidate.sourcePath, dest)
    // 备份里本身没有发布链接但目标原本有：恢复后补回，保持「已发布」标识
    if (prevRemote && !readRemoteResourceAtDir(dest)) {
      writeRemoteResourceAtDir(dest, prevRemote)
    }
    restored.push(candidate.folderName)
  }
  return { restored, skipped }
}

// ==================== 脚本管理 ====================

export function renameScript(script: ScriptInfo, newName: string): void {
  const clean = newName.trim()
  if (!clean) {
    throw new Error("名称不能为空")
  }
  if (/[\/\\:]/.test(clean)) {
    throw new Error("名称不能包含 / \\ : 字符")
  }
  if (clean === script.folderName) {
    return
  }
  const dest = Path.join(FileManager.scriptsDirectory, clean)
  if (pathExists(dest)) {
    throw new Error(`已存在同名脚本「${clean}」`)
  }
  FileManager.renameSync(script.path, dest)
  // 同步更新 script.json 里的 name 和 localizedNames（主界面用 localizedNames 显示）
  try {
    const metaPath = Path.join(dest, "script.json")
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    if (typeof obj === "object" && obj !== null) {
      obj.name = clean
      if (obj.localizedNames && typeof obj.localizedNames === "object") {
        obj.localizedNames.zh = clean
      }
      if (obj.localizedDescriptions && typeof obj.localizedDescriptions === "object") {
        // localizedDescriptions 保持不变，只改名字
      }
      FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
    }
  } catch {
    // 元信息更新失败不阻断重命名
  }
}

export function setScriptVersion(script: ScriptInfo, version: string): void {
  const clean = version.trim()
  if (!clean) {
    throw new Error("版本号不能为空")
  }
  if (!/^\d+\.\d+\.\d+$/.test(clean)) {
    throw new Error("版本号格式应为 x.y.z，例如 1.0.1")
  }
  const metaPath = Path.join(script.path, "script.json")
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error("script.json 格式错误")
  }
  obj.version = clean
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/** 读取指定脚本目录 script.json 里的 remoteResource（更新链接）信息，无则返回 null。
 *  供 getScriptRemoteResource 与恢复流程共用（恢复时需按路径读取）。 */
function readRemoteResourceAtDir(
  dir: string
): { url: string; hash?: string; autoUpdateInterval?: number } | null {
  const metaPath = Path.join(dir, "script.json")
  if (!pathExists(metaPath)) {
    return null
  }
  try {
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    const remote = obj?.remoteResource
    if (!remote || typeof remote !== "object") {
      return null
    }
    return {
      url: typeof remote.url === "string" ? remote.url : "",
      hash: typeof remote.hash === "string" ? remote.hash : undefined,
      autoUpdateInterval:
        typeof remote.autoUpdateInterval === "number" ? remote.autoUpdateInterval : undefined,
    }
  } catch {
    return null
  }
}

/** 把 remoteResource（更新链接）写回指定脚本目录的 script.json，仅当该目录存在 script.json。 */
function writeRemoteResourceAtDir(
  dir: string,
  remote: { url: string; hash?: string; autoUpdateInterval?: number }
): void {
  const metaPath = Path.join(dir, "script.json")
  if (!pathExists(metaPath)) {
    return
  }
  try {
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    if (typeof obj !== "object" || obj === null) {
      return
    }
    obj.remoteResource = {
      url: remote.url,
      ...(remote.hash != null ? { hash: remote.hash } : {}),
      ...(remote.autoUpdateInterval != null ? { autoUpdateInterval: remote.autoUpdateInterval } : {}),
    }
    FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
  } catch {}
}

/**
 * 读取脚本 script.json 里的 remoteResource（更新链接）信息。
 * 若脚本配置了自动更新（autoUpdateInterval），Scripting 会定期从远程拉取 script.json
 * 覆盖本地文件，导致手动修改的版本号被还原。返回 null 表示没有远程更新链接。
 */
export function getScriptRemoteResource(
  script: ScriptInfo
): { url: string; hash?: string; autoUpdateInterval?: number } | null {
  return readRemoteResourceAtDir(script.path)
}

/**
 * 下载脚本云端 .scripting 包（remoteResource.url），读取其 script.json 的版本号与更新说明（changelog），
 * 用于检测「云端与本地不同步」及展示云端版本的更新说明。仅读取不覆盖本地；失败返回 null。
 */
export async function fetchScriptCloudMeta(
  script: ScriptInfo
): Promise<{ version: string | null; changelog: string | null } | null> {
  const remote = getScriptRemoteResource(script)
  if (!remote?.url) {
    return null
  }
  try {
    const res = await fetch(remote.url)
    if (!res.ok) {
      return null
    }
    const bytes = await res.bytes()
    const staging = Path.join(
      FileManager.temporaryDirectory,
      `cloud-ver-${Date.now()}-${Math.floor(Math.random() * 10000)}`
    )
    FileManager.createDirectorySync(staging, true)
    try {
      const zipPath = Path.join(staging, "cloud.scripting")
      FileManager.writeAsBytesSync(zipPath, bytes)
      const inner = Path.join(staging, "inner")
      FileManager.createDirectorySync(inner, true)
      FileManager.unzipSync(zipPath, inner)
      const candidates = scanScriptDirsInTree(inner)
      if (candidates.length === 0) {
        return null
      }
      const first = candidates[0]
      let changelog: string | null = null
      try {
        const metaPath = Path.join(first.sourcePath, "script.json")
        const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
        if (typeof obj?.changelog === "string" && obj.changelog.trim()) {
          changelog = obj.changelog
        }
      } catch {}
      return { version: first.version || null, changelog }
    } finally {
      if (pathExists(staging)) {
        try {
          FileManager.removeSync(staging)
        } catch {}
      }
    }
  } catch {
    return null
  }
}

/** 写入脚本 script.json 的更新说明字段（changelog），随发布包一起分发；空说明则移除字段 */
export function setScriptChangelog(script: ScriptInfo, changelog: string): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  const text = (changelog ?? "").trim()
  if (text) {
    obj.changelog = text
  } else {
    delete obj.changelog
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/** 读取脚本 script.json 的更新说明（changelog），无则返回 null */
export function readScriptChangelog(script: ScriptInfo): string | null {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    return null
  }
  try {
    const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
    if (typeof obj?.changelog === "string" && obj.changelog.trim()) {
      return obj.changelog
    }
  } catch {}
  return null
}

const CHANGELOG_MARKER_START = "// ===== 更新说明检查（脚本管理工具注入，勿删） ====="
const CHANGELOG_MARKER_END = "// ===== 更新说明检查结束 ====="

/**
 * 向被发布脚本的 index.tsx 注入「更新说明检查」代码（顶部 IIFE）：
 * 更新到新版本后首次运行时自动弹出该版本的更新说明（App Store 更新日志风格自定义页面），
 * 并提供「不再显示本次更新说明」按钮。
 * 说明文本、版本号、脚本名全部直接嵌入代码常量；UI 组件通过动态 import("scripting") 获取，
 * 不读 script.json（Scripting 应用会重写它并丢掉自定义字段），也不依赖裸全局 Script（需要 import from "scripting"）。
 * 延迟 600ms 再 present，避免被脚本主体页面的 Navigation.present 覆盖。
 * 重复注入会自动移除旧块后替换。找不到 index.tsx 返回 false。
 */
export function injectChangelogChecker(script: ScriptInfo, changelog: string): boolean {
  const entry = Path.join(script.path, "index.tsx")
  if (!pathExists(entry)) {
    return false
  }
  let source = FileManager.readAsStringSync(entry)
  const startIdx = source.indexOf(CHANGELOG_MARKER_START)
  const endIdx = source.indexOf(CHANGELOG_MARKER_END)
  if (startIdx >= 0 && endIdx >= 0 && endIdx > startIdx) {
    source = source.slice(0, startIdx) + source.slice(endIdx + CHANGELOG_MARKER_END.length)
  }
  const noteLiteral = JSON.stringify((changelog ?? "").trim())
  const versionLiteral = JSON.stringify(String(script.version ?? ""))
  const nameLiteral = JSON.stringify(String(script.displayName ?? ""))
  const block =
    CHANGELOG_MARKER_START +
    "\n" +
    `;(async () => {
  try {
    const note = ${noteLiteral}
    if (!note) return
    const version = ${versionLiteral}
    const scriptName = ${nameLiteral}
    if (!version) return
    const base = FileManager.appGroupDocumentsDirectory || ""
    if (!base) return
    const seenDir = base + "/changelog_seen"
    try { await FileManager.createDirectory(seenDir, true) } catch (e) {}
    const statePath = seenDir + "/" + scriptName + ".json"
    let seen: Record<string, boolean> = {}
    try { seen = JSON.parse(await FileManager.readAsString(statePath)) || {} } catch (e) {}
    if (seen[version]) return
    await new Promise<void>((resolve) => setTimeout(() => resolve(), 600))
    const { Navigation, NavigationStack, ScrollView, VStack, HStack, Text, Button, Divider, Spacer } = await import("scripting")
    const markSeen = async () => {
      try {
        seen[version] = true
        await FileManager.writeAsString(statePath, JSON.stringify(seen))
      } catch (e) {}
    }
    function ChangelogView(props: { note: string; version: string; scriptName: string }) {
      const dismiss = Navigation.useDismiss()
      return (
        <NavigationStack>
          <VStack navigationTitle={props.scriptName + " · 更新说明"} navigationBarTitleDisplayMode="inline" navigationBarBackButtonHidden spacing={0}>
            <ScrollView>
              <VStack alignment="leading" spacing={10} padding={16}>
                <Text font="headline" bold foregroundStyle="secondaryLabel">版本 {props.version}</Text>
                <Divider />
                <Text font="body">{props.note}</Text>
              </VStack>
            </ScrollView>
            <Divider />
            <HStack spacing={10} padding={16}>
              <Button action={() => { markSeen(); dismiss() }} buttonStyle="bordered" controlSize="large">
                <Text font="footnote" foregroundStyle="secondaryLabel">此版不再显示</Text>
              </Button>
              <Button action={() => dismiss()} buttonStyle="borderedProminent" controlSize="large">
                <Text font="footnote" bold>稍候再看说明</Text>
              </Button>
            </HStack>
          </VStack>
        </NavigationStack>
      )
    }
    await Navigation.present({
      element: <ChangelogView note={note} version={version} scriptName={scriptName} />,
    })
  } catch (e) {}
})();\n` +
    CHANGELOG_MARKER_END +
    "\n\n"
  FileManager.writeAsStringSync(entry, block + source)
  return true
}

/** 移除脚本 index.tsx 里的更新说明检查代码（无则不动） */
export function removeChangelogChecker(script: ScriptInfo): void {
  const entry = Path.join(script.path, "index.tsx")
  if (!pathExists(entry)) {
    return
  }
  const source = FileManager.readAsStringSync(entry)
  const startIdx = source.indexOf(CHANGELOG_MARKER_START)
  const endIdx = source.indexOf(CHANGELOG_MARKER_END)
  if (startIdx >= 0 && endIdx >= 0 && endIdx > startIdx) {
    FileManager.writeAsStringSync(
      entry,
      source.slice(0, startIdx) + source.slice(endIdx + CHANGELOG_MARKER_END.length)
    )
  }
}

/**
 * 关闭脚本的自动更新：保留更新链接（url/hash），只移除 autoUpdateInterval 开关。
 * 用于修改版本号后防止 Scripting 按间隔从远程拉取覆盖本地改动的版本号，
 * 同时保留链接，之后可重新开启自动更新。
 */
export function disableScriptAutoUpdate(script: ScriptInfo): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  const remote = obj.remoteResource
  if (remote && typeof remote === "object") {
    // 只关开关，不删链接
    delete remote.autoUpdateInterval
  } else {
    obj.remoteResource = null
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/**
 * 彻底移除脚本的更新链接与自动更新配置（remoteResource 置为 null）。
 * 用于发布失败回滚时恢复“从未配置过更新链接”的原状。
 */
function clearScriptRemoteResource(script: ScriptInfo): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  obj.remoteResource = null
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

export function deleteScript(script: ScriptInfo): void {
  if (!pathExists(script.path)) {
    return
  }
  FileManager.removeSync(script.path)
}

/** 打包脚本为 .scripting 文件并通过系统分享面板分享（staging 位于临时目录，分享完成后清理） */
export async function shareScripts(scripts: ScriptInfo[]): Promise<void> {
  if (scripts.length === 0) {
    return
  }
  const staging = Path.join(FileManager.temporaryDirectory, `share-${Date.now()}`)
  FileManager.createDirectorySync(staging, true)
  const name =
    scripts.length === 1
      ? `${scripts[0].folderName}_${scripts[0].version}`
      : `${scripts[0].folderName}等${scripts.length}个脚本`
  const filePath = Path.join(staging, `${safeFileName(name)}.scripting`)
  try {
    if (scripts.length === 1) {
      await FileManager.zip(scripts[0].path, filePath, true)
    } else {
      const inner = Path.join(staging, "scripts")
      FileManager.createDirectorySync(inner, true)
      for (const script of scripts) {
        copyDirectory(script.path, Path.join(inner, script.folderName))
      }
      await FileManager.zip(inner, filePath, false)
    }
    await ShareSheet.present([filePath])
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

/**
 * 打包单个脚本为 .scripting 并返回压缩包实际大小（与备份/分享产物一致），失败返回 null。
 * 行菜单显示脚本大小时用它，避免“目录内文件大小之和”与备份 zip 大小不一致。
 */
export async function scriptZipSize(script: ScriptInfo): Promise<number | null> {
  const staging = Path.join(FileManager.temporaryDirectory, `size-${Date.now()}`)
  FileManager.createDirectorySync(staging, true)
  const filePath = Path.join(staging, `${safeFileName(script.folderName)}.scripting`)
  try {
    await FileManager.zip(script.path, filePath, true)
    return statSize(filePath)
  } catch {
    return null
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

// ==================== GitHub 发布 ====================

/** 简单 HTTP 封装（GitHub API 使用） */
async function githubHttp(
  url: string,
  init: {
    method?: string
    headers?: Record<string, string>
    body?: string
  } = {}
): Promise<{ status: number; data: any; text: string }> {
  const r = await fetch(url, {
    method: init.method || "GET",
    headers: { ...(init.headers || {}) },
    body: init.body,
  })
  const text = await r.text()
  let data: any = null
  try {
    data = JSON.parse(text)
  } catch {}
  return { status: r.status, data, text }
}

// ==================== 仓库监控 ====================

/** 默认监控仓库（工具作者的发布仓库），首次启用时自动加入配置 */
export const DEFAULT_CHANNEL_MONITOR_LINK =
  "https://github.com/vvvvvveng/Scripting-releases"

export const DEFAULT_CHANNEL_MONITOR_LINKS: ChannelMonitorLink[] = [
  {
    url: DEFAULT_CHANNEL_MONITOR_LINK,
    name: "WWWeng🐝的脚本仓库",
  },
]

/**
 * 仓库监控默认排除关键词：仓库里的「测试脚本_请勿下载_」等脚本名称含「请勿下载」，默认不提示更新。
 * 仅当用户配置里未设置过该字段时生效（用户保存过自己的关键词列表后以用户为准）。
 */
export const DEFAULT_CHANNEL_EXCLUDE_KEYWORDS = ["请勿下载"]

/**
 * 解析 GitHub 仓库地址，返回规范化 URL；无法解析返回 null。
 * 支持：https://github.com/owner/repo、github.com/owner/repo、owner/repo、结尾带 / 或 .git。
 */
export function normalizeRepoUrl(input: string): string | null {
  const raw = (input || "").trim().replace(/\/+$/, "")
  if (!raw) return null
  let m = raw.match(
    /^(?:https?:\/\/)?(?:www\.)?github\.com\/([^/?#]+)\/([^/?#]+)$/i
  )
  if (!m) {
    m = raw.match(/^([^/?#]+)\/([^/?#]+)$/)
  }
  if (!m) return null
  const owner = m[1].replace(/\.git$/i, "")
  const repo = m[2].replace(/\.git$/i, "")
  if (!owner || !repo) return null
  return `https://github.com/${owner}/${repo}`
}

/** 仓库显示名：默认取 所有者/仓库名，如 vvvvvveng/Scripting-releases */
export function repoDisplayName(url: string): string {
  const norm = normalizeRepoUrl(url)
  if (!norm) return url
  return norm.replace(/^https?:\/\/github\.com\//i, "")
}

/**
 * 规范化监控链接列表：过滤无效/重复项；全空时补默认仓库。
 * 备注名为空时自动取 所有者/仓库名。
 */
export function normalizeChannelMonitorLinks(
  links?: unknown
): ChannelMonitorLink[] {
  const arr = Array.isArray(links) ? links : []
  const list: ChannelMonitorLink[] = []
  const seen = new Set<string>()
  for (const item of arr) {
    if (!item || typeof item !== "object") continue
    const anyItem = item as Record<string, unknown>
    const url = normalizeRepoUrl(String(anyItem.url ?? ""))
    if (!url || seen.has(url)) continue
    seen.add(url)
    const auto = repoDisplayName(url)
    list.push({
      url,
      name: String(anyItem.name ?? "").trim() || auto,
    })
  }
  if (list.length === 0) {
    list.push({ ...DEFAULT_CHANNEL_MONITOR_LINKS[0] })
  }
  return list
}

/**
 * 规范化排除关键词列表：过滤空串、去重、统一 trim。
 */
export function normalizeChannelExcludeKeywords(keywords?: unknown): string[] {
  const arr = Array.isArray(keywords) ? keywords : []
  const out: string[] = []
  const seen = new Set<string>()
  for (const k of arr) {
    const s = String(k ?? "").trim()
    if (!s || seen.has(s)) continue
    seen.add(s)
    out.push(s)
  }
  return out
}

/**
 * 规范化已忽略脚本路径列表：过滤空串、去重、统一 trim（格式 `仓库url|脚本路径`）。
 */
export function normalizeChannelIgnoredPaths(paths?: unknown): string[] {
  const arr = Array.isArray(paths) ? paths : []
  const out: string[] = []
  const seen = new Set<string>()
  for (const p of arr) {
    const s = String(p ?? "").trim()
    if (!s || seen.has(s)) continue
    seen.add(s)
    out.push(s)
  }
  return out
}

/**
 * 判断脚本路径是否命中排除关键词（去掉扩展名后的名称部分含任一关键词即排除）。
 */
export function isChannelScriptExcluded(
  path: string,
  keywords: string[]
): boolean {
  if (!Array.isArray(keywords) || keywords.length === 0) return false
  const name = String(path ?? "").replace(/\.scripting$/i, "")
  return keywords.some((k) => name.includes(k))
}

/** 仓库监控：检查间隔换算为秒（默认 12 小时） */
export function channelMonitorIntervalSeconds(
  value: number,
  unit: "minute" | "hour" | "day"
): number {
  const base = Number.isFinite(value) && value > 0 ? value : 12
  if (unit === "day") return Math.round(base * 86400)
  if (unit === "hour") return Math.round(base * 3600)
  return Math.round(base * 60)
}

/**
 * 拉取仓库里所有 .scripting 文件（git/trees 递归接口，一次请求；公开仓库无需 Token）。
 * 依次尝试 main → HEAD → master 分支。失败抛错。
 */
export async function fetchChannelRepoScripts(
  url: string
): Promise<ChannelRepoFile[]> {
  const norm = normalizeRepoUrl(url)
  if (!norm) throw new Error("无法解析仓库地址")
  const parts = norm.replace(/^https?:\/\/github\.com\//i, "").split("/")
  if (parts.length !== 2) throw new Error("无法解析仓库地址")
  const [owner, repo] = parts
  // 若配置过 GitHub Token 则带上（提高 API 限额），没有也能匿名读取公开仓库
  const gh = resolveGithubConfig()
  const token = gh.publishToken || gh.backupToken || gh.token || ""
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  if (token) headers.Authorization = `Bearer ${token}`
  let lastError: Error | null = null
  for (const branch of ["main", "HEAD", "master"]) {
    const { status, data } = await githubHttp(
      `https://api.github.com/repos/${owner}/${repo}/git/trees/${encodeURIComponent(
        branch
      )}?recursive=1`,
      { headers }
    )
    if (status === 200 && data && Array.isArray(data.tree)) {
      return (data.tree as any[])
        .filter(
          (x) =>
            x &&
            x.type === "blob" &&
            typeof x.path === "string" &&
            x.path.toLowerCase().endsWith(".scripting")
        )
        .map((x) => ({
          path: x.path as string,
          sha: String(x.sha ?? ""),
          size: typeof x.size === "number" ? x.size : 0,
        }))
    }
    lastError = new Error(`HTTP ${status}: ${data?.message ?? ""}`)
  }
  throw lastError ?? new Error("获取仓库文件列表失败")
}

/** 只更新仓库监控相关配置字段（不覆盖其它字段） */
export function updateChannelMonitorConfig(patch: Partial<AppConfig>) {
  saveConfig({ ...resolveConfig(), ...patch })
}

/**
 * 执行一次仓库监控全量检查：遍历所有监控仓库，拉取 .scripting 文件列表并对比基线快照。
 * 首次扫描（未建立基线）只记录快照不产生变化；之后新增/更新/删除都会记录到 changes。
 * 变化检测依赖 blob sha：文件内容变了 sha 就变，无需下载文件本体。
 * 调用方决定如何提示（应用内弹窗/系统通知）。
 */
export async function runChannelMonitorCheck(): Promise<ChannelCheckSummary> {
  const cfg = resolveConfig()
  if (!cfg.channelMonitorEnabled) {
    return { results: [], totalChanges: 0, newBaseline: false }
  }
  const links =
    Array.isArray(cfg.channelMonitorLinks) && cfg.channelMonitorLinks.length > 0
      ? cfg.channelMonitorLinks
      : DEFAULT_CHANNEL_MONITOR_LINKS
  const snapshots = { ...(cfg.channelMonitorSnapshots ?? {}) }
  const baselineReady = cfg.channelMonitorBaselineReady === true
  const results: ChannelCheckResult[] = []
  for (const link of links) {
    const snapshot = snapshots[link.url] ?? {}
    try {
      const files = await fetchChannelRepoScripts(link.url)
      const changes: ChannelChange[] = []
      for (const f of files) {
        const prevSha = snapshot[f.path]
        if (!baselineReady || prevSha == null) {
          // 未建立基线（首次扫描）不把全部文件当「新增」提示
          if (baselineReady) {
            changes.push({ type: "added", path: f.path, size: f.size, sha: f.sha })
          }
        } else if (prevSha !== f.sha) {
          changes.push({ type: "updated", path: f.path, size: f.size, sha: f.sha })
        }
      }
      // 更新快照（快照始终全量记录，排除关键词只影响提示与更新页，不影响基线对比）。
      // 已从仓库删除的文件不再提示（用户要求不显示「已从仓库删除」），快照更新时自然移除其路径。
      const next: Record<string, string> = {}
      for (const f of files) next[f.path] = f.sha
      snapshots[link.url] = next
      const kw = Array.isArray(cfg.channelMonitorExcludeKeywords)
        ? cfg.channelMonitorExcludeKeywords
        : []
      const ignoredPaths = new Set(
        Array.isArray(cfg.channelMonitorIgnoredPaths)
          ? cfg.channelMonitorIgnoredPaths
          : []
      )
      // 排除关键词过滤（名称命中关键词不提示）
      const notExcluded = changes.filter((c) => !isChannelScriptExcluded(c.path, kw))
      // 被「全部忽略」按路径忽略（同一脚本再发布新版本也不提示，直到在设置里恢复提醒）
      const ignored = notExcluded.filter((c) =>
        ignoredPaths.has(`${link.url}|${c.path}`)
      )
      const visibleChanges = notExcluded.filter(
        (c) => !ignoredPaths.has(`${link.url}|${c.path}`)
      )
      results.push({
        name: link.name,
        url: link.url,
        changes: visibleChanges,
        scriptCount: files.length,
        ok: true,
        excludedCount: changes.length - notExcluded.length,
        ignoredCount: ignored.length,
      })
    } catch (error) {
      results.push({
        name: link.name,
        url: link.url,
        changes: [],
        scriptCount: 0,
        ok: false,
        error: error instanceof Error ? error.message : String(error),
      })
    }
  }
  const newBaseline = !baselineReady
  if (newBaseline) {
    updateChannelMonitorConfig({
      channelMonitorSnapshots: snapshots,
      channelMonitorBaselineReady: true,
    })
  } else {
    updateChannelMonitorConfig({ channelMonitorSnapshots: snapshots })
  }
  const totalChanges = results.reduce((n, r) => n + r.changes.length, 0)
  const summary: ChannelCheckSummary = { results, totalChanges, newBaseline }
  saveLastChannelCheck(summary)
  return summary
}

// ==================== 仓库监控：最近检查结果持久化 ====================

const CHANNEL_LAST_CHECK_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "channel-monitor-last-check.json"
)

/** 最近一次仓库监控检查结果（供通知点击后打开更新页使用） */
export type ChannelLastCheck = {
  /** 检查完成时间戳（毫秒） */
  checkedAt: number
  summary: ChannelCheckSummary
}

/** 持久化最近一次仓库监控检查结果 */
export function saveLastChannelCheck(summary: ChannelCheckSummary) {
  try {
    const data: ChannelLastCheck = { checkedAt: Date.now(), summary }
    FileManager.writeAsStringSync(
      CHANNEL_LAST_CHECK_PATH,
      JSON.stringify(data)
    )
  } catch {
    // ignore
  }
}

/** 读取最近一次仓库监控检查结果；没有或读取失败返回 null */
export function readLastChannelCheck(): ChannelLastCheck | null {
  try {
    if (!pathExists(CHANNEL_LAST_CHECK_PATH)) return null
    const raw = JSON.parse(
      FileManager.readAsStringSync(CHANNEL_LAST_CHECK_PATH)
    ) as Partial<ChannelLastCheck>
    if (!raw || !raw.summary || !Array.isArray(raw.summary.results)) {
      return null
    }
    return {
      checkedAt: typeof raw.checkedAt === "number" ? raw.checkedAt : 0,
      summary: raw.summary as ChannelCheckSummary,
    }
  } catch {
    return null
  }
}

/**
 * 清除最近检查结果中的 removed 记录：用户已在更新页看到「已从仓库删除」，
 * 下次打开更新页不再重复显示（不重新检查，仅移除持久化结果里的 removed 条目）。
 */
export function dismissChannelRemoved() {
  try {
    const last = readLastChannelCheck()
    if (!last) return
    let removedCount = 0
    const results = last.summary.results.map((r) => ({
      ...r,
      changes: r.changes.filter((c) => {
        if (c.type === "removed") {
          removedCount += 1
          return false
        }
        return true
      }),
    }))
    if (removedCount === 0) return
    const totalChanges = results.reduce((n, r) => n + r.changes.length, 0)
    saveLastChannelCheck({ ...last.summary, results, totalChanges })
  } catch {
    // ignore
  }
}

/**
 * 全部忽略：清零最近检查结果（totalChanges → 0）。
 * 配合 channelMonitorNotifiedSig 持久化签名，用户点「全部忽略」后：
 * ① 监控循环同一批变化不再提示/弹更新页；
 * ② 通知点击路径读到 totalChanges=0，也不会再重新打开更新页。
 */
export function dismissChannelUpdates() {
  try {
    const last = readLastChannelCheck()
    if (!last) return
    const results = last.summary.results.map((r) => ({
      ...r,
      changes: [] as ChannelChange[],
    }))
    saveLastChannelCheck({
      ...last.summary,
      results,
      totalChanges: 0,
    })
  } catch {
    // ignore
  }
}

// ==================== 仓库监控：更新脚本 ====================

/** 解析仓库链接为 { owner, repo }；解析失败返回 null */
export function repoParts(
  url: string
): { owner: string; repo: string } | null {
  const norm = normalizeRepoUrl(url)
  if (!norm) return null
  const parts = norm.replace(/^https?:\/\/github\.com\//i, "").split("/")
  if (parts.length !== 2 || !parts[0] || !parts[1]) return null
  return { owner: parts[0], repo: parts[1] }
}

/**
 * 生成仓库内某个文件的 raw 下载地址（https://raw.githubusercontent.com/…）。
 * 依次尝试 main → master 分支，找到能下载的分支即返回；找不到返回 null。
 */
export async function resolveRawScriptUrl(
  url: string,
  filePath: string
): Promise<string | null> {
  const parts = repoParts(url)
  if (!parts) return null
  for (const branch of ["main", "master"]) {
    const rawUrl = `https://raw.githubusercontent.com/${parts.owner}/${parts.repo}/${branch}/${filePath}`
    try {
      const r = await fetch(rawUrl, { method: "HEAD" })
      if (r.status === 200) {
        return rawUrl
      }
    } catch {
      // 继续尝试下一个分支
    }
  }
  return null
}

/** 校验 GitHub Token 是否有效，返回登录名 */
export async function githubVerify(token: string): Promise<string> {
  const { status, data } = await githubHttp(
    "https://api.github.com/user",
    {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github+json",
      },
    }
  )
  if (status !== 200) {
    throw new Error(`GitHub Token 无效 (${status}): ${data?.message || ""}`)
  }
  return data.login as string
}

/**
 * 确保仓库存在：不存在时自动创建（默认公开）。
 * 通过 GET /repos/{owner}/{repo} 判断，404 时 POST /user/repos 创建。
 * 返回 { empty, confirmed }：empty=仓库是否为空；confirmed=是否成功查到分支状态（非猜测）。
 *
 * 注意：POST /user/repos 返回 422 通常意味着仓库名已被占用（仓库已存在），
 * 此时视为仓库存在且非空，直接继续上传流程。
 */
export async function ensureGithubRepo(
  token: string,
  owner: string,
  repo: string,
  isPrivate: boolean = false
): Promise<{ empty: boolean; confirmed: boolean }> {
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  let repoExists = false

  const check = await githubHttp(
    `https://api.github.com/repos/${owner}/${repo}`,
    { headers }
  )
  if (check.status === 200) {
    repoExists = true
  }
  // GET 返回 403/404 可能是 token 无读私有仓库权限
  // 无法判断 → 先尝试上传，上传失败再报错

  if (!repoExists) {
    // 仓库可能不存在 → 尝试创建
    const created = await githubHttp(
      "https://api.github.com/user/repos",
      {
        method: "POST",
        headers,
        body: JSON.stringify({
          name: repo,
          private: isPrivate,
          auto_init: true,
          description: isPrivate
            ? "脚本管理工具自动创建的私密备份仓库"
            : "脚本管理工具自动创建的公开发布仓库",
        }),
      }
    )
    if (created.status === 201) {
      // 创建成功 → auto_init 已初始化，非空
      return { empty: false, confirmed: true }
    }
    if (created.status === 422) {
      // 422 = 仓库名已被占用（已存在），视为已存在，继续
      repoExists = true
    } else {
      throw new Error(
        `自动创建仓库 ${owner}/${repo} 失败 (${created.status}): ${created.data?.message || ""}`
      )
    }
  }

  // 仓库已存在：尝试检查分支判断是否为空
  try {
    const branches = await githubHttp(
      `https://api.github.com/repos/${owner}/${repo}/branches`,
      { headers }
    )
    if (branches.status === 200 && Array.isArray(branches.data)) {
      return { empty: branches.data.length === 0, confirmed: true }
    }
  } catch {
    // fall through
  }
  // 无法确认分支状态（无读权限）→ 返回 confirmed=false，上传时不指定 branch
  return { empty: false, confirmed: false }
}

const LARGE_FILE_LIMIT = 1024 * 1024 // Contents API 单文件上限约 1MB

/**
 * 当 zip > 1MB 时改用 Git Data API（blob+tree+commit）上传，
 * 规避 Contents API PUT 的 1MB 限制（最大支持 ~100MB base64）。
 */
async function gitPushLarge(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  remotePath: string,
  localPath: string,
  skipBranch: boolean
): Promise<string> {
  const base64 = (Data.fromFile(localPath) as Data).toBase64String()
  const apiBase = `https://api.github.com/repos/${owner}/${repo}`
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }

  // 1. 创建 blob
  const blobRes = await githubHttp(`${apiBase}/git/blobs`, {
    method: "POST",
    headers,
    body: JSON.stringify({ content: base64, encoding: "base64" }),
  })
  if (blobRes.status !== 201) {
    throw new Error(`创建 blob 失败 (${blobRes.status}): ${blobRes.data?.message || ""}`)
  }
  const blobSha = blobRes.data.sha as string

  if (skipBranch || !branch.trim()) {
    // 空仓库：创建 tree + commit + ref
    const treeRes = await githubHttp(`${apiBase}/git/trees`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        tree: [{ path: remotePath, mode: "100644", type: "blob", sha: blobSha }],
      }),
    })
    if (treeRes.status !== 201) {
      throw new Error(`创建 tree 失败 (${treeRes.status}): ${treeRes.data?.message || ""}`)
    }
    const commitRes = await githubHttp(`${apiBase}/git/commits`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        message: `Add ${remotePath}`,
        tree: treeRes.data.sha,
      }),
    })
    if (commitRes.status !== 201) {
      throw new Error(`创建 commit 失败 (${commitRes.status}): ${commitRes.data?.message || ""}`)
    }
    await githubHttp(`${apiBase}/git/refs`, {
      method: "POST",
      headers,
      body: JSON.stringify({ ref: "refs/heads/main", sha: commitRes.data.sha }),
    })
    return `https://raw.githubusercontent.com/${owner}/${repo}/main/${remotePath}`
  }

  // 已有分支：读当前 commit → tree → 创建新 tree → commit → 更新 ref
  const refRes = await githubHttp(`${apiBase}/git/refs/heads/${branch}`, {
    headers,
  })
  if (refRes.status !== 200) {
    throw new Error(`读取分支 ref 失败 (${refRes.status}): ${refRes.data?.message || ""}`)
  }
  const commitSha = (refRes.data.object as any).sha as string
  const commitRes = await githubHttp(`${apiBase}/git/commits/${commitSha}`, {
    headers,
  })
  const treeSha = commitRes.data.tree.sha as string

  const newTreeRes = await githubHttp(`${apiBase}/git/trees`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      base_tree: treeSha,
      tree: [{ path: remotePath, mode: "100644", type: "blob", sha: blobSha }],
    }),
  })
  if (newTreeRes.status !== 201) {
    throw new Error(`创建 tree 失败 (${newTreeRes.status}): ${newTreeRes.data?.message || ""}`)
  }

  const newCommitRes = await githubHttp(`${apiBase}/git/commits`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      message: `Add ${remotePath}`,
      tree: newTreeRes.data.sha,
      parents: [commitSha],
    }),
  })
  if (newCommitRes.status !== 201) {
    throw new Error(`创建 commit 失败 (${newCommitRes.status}): ${newCommitRes.data?.message || ""}`)
  }

  const updateRefRes = await githubHttp(`${apiBase}/git/refs/heads/${branch}`, {
    method: "PATCH",
    headers,
    body: JSON.stringify({ sha: newCommitRes.data.sha, force: false }),
  })
  if (updateRefRes.status !== 200) {
    throw new Error(`更新 ref 失败 (${updateRefRes.status}): ${updateRefRes.data?.message || ""}`)
  }

  return `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${remotePath}`
}

/**
 * 把 zip 二进制内容通过 Contents API 上传到 GitHub 仓库。
 * < 1MB 用 Contents API PUT（快速）；>= 1MB 用 Git Data API（支持大文件）。
 * 返回 raw 下载链接。
 */
async function githubPushZip(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  dir: string,
  remotePath: string,
  zipPath: string,
  skipBranch: boolean = false
): Promise<string> {
  const size = statSize(zipPath)

  // >= 1MB：使用 Git Data API 上传大文件
  if (size >= LARGE_FILE_LIMIT) {
    return gitPushLarge(token, owner, repo, branch, remotePath, zipPath, skipBranch)
  }

  // < 1MB：Contents API（原有快速路径）
  const base64 = (Data.fromFile(zipPath) as Data).toBase64String()
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${remotePath}`

  // 先 GET 检查文件是否已存在，拿到 sha 才能覆盖
  let sha: string | undefined
  const existing = await githubHttp(url, {
    headers: {
      Authorization: headers.Authorization,
      Accept: headers.Accept,
    },
  })
  if (existing.status === 200 && existing.data?.sha) {
    sha = existing.data.sha
  } else if (existing.status !== 404) {
    // 仓库不存在等错误：交给上层 ensureGithubRepo 处理，这里允许 404（文件不存在）
  }

  const body: any = {
    message: sha ? `Update ${remotePath}` : `Add ${remotePath}`,
    content: base64,
  }
  if (sha) {
    body.sha = sha
  }
  // skipBranch=true 时：空仓库没有分支，不能指定 branch（GitHub 会自动创建默认分支）
  if (!skipBranch && branch.trim()) {
    body.branch = branch.trim()
  }

  const { status, data } = await githubHttp(url, {
    method: "PUT",
    headers,
    body: JSON.stringify(body),
  })
  if (status !== 200 && status !== 201) {
    const hint = status === 422
      ? "（可能是仓库为空或文件过大，已自动处理空仓库；若仍失败请检查 Token 是否有 repo 权限、文件名是否合法）"
      : ""
    throw new Error(`推送 ${remotePath} 失败 (${status}): ${data?.message || ""}${hint}`)
  }

  const branchName = (skipBranch ? "main" : branch.trim()) || "main"
  // remotePath 已包含目录前缀，直接拼接；与 gitPushLarge 的 raw 链接保持一致
  return `https://raw.githubusercontent.com/${owner}/${repo}/${branchName}/${remotePath}`
}

/** 更新脚本 script.json 里的 remoteResource（更新链接），hash 为 zip 包的 MD5。
 *  autoUpdateInterval 缺省时只保留链接、不开启自动更新（开关保持关闭）。 */
export function updateScriptRemoteResource(
  script: ScriptInfo,
  url: string,
  hash: string,
  autoUpdateInterval?: number
): void {
  const metaPath = Path.join(script.path, "script.json")
  if (!pathExists(metaPath)) {
    throw new Error(`缺少 ${script.displayName}/script.json`)
  }
  const obj = parseScriptJson(FileManager.readAsStringSync(metaPath))
  if (typeof obj !== "object" || obj === null) {
    throw new Error(`${script.displayName}/script.json 格式错误`)
  }
  obj.remoteResource = {
    url,
    hash,
    ...(autoUpdateInterval != null ? { autoUpdateInterval } : {}),
  }
  FileManager.writeAsStringSync(metaPath, JSON.stringify(obj, null, 2))
}

/** 计算 zip 包的 MD5（Scripting 更新链接的 hash 字段） */
export function zipMd5(zipPath: string): string {
  const data = Data.fromFile(zipPath)
  if (!data) {
    throw new Error("无法读取文件内容")
  }
  return Crypto.md5(data).toHexString()
}

/**
 * 把选中的脚本逐个发布（打包 .scripting → 上传 GitHub → 同步 remoteResource）。
 * 仓库不存在时自动创建（默认公开）。
 * 发布前先把更新链接写入 script.json 再打包，确保发布的 zip 自带 remoteResource，
 * 安装方即可获得自动更新链接；上传成功后本机 hash 修正为本次 zip 的真实 MD5。
 * 返回每个脚本的 raw 链接。
 */
export async function publishScriptsToGithub(
  scripts: ScriptInfo[],
  config: GithubConfig
): Promise<Array<{ folderName: string; url: string; zipPath: string }>> {
  if (!isGithubConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 发布配置（Token/所有者/仓库名）")
  }
  // 首次使用自动创建发布仓库（默认公开）；拿到仓库状态
  const repoState = await ensureGithubRepo(config.token, config.owner, config.repo, false)
  const skipBranch = !repoState.confirmed || repoState.empty

  const results: Array<{ folderName: string; url: string; zipPath: string }> = []
  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-publish-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const dir = config.path.trim().replace(/^\/+|\/+$/g, "")
  try {
    for (let i = 0; i < scripts.length; i++) {
      const script = scripts[i]
      const zipName = `${safeFileName(script.folderName)}.scripting`
      const remotePath = dir ? `${dir}/${zipName}` : zipName
      const branchName = (skipBranch ? "main" : config.branch.trim()) || "main"
      const url = `https://raw.githubusercontent.com/${config.owner}/${config.repo}/${branchName}/${remotePath}`
      const zipPath = Path.join(staging, zipName)
      // 先把更新链接写进 script.json 再打包：确保发布的 zip 自带 remoteResource，
      // 别人安装后即可获得自动更新链接。首次发布 hash 为空占位，后续用上一次的 hash。
      // 记录原始 remoteResource，上传失败时恢复，避免本机留下失效链接。
      const prev = getScriptRemoteResource(script)
      updateScriptRemoteResource(script, url, prev?.hash ?? "", 3600)
      try {
        await FileManager.zip(script.path, zipPath, true)
        await githubPushZip(
          config.token,
          config.owner,
          config.repo,
          config.branch,
          dir,
          remotePath,
          zipPath,
          skipBranch
        )
      } catch (error) {
        if (prev) {
          // 严格恢复原状：interval 原来没有就不补，避免失败回滚把开关打开
          updateScriptRemoteResource(script, prev.url, prev.hash ?? "", prev.autoUpdateInterval)
        } else {
          // 之前没有更新链接：彻底移除，恢复原状（不留失效链接）
          clearScriptRemoteResource(script)
        }
        throw error
      }
      // 上传成功后，把本机 script.json 的 hash 修正为本次 zip 的真实 MD5；
      // interval 沿用发布前的状态（之前没开自动更新就不开），避免“突然自动打开开关”。
      // 注意：zip 在打包时已内嵌 autoUpdateInterval=3600，下载方导入后自动更新默认开启。
      const hash = zipMd5(zipPath)
      updateScriptRemoteResource(script, url, hash, prev?.autoUpdateInterval)
      results.push({ folderName: script.folderName, url, zipPath })
    }
    return results
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

/**
 * 列出 GitHub 私密备份仓库 backupPath 目录下的所有 zip 备份文件。
 * 通过 Contents API 读取目录列表，仅返回 .zip 文件，按名称倒序。
 */
export async function listGithubBackups(
  config: GithubConfig
): Promise<{ name: string; path: string; size: number }[]> {
  if (!isGithubBackupConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 备份配置（Token/所有者/备份仓库名）")
  }
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const dir = config.backupPath.trim().replace(/^\/+|\/+$/g, "")
  const url = dir
    ? `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${dir
        .split("/")
        .map(encodeURIComponent)
        .join("/")}`
    : `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents`
  const res = await githubHttp(url, { headers })
  if (res.status !== 200) {
    throw new Error(
      `读取备份仓库失败 (${res.status}): ${res.data?.message || res.text || ""}`
    )
  }
  const list = Array.isArray(res.data) ? res.data : []
  return list
    .filter(
      (item: any) =>
        item &&
        item.type === "file" &&
        item.name &&
        (item.name.toLowerCase().endsWith(".zip") ||
          item.name.toLowerCase().endsWith(".scripting"))
    )
    .map((item: any) => ({
      name: item.name as string,
      path: item.path as string,
      size: (item.size as number) || 0,
    }))
    .sort((a, b) => b.name.localeCompare(a.name))
}

/**
 * 备份按时间倒序（最新备份在最上面）：
 * 优先取 manifest 记录的上传时间；没有记录时尝试解析文件名里的 YYYYMMDD_HHMMSS 时间编号；
 * 都拿不到就回退到按名称倒序（与 listGithubBackups 默认一致）。
 */
export function sortGithubBackupsByTime(
  list: { name: string; path: string; size: number }[],
  manifest: GithubBackupManifest | null
): { name: string; path: string; size: number }[] {
  function timeOf(item: { name: string; path: string }): number {
    const meta = manifest?.backups[item.path]
    if (meta && typeof meta.createdAt === "number" && Number.isFinite(meta.createdAt)) {
      return meta.createdAt
    }
    // 文件名中的 YYYYMMDD_HHMMSS 时间编号（timestampForName 格式，如 前缀_20260814_041023）
    const m = item.name.match(/(\d{8})_(\d{6})/)
    if (m) {
      const day = m[1]
      const time = m[2]
      const ts = new Date(
        Number(day.slice(0, 4)),
        Number(day.slice(4, 6)) - 1,
        Number(day.slice(6, 8)),
        Number(time.slice(0, 2)),
        Number(time.slice(2, 4)),
        Number(time.slice(4, 6))
      ).getTime()
      if (!Number.isNaN(ts)) {
        return ts
      }
    }
    return 0
  }
  return [...list].sort((a, b) => {
    const ta = timeOf(a)
    const tb = timeOf(b)
    if (ta !== tb) {
      return tb - ta
    }
    return b.name.localeCompare(a.name)
  })
}

/**
 * 从 GitHub 私密备份仓库下载指定 zip 到临时目录，返回本地 zip 路径。
 * 私有仓库的 raw.githubusercontent.com 不接受 Authorization，
 * 改用 Contents API + Accept: application/vnd.github.raw 获取原始内容。
 */
export async function downloadGithubBackup(
  config: GithubConfig,
  remotePath: string
): Promise<string> {
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github.raw",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${remotePath
    .split("/")
    .map(encodeURIComponent)
    .join("/")}`
  const res = await fetch(url, { headers })
  if (!res.ok) {
    throw new Error(`下载备份失败 (${res.status}): ${remotePath}`)
  }
  const bytes = await res.bytes()
  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-restore-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const localPath = Path.join(staging, Path.basename(remotePath) || "backup.zip")
  FileManager.writeAsBytesSync(localPath, bytes)
  return localPath
}

/**
 * 删除 GitHub 备份仓库中的指定 zip（通过 Contents API）。
 */
export async function deleteGithubBackup(
  config: GithubConfig,
  remotePath: string
): Promise<void> {
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${remotePath
    .split("/")
    .map(encodeURIComponent)
    .join("/")}`
  const get = await githubHttp(url, { headers })
  if (get.status !== 200) {
    throw new Error(
      `读取待删除文件失败 (${get.status}): ${get.data?.message || get.text || ""}`
    )
  }
  const sha = get.data?.sha as string
  if (!sha) {
    throw new Error("无法获取文件 sha，删除失败")
  }
  const del = await githubHttp(url, {
    method: "DELETE",
    headers,
    body: JSON.stringify({ message: "删除备份", sha }),
  })
  if (del.status !== 200) {
    throw new Error(
      `删除失败 (${del.status}): ${del.data?.message || del.text || ""}`
    )
  }
  // 同步从 manifest 移除条目（失败不影响删除本身）
  try {
    await removeFromGithubBackupManifest(config, remotePath)
  } catch (e) {
    logError("Github备份元数据", e)
  }
}

/**
 * 下载一个或多个 GitHub 备份 zip 到临时目录并调起系统分享面板，完成后清理临时目录。
 */
export async function shareGithubBackups(
  config: GithubConfig,
  items: { name: string; path: string; size: number }[]
): Promise<void> {
  if (items.length === 0) {
    return
  }
  const downloaded: string[] = []
  try {
    for (const item of items) {
      downloaded.push(await downloadGithubBackup(config, item.path))
    }
    await ShareSheet.present(downloaded)
  } finally {
    for (const zipPath of downloaded) {
      const dir = Path.dirname(zipPath)
      if (pathExists(dir)) {
        try {
          FileManager.removeSync(dir)
        } catch {
          // ignore
        }
      }
    }
  }
}

/**
 * 重命名 GitHub 备份 zip：下载旧文件 → 上传到新路径 → 删除旧路径 → 迁移 manifest 条目。
 * GitHub Contents API 没有 rename 接口，因此用「下载-上传-删除」实现。
 */
export async function renameGithubBackup(
  config: GithubConfig,
  item: { name: string; path: string; size: number },
  newName: string
): Promise<void> {
  if (!isGithubBackupConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 备份配置（Token/所有者/备份仓库名）")
  }
  const clean = newName.trim()
  if (!clean) {
    throw new Error("名称不能为空")
  }
  if (/[\/\\:]/.test(clean)) {
    throw new Error("名称不能包含 / \\ : 字符")
  }
  const safe = safeFileName(clean) || "备份"
  const ext = item.name.toLowerCase().endsWith(".scripting") ? ".scripting" : ".zip"
  const dir = config.backupPath.trim().replace(/^\/+|\/+$/g, "")
  const newRemotePath = dir ? `${dir}/${safe}${ext}` : `${safe}${ext}`
  if (newRemotePath === item.path) {
    return
  }
  // 先确认新路径不存在（防止覆盖已有备份）
  const existing = await listGithubBackups(config)
  if (existing.some((b) => b.path === newRemotePath)) {
    throw new Error(`已存在同名备份「${clean}」`)
  }
  // 保留旧 manifest 条目的脚本数与创建时间，重命名后迁移到新路径
  const manifest = await readGithubBackupManifest(config)
  const oldMeta = manifest?.backups[item.path]

  const zipPath = await downloadGithubBackup(config, item.path)
  try {
    const repoState = await ensureGithubRepo(config.token, config.owner, config.backupRepo, true)
    const skipBranch = !repoState.confirmed || repoState.empty
    await githubPushZip(
      config.token,
      config.owner,
      config.backupRepo,
      config.backupBranch,
      dir,
      newRemotePath,
      zipPath,
      skipBranch
    )
    // 删除旧文件（内部会自动移除旧 manifest 条目）
    await deleteGithubBackup(config, item.path)
    // 若有旧元数据，写入新路径（脚本数/创建时间保持不变）
    if (oldMeta) {
      try {
        await updateGithubBackupManifest(
          config,
          newRemotePath,
          `${safe}${ext}`,
          oldMeta.scriptCount,
          oldMeta.createdAt
        )
      } catch (e) {
        logError("Github备份元数据", e)
      }
    }
  } finally {
    const dirPath = Path.dirname(zipPath)
    if (pathExists(dirPath)) {
      try {
        FileManager.removeSync(dirPath)
      } catch {
        // ignore
      }
    }
  }
}

/**
 * 把选中的脚本备份到 GitHub 私密备份仓库：单个脚本打包为 `.scripting`，多个脚本打包为一个 zip 上传（不更新 remoteResource）。
 * 备份仓库不存在时自动创建（私密）。返回 zip 的 raw 链接。
 */
export async function backupScriptsToGithub(
  scripts: ScriptInfo[],
  config: GithubConfig,
  zipName: string
): Promise<{ name: string; url: string; zipPath: string }> {
  if (!isGithubBackupConfigured(config)) {
    throw new Error("请先在设置中填写 GitHub 备份配置（Token/所有者/备份仓库名）")
  }
  // 首次使用自动创建备份仓库（私密）；拿到仓库状态
  const repoState = await ensureGithubRepo(config.token, config.owner, config.backupRepo, true)
  const skipBranch = !repoState.confirmed || repoState.empty

  const staging = Path.join(
    FileManager.temporaryDirectory,
    `github-backup-${Date.now()}`
  )
  FileManager.createDirectorySync(staging, true)
  const safe = safeFileName(zipName) || "GitHub备份"
  const ext = scripts.length === 1 ? ".scripting" : ".zip"
  const zipPath = Path.join(staging, `${safe}${ext}`)
  try {
    if (scripts.length === 1) {
      await FileManager.zip(scripts[0].path, zipPath, true)
    } else {
      const inner = Path.join(staging, "scripts")
      FileManager.createDirectorySync(inner, true)
      for (const script of scripts) {
        copyDirectory(script.path, Path.join(inner, script.folderName))
      }
      await FileManager.zip(inner, zipPath, false)
    }
    const dir = config.backupPath.trim().replace(/^\/+|\/+$/g, "")
    const remotePath = dir ? `${dir}/${safe}${ext}` : `${safe}${ext}`
    const url = await githubPushZip(
      config.token,
      config.owner,
      config.backupRepo,
      config.backupBranch,
      dir,
      remotePath,
      zipPath,
      skipBranch
    )
    // 备份成功后把脚本数与时间写入仓库根目录的 manifest（失败不影响备份本身）
    try {
      await updateGithubBackupManifest(
        config,
        remotePath,
        `${safe}${ext}`,
        scripts.length,
        Date.now()
      )
    } catch (e) {
      logError("Github备份元数据", e)
    }
    return { name: safe, url, zipPath }
  } finally {
    if (pathExists(staging)) {
      FileManager.removeSync(staging)
    }
  }
}

// ==================== GitHub 备份元数据（manifest） ====================
// 在备份仓库根目录维护一个隐藏文件 .script-manager-meta.json，
// 记录每个备份 zip 的脚本数与备份时间；恢复页直接读取它，避免逐个下载统计。

export type GithubBackupMeta = {
  name: string
  path: string
  scriptCount: number
  createdAt: number
}

export type GithubBackupManifest = {
  updatedAt: number
  backups: Record<string, GithubBackupMeta>
}

const GITHUB_MANIFEST_NAME = ".script-manager-meta.json"

/** UTF-8 字符串 → base64（manifest 内容小，自己编码避免依赖 Data.fromFile 的文件缓存） */
function utf8ToBase64(str: string): string {
  const bytes: number[] = []
  for (let i = 0; i < str.length; i++) {
    let code = str.codePointAt(i)!
    if (code > 0xffff) i++
    if (code < 0x80) bytes.push(code)
    else if (code < 0x800)
      bytes.push(0xc0 | (code >> 6), 0x80 | (code & 63))
    else if (code < 0x10000)
      bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63))
    else
      bytes.push(
        0xf0 | (code >> 18),
        0x80 | ((code >> 12) & 63),
        0x80 | ((code >> 6) & 63),
        0x80 | (code & 63)
      )
  }
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  let out = ""
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i]
    const b1 = bytes[i + 1]
    const b2 = bytes[i + 2]
    out += chars[b0 >> 2]
    out += chars[((b0 & 3) << 4) | (b1 !== undefined ? b1 >> 4 : 0)]
    out += b1 !== undefined ? chars[((b1 & 15) << 2) | (b2 !== undefined ? b2 >> 6 : 0)] : "="
    out += b2 !== undefined ? chars[b2 & 63] : "="
  }
  return out
}

/** 读取远端 manifest（不存在或解析失败返回 null）。URL 带时间戳参数避免 fetch/HTTP 缓存返回旧内容 */
export async function readGithubBackupManifest(
  config: GithubConfig
): Promise<GithubBackupManifest | null> {
  if (!isGithubBackupConfigured(config)) {
    return null
  }
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github.raw",
    "X-GitHub-Api-Version": "2022-11-28",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${GITHUB_MANIFEST_NAME}?ts=${Date.now()}`
  // GitHub 最终一致性：PUT 后立即 GET 可能短暂 404/旧内容，404 时重试
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await githubHttp(url, { headers })
    if (res.status === 404) {
      if (attempt < 2) {
        await new Promise<void>((resolve) => setTimeout(() => resolve(), 400))
        continue
      }
      return null
    }
    if (res.status !== 200) {
      return null
    }
    try {
      return JSON.parse(res.text) as GithubBackupManifest
    } catch {
      return null
    }
  }
  return null
}

/** 把 manifest 写入仓库根目录（自编码 base64 + Contents API PUT，不依赖临时文件读取） */
async function writeGithubBackupManifest(
  config: GithubConfig,
  manifest: GithubBackupManifest
): Promise<void> {
  const headers = {
    Authorization: `Bearer ${config.token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "Content-Type": "application/json",
  }
  const url = `https://api.github.com/repos/${config.owner}/${config.backupRepo}/contents/${GITHUB_MANIFEST_NAME}`

  // 先 GET 拿 sha（文件存在才能覆盖）；URL 带时间戳避免 fetch 缓存返回旧 sha
  let sha: string | undefined
  const existing = await githubHttp(`${url}?ts=${Date.now()}`, { headers })
  if (existing.status === 200 && existing.data?.sha) {
    sha = existing.data.sha
  }

  const body: any = {
    message: sha ? "Update backup metadata" : "Add backup metadata",
    content: utf8ToBase64(JSON.stringify(manifest)),
  }
  if (sha) {
    body.sha = sha
  }
  // 仓库可能为空时不能带 branch（GitHub 会自动创建默认分支）
  const repoState = await ensureGithubRepo(
    config.token,
    config.owner,
    config.backupRepo,
    true
  )
  const skipBranch = !repoState.confirmed || repoState.empty
  if (!skipBranch && config.backupBranch.trim()) {
    body.branch = config.backupBranch.trim()
  }

  const { status, data } = await githubHttp(url, {
    method: "PUT",
    headers,
    body: JSON.stringify(body),
  })
  if (status !== 200 && status !== 201) {
    throw new Error(`写入备份元数据失败 (${status}): ${data?.message || ""}`)
  }
  // GitHub 最终一致性：等待写入传播，避免紧接着的读取拿到旧内容
  await new Promise<void>((resolve) => setTimeout(() => resolve(), 1000))
}

/** 备份上传成功后，把 zip 的脚本数与时间写入 manifest */
export async function updateGithubBackupManifest(
  config: GithubConfig,
  remotePath: string,
  name: string,
  scriptCount: number,
  createdAt: number
): Promise<void> {
  const manifest =
    (await readGithubBackupManifest(config)) || {
      updatedAt: Date.now(),
      backups: {},
    }
  manifest.backups[remotePath] = { name, path: remotePath, scriptCount, createdAt }
  manifest.updatedAt = Date.now()
  await writeGithubBackupManifest(config, manifest)
}

/** 删除备份后，把对应条目从 manifest 移除 */
export async function removeFromGithubBackupManifest(
  config: GithubConfig,
  remotePath: string
): Promise<void> {
  const manifest = await readGithubBackupManifest(config)
  if (!manifest || !manifest.backups[remotePath]) {
    return
  }
  delete manifest.backups[remotePath]
  manifest.updatedAt = Date.now()
  await writeGithubBackupManifest(config, manifest)
}

// ==================== 错误日志 ====================

const ERROR_LOG_PATH = Path.join(
  FileManager.appGroupDocumentsDirectory,
  "script-manager-errors.json"
)

/** 单条错误日志 */
export type ErrorLogItem = {
  /** 时间戳（ms） */
  time: number
  /** 操作名，如「Github备份」「Github发布」「本地备份」 */
  operation: string
  /** 错误信息 */
  message: string
}

const MAX_ERROR_LOGS = 50

/** 记录一条错误日志（追加到本地文件，最多保留 50 条） */
export function logError(operation: string, error: unknown): void {
  try {
    const message = error instanceof Error ? error.message : String(error)
    const logs = resolveErrorLogs()
    logs.unshift({
      time: Date.now(),
      operation,
      message,
    })
    const trimmed = logs.slice(0, MAX_ERROR_LOGS)
    FileManager.writeAsStringSync(
      ERROR_LOG_PATH,
      JSON.stringify(trimmed, null, 2)
    )
  } catch {
    // 日志记录失败不影响主流程
  }
}

/** 读取全部错误日志（最新的在前） */
export function resolveErrorLogs(): ErrorLogItem[] {
  if (!pathExists(ERROR_LOG_PATH)) {
    return []
  }
  try {
    const raw = JSON.parse(FileManager.readAsStringSync(ERROR_LOG_PATH))
    if (!Array.isArray(raw)) {
      return []
    }
    return raw
      .filter(
        (item): item is ErrorLogItem =>
          typeof item === "object" &&
          item !== null &&
          typeof item.time === "number" &&
          typeof item.operation === "string" &&
          typeof item.message === "string"
      )
      .sort((a, b) => b.time - a.time)
  } catch {
    return []
  }
}

/** 清空全部错误日志 */
export function clearErrorLogs(): void {
  try {
    if (pathExists(ERROR_LOG_PATH)) {
      FileManager.removeSync(ERROR_LOG_PATH)
    }
  } catch {
    // ignore
  }
}
