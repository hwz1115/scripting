// ==================== 语言模块（中文 / English，默认中文） ====================
// t(): 静态文案；tpl(): 模板文案（{name} 占位）。
// 词典未收录的词条回退中文，可随时补充。

let currentLang: "zh" | "en" = "zh"
let listeners: Array<() => void> = []

export function getLanguage(): "zh" | "en" {
  return currentLang
}

export function setLanguage(lang: "zh" | "en") {
  if (currentLang === lang) {
    return
  }
  currentLang = lang
  listeners.forEach((cb) => cb())
}

/** 订阅语言变化（返回取消订阅函数） */
export function subscribeLanguageChange(cb: () => void): () => void {
  listeners.push(cb)
  return () => {
    listeners = listeners.filter((x) => x !== cb)
  }
}

/** 静态文案：中文原串 → 当前语言 */
export function t(zh: string): string {
  return currentLang === "en" ? (EN[zh] ?? zh) : zh
}

/** 模板文案：{name} 占位，values 提供实际值 */
export function tpl(zh: string, values: Record<string, string>): string {
  const tplStr = currentLang === "en" ? (EN[zh] ?? zh) : zh
  return tplStr.replace(/\{(\w+)\}/g, (_, k) =>
    Object.prototype.hasOwnProperty.call(values, k) ? values[k] : ""
  )
}

const EN: Record<string, string> = {
  // ---- 通用 ----
  "取消": "Cancel",
  "删除": "Delete",
  "分享": "Share",
  "恢复": "Restore",
  "默认": "Default",
  "全部": "All",
  "不再更新": "Stop Updating",
  "忽略本次": "Ignore This Batch",
  "更新选中": "Update Selected",
  "已忽略本次更新，不再提示": "Ignored this batch, no more prompts",
  "完成": "Done",
  "选择": "Select",
  "刷新": "Refresh",
  "更新说明": "Release notes",
  "版本": "Version",
  "填写本次更新的说明（可留空，将随发布包分发，更新到新版本的设备可查看）": "Describe this update (optional; it ships with the release package and is viewable on devices that update)",
  "例如：新增云端同步标识、修复自动备份…": "e.g. Added cloud sync badge, fixed auto backup…",
  "填写本次更新的说明，将随发布包分发；更新到新版本的设备首次运行时会自动弹出。": "Describe this update; it ships with the release package and auto-pops on first run after updating.",
  "填写本次更新的说明（可留空）": "Describe this update (optional)",
  "填写本次更新说明，可换行编排格式…": "Write release notes here, use line breaks to format…",
  "更新说明为空": "Empty release notes",
  "本次更新说明留空了：要保留上次发布的说明，还是本次不显示更新说明？": "You left the release notes empty: keep the previous notes, or hide release notes for this update?",
  "保留上次更新说明": "Keep previous notes",
  "不显示更新说明": "Hide release notes",
  "清空": "Clear",
  "{name} 更新后首次运行会自动弹出此说明": "This note auto-pops on first run after {name} updates",
  "关闭": "Close",
  "备份": "Backup",
  "发布": "Publish",
  "未知": "Unknown",
  "重命名": "Rename",
  "设置": "Settings",
  "所有设置修改后自动保存，无需手动保存": "All settings are saved automatically — no manual save needed",
  "保存失败": "Failed to save",
  "确认": "Confirm",
  "确定": "OK",

  // ---- 首页脚本菜单 ----
  "改版本号": "Edit version",
  "移动分组": "Move to group",
  "重新命名": "Rename",
  "脚本发布": "Publish script",
  "脚本备份": "Backup script",
  "分享链接": "Share link",
  "分享文件": "Share file",
  "已置顶": "Pinned",
  "已取消置顶": "Unpinned",
  "已删除": "Deleted",
  "已重命名": "Renamed",
  "版本号已更新": "Version updated",

  // ---- 菜单 / 弹窗 ----
  "该脚本开启了自动更新": "This script has auto-update enabled",
  "直接修改": "Change anyway",
  "修改并关闭自动更新": "Change & disable auto-update",
  "修改的版本号会保留到下一次应用云端更新为止（应用后版本号会被替换为云端版本）。":
    "Your edited version is kept until the next cloud update is applied (after which it is replaced by the cloud version).",
  "也可以选择同时关闭自动更新（保留更新链接，之后可重新开启），避免后续被云端覆盖。":
    "You can also disable auto-update (the update link is kept and can be re-enabled later) to avoid being overwritten by the cloud.",
  "恢复脚本": "Restore script",
  "覆盖并恢复": "Overwrite & restore",
  "删除确认": "Confirm delete",
  "请先勾选脚本": "Please select scripts first",
  "请先选择脚本": "Please select scripts first",
  "没有可移动的分组": "No groups to move to",
  "移动到分组": "Move to group",
  "没有可移动的脚本": "No scripts to move",
  "没有可备份的脚本": "No scripts to back up",
  "临时备份": "Temporary backup",
  "重命名脚本": "Rename script",
  "输入新的脚本名称": "Enter the new script name",
  "该脚本没有发布链接，请先发布": "This script has no publish link, please publish it first",
  "导入链接已复制": "Import link copied",
  "修改版本号": "Edit version",
  "输入新的版本号（格式 x.y.z，例如 1.0.1）": "Enter a new version (format x.y.z, e.g. 1.0.1)",
  "iCloud 不可用，请先在系统设置中登录 iCloud 并授权 Scripting":
    "iCloud is unavailable. Please sign in to iCloud in System Settings and authorize Scripting",
  "请在设置中勾选「Github发布」以使用此功能": 'Enable "GitHub Publish" in Settings to use this feature',
  "该分组没有可备份的脚本": "This group has no scripts to back up",
  "请先到右上角「设置」配置 GitHub 发布（Token/所有者/仓库名）":
    "Please configure GitHub Publish in Settings (Token / Owner / Repo)",
  "请等待上个脚本发布成功，或者去 Github 发布页面使用长按多选发布":
    "Wait for the current publish to finish, or long-press to multi-select on the GitHub publish page",
  "请先到右上角「设置」配置 GitHub 备份（Token/所有者/备份仓库名）":
    "Please configure GitHub Backup in Settings (Token / Owner / Backup repo)",
  "GitHub 发布完成:": "GitHub publish done:",
  "备份名称": "Backup name",
  "单个脚本备份为 .scripting 格式上传到 GitHub 私密仓库，默认使用「脚本名+版本号」":
    "A single script is uploaded to the private GitHub repo as .scripting, named \u201cScript name + version\u201d by default",
  "请先选择要备份的脚本": "Please choose scripts to back up first",
  "请先选择要备份的分组": "Please choose a group to back up first",
  "单个备份默认使用「脚本名+版本号」":
    "A single backup uses \u201cScript name + version\u201d by default",
  "所选文件中没有找到脚本（缺少 script.json）":
    "No script found in the selected file (missing script.json)",
  "已恢复": "Restored",
  "未配置，请在设置中填写 GitHub 发布参数":
    "Not configured, please fill in the GitHub Publish settings",
  "未配置，请在设置中填写 GitHub 备份参数":
    "Not configured, please fill in the GitHub Backup settings",
  "备份到": "Backup to",
  "备份范围": "Backup scope",
  "正在发布…": "Publishing\u2026",
  "正在备份…": "Backing up\u2026",
  "开始发布": "Start publishing",
  "开始备份": "Start backup",
  "从 GitHub 私密备份仓库下载 .scripting 恢复脚本":
    "Restore scripts from the private GitHub backup repo (.scripting)",
  "从备份目录或外部 .scripting 文件恢复脚本":
    "Restore scripts from the backup folder or an external .scripting file",
  "Github备份仓库": "GitHub Backup repo",
  "按名称 A-Z": "By name A-Z",
  "按名称 Z-A": "By name Z-A",
  "按最新修改": "Latest modified",
  "搜索脚本名": "Search script name",
  "正在加载脚本…": "Loading scripts\u2026",
  "请先填写 GitHub Token": "Please enter a GitHub Token first",
  "验证中…": "Verifying\u2026",
  "验证 Token": "Verify Token",
  "Token（备份）": "Token (Backup)",
  "仓库所有者（备份）": "Repo owner (Backup)",
  "如 vvvvvveng": "e.g. vvvvvveng",
  "备份仓库名（必填）": "Backup repo name (required)",
  "如 scripting-backups": "e.g. scripting-backups",
  "备份分支": "Backup branch",
  "仓库内目录": "Folder in repo",
  "留空为根目录，如 backups": "Leave empty for root, e.g. backups",
  "Token（发布）": "Token (Publish)",
  "仓库所有者（发布）": "Repo owner (Publish)",
  "发布仓库名（必填）": "Publish repo name (required)",
  "如 scripting-releases": "e.g. scripting-releases",
  "发布分支": "Publish branch",
  "留空为根目录，如 releases": "Leave empty for root, e.g. releases",
  "Github备份": "GH Backup",
  "Github发布": "GH Publish",
  "GitHub 备份": "GitHub Backup",
  "GitHub 发布": "GitHub Publish",
  "记住展开状态": "Remember expanded state",
  "搜索不隐藏其他脚本": "Keep other scripts visible when searching",
  "自动备份升级项": "Auto backup upgrades",
  "检测到脚本版本变化后，先刷新脚本内容，内容稳定后才自动备份到 iPhone 端，避免备份到旧内容": "When a script version changes, refresh its content first and back up to iPhone only after the content is stable (avoids backing up stale content)",
  "检测到 {n} 个脚本版本变化，正在刷新内容…": "Detected version changes in {n} scripts, refreshing content…",
  "检测到 {n} 个脚本版本变化，自动备份中…": "Detected version changes in {n} scripts, auto backing up…",
  "自动备份": "Auto backup",
  "自动备份_{stamp}": "AutoBackup_{stamp}",
  "已自动备份 {n} 个脚本到 iPhone": "Auto backed up {n} scripts to iPhone",
  "暂无错误记录": "No error logs",
  "已清空错误记录": "Error logs cleared",
  "选择分组": "Choose group",
  "没有可备份的分组": "No groups to back up",
  "请至少选择一个脚本": "Please select at least one script",
  "选择要发布的脚本": "Choose scripts to publish",
  "选择要备份的脚本": "Choose scripts to back up",
  "取消全选": "Deselect all",
  "全选": "Select all",
  "未找到匹配的脚本": "No matching scripts found",
  "请先选择要删除的备份": "Please select backups to delete first",
  "删除备份": "Delete backups",
  "删除失败": "Delete failed",
  "请先选择要分享的备份": "Please select backups to share first",
  "请先选择要重命名的备份": "Please select a backup to rename first",
  "重命名仅支持单选备份": "Rename only supports a single backup",
  "重命名备份": "Rename backup",
  "输入新的备份名称": "Enter the new backup name",
  "无法读取该备份": "Cannot read this backup",
  "该备份中没有找到脚本（缺少 script.json）":
    "No script found in this backup (missing script.json)",
  "恢复备份": "Restore backup",
  "搜索备份": "Search backups",
  "正在读取备份…": "Reading backups\u2026",
  "暂无备份，先到首页开始备份吧": "No backups yet, start backing up from the home page",
  "统计中…": "Counting\u2026",
  "加载中…": "Loading\u2026",
  "正在读取备份仓库…": "Reading backup repo\u2026",
  "备份仓库里暂无备份，先到首页开始备份吧":
    "No backups in the repo yet, start backing up from the home page",
  "请先选择要恢复的脚本": "Please choose scripts to restore first",
  "覆盖确认": "Overwrite confirmation",
  "选择要恢复的脚本": "Choose scripts to restore",
  "恢复中…": "Restoring\u2026",
  "没有找到脚本": "No scripts found",
  "移动到其他分组": "Move to another group",
  "移到其他分组": "Move to another group",
  "分享(链接)": "Share (link)",
  "分享(文件)": "Share (file)",
  "脚本管理": "Script management",
  "勾选脚本后可用下方按钮批量删除/分享":
    "After checking scripts, use the buttons below to delete / share in batch",
  "点击脚本可重命名、分享、修改版本号或删除":
    "Tap a script to rename, share, edit its version or delete it",

  // ---- 裸文本节点 ----
  "最新": "Latest",
  "名称": "Name",
  "分组": "Group",
  "从文件恢复": "Restore from file",
  "注：": "Note:",
  "②双击单项快速置顶，再次双击取消置顶": "Double-tap a row to pin, double-tap again to unpin",
  "④长按任意脚本可多选备份、分享、移动或删除":
    "Long-press any script to multi-select backup, share, move or delete",
  "①单击行弹出菜单（删除/版本号/移动分组/重命名/备份/分享）":
    "Tap a row to open the menu (Delete / Version / Move group / Rename / Backup / Share)",
  "③点击右侧按钮(三角图标)直接运行该脚本":
    "Tap the right button (triangle icon) to run the script directly",
  "⑤搜索时匹配的脚本排在前面；默认不隐藏其他脚本（设置里可关闭，关闭后只显示匹配项）":
    "When searching, matched scripts come first; others stay visible by default (can be turned off in Settings to show matches only)",
  "通用": "General",
  "反馈": "Feedback",
  "错误记录": "Error logs",
  "清空错误记录": "Clear error logs",
  "脚本分组": "Script groups",
  "批量操作": "Batch actions",
  "脚本列表": "Script list",
  "暂无备份": "No backups yet",

  // ---- 模板词条（tpl，{name} 占位） ----
  "「{name}」配置了远程自动更新（约每 {interval} 秒检查一次）。":
    "\u201c{name}\u201d is configured with remote auto-update (checks about every {interval} seconds).",
  "将恢复脚本「{name}」，目录中已存在同名脚本，恢复会覆盖当前版本。":
    "Restoring \u201c{name}\u201d. A script with the same name already exists, restoring will overwrite the current version.",
  "将恢复脚本「{name}」到 Scripting 脚本目录。":
    "Restoring \u201c{name}\u201d to the Scripting scripts directory.",
  "版本 {v} · {date} · {size} · 分组 {group}":
    "Version {v} \u00b7 {date} \u00b7 {size} \u00b7 Group {group}",
  "确定删除 {n} 个脚本？此操作不可恢复。":
    "Delete {n} scripts? This cannot be undone.",
  "确定删除「{name}」？此操作不可恢复。":
    "Delete \u201c{name}\u201d? This cannot be undone.",
  "把勾选的 {n} 个脚本移动到哪个分组？":
    "Move the selected {n} scripts to which group?",
  "把「{name}」移动到哪个分组？":
    "Move \u201c{name}\u201d to which group?",
  "已移动 {n} 个脚本到「{group}」":
    "Moved {n} scripts to \u201c{group}\u201d",
  "已移动到「{group}」": "Moved to \u201c{group}\u201d",
  "将 {n} 个脚本打包为 .scripting 上传到 {repo}（仓库不存在将自动创建，默认公开），并更新每个脚本的远程更新链接（remoteResource），其他设备即可通过该链接拉取新版本。":
    "Pack {n} scripts into .scripting and upload to {repo} (the repo is auto-created as public if missing), and update each script's remote update link (remoteResource) so other devices can pull the new version.",
  "已发布 {n} 个脚本并同步更新链接，更新链接已复制":
    "Published {n} scripts and updated their links; the update link has been copied",
  "将 {n} 个脚本打包为一个 zip 上传到 GitHub 私密仓库，默认命名为「{name}+时间编号」":
    "Pack {n} scripts into a zip and upload to the private GitHub repo, named \u201c{name}+time number\u201d by default",
  "脚本备份_{stamp}": "Script backup_{stamp}",
  "将 {n} 个脚本打包为一个 zip 上传到 GitHub 私密仓库":
    "Pack {n} scripts into a zip and upload to the private GitHub repo",
  "已备份 {n} 个脚本到 {repo}": "Backed up {n} scripts to {repo}",
  "将 {n} 个脚本打包为一个 zip 上传到 iPhone/iCloud，默认命名为「分组名+时间编号」":
    "Pack {n} scripts into a zip and upload to iPhone/iCloud, named \u201cGroup name + time number\u201d by default",
  "将 {n} 个脚本打包为一个 zip 上传到 iPhone/iCloud，留空则命名为「{base}_时间码」":
    "Pack {n} scripts into a zip and upload to iPhone/iCloud; leave empty to name it \u201c{base}_time code\u201d",
  "已备份 {n} 个脚本": "Backed up {n} scripts",
  "已恢复 {n} 个脚本": "Restored {n} scripts",
  "发布到仓库：{pub}（{branch} 分支，公开，可自动创建）":
    "Publish to repo: {pub} ({branch} branch, public, auto-create allowed)",
  "备份到仓库：{backup}（{branch} 分支，私密，可自动创建）":
    "Backup to repo: {backup} ({branch} branch, private, auto-create allowed)",
  "{n} 个备份": "{n} backups",
  "Token 有效：@{login}": "Token valid: @{login}",
  "确定删除 {n} 个备份？此操作不可恢复。":
    "Delete {n} backups? This cannot be undone.",
  "确定删除 {n} 个远端备份？此操作不可恢复。":
    "Delete {n} remote backups? This cannot be undone.",
  "已删除 {n} 个备份": "Deleted {n} backups",
  "{n} 个脚本": "{n} scripts",
  "正在下载 {name}…": "Downloading {name}\u2026",
  "仓库目录：{dir}（{repo}）": "Repo folder: {dir} ({repo})",
  "仓库：{repo}": "Repo: {repo}",
  "以下 {n} 个脚本已存在，恢复将覆盖当前版本：\n{names}":
    "The following {n} scripts already exist; restoring will overwrite the current versions:\n{names}",
  "恢复 ({n})": "Restore ({n})",
  " · 未知": " \u00b7 Unknown",
  " · {group}": " \u00b7 {group}",
  " · 默认": " \u00b7 Default",

  // ---- JSX 混合文本（tpl） ----
  "脚本管理（{n}）": "Scripts ({n})",
  "脚本列表（共 {n} 个脚本）": "Script list ({n} total)",
  "脚本列表（{n}）": "Script list ({n})",
  "备份目录：{dir}": "Backup folder: {dir}",
  "备份列表（共 {n} 个）": "Backup list ({n} total)",
  "这个备份里有 {n} 个脚本": "This backup contains {n} scripts",
  "这个备份里有 {n} 个候选": "This backup contains {n} candidates",

  // ---- 界面操作注释 / 说明文字 ----
  "返回": "Back",
  "移动": "Move",
  "⑥点击左上角按钮可隐藏备份相关板块":
    "\u2466 Tap the button at the top-left to hide the backup sections",
  "⑦自己已发布到仓库的脚本会有绿色勾标；本地与云端版本不同步时显示橙色警示标":
    "\u2467 Scripts you've published to a repo show a green checkmark; when the local version differs from the cloud, an orange warning badge appears",
  "⑧该脚本若被固定到首页，更新后有些功能可能需要长按主页按钮并点击重新加载才会生效":
    "\u2468 If this script is pinned to the home screen, some features after an update may require long-pressing the home button and tapping Reload to take effect",
  "首页「备份到 → Github备份」把脚本打包为 zip 上传到私密备份仓库，仅用于备份，不影响脚本更新链接。备份仓库不存在时会自动创建，默认私密。备份 Token 与所有者可独立于发布设置；若留空则自动沿用发布账号":
    "On Home, \u201cBack up to \u2192 GitHub Backup\u201d packages scripts as a zip uploaded to a private backup repo \u2014 backup only, doesn't affect update links. The repo is auto-created if missing (private by default). Backup token & owner can differ from publish settings; leave empty to reuse the publish account",
  "填 GitHub 个人访问令牌。获取：GitHub 网页 → 右上角头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限 → 生成后复制 ghp_… 粘贴到这里。备份可用独立 Token（与发布不同账号）；留空自动沿用发布 Token":
    "Enter a GitHub personal access token. Get one: GitHub \u2192 avatar (top-right) \u2192 Settings \u2192 Developer settings \u2192 Personal access tokens \u2192 Tokens (classic) \u2192 Generate new token \u2192 check the repo scope \u2192 copy the ghp_\u2026 token here. Backup can use its own token (different account); leave empty to reuse the publish token",
  "备份仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。备份可用独立所有者（不同账号）；留空自动沿用发布所有者":
    "Repo owner \u2014 your GitHub username or org, the \u201cowner\u201d part of github.com/owner/repo. Backup can use its own owner (different account); leave empty to reuse the publish owner",
  "必填：存放备份 zip 的仓库名（私密）。若不存在，首次备份时会自动创建私密仓库，其他人不可见":
    "Required: name of the repo (private) that stores the backup zip. If missing, a private repo is auto-created on first backup \u2014 invisible to others",
  "备份到的分支，一般用默认的 main，留空自动填 main":
    "Branch to back up to. Use main by default; leave empty to auto-fill main",
  "备份 zip 放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 backups":
    "Which folder in the repo holds the backup zip; leave empty (root) or enter a folder name like backups",
  "首页「备份到 → Github发布」即可把脚本打包为 .scripting 上传到公开仓库并同步更新脚本的远程更新链接（remoteResource）。发布仓库不存在时会自动创建，默认公开。发布 Token 与所有者可独立于备份设置；若留空则自动沿用备份账号":
    "On Home, \u201cBack up to \u2192 GitHub Publish\u201d packages scripts as .scripting, uploads them to a public repo and syncs each script's remote update link (remoteResource). The repo is auto-created if missing (public by default). Publish token & owner can differ from backup settings; leave empty to reuse the backup account",
  "填 GitHub 个人访问令牌，与备份可用不同账号。获取方式同备份：GitHub 网页 → 头像 → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token → 勾选 repo 权限。留空自动沿用备份 Token":
    "Enter a GitHub personal access token; can differ from the backup account. Same steps as backup: GitHub \u2192 avatar \u2192 Settings \u2192 Developer settings \u2192 Personal access tokens \u2192 Tokens (classic) \u2192 Generate new token \u2192 check the repo scope. Leave empty to reuse the backup token",
  "发布仓库拥有者，即 GitHub 用户名或组织名，就是仓库地址 github.com/所有者/仓库名 中的「所有者」部分。发布可用独立所有者（不同账号）；留空自动沿用备份所有者":
    "Repo owner \u2014 your GitHub username or org, the \u201cowner\u201d part of github.com/owner/repo. Publish can use its own owner (different account); leave empty to reuse the backup owner",
  "必填：接收发布文件的仓库名（公开）。若不存在，首次发布时会自动创建公开仓库，无需手动建仓":
    "Required: name of the repo (public) that receives the releases. If missing, a public repo is auto-created on first publish",
  "发布到的分支，一般用默认的 main，留空自动填 main。如仓库默认分支是 master 就填 master":
    "Branch to publish to. Use main by default; leave empty to auto-fill main. If the repo's default branch is master, enter master",
  "发布文件放在仓库里的哪个文件夹，可留空（根目录）或填一个目录名如 releases。脚本会在该目录下按脚本名生成 .scripting 文件":
    "Which folder in the repo holds the releases; leave empty (root) or enter a folder name like releases. A .scripting file per script is generated there",
  "勾选后首页显示「Github备份」入口（可把脚本打包 zip 上传到私密仓库备份）":
    "Show the \u201cGitHub Backup\u201d entry on Home (zip scripts to a private repo for backup)",
  "只有开发者才用得上：勾选后显示「Github发布」入口（可把脚本作为可更新版本发布到公开仓库）":
    "For developers only: show the \u201cGitHub Publish\u201d entry on Home (publish scripts as updatable versions to a public repo)",
  "勾选后记住首页左上角「备份 / 恢复」的展开 / 收起状态，下次打开仍保持（默认勾选）":
    "Remember the expanded/collapsed state of \u201cBackup / Restore\u201d at the top-left of Home (on by default)",
  "首页搜索时仍显示全部脚本，匹配的排在前面；关闭后只显示匹配的脚本（默认勾选）":
    "Search still shows all scripts, with matches first; turn off to show only matches (on by default)",
  "使用中遇到问题或有功能建议？欢迎到 WWWeng🐝的仓库提 Issue，或发邮件联系":
    "Questions or feature ideas? Open an Issue in WWWeng\u2019s repo, or email us",
  "我的仓库": "My Repo",
  "我的频道": "My Channel",
  "我的邮箱": "My Email",
  "最近失败的备份 / 发布 / 恢复等操作会记录在这里（最多保留 50 条），方便排查问题":
    "Recent failed backups / publishes / restores are logged here (up to 50), for troubleshooting",
  "来自 Scripting 应用的分组（.scripting/settings.json），点击分组直接备份该组全部脚本":
    "Groups from the Scripting app (.scripting/settings.json). Tap a group to back up all its scripts",
  "点击脚本名：直接开始备份/发布该脚本":
    "Tap a script name: back it up / publish it right away",
  "长按脚本名：进入多选模式，可勾选多个后统一备份/发布":
    "Long-press a script name: enter multi-select, tick several and back up / publish them together",
  "备份、删除的文件受网络传输影响不会立马成功，耐心等待即可":
    "Backups and deletions rely on network transfer, so they may not finish instantly \u2014 just wait",
  " · {date} · {n} 个脚本": " \u00b7 {date} \u00b7 {n} scripts",

  // ---- 仓库监控 ----
  "仓库监控": "Repo Monitor",
  "打开后定时检查监控仓库里的 .scripting 脚本是否有更新，有变化时发通知提醒。应用在前台或后台保活期间按间隔自动检查；被系统挂起后，每次打开应用会补查，并按间隔发送提醒通知（点通知立即检查）。开启后首页右上角会增加一个手动检测按钮。首次启用只记录，之后有变化才提示":
    "Check monitored repos for .scripting updates on an interval and notify you when they change. Checks run while the app is foreground or kept alive; if the system suspends the app, it re-checks on next open and sends a reminder notification each interval (tap it to check right away). After enabling, a manual check button appears in the top-right corner of the home page. The first run only records; you'll be alerted only when something changes afterwards",
  "检查间隔": "Check interval",
  "单位": "Unit",
  "分": "min",
  "小时": "hr",
  "天": "day",
  "备注": "Remark",
  "添加仓库链接": "Add repo link",
  "添加": "Add",
  "默认 {n} 分，最短 1 分；按间隔自动检查并发送提醒通知":
    "Default {n} min, minimum 1 min; auto-checks and sends a reminder at the interval",
  "立即检查": "Check now",
  "检查中…": "Checking\u2026",
  "链接无效，请输入形如 https://github.com/所有者/仓库名 的 GitHub 地址":
    "Invalid link. Enter a GitHub URL like https://github.com/owner/repo",
  "该仓库已在监控列表中": "This repo is already being monitored",
  "修改备注名": "Edit remark",
  "修改": "Edit",
  "修改仓库链接": "Edit repo link",
  "修改排除关键词": "Edit excluded keyword",
  "修改成功": "Saved",

  "仓库备注名": "Repo remark",
  "请先打开仓库监控开关": "Turn on the Repo Monitor switch first",

  "检查完成，没有发现更新": "Check complete, no updates found",
  "{n} 个仓库检查失败，请检查链接或网络": "{n} repo(s) failed to check \u2014 verify the links or network",
  "已建立基线：共 {n} 个仓库、{m} 个脚本，之后有变化会提醒":
    "Baseline set: {n} repo(s), {m} scripts. You'll be alerted when anything changes",
  "发现 {n} 个脚本有更新": "Found updates in {n} scripts",
  "仓库监控：{n} 个脚本有更新": "Repo Monitor: {n} scripts updated",
  "仓库监控提醒": "Repo Monitor reminder",
  "点击检查监控的仓库是否有脚本更新": "Tap to check monitored repos for script updates",
  "默认 12 小时，最短 1 分钟；按间隔自动检查并发送提醒通知":
    "Default 12 hr, minimum 1 min; auto-checks and sends a reminder at the interval",
  "「{name}」：{n} 个脚本有更新": "\u201c{name}\u201d: {n} scripts updated",
  "频道更新": "Channel Updates",
  "可更新的脚本": "Updatable scripts",
  "默认全选；点「更新」通过 Scripting 导入安装新版本，未勾选的跳过":
    "All selected by default; tap Update to install new versions via Scripting import, unchecked are skipped",
  "默认全选；点「更新」通过 Scripting 导入安装新版本，未勾选的跳过；全部处理完自动关闭":
    "All selected by default; tap Update to install via Scripting import, unchecked are skipped; closes automatically once all are processed",
  "已开始更新 {n} 个脚本，还有 {m} 个待处理":
    "Started updating {n} script(s), {m} still pending",
  "请先选择要更新的脚本": "Select scripts to update first",
  "获取下载地址失败，请检查网络后重试":
    "Failed to get download URLs. Check the network and retry",
  "已开始更新 {n} 个脚本": "Started updating {n} scripts",
  "没有可更新的脚本": "No scripts to update",
  "更新 {n}": "Update {n}",
  "更新 ({n})": "Update ({n})",
  "更新中…": "Updating\u2026",
  "排除关键词": "Excluded keywords",
  "添加排除关键词": "Add excluded keyword",
  "脚本名称包含任一关键词时，即使有更新也不提示、不列入更新页（例如排除「测试」可忽略测试脚本）":
    "When a script name contains any keyword, updates for it are neither notified nor listed on the update page (e.g. exclude \u201cTest\u201d to ignore test scripts)",
  "未设置排除关键词": "No excluded keywords",
  "如：测试、请勿下载": "e.g. Test, DoNotDownload",
  "请输入排除关键词": "Enter an excluded keyword",
  "该关键词已存在": "Keyword already exists",
  "删除成功": "Deleted",
  "{n} 个脚本因排除关键词未显示": "{n} script(s) hidden by exclude keywords",
  "{n} 个脚本因名称含排除关键词未显示，可在设置里调整":
    "{n} script(s) hidden because names contain exclude keywords; adjust them in Settings",
  "已忽略 {n} 个脚本的更新，不再提示；可在设置→仓库监控 中恢复":
    "Ignored {n} script(s) — no more prompts. Restore them in Settings ▶ Repo Monitor",
  "{n} 个脚本已忽略更新（再发新版也不再提示），可在设置→仓库监控 中恢复":
    "{n} script(s) ignored (no prompts for new releases). Restore in Settings ▶ Repo Monitor",
  "已忽略更新的脚本": "Ignored scripts",
  "这些脚本再发布新版本也不会提示；点「恢复提醒」后正常提示":
    "New releases of these scripts won't be prompted; tap Restore Reminders to get alerts again",
  "未忽略任何脚本": "No scripts ignored",
  "恢复提醒": "Restore Reminders",
  "已恢复提醒": "Reminders restored",

  "新增": "New",
  "更新": "Update",
  "展开": "Expand",
  "收起": "Collapse",
}
