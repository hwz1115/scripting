import {
  Widget,
  VStack,
  HStack,
  Text,
  Spacer,
  WidgetReloadPolicy,
} from "scripting"

import {
  type IpSourceResult,
  type NetworkInfoData,
  type RiskInfo,
  type ServiceResult,
  fetchNetworkInfo,
} from "./api"
import { loadSkkIpInfoSettings, type SkkIpInfoSettings } from "./settings"

function clampRefreshMinutes(value: number) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 30
  return Math.min(1440, Math.max(5, Math.floor(n)))
}

function two(n: number) {
  return String(n).padStart(2, "0")
}

function formatTime(ts: number) {
  const date = new Date(ts)
  return `${two(date.getHours())}:${two(date.getMinutes())}`
}

function maskIp(ip?: string) {
  const raw = String(ip ?? "")
  if (!raw) return "—"
  if (raw.includes(":")) {
    const parts = raw.split(":").filter(Boolean)
    if (parts.length <= 2) return raw
    return `${parts.slice(0, 2).join(":")}:...:${parts.slice(-1)[0]}`
  }
  const parts = raw.split(".")
  if (parts.length !== 4) return raw
  return `${parts[0]}.${parts[1]}.*.*`
}

function text(value?: string, fallback = "—") {
  const s = String(value ?? "").trim()
  return s || fallback
}

function ellipsis(value?: string, limit = 30) {
  const raw = text(value, "")
  if (!raw) return "—"
  return raw.length > limit ? `${raw.slice(0, limit - 1)}…` : raw
}

function displayIp(item: IpSourceResult | undefined, settings: SkkIpInfoSettings) {
  if (!item?.ip) return "—"
  return settings.maskIp ? maskIp(item.ip) : item.ip
}

function displayLocation(item: IpSourceResult | undefined, settings: SkkIpInfoSettings) {
  if (!item) return "—"
  if (settings.maskLocation) return "已隐藏"
  return text(item.location || item.countryCode)
    .replace(/^(中国\s*){2,}/i, "中国 ")
    .replace(/\s+/g, " ")
    .trim()
}

function displayLocationCompact(item: IpSourceResult | undefined, settings: SkkIpInfoSettings) {
  const raw = displayLocation(item, settings)
  if (raw === "—" || raw === "已隐藏") return raw

  const cc = String(item?.countryCode || "").trim().toUpperCase()
  let value = raw
  if (cc && value.toUpperCase().startsWith(`${cc} `)) {
    value = value.slice(cc.length).trim()
  }

  return value
    .replace(/\s+/g, " ")
    .replace(/Taiwan\s+([A-Za-z-]+)/i, "Taiwan · $1")
    .replace(/China\s+([\u4e00-\u9fa5A-Za-z-]+)/i, "China · $1")
}

function pickSources(data: NetworkInfoData) {
  const preferred = [
    data.primaryDomestic,
    data.primaryInternational,
    data.primaryIPv6,
  ].filter(Boolean) as IpSourceResult[]

  const seen = new Set(preferred.map((item) => item.id))
  data.sources.forEach((item) => {
    if (item.ok && !seen.has(item.id)) {
      preferred.push(item)
      seen.add(item.id)
    }
  })
  return preferred
}

function pickReferenceSources(data: NetworkInfoData) {
  const ids = ["ipip", "bilibili", "cloudflare", "ipinfo"]
  const picked: IpSourceResult[] = []
  ids.forEach((id) => {
    const found = data.sources.find((item) => item.id === id && item.ok && item.ip)
    if (found) picked.push(found)
  })
  const seen = new Set(picked.map((item) => item.id))
  pickSources(data).forEach((item) => {
    if (!seen.has(item.id)) {
      picked.push(item)
      seen.add(item.id)
    }
  })
  return picked
}

function riskColor(risk: RiskInfo): any {
  if (risk.level === "高") return "systemRed"
  if (risk.level === "中") return "systemOrange"
  return "systemGreen"
}

function statusColor(ok: boolean, statusText?: string): any {
  if (ok && /仅自制|部分/i.test(String(statusText || ""))) return "systemYellow"
  return ok ? "systemGreen" : "systemRed"
}

function latencyText(value?: number) {
  if (typeof value !== "number" || !Number.isFinite(value)) return "—"
  return `${Math.round(value)}ms`
}

function serviceLabel(item: ServiceResult) {
  if (item.region === "流媒体") return "流媒"
  return item.region
}

function clampLatencyDotCount(value: number) {
  const n = Number(value)
  if (!Number.isFinite(n)) return 4
  return Math.min(4, Math.max(0, Math.floor(n)))
}

function ColoredDot(props: { color: any; size?: number }) {
  return (
    <Text font={props.size ?? 7} foregroundStyle={props.color} lineLimit={1} minScaleFactor={1}>
      ●
    </Text>
  )
}

function RiskIcon(props: { risk: RiskInfo }) {
  void props.risk
  return (
    <Text font={13} fontWeight="bold" foregroundStyle="#0A84FF" lineLimit={1} minScaleFactor={1}>
      ⓘ
    </Text>
  )
}

function Root(props: { children: any; compact?: boolean }) {
  const pad = props.compact
    ? { top: 8, leading: 8, bottom: 8, trailing: 8 }
    : { top: 6, leading: 6, bottom: 6, trailing: 6 }

  return (
    <VStack
      frame={{ minWidth: 0, maxWidth: Infinity, minHeight: 0, maxHeight: Infinity }}
      padding={pad}
      spacing={props.compact ? 0 : 2}
      widgetBackground={{
        style: { light: "#F5F8FA", dark: "rgba(33,52,70,0.88)" } as any,
        shape: { type: "rect", cornerRadius: 22, style: "continuous" },
      }}
    >
      {props.children}
    </VStack>
  )
}

function Card(props: { children: any; padding?: number; spacing?: number; frame?: any }) {
  const pad = props.padding ?? 6
  return (
    <VStack
      alignment="leading"
      spacing={props.spacing ?? 4}
      padding={{ top: pad, leading: pad, bottom: pad, trailing: pad }}
      frame={props.frame || { minWidth: 0, maxWidth: Infinity }}
    >
      {props.children}
    </VStack>
  )
}

function ServicePanel(props: { children: any }) {
  return (
    <VStack
      alignment="leading"
      spacing={3}
      padding={{ top: 3, leading: 6, bottom: 3, trailing: 6 }}
      frame={{ minWidth: 0, maxWidth: Infinity }}
    >
      {props.children}
    </VStack>
  )
}

function Badge(props: { text: string; tone: "domestic" | "international" | "risk" }) {
  const bg =
    props.tone === "domestic"
      ? "systemBlue"
      : props.tone === "risk"
        ? "systemOrange"
        : "systemGreen"
  const fg = "white"

  return (
    <VStack
      padding={{ top: 2, leading: 5, bottom: 2, trailing: 5 }}
      widgetBackground={{
        style: bg,
        shape: { type: "capsule", style: "continuous" },
      }}
    >
      <Text font={9.5} fontWeight="bold" foregroundStyle={fg} lineLimit={1} minScaleFactor={0.85}>
        {props.text}
      </Text>
    </VStack>
  )
}

function Header(props: {
  title: string
  updatedAt: number
}) {
  return (
    <HStack alignment="center" spacing={6}>
      <VStack
        frame={{ width: 4, height: 16 }}
        widgetBackground={{
          style: "systemGreen",
          shape: { type: "capsule", style: "continuous" },
        }}
      />
      <Text font={14} fontWeight="bold" lineLimit={1} minScaleFactor={0.8}>
        {props.title}
      </Text>
      <Spacer />
      <Text font={11} foregroundStyle="secondaryLabel" lineLimit={1} minScaleFactor={0.8}>
        {formatTime(props.updatedAt)}
      </Text>
    </HStack>
  )
}

function InfoBlock(props: { label: string; value: string; strong?: boolean }) {
  return (
    <VStack spacing={1} alignment="leading">
      <Text font={10} foregroundStyle="secondaryLabel" lineLimit={1}>
        {props.label}
      </Text>
      <Text
        font={props.strong ? 10.2 : 8.8}
        fontWeight={props.strong ? "semibold" : "regular"}
        lineLimit={2}
        minScaleFactor={0.6}
      >
        {props.value}
      </Text>
    </VStack>
  )
}

function StatusPill(props: { text: string }) {
  return (
    <VStack
      padding={{ top: 2, leading: 5, bottom: 2, trailing: 5 }}
      widgetBackground={{
        style: { light: "rgba(0,0,0,0.045)", dark: "rgba(255,255,255,0.08)" } as any,
        shape: { type: "capsule", style: "continuous" },
      }}
    >
      <Text font={7} foregroundStyle="secondaryLabel" lineLimit={1} minScaleFactor={0.62}>
        {props.text}
      </Text>
    </VStack>
  )
}

function StatusStrip(props: {
  data: NetworkInfoData
}) {
  return (
    <VStack
      padding={{ top: 2, leading: 6, bottom: 2, trailing: 6 }}
      frame={{ minWidth: 0, maxWidth: Infinity }}
    >
      <HStack alignment="center" spacing={5} frame={{ maxWidth: Infinity }}>
        <RiskIcon risk={props.data.risk} />
        <Text font={8} foregroundStyle="secondaryLabel" lineLimit={1}>
          风险值
        </Text>
        <Text font={11} fontWeight="bold" foregroundStyle={riskColor(props.data.risk)} lineLimit={1}>
          {String(props.data.risk.score)}
        </Text>
        <Text font={7.8} foregroundStyle="secondaryLabel" lineLimit={1} minScaleFactor={0.66}>
          / 100 · {props.data.risk.title}
        </Text>
        <Spacer />
        <StatusPill text={props.data.risk.lineType} />
        <StatusPill text={props.data.risk.nativeHint} />
        <StatusPill text={props.data.risk.subtype} />
        <Text font={7.2} foregroundStyle="secondaryLabel" lineLimit={1} minScaleFactor={0.62}>
          {formatTime(props.data.updatedAt)}
        </Text>
      </HStack>
    </VStack>
  )
}

function RiskChip(props: { text: string; color: any }) {
  if (!props.text) return null
  return (
    <VStack
      padding={{ top: 3, leading: 7, bottom: 3, trailing: 7 }}
      widgetBackground={{
        style: props.color,
        shape: { type: "capsule", style: "continuous" },
      }}
    >
      <Text font={11} fontWeight="bold" foregroundStyle="white" lineLimit={1} minScaleFactor={0.7}>
        {props.text}
      </Text>
    </VStack>
  )
}

function signalTextColor(label: string): any {
  if (/非家宽|机房|代理|专线/.test(label)) return "systemPurple"
  if (/非原生|隧道/.test(label)) return "systemIndigo"
  if (/家宽|原生/.test(label)) return "systemTeal"
  if (/移动/.test(label)) return "systemBlue"
  return "systemCyan"
}

function RiskStrip(props: { risk: RiskInfo }) {
  const color = riskColor(props.risk)
  const line = String(props.risk.lineType || "").trim()
  const native = String(props.risk.nativeHint || "").trim()
  const tag1 = /非家宽/.test(line) ? "非家宽" : /家宽/.test(line) ? "家宽" : ""
  const tag2 = /非原生/.test(native) ? "非原生" : /原生/.test(native) ? "原生" : ""

  return (
    <VStack
      alignment="leading"
      spacing={4}
      padding={{ top: 6, leading: 6, bottom: 6, trailing: 6 }}
      widgetBackground={{
        style: { light: "rgba(0,0,0,0.04)", dark: "rgba(255,255,255,0.10)" } as any,
        shape: { type: "rect", cornerRadius: 12, style: "continuous" },
      }}
    >
      <HStack alignment="center" spacing={6} frame={{ maxWidth: Infinity }}>
        <VStack
          alignment="center"
          spacing={0}
          padding={{ top: 4, leading: 5, bottom: 4, trailing: 5 }}
          widgetBackground={{
            style: color,
            shape: { type: "rect", cornerRadius: 8, style: "continuous" },
          }}
        >
          <Text font={14} fontWeight="bold" foregroundStyle="white" lineLimit={1}>
            {String(props.risk.score)}
          </Text>
        </VStack>

        <VStack alignment="leading" spacing={3} frame={{ maxWidth: Infinity }}>
          <HStack spacing={4} alignment="center" frame={{ maxWidth: Infinity }}>
            <Text font={13} fontWeight="bold" foregroundStyle={color} lineLimit={1}>
              {props.risk.level + "风险"}
            </Text>
            <Spacer />
          </HStack>
          <HStack spacing={5} alignment="center" frame={{ maxWidth: Infinity }}>
            {tag1 ? (
              <Text
                font={10.5}
                fontWeight="semibold"
                foregroundStyle="secondaryLabel"
                lineLimit={1}
                minScaleFactor={0.7}
              >
                {tag1}
              </Text>
            ) : null}
            {tag1 && tag2 ? (
              <Text font={10} foregroundStyle="secondaryLabel">
                {"·"}
              </Text>
            ) : null}
            {tag2 ? (
              <Text
                font={10.5}
                fontWeight="semibold"
                foregroundStyle="secondaryLabel"
                lineLimit={1}
                minScaleFactor={0.7}
              >
                {tag2}
              </Text>
            ) : null}
            <Spacer />
          </HStack>
        </VStack>
      </HStack>
    </VStack>
  )
}

function countryLabel(item?: IpSourceResult) {
  const cc = String(item?.countryCode || "").trim().toUpperCase()
  if (/^[A-Z]{2}$/.test(cc)) return cc
  return item?.kind === "domestic" ? "国内" : "国际"
}

function sourceTone(item?: IpSourceResult): "domestic" | "international" {
  return item?.kind === "domestic" ? "domestic" : "international"
}

function PrimaryIpCard(props: { data: NetworkInfoData; settings: SkkIpInfoSettings }) {
  const primary =
    props.data.primaryInternational || props.data.primaryDomestic || props.data.primaryIPv6
  const ipv6 = props.data.primaryIPv6

  return (
    <Card padding={5} spacing={4} frame={{ width: 166, minHeight: 230 }}>
      <HStack alignment="center" spacing={6} frame={{ maxWidth: Infinity }}>
        <Text font={8.8} foregroundStyle="secondaryLabel" lineLimit={1}>
          IPv4
        </Text>
        <Spacer />
        <Badge text={countryLabel(primary)} tone={sourceTone(primary)} />
      </HStack>

      <Text font={18} fontWeight="bold" lineLimit={1} minScaleFactor={0.4}>
        {displayIp(primary, props.settings)}
      </Text>

      <InfoBlock label="Location" value={displayLocationCompact(primary, props.settings)} strong />
      <InfoBlock label="ISP" value={text(primary?.isp)} strong />
      <InfoBlock label="ASN" value={text(primary?.asn || primary?.isp)} strong />

      <HStack alignment="center" spacing={6} frame={{ maxWidth: Infinity }}>
        <Text font={9} foregroundStyle="secondaryLabel" lineLimit={1}>
          IPv6
        </Text>
        <Spacer />
        {ipv6 ? <Badge text={countryLabel(ipv6)} tone={sourceTone(ipv6)} /> : null}
      </HStack>

      <Text
        font={13.5}
        fontWeight="bold"
        foregroundStyle={ipv6 ? "label" : "secondaryLabel"}
        lineLimit={1}
        minScaleFactor={0.5}
      >
        {ipv6 ? displayIp(ipv6, props.settings) : "不可用"}
      </Text>

      <InfoBlock
        label="Location"
        value={ipv6 ? displayLocationCompact(ipv6, props.settings) : "—"}
        strong
      />
      <InfoBlock label="ISP" value={ipv6 ? text(ipv6?.isp) : "—"} strong />
      <InfoBlock label="ASN" value={ipv6 ? text(ipv6?.asn || ipv6?.isp) : "—"} strong />
    </Card>
  )
}

function CompactIpCard(props: { data: NetworkInfoData; settings: SkkIpInfoSettings }) {
  const primary =
    props.data.primaryInternational || props.data.primaryDomestic || props.data.primaryIPv6
  const risk = props.data.risk
  const line = String(risk.lineType || "").trim()
  const native = String(risk.nativeHint || "").trim()
  const tag1 = /非家宽/.test(line) ? "非家宽" : /家宽/.test(line) ? "家宽" : ""
  const tag2 = /非原生/.test(native) ? "非原生" : /原生/.test(native) ? "原生" : ""

  return (
    <Card padding={5} spacing={0}>
      <HStack alignment="center" spacing={8} frame={{ maxWidth: Infinity }}>
        <VStack spacing={2} alignment="leading" frame={{ maxWidth: Infinity }}>
          <HStack spacing={4} alignment="center" frame={{ maxWidth: Infinity }}>
            <Text font={10.5} foregroundStyle="secondaryLabel" lineLimit={1}>
              IPv4
            </Text>
            <Text font={18} fontWeight="bold" lineLimit={1} minScaleFactor={0.55}>
              {displayIp(primary, props.settings)}
            </Text>
          </HStack>
          <HStack spacing={4} alignment="center" frame={{ maxWidth: Infinity }}>
            <Text font={10.5} foregroundStyle="clear" lineLimit={1}>
              IPv4
            </Text>
            <Text font={12} fontWeight="medium" foregroundStyle="label" lineLimit={1} minScaleFactor={0.7}>
              {displayLocation(primary, props.settings)}
            </Text>
          </HStack>
        </VStack>
        <VStack spacing={1} alignment="trailing">
          <HStack spacing={4} alignment="center">
            <Text font={10.5} foregroundStyle="secondaryLabel" lineLimit={1}>
              风险值
            </Text>
            <Text font={22} fontWeight="bold" foregroundStyle={riskColor(risk)} lineLimit={1}>
              {String(risk.score)}
            </Text>
          </HStack>
          <HStack spacing={4} alignment="center">
            <Text font={10.5} foregroundStyle="clear" lineLimit={1}>
              风险值
            </Text>
            <Text font={11.5} fontWeight="medium" foregroundStyle="label" lineLimit={1} minScaleFactor={0.75}>
              {[risk.level + "风险", tag1, tag2].filter(Boolean).join(" · ")}
            </Text>
          </HStack>
        </VStack>
      </HStack>
    </Card>
  )
}

function SourceLine(props: { item: IpSourceResult; settings: SkkIpInfoSettings }) {
  const name = props.settings.showSourceName
    ? props.item.name
    : props.item.kind === "domestic"
      ? "国内探针"
      : "国际探针"
  const detail = `${displayLocation(props.item, props.settings)} ${text(props.item.isp || props.item.asn, "")}`.trim()

  return (
    <VStack spacing={1} frame={{ maxWidth: Infinity }}>
      <HStack alignment="center" spacing={5} frame={{ maxWidth: Infinity }}>
        <Text font={8.4} fontWeight="regular" lineLimit={1} minScaleFactor={0.6}>
          {name}
        </Text>
        <Spacer />
        <Badge text={props.item.kind === "domestic" ? "国内" : "国际"} tone={sourceTone(props.item)} />
      </HStack>
      <Text font={7.2} foregroundStyle="secondaryLabel" fontWeight="semibold" lineLimit={1} minScaleFactor={0.58}>
        IP: {displayIp(props.item, props.settings)}
      </Text>
      <Text font={7.1} fontWeight="semibold" lineLimit={2} minScaleFactor={0.62}>
        {detail || "—"}
      </Text>
    </VStack>
  )
}

function Separator() {
  return (
    <VStack
      frame={{ maxWidth: Infinity, height: 1 }}
      widgetBackground={{
        style: "rgba(0,0,0,0)",
        shape: { type: "rect", cornerRadius: 0, style: "continuous" },
      }}
    />
  )
}

function SourceListCard(props: { data: NetworkInfoData; settings: SkkIpInfoSettings }) {
  const sources = pickReferenceSources(props.data).slice(0, 4)
  return (
    <Card padding={4} spacing={1.5} frame={{ width: 163 }}>
      {sources.map((item, index) => (
        <VStack key={item.id} spacing={2} frame={{ maxWidth: Infinity }}>
          {index > 0 ? <Separator /> : null}
          <SourceLine item={item} settings={props.settings} />
        </VStack>
      ))}
    </Card>
  )
}

function cleanIsp(value?: string) {
  const raw = text(value, "")
  if (!raw) return "—"
  return raw
    .replace(/\s*(Co\.|Company|Ltd\.|Limited|Inc\.|Corporation|Corp\.)\s*$/i, "")
    .trim()
}

function SummaryItem(props: { label: string; value: string }) {
  return (
    <VStack
      alignment="leading"
      spacing={1}
      padding={{ top: 1, leading: 0, bottom: 1, trailing: 0 }}
      frame={{ minWidth: 0, maxWidth: Infinity }}
    >
      <Text font={7.2} foregroundStyle="secondaryLabel" lineLimit={1}>
        {props.label}
      </Text>
      <Text font={7.8} fontWeight="semibold" lineLimit={1} minScaleFactor={0.55}>
        {props.value}
      </Text>
    </VStack>
  )
}

function NetworkSummaryCard(props: { data: NetworkInfoData; settings: SkkIpInfoSettings }) {
  void props.settings
  const primary = props.data.primaryInternational || props.data.primaryDomestic || props.data.primaryIPv6
  const exit = `${countryLabel(primary)} / ${primary?.kind === "domestic" ? "国内" : "国际"}`
  const isp = cleanIsp(primary?.isp || primary?.asn)
  const ipv6 = props.data.primaryIPv6 ? "可用" : "不可用"
  const risk = `${props.data.risk.level} · ${props.data.risk.title}`

  return (
    <Card padding={4} spacing={3} frame={{ width: 163 }}>
      <Text font={8.8} fontWeight="semibold" foregroundStyle="secondaryLabel" lineLimit={1}>
        网络摘要
      </Text>
      <HStack spacing={5} frame={{ maxWidth: Infinity }}>
        <SummaryItem label="出口" value={exit} />
        <SummaryItem label="IPv6" value={ipv6} />
      </HStack>
      <HStack spacing={5} frame={{ maxWidth: Infinity }}>
        <SummaryItem label="ISP" value={ellipsis(isp, 18)} />
        <SummaryItem label="风险" value={risk} />
      </HStack>
    </Card>
  )
}

function autoLatencyDotCount(item: ServiceResult) {
  if (!item.ok) return 2

  const latency = item.latencyMs
  if (typeof latency !== "number" || !Number.isFinite(latency)) return 1

  if (latency <= 120) return 1
  if (latency <= 250) return 2
  if (latency <= 400) return 2
  if (latency <= 700) return 3
  if (latency <= 1000) return 3
  if (latency <= 1500) return 4
  return 4
}

function dotColor(item: ServiceResult, index: number): any {
  void index
  if (!item.ok) return "systemRed"
  const latency = item.latencyMs || 0
  if (/仅自制|部分/i.test(String(item.statusText || ""))) return "systemYellow"
  if (latency <= 120) return "systemGreen"
  if (latency <= 350) return "systemYellow"
  if (latency <= 1000) return "systemOrange"
  return "systemRed"
}

function DotStrip(props: { item: ServiceResult; count?: number; auto?: boolean }) {
  const count = props.auto
    ? autoLatencyDotCount(props.item)
    : clampLatencyDotCount(props.count ?? 5)

  if (count <= 0) return null

  return (
    <HStack spacing={2}>
      {Array.from({ length: count }).map((_, index) => (
        <ColoredDot key={index} color={dotColor(props.item, index)} size={5.6} />
      ))}
    </HStack>
  )
}

function serviceRegionText(item: ServiceResult) {
  const cc = String(item.countryCode || "").trim().toUpperCase()
  if (/^[A-Z]{2}$/.test(cc)) return cc
  if (!item.ok) return "失败"
  return "—"
}

function ServiceTile(props: { item: ServiceResult; settings: SkkIpInfoSettings }) {
  return (
    <HStack
      alignment="center"
      spacing={4}
      padding={{ top: 1, leading: 4, bottom: 1, trailing: 4 }}
      frame={{ minWidth: 0, maxWidth: Infinity }}
    >
      {props.settings.showServiceDots ? (
        <ColoredDot color={statusColor(props.item.ok, props.item.statusText)} size={7} />
      ) : null}
      <Text font={11} fontWeight="bold" lineLimit={1} minScaleFactor={0.6}>
        {props.item.name}
      </Text>
      <Text
        font={11}
        fontWeight="bold"
        foregroundStyle={statusColor(props.item.ok, props.item.statusText)}
        lineLimit={1}
        minScaleFactor={0.7}
      >
        {props.item.ok ? latencyText(props.item.latencyMs) : "失败"}
      </Text>
      {props.settings.showServiceDots ? (
        <DotStrip item={props.item} count={props.settings.latencyDotCount} auto={props.settings.latencyDotAuto} />
      ) : null}
      <Spacer />
      <Badge
        text={serviceLabel(props.item)}
        tone={props.item.region === "国内" ? "domestic" : "international"}
      />
    </HStack>
  )
}

function servicePriority(item: ServiceResult) {
  const order = [
    "youtube",
    "chatgpt",
    "spotify",
    "netflix",
    "disney",
    "max",
    "openai_api",
    "cloudflare",
    "github",
    "bilibili",
    "bytedance",
    "jsdelivr",
    "wechat",
    "taobao",
  ]
  const index = order.indexOf(item.id)
  return index >= 0 ? index : 99
}

function pickServices(data: NetworkInfoData, limit: number) {
  return [...(data.services || data.connectivity || [])]
    .sort((a, b) => servicePriority(a) - servicePriority(b))
    .slice(0, limit)
}

function ServiceGrid(props: { items: ServiceResult[]; columns: 2 | 3 | 4; settings: SkkIpInfoSettings }) {
  const rows: ServiceResult[][] = []
  props.items.forEach((item, index) => {
    const row = Math.floor(index / props.columns)
    if (!rows[row]) rows[row] = []
    rows[row].push(item)
  })

  return (
    <VStack spacing={2} frame={{ maxWidth: Infinity }}>
      {rows.map((row, index) => (
        <HStack key={index} spacing={3} frame={{ maxWidth: Infinity }}>
          {row.map((item) => (
            <ServiceTile key={item.id} item={item} settings={props.settings} />
          ))}
          {row.length < props.columns ? <Spacer /> : null}
        </HStack>
      ))}
    </VStack>
  )
}

function SmallView(props: {
  data: NetworkInfoData
  settings: SkkIpInfoSettings
}) {
  const primary =
    props.data.primaryInternational || props.data.primaryDomestic || props.data.primaryIPv6
  const cc = String(primary?.countryCode || "").trim().toUpperCase()
  const isDomestic =
    primary?.kind === "domestic" || cc === "CN" || /中国|国内/.test(String(primary?.location || ""))
  const regionLabel = isDomestic ? "国内" : "国际"
  const regionColor = isDomestic ? "systemBlue" : "systemGreen"

  return (
    <Root compact>
      <Header
        title={props.settings.title}
        updatedAt={props.data.updatedAt}
      />
      <Spacer minLength={1} />
      <VStack spacing={3} alignment="leading" frame={{ maxWidth: Infinity }}>
        <Text font={17} fontWeight="bold" lineLimit={1} minScaleFactor={0.6}>
          {displayIp(primary, props.settings)}
        </Text>
        <HStack spacing={6} alignment="center" frame={{ maxWidth: Infinity }}>
          <RiskChip text={regionLabel} color={regionColor} />
          <Text font={12} fontWeight="medium" foregroundStyle="label" lineLimit={1} minScaleFactor={0.75}>
            {displayLocation(primary, props.settings)}
          </Text>
          <Spacer />
        </HStack>
        <Text font={11.5} foregroundStyle="secondaryLabel" lineLimit={1} minScaleFactor={0.7}>
          {text(primary?.isp)}
        </Text>
      </VStack>
      <Spacer minLength={6} />
      <RiskStrip risk={props.data.risk} />
    </Root>
  )
}

function MediumView(props: {
  data: NetworkInfoData
  settings: SkkIpInfoSettings
}) {
  const services = pickServices(props.data, 4)
  return (
    <Root compact>
      <Header
        title={props.settings.title}
        updatedAt={props.data.updatedAt}
      />

      <CompactIpCard data={props.data} settings={props.settings} />

      {services.length ? (
        <VStack spacing={2} frame={{ maxWidth: Infinity }}>
          <Text font={11.5} fontWeight="semibold" foregroundStyle="label" lineLimit={1}>
            服务检测
          </Text>
          <ServiceGrid items={services} columns={2} settings={props.settings} />
        </VStack>
      ) : (
        <Text font={12} foregroundStyle="secondaryLabel">
          未选择服务（可在设置中开启）
        </Text>
      )}
    </Root>
  )
}

function LargeView(props: {
  data: NetworkInfoData
  settings: SkkIpInfoSettings
}) {
  const services = pickServices(props.data, 6)
  return (
    <Root>
      <HStack alignment="top" spacing={3} frame={{ maxWidth: Infinity }}>
        <PrimaryIpCard data={props.data} settings={props.settings} />
        <VStack alignment="leading" spacing={2} frame={{ minWidth: 0, maxWidth: Infinity }}>
          <SourceListCard data={props.data} settings={props.settings} />
          <NetworkSummaryCard data={props.data} settings={props.settings} />
        </VStack>
      </HStack>

      <StatusStrip data={props.data} />

      {services.length ? (
        <ServicePanel>
          <Text font={12} fontWeight="semibold" foregroundStyle="label" lineLimit={1}>
            服务检测
          </Text>
          <ServiceGrid items={services} columns={3} settings={props.settings} />
        </ServicePanel>
      ) : (
        <Text font={9} foregroundStyle="secondaryLabel">
          未选择服务
        </Text>
      )}
    </Root>
  )
}

function ErrorView(props: { title: string; message: string }) {
  return (
    <Root compact>
      <Spacer />
      <VStack spacing={6} alignment="center">
        <Text font="headline" foregroundStyle="systemRed">
          {props.title}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={4} multilineTextAlignment="center">
          {props.message}
        </Text>
      </VStack>
      <Spacer />
    </Root>
  )
}

async function render() {
  const settings = loadSkkIpInfoSettings()
  const refreshMinutes = clampRefreshMinutes(settings.refreshIntervalMinutes)
  const reloadPolicy: WidgetReloadPolicy = {
    policy: "after",
    date: new Date(Date.now() + refreshMinutes * 60 * 1000),
  }

  try {
    const data = await fetchNetworkInfo(settings)
    const props = {
      data,
      settings,
    }

    if (Widget.family === "systemSmall") {
      Widget.present(<SmallView {...props} />, reloadPolicy)
      return
    }

    if (Widget.family === "systemLarge" || Widget.family === "systemExtraLarge") {
      Widget.present(<LargeView {...props} />, reloadPolicy)
      return
    }

    Widget.present(<MediumView {...props} />, reloadPolicy)
  } catch (error: any) {
    const message = error?.message ? String(error.message) : String(error)
    Widget.present(<ErrorView title="加载失败" message={message} />, reloadPolicy)
  }
}

render()
