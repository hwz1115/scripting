import { fetch } from "scripting"
import type { SkkIpInfoSettings } from "./settings"


export type IpSourceKind = "domestic" | "international" | "cloudflare" | "ipv6"

export type IpSourceResult = {
  id: string
  name: string
  kind: IpSourceKind
  ok: boolean
  ip?: string
  countryCode?: string
  location?: string
  isp?: string
  org?: string
  asn?: string
  latencyMs?: number
  error?: string
  extra?: string
}

export type ServiceRegion = "国内" | "国际" | "AI" | "流媒体"

export type ServiceResult = {
  id: string
  name: string
  region: ServiceRegion
  ok: boolean
  latencyMs?: number
  status?: number
  countryCode?: string
  statusText?: string
  detail?: string
  error?: string
}

export type RiskInfo = {
  score: number
  level: "低" | "中" | "高"
  title: string
  lineType: string
  subtype: string
  nativeHint: string
  tunnelHint: string
  items: string[]
}

export type NetworkInfoData = {
  updatedAt: number
  sources: IpSourceResult[]
  services: ServiceResult[]
  connectivity: ServiceResult[]
  risk: RiskInfo
  primaryDomestic?: IpSourceResult
  primaryInternational?: IpSourceResult
  primaryIPv6?: IpSourceResult
}


type SourceFetcher = (timeoutMs: number) => Promise<Partial<IpSourceResult>>


const BASIC_SERVICE_TARGETS: Array<{
  id: string
  name: string
  region: ServiceRegion
  url: string
}> = [
  { id: "bytedance", name: "字节跳动", region: "国内", url: "https://www.bytedance.com/favicon.ico" },
  { id: "bilibili", name: "Bilibili", region: "国内", url: "https://www.bilibili.com/favicon.ico" },
  { id: "wechat", name: "微信", region: "国内", url: "https://weixin.qq.com/favicon.ico" },
  { id: "taobao", name: "淘宝", region: "国内", url: "https://www.taobao.com/favicon.ico" },
  { id: "github", name: "GitHub", region: "国际", url: "https://github.githubassets.com/favicons/favicon.svg" },
  { id: "jsdelivr", name: "jsDelivr", region: "国际", url: "https://cdn.jsdelivr.net/npm/@sukka/uuid@latest/package.json" },
  { id: "cloudflare", name: "Cloudflare", region: "国际", url: "https://www.cloudflare.com/cdn-cgi/trace" },
]

function errToString(error: any) {
  if (!error) return "unknown"
  if (typeof error === "string") return error
  if (error?.message) return String(error.message)
  return String(error)
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number, label: string): Promise<T> {
  let timer: any
  const timeout = new Promise<T>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timeout`)), timeoutMs)
  })
  return Promise.race([promise, timeout]).finally(() => {
    try {
      clearTimeout(timer)
    } catch {}
  })
}

async function fetchText(
  url: string,
  timeoutMs: number,
  options: any = {},
): Promise<{ text: string; status: number; headers: any }> {
  const response: any = await withTimeout(
    fetch(url, {
      headers: {
        Accept: "text/plain,application/json,*/*",
        "Accept-Language": "en",
        "User-Agent":
          "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
        ...(options.headers || {}),
      },
      method: options.method,
      body: options.body,
    } as any),
    timeoutMs,
    url,
  )
  const text = String(await withTimeout(response.text() as Promise<string>, timeoutMs, ` body`))
  return { text, status: Number(response.status || 0), headers: response.headers || {} }
}

async function fetchStatus(
  url: string,
  timeoutMs: number,
  options: any = {},
): Promise<{ status: number; headers: any }> {
  const response: any = await withTimeout(
    fetch(url, {
      headers: {
        Accept: "*/*",
        "Accept-Language": "en",
        "User-Agent":
          "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
        ...(options.headers || {}),
      },
      method: options.method || "HEAD",
      body: options.body,
    } as any),
    timeoutMs,
    url,
  )
  return { status: Number(response.status || 0), headers: response.headers || {} }
}

async function fetchJson(url: string, timeoutMs: number): Promise<any> {
  const { text } = await fetchText(url, timeoutMs)
  return JSON.parse(text)
}

function compact(parts: Array<string | null | undefined>) {
  const out: string[] = []
  for (const part of parts) {
    const s = String(part ?? "").trim()
    if (!s || s === "null" || s === "undefined") continue
    if (!out.includes(s)) out.push(s)
  }
  return out.join(" ")
}

function parseAsn(value: any) {
  const raw = String(value ?? "").trim()
  if (!raw) return ""
  const match = raw.match(/AS\s?(\d+)/i)
  return match ? `AS${match[1]}` : raw
}

function parseCloudflareTrace(text: string) {
  const data: Record<string, string> = {}
  text.split(/\n+/).forEach((line) => {
    const idx = line.indexOf("=")
    if (idx <= 0) return
    data[line.slice(0, idx)] = line.slice(idx + 1)
  })
  return data
}

function plainTextFromHtml(html: string) {
  return String(html || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
}

function isAsnOrg(value: any) {
  return /^AS\d+\b/i.test(String(value || "").trim())
}

function preferredIspName(...values: any[]) {
  for (const value of values) {
    const raw = String(value || "").replace(/\s+/g, " ").trim()
    if (!raw) continue
    if (isAsnOrg(raw)) continue
    return raw
  }
  return ""
}

function pickBetterLocation(candidate: any, current: any) {
  const a = String(candidate || "").trim()
  const b = String(current || "").trim()
  if (!a) return b
  if (!b) return a

  if (
    a.length > b.length &&
    a.length <= 42 &&
    !/邮政|编码|身份证|手机号|天气|查询|验证|在线|工具|更多|新闻|Copyright/i.test(a)
  ) {
    return a
  }

  return b
}

function parseDomesticTextLocation(value: any) {
  let raw = plainTextFromHtml(String(value || ""))
    .replace(/^来自[：:\s]*/i, "")
    .replace(/^归属地[：:\s]*/i, "")
    .replace(/^所在地理位置[：:\s]*/i, "")
    .replace(/中国大陆/g, "中国")
    .replace(/^(中国\s*)+/i, "中国 ")
    .trim()

  if (!raw) return { location: "", isp: "" }

  const ispMatch = raw.match(/(中国电信|电信|中国联通|联通|中国移动|移动|中国广电|广电|教育网|CERNET|铁通)/i)
  const isp = ispMatch ? ispMatch[1].replace(/^中国/, "") : ""

  raw = raw
    .replace(/中国电信|电信|中国联通|联通|中国移动|移动|中国广电|广电|教育网|CERNET|铁通/gi, " ")
    .replace(/省|市|区|县/g, " ")
    .replace(/\s+/g, " ")
    .trim()

  raw = raw.replace(/^(中国\s*)+/i, "中国 ").trim()
  if (raw && !/^中国(?:\s|$)/.test(raw)) raw = `中国 ${raw}`
  raw = raw.replace(/^(中国\s*){2,}/i, "中国 ").trim()

  return { location: raw, isp }
}

function parseIp138Current(text: string) {
  const plain = plainTextFromHtml(text)
  const ip =
    plain.match(/(?:IP|iP)地址是[：:\s]*\[?\s*(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] ||
    plain.match(/\b(\d{1,3}(?:\.\d{1,3}){3})\b/)?.[1] ||
    ""

  const locRaw =
    plain.match(/来自[：:\s]*(.+?)(?:\s+ip查询api接口|\s+安卓SDK|$)/i)?.[1] ||
    plain.match(/归属地[：:\s]*(.+?)(?:\s+ip查询api接口|\s+安卓SDK|$)/i)?.[1] ||
    ""

  const parsed = parseDomesticTextLocation(locRaw)

  return {
    ip,
    location: parsed.location,
    isp: parsed.isp,
    org: parsed.isp,
  }
}

function parseMyIpCn(text: string) {
  const plain = plainTextFromHtml(text)
  const ip =
    plain.match(/ip[：:\s]*(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] ||
    plain.match(/\b(\d{1,3}(?:\.\d{1,3}){3})\b/)?.[1] ||
    ""

  const locRaw =
    plain.match(/归属地[：:\s]*(.+?)$/i)?.[1] ||
    plain.replace(/^.*?归属地[：:\s]*/i, "")

  const parsed = parseDomesticTextLocation(locRaw)

  return {
    ip,
    location: parsed.location,
    isp: parsed.isp,
    org: parsed.isp,
  }
}

async function source(
  id: string,
  name: string,
  kind: IpSourceKind,
  timeoutMs: number,
  loader: SourceFetcher,
): Promise<IpSourceResult> {
  const start = Date.now()
  try {
    const data = await loader(timeoutMs)
    const latencyMs = Date.now() - start
    return {
      id,
      name,
      kind,
      ok: Boolean(data.ip),
      latencyMs,
      ...data,
    }
  } catch (error) {
    return {
      id,
      name,
      kind,
      ok: false,
      latencyMs: Date.now() - start,
      error: errToString(error),
    }
  }
}

async function fetchIp138ByYear(year: number, timeoutMs: number): Promise<Partial<IpSourceResult>> {
  const { text } = await fetchText(`https://${year}.ip138.com/`, timeoutMs, {
    headers: {
      Accept: "text/html,text/plain,*/*",
      Referer: "https://ip.skk.moe/",
    },
  })
  const parsed = parseIp138Current(text)
  if (!parsed.ip && !parsed.location) throw new Error(`iP138 ${year} parse failed`)
  return parsed
}

async function loadIpip(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  // 同步 ip.skk.moe 的国内 iP138 来源：year.ip138.com。
  // 注意不能固定 2026；HAR 里 2026 失败、2025 成功，所以这里按年份回退。
  const currentYear = new Date().getFullYear()
  const years: number[] = []
  ;[currentYear, currentYear - 1, currentYear + 1, 2026, 2025, 2024].forEach((year) => {
    if (!years.includes(year)) years.push(year)
  })

  let lastError: any = null

  for (const year of years) {
    try {
      return await fetchIp138ByYear(year, timeoutMs)
    } catch (error) {
      lastError = error
    }
  }

  throw lastError || new Error("iP138 failed")
}

async function loadBilibili(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  // 保持函数名，实际同步 ip.skk.moe 里的 IP.cn 查询网来源：my.ip.cn。
  const { text } = await fetchText("https://my.ip.cn/", timeoutMs, {
    headers: {
      Accept: "text/html,text/plain,*/*",
      Referer: "https://ip.skk.moe/",
    },
  })
  const parsed = parseMyIpCn(text)
  if (!parsed.ip && !parsed.location) throw new Error("IP.cn parse failed")
  return parsed
}

async function loadIpApi(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  const data = await fetchJson("http://ip-api.com/json?lang=zh-CN", timeoutMs)
  if (data?.status && data.status !== "success") throw new Error("ip-api failed")
  return {
    ip: data?.query,
    countryCode: data?.countryCode,
    location: compact([data?.country, data?.regionName, data?.city]),
    isp: preferredIspName(data?.isp, data?.org),
    org: data?.org,
    asn: String(data?.as || "").trim() || parseAsn(data?.as),
  }
}

async function loadIpSb(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  const data = await fetchJson("https://api-ipv4.ip.sb/geoip", timeoutMs)
  return {
    ip: data?.ip,
    countryCode: data?.country_code,
    location: compact([data?.country, data?.region, data?.city]),
    isp: preferredIspName(data?.isp, data?.organization, data?.asn_organization),
    org: compact([data?.organization || data?.asn_organization]),
    asn: data?.asn
      ? compact([`AS${data.asn}`, data?.asn_organization || data?.organization])
      : parseAsn(data?.asn),
  }
}

async function loadIpInfo(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  // 不使用 ip.api.skk.moe/v1/ipinfo-simple：
  // Scriptable 直连时可能得到 API/边缘自身信息；这里恢复真实客户端直连 IPinfo。
  const data = await fetchJson("https://ipinfo.io/json", timeoutMs)
  return {
    ip: data?.ip,
    countryCode: data?.country,
    location: compact([data?.country, data?.region, data?.city]),
    isp: data?.org,
    org: data?.org,
    asn: data?.org,
  }
}

async function loadCloudflare(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  // 同站点 trace，和 ip.skk.moe 的 Cloudflare 口径更接近。
  const { text } = await fetchText("https://ip.skk.moe/cdn-cgi/trace", timeoutMs)
  const data = parseCloudflareTrace(text)
  return {
    ip: data.ip,
    countryCode: data.loc,
    location: data.loc,
    isp: data.colo ? `Cloudflare ${data.colo}` : "Cloudflare",
    org: data.colo ? `Cloudflare ${data.colo}` : "Cloudflare",
    extra: compact([data.http, data.tls, data.warp === "on" ? "WARP" : ""]),
  }
}

async function loadIpv6IpSb(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  const data = await fetchJson("https://api-ipv6.ip.sb/geoip", timeoutMs)
  return {
    ip: data?.ip,
    countryCode: data?.country_code,
    location: compact([data?.country, data?.region, data?.city]),
    isp: preferredIspName(data?.isp, data?.organization, data?.asn_organization),
    org: compact([data?.organization || data?.asn_organization]),
    asn: data?.asn
      ? compact([`AS${data.asn}`, data?.asn_organization || data?.organization])
      : parseAsn(data?.asn),
  }
}

async function loadIpv6Plain(timeoutMs: number): Promise<Partial<IpSourceResult>> {
  const { text } = await fetchText("https://api6.ipify.org", timeoutMs)
  return { ip: text.trim() }
}

function getHeader(headers: any, name: string) {
  const lower = name.toLowerCase()
  try {
    if (headers?.get) return headers.get(name) || headers.get(lower) || ""
    for (const key of Object.keys(headers || {})) {
      if (key.toLowerCase() === lower) return String(headers[key] ?? "")
    }
  } catch {}
  return ""
}

function countryFromText(text: string) {
  const content = String(text || "")
  const patterns = [
    /loc=([A-Z]{2})/,
    /"countryCode"\s*:\s*"([A-Z]{2})"/i,
    /"INNERTUBE_CONTEXT_GL"\s*:\s*"([A-Z]{2})"/i,
    /"GL"\s*:\s*"([A-Z]{2})"/i,
    /"gl"\s*:\s*"([A-Z]{2})"/i,
    /data-country=["']([A-Z]{2})["']/i,
    /[?&]gl=([A-Z]{2})(?:[&"'\\]|$)/i,
  ]

  for (const pattern of patterns) {
    const m = content.match(pattern)
    if (m?.[1]) return m[1].toUpperCase()
  }
  return ""
}

function responseCountryCode(text = "", headers: any = {}) {
  const fromHeader =
    getHeader(headers, "cf-ipcountry") ||
    getHeader(headers, "x-country-code") ||
    getHeader(headers, "x-region-code") ||
    getHeader(headers, "x-geo-country")
  const cc = String(fromHeader || "").trim().toUpperCase()
  if (/^[A-Z]{2}$/.test(cc)) return cc
  return countryFromText(text)
}

function serviceState(ok: boolean, statusText = "") {
  if (!ok) return statusText || "不可达"
  return statusText || "可用"
}

async function service(
  id: string,
  name: string,
  region: ServiceRegion,
  timeoutMs: number,
  loader: (timeoutMs: number) => Promise<Partial<ServiceResult>>,
): Promise<ServiceResult> {
  const start = Date.now()
  try {
    const data = await withTimeout(loader(timeoutMs), timeoutMs + 800, `${name} service`)
    return {
      id,
      name,
      region,
      ok: data.ok === true,
      latencyMs: Date.now() - start,
      statusText: serviceState(data.ok === true, data.statusText),
      ...data,
    }
  } catch (error) {
    return {
      id,
      name,
      region,
      ok: false,
      latencyMs: Date.now() - start,
      statusText: "不可达",
      error: errToString(error),
    }
  }
}

async function testBasicService(
  target: (typeof BASIC_SERVICE_TARGETS)[number],
  timeoutMs: number,
): Promise<ServiceResult> {
  return service(target.id, target.name, target.region, timeoutMs, async (ms) => {
    const r = await fetchText(target.url, ms)
    const ok = r.status === 0 || (r.status >= 200 && r.status < 500)
    return { ok, status: r.status, statusText: ok ? "可用" : `HTTP ${r.status}` }
  })
}

async function fetchYouTubeRegion(timeoutMs: number) {
  const headers = {
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
    Cookie: "CONSENT=YES+cb",
  }

  const urls = [
    "https://m.youtube.com/?persist_app=1&app=m&hl=en",
    "https://www.youtube.com/premium?persist_app=1&app=desktop&hl=en",
  ]

  let last: { text: string; status: number; headers: any } | null = null

  for (const url of urls) {
    try {
      const r = await fetchText(url, timeoutMs, { method: "GET", headers })
      last = r
      const cc = countryFromText(r.text) || responseCountryCode(r.text, r.headers)
      if (/^[A-Z]{2}$/.test(cc)) return { response: r, countryCode: cc }
    } catch {}
  }

  if (last) return { response: last, countryCode: "" }
  throw new Error("YouTube region unavailable")
}

async function testYouTube(timeoutMs: number) {
  return service("youtube", "YouTube", "流媒体", timeoutMs, async (ms) => {
    const { response: r, countryCode: cc } = await fetchYouTubeRegion(ms)
    const ok = r.status >= 200 && r.status < 500
    return {
      ok,
      status: r.status,
      countryCode: /^[A-Z]{2}$/.test(cc) ? cc : "",
      statusText: ok ? "可用" : "不可达",
    }
  })
}

async function testChatGPT(timeoutMs: number) {
  return service("chatgpt", "ChatGPT", "AI", timeoutMs, async (ms) => {
    const r = await fetchText("https://chatgpt.com/cdn-cgi/trace", ms)
    const cc = countryFromText(r.text)
    const ok = r.status >= 200 && r.status < 500 && Boolean(cc)
    return { ok, status: r.status, countryCode: cc, statusText: ok ? "可用" : "受限" }
  })
}

async function testOpenAIAPI(timeoutMs: number) {
  return service("openai_api", "OpenAI API", "AI", timeoutMs, async (ms) => {
    const r = await fetchText("https://api.openai.com/v1/models", ms)
    const cc = getHeader(r.headers, "cf-ipcountry").toUpperCase()
    const ok = r.status === 401 || r.status === 403 || (r.status >= 200 && r.status < 500)
    return { ok, status: r.status, countryCode: cc, statusText: ok ? "可达" : "不可达" }
  })
}

const NF_ORIGINAL = "80018499"
const NF_NON_ORIGINAL = "81280792"

function parseNetflixRegion(text: string, headers: any) {
  const origin = getHeader(headers, "x-originating-url") || getHeader(headers, "x-origining-url")
  const fromHeader = String(origin || "").match(/\/([A-Z]{2})(?:[-/]|$)/i)
  if (fromHeader) return fromHeader[1].toUpperCase()
  return countryFromText(text)
}

async function fetchNetflixTitle(id: string, timeoutMs: number) {
  return fetchText(`https://www.netflix.com/title/${id}`, timeoutMs)
}

async function testNetflix(timeoutMs: number) {
  return service("netflix", "Netflix", "流媒体", timeoutMs, async (ms) => {
    const r1 = await fetchNetflixTitle(NF_NON_ORIGINAL, ms)
    if (r1.status === 403) return { ok: false, status: r1.status, statusText: "区域受限" }
    if (r1.status === 404) {
      const r2 = await fetchNetflixTitle(NF_ORIGINAL, ms)
      if (r2.status === 200) {
        return {
          ok: true,
          status: r2.status,
          countryCode: parseNetflixRegion(r2.text, r2.headers),
          statusText: "仅自制",
          detail: "Originals",
        }
      }
      return { ok: false, status: r2.status, statusText: "区域受限" }
    }
    const ok = r1.status === 200
    return {
      ok,
      status: r1.status,
      countryCode: parseNetflixRegion(r1.text, r1.headers),
      statusText: ok ? "完整解锁" : `HTTP ${r1.status}`,
    }
  })
}

async function testDisney(timeoutMs: number) {
  return service("disney", "Disney+", "流媒体", timeoutMs, async (ms) => {
    const r = await fetchText("https://www.disneyplus.com/", ms, {
      headers: { "Accept-Language": "en" },
    })
    const blocked = /not\s+available|Sorry,\s*Disney\+\s*is\s*not\s*available/i.test(r.text || "")
    const ok = r.status === 200 && !blocked
    return {
      ok,
      status: r.status,
      countryCode: ok ? countryFromText(r.text) : "",
      statusText: ok ? "可用" : "区域受限",
    }
  })
}

async function testMax(timeoutMs: number) {
  return service("max", "Max", "流媒体", timeoutMs, async (ms) => {
    const r = await fetchText("https://www.max.com/", ms)
    const blocked = /not\s+available\s+in\s+your\s+region|country\s+not\s+supported/i.test(r.text || "")
    const ok = r.status >= 200 && r.status < 500 && !blocked
    return {
      ok,
      status: r.status,
      countryCode: ok ? countryFromText(r.text) : "",
      statusText: ok ? "可用" : "区域受限",
    }
  })
}

async function testSpotify(timeoutMs: number) {
  return service("spotify", "Spotify", "流媒体", timeoutMs, async (ms) => {
    const r = await fetchText("https://www.spotify.com/", ms)
    const ok = r.status >= 200 && r.status < 500
    return { ok, status: r.status, countryCode: countryFromText(r.text), statusText: ok ? "可用" : "不可达" }
  })
}

async function testYouTubeFast(timeoutMs: number) {
  return service("youtube", "YouTube", "流媒体", timeoutMs, async (ms) => {
    const r = await fetchStatus("https://www.youtube.com/generate_204", ms, { method: "GET" })
    const ok = r.status === 204 || (r.status >= 200 && r.status < 500)
    return {
      ok,
      status: r.status,
      countryCode: responseCountryCode("", r.headers),
      statusText: ok ? "可用" : "不可达",
    }
  })
}

async function testSpotifyFast(timeoutMs: number) {
  return service("spotify", "Spotify", "流媒体", timeoutMs, async (ms) => {
    try {
      const r = await fetchText(
        "https://spclient.wg.spotify.com/signup/public/v1/account?validate=1&email=scripting-ipinfo-test%40example.com",
        ms,
        { headers: { Accept: "application/json,*/*" } },
      )
      let country = responseCountryCode(r.text, r.headers)
      try {
        const json = JSON.parse(r.text || "{}")
        country = String(json.country || json.countryCode || country || "").trim().toUpperCase()
      } catch {}
      const ok = r.status >= 200 && r.status < 500
      return {
        ok,
        status: r.status,
        countryCode: /^[A-Z]{2}$/.test(country) ? country : "",
        statusText: ok ? "可用" : "不可达",
      }
    } catch {
      const r = await fetchStatus("https://www.spotify.com/", ms, { method: "HEAD" })
      const ok = r.status >= 200 && r.status < 500
      return {
        ok,
        status: r.status,
        countryCode: responseCountryCode("", r.headers),
        statusText: ok ? "可用" : "不可达",
      }
    }
  })
}

async function testNetflixFast(timeoutMs: number) {
  return service("netflix", "Netflix", "流媒体", timeoutMs, async (ms) => {
    const r = await fetchStatus("https://www.netflix.com/title/81280792", ms, { method: "HEAD" })
    const ok = r.status >= 200 && r.status < 500 && r.status !== 403
    const statusText = r.status === 403 ? "区域受限" : ok ? "可达" : `HTTP ${r.status}`
    const countryCode = parseNetflixRegion("", r.headers) || responseCountryCode("", r.headers)
    return { ok, status: r.status, countryCode, statusText }
  })
}

async function testDisneyFast(timeoutMs: number) {
  return service("disney", "Disney+", "流媒体", timeoutMs, async (ms) => {
    const r = await fetchStatus("https://www.disneyplus.com/", ms, {
      method: "HEAD",
      headers: { "Accept-Language": "en" },
    })
    const ok = r.status >= 200 && r.status < 500
    return {
      ok,
      status: r.status,
      countryCode: responseCountryCode("", r.headers),
      statusText: ok ? "可达" : "区域受限",
    }
  })
}

async function testMaxFast(timeoutMs: number) {
  return service("max", "Max", "流媒体", timeoutMs, async (ms) => {
    const r = await fetchStatus("https://www.max.com/", ms, { method: "HEAD" })
    const ok = r.status >= 200 && r.status < 500
    return {
      ok,
      status: r.status,
      countryCode: responseCountryCode("", r.headers),
      statusText: ok ? "可达" : "区域受限",
    }
  })
}

function selectedServiceIds(settings: SkkIpInfoSettings) {
  const selected: string[] = []
  if (settings.serviceYouTube) selected.push("youtube")
  if (settings.serviceChatGPT) selected.push("chatgpt")
  if (settings.serviceSpotify) selected.push("spotify")
  if (settings.serviceNetflix) selected.push("netflix")
  if (settings.serviceDisney) selected.push("disney")
  if (settings.serviceMax) selected.push("max")
  return selected
}

async function runServiceChecks(
  timeoutMs: number,
  settings: SkkIpInfoSettings,
): Promise<ServiceResult[]> {
  const ms = Math.max(1000, Math.min(3000, timeoutMs || 3000))
  const taskMap: Record<string, () => Promise<ServiceResult>> = {
    youtube: () => testYouTube(ms),
    chatgpt: () => testChatGPT(ms),
    spotify: () => testSpotifyFast(ms),
    netflix: () => testNetflix(ms),
    disney: () => testDisney(ms),
    max: () => testMax(ms),
  }
  const tasks = selectedServiceIds(settings)
    .map((id) => taskMap[id])
    .filter((fn): fn is () => Promise<ServiceResult> => typeof fn === "function")
  if (!tasks.length) return []
  return Promise.all(tasks.map((task) => task()))
}

function firstOk(sources: IpSourceResult[], kind: IpSourceKind) {
  return sources.find((item) => item.kind === kind && item.ok && item.ip)
}

function firstOkById(sources: IpSourceResult[], ids: string[]) {
  for (const id of ids) {
    const found = sources.find((item) => item.id === id && item.ok && item.ip)
    if (found) return found
  }
  return undefined
}

function sameIp(a?: string, b?: string) {
  return Boolean(a && b && String(a).trim() === String(b).trim())
}

function enrichSources(sources: IpSourceResult[]) {
  return sources.map((item) => {
    if (!item) return item

    // 国际来源必须保持各自口径：
    // Cloudflare 就显示 Cloudflare，IPinfo 就显示 IPinfo，不再被同 IP 的其它来源覆盖。
    if (item.kind !== "domestic") return item

    let location = item.location
    const sameDomestic = sources.filter(
      (source) =>
        source?.ip &&
        item.ip &&
        source.ip === item.ip &&
        source.kind === "domestic",
    )

    sameDomestic.forEach((source) => {
      location = pickBetterLocation(source.location, location)
    })

    return {
      ...item,
      location,
    }
  })
}

const RISK_RULES = {
  dataCenterKeywords: [
    "datacenter",
    "data center",
    "hosting",
    "cloud",
    "cdn",
    "edge",
    "vps",
    "colo",
    "colocation",
    "proxy",
    "vpn",
    "tunnel",
    "relay",
    "compute",
    "server",
    "amazon",
    "aws",
    "google",
    "gcp",
    "microsoft",
    "azure",
    "digitalocean",
    "linode",
    "ovh",
    "hetzner",
    "vultr",
    "oracle",
    "alibaba cloud",
    "tencent cloud",
    "cloudflare",
    "fastly",
    "akamai",
    "leaseweb",
    "choopa",
    "dmit",
    "racknerd",
  ],
  homeBroadbandKeywords: [
    "china telecom",
    "chinanet",
    "ctcc",
    "as4134",
    "as4809",
    "china mobile",
    "cmcc",
    "cmnet",
    "cmi",
    "as9808",
    "china unicom",
    "unicom",
    "cucc",
    "as4837",
    "cernet",
    "china education",
    "comcast",
    "xfinity",
    "verizon",
    "at&t",
    "charter",
    "spectrum",
    "cox",
    "rogers",
    "bell canada",
    "telus",
    "bt",
    "virgin media",
    "sky broadband",
    "deutsche telekom",
    "telefonica",
    "orange",
    "vodafone",
    "isp",
    "broadband",
    "fiber",
    "ftth",
    "residential",
    "cable",
    "docsis",
    "pppoe",
    "dsl",
    "adsl",
    "vdsl",
    "pon",
    "gpon",
    "epon",
    "cpe",
    "dynamic",
    "dyn",
    "pool",
    "subscriber",
    "cust",
    "customer",
    "telecom",
    "communication",
    "communications",
    "as3462",
    "data communication business group",
    "chunghwa telecom",
    "chunghwa",
    "cht",
    "hinet",
    "kbro",
    "formosabroadband",
    "formosa broadband",
    "seednet",
    "taiwan broadband",
    "tbc",
    "cable tv",
    "cablemodem",
  ],
  mobileKeywords: ["mobile", "lte", "4g", "5g", "cell", "cellular", "wireless", "epc", "ims", "gprs", "wimax"],
  highRiskCountries: ["俄罗斯", "russia", "印度", "india", "乌克兰", "ukraine"],
}

const ASN_HOME_STRONG = new Set([3462, 38841])

function parseASNNumber(s?: string) {
  const str = String(s || "")
  const m = str.match(/\bAS(\d{1,10})\b/i)
  if (m) return Number(m[1]) || 0
  const m2 = str.match(/\b(\d{1,10})\b/)
  return m2 ? Number(m2[1]) || 0 : 0
}

function normStr(x?: string) {
  return String(x || "")
    .replace(/\s+/g, " ")
    .replace(/[（(].*?[）)]/g, " ")
    .trim()
    .toLowerCase()
}

function hasAny(hay: string, list: string[]) {
  const raw = normStr(hay)
  if (!raw) return false
  return list.some((kw) => {
    const needle = normStr(kw)
    return Boolean(needle && raw.includes(needle))
  })
}

function riskSubject(data: {
  primaryInternational?: IpSourceResult
  primaryDomestic?: IpSourceResult
}) {
  return data.primaryInternational || data.primaryDomestic
}

function calculateLineRisk(source?: IpSourceResult): RiskInfo {
  const hay = compact([source?.isp, source?.org, source?.asn])
  const country = normStr(source?.location || source?.countryCode)
  const asn = parseASNNumber(source?.asn)
  const reasons: string[] = []
  let score = 0

  const dcHit = hasAny(hay, RISK_RULES.dataCenterKeywords)
  const hbHit = hasAny(hay, RISK_RULES.homeBroadbandKeywords)
  const mobileHit = hasAny(hay, RISK_RULES.mobileKeywords)

  if (dcHit) {
    score += 55
    reasons.push("命中机房/云/托管关键词")
  }
  if (hbHit) {
    const delta = dcHit ? -10 : -22
    score += delta
    reasons.push("命中家宽/接入网关键词")
  }
  if (mobileHit) {
    const delta = dcHit ? 0 : -10
    score += delta
    reasons.push("命中移动网络关键词")
  }
  if (RISK_RULES.highRiskCountries.some((item) => country.includes(normStr(item)))) {
    score += 18
    reasons.push("地区存在额外风险")
  }
  if (!hay || hay.length <= 3) {
    score += 10
    reasons.push("落地信息不足")
  }

  score = Math.max(0, Math.min(100, Math.round(score)))

  const hbEvidence = (hbHit ? 1 : 0) + (ASN_HOME_STRONG.has(asn) ? 1 : 0)
  const dcEvidence = dcHit ? 1 : 0
  const tunnelLike = dcEvidence >= 1 || score >= 70
  const isHomeBroadband =
    hbEvidence >= 2 && !tunnelLike && score <= 50
      ? true
      : hbEvidence >= 1 && dcEvidence === 0 && !tunnelLike && score <= 38

  const lineType = isHomeBroadband ? "家宽" : "非家宽"
  const subtype = mobileHit
    ? "移动网络"
    : tunnelLike
      ? "机房/专线特征"
      : isHomeBroadband
        ? "住宅/接入特征"
        : hbEvidence >= 1
          ? "运营商/接入"
          : "普通 ISP"
  const nativeHint = !tunnelLike && score < 55 ? "更像原生" : "可能非原生"
  const tunnelHint = tunnelLike ? "机房/代理特征偏强" : "机房/代理特征偏弱"
  const level: RiskInfo["level"] = score >= 70 ? "高" : score >= 40 ? "中" : "低"
  const title =
    level === "高"
      ? "机房/代理特征"
      : level === "中"
        ? `${lineType} · ${nativeHint}`
        : `${lineType} · ${nativeHint}`

  return {
    score,
    level,
    title,
    lineType,
    subtype,
    nativeHint,
    tunnelHint,
    items: [lineType, nativeHint, tunnelHint, subtype, ...reasons].slice(0, 5),
  }
}

function computeRisk(
  sources: IpSourceResult[],
  services: ServiceResult[],
  data: {
    primaryDomestic?: IpSourceResult
    primaryInternational?: IpSourceResult
    primaryIPv6?: IpSourceResult
  },
): RiskInfo {
  void sources
  void services
  return calculateLineRisk(riskSubject(data))
}


export async function fetchNetworkInfo(settings: SkkIpInfoSettings): Promise<NetworkInfoData> {
  const timeoutMs = Math.max(1000, Math.min(15000, settings.timeoutMs || 3000))
  const sourceTasks: Array<Promise<IpSourceResult>> = [
    source("ipip", "iP138.com", "domestic", timeoutMs, loadIpip),
    source("bilibili", "IP.cn 查询网", "domestic", timeoutMs, loadBilibili),
    source("ipapi", "IP-API", "international", timeoutMs, loadIpApi),
    source("ipsb", "IP.SB", "international", timeoutMs, loadIpSb),
    source("cloudflare", "Cloudflare", "cloudflare", timeoutMs, loadCloudflare),
    source("ipinfo", "IPinfo.io", "international", timeoutMs, loadIpInfo),
  ]

  if (settings.enableIPv6) {
    sourceTasks.push(source("ipv6_ipsb", "IPv6 IP.SB", "ipv6", timeoutMs, loadIpv6IpSb))
    sourceTasks.push(source("ipv6_ipify", "IPv6 IPify", "ipv6", timeoutMs, loadIpv6Plain))
  }

  const sourcesPromise = Promise.all(sourceTasks)
  const servicesPromise = settings.enableConnectivity
    ? runServiceChecks(timeoutMs, settings)
    : Promise.resolve([] as ServiceResult[])
  const [rawSources, services] = await Promise.all([sourcesPromise, servicesPromise])
  const sources = enrichSources(rawSources)
  const primaryDomestic = firstOk(sources, "domestic")
  const primaryInternational =
    firstOkById(sources, ["ipsb", "ipapi", "cloudflare", "ipinfo"]) ||
    firstOk(sources, "international") ||
    firstOk(sources, "cloudflare")
  const primaryIPv6 = firstOk(sources, "ipv6")

  const data: NetworkInfoData = {
    updatedAt: Date.now(),
    sources,
    services,
    connectivity: services,
    primaryDomestic,
    primaryInternational,
    primaryIPv6,
    risk: computeRisk(sources, services, {
      primaryDomestic,
      primaryInternational,
      primaryIPv6,
    }),
  }

  if (!sources.some((item) => item.ok)) {
    throw new Error("所有 IP 探针均请求失败")
  }

  return data
}
