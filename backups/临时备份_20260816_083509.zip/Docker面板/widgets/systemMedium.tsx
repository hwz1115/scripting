import {
    Text,
    VStack,
    HStack,
    Image,
    Color,
    Divider,
    Spacer,
    Button,
    gradient,
} from "scripting";
import { DockerInfoData } from "./type";
import { reloadWidget } from "../app_intents";
import { formatMemory } from "../utils/format";

export function View({ data }: { data: DockerInfoData }) {
    const {
        Name,
        Version,
        CPUs,
        Memory,
        Containers,
        Running,
        Stopped,
        Images,
    } = data;
    const dividerLength = 27;
    const dividerColor = "rgba(0,0,0,0.12)";
    return (
        <VStack
            padding
            background={gradient("linear", {
                colors: ["rgba(255,255,255,1)", "rgba(120,175,220,1)"],
                startPoint: "top",
                endPoint: "bottom",
            })}>
            <HStack padding={{ leading: true, trailing: true }}>
                <Text bold foregroundStyle="black">{Name}</Text>
                <Spacer />
                <Button buttonStyle={"plain"} intent={reloadWidget(undefined)}>
                    <Image
                        systemName={"arrow.clockwise"}
                        foregroundStyle={"systemBlue"}
                    />
                </Button>
                <Text foregroundStyle="rgba(0,0,0,0.55)">{Version}</Text>
            </HStack>
            <Spacer />
            <HStack>
                <ArgView
                    icon="play"
                    title="运行"
                    body={Running.toString()}
                    color="systemGreen"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="stop"
                    title="停止"
                    body={Stopped.toString()}
                    color="systemRed"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="cube.box"
                    title="总计"
                    body={Containers.toString()}
                    color="black"
                />
            </HStack>
            <Spacer />
            <HStack>
                <ArgView
                    icon="cpu"
                    title="CPU"
                    body={CPUs.toString()}
                    color="systemOrange"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="memorychip"
                    title="内存"
                    body={formatMemory(Memory)}
                    color="systemPurple"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="cube"
                    title="镜像"
                    body={Images.toString()}
                    color="systemBlue"
                />
            </HStack>
        </VStack>
    );
}

function ArgView({
    icon,
    title,
    body,
    color,
}: {
    icon: string;
    title: string;
    body: string;
    color: Color;
}) {
    return (
        <VStack>
            <HStack foregroundStyle={"rgba(0,0,0,0.5)"}>
                <Spacer />
                <Image systemName={icon} />
                <Text>{title}</Text>
                <Spacer />
            </HStack>
            <Text
                bold
                foregroundStyle={color}
                lineLimit={1}
                allowsTightening={true}>
                {body}
            </Text>
        </VStack>
    );
}
