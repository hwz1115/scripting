import {
    Text,
    VStack,
    HStack,
    Image,
    Color,
    Divider,
    Spacer,
    ZStack,
    gradient,
} from "scripting";
import { DockerInfoData } from "./type";
import { formatMemory } from "../utils/format";

export function View({ data }: { data: DockerInfoData }) {
    const { CPUs, Memory, Running, Stopped } = data;
    const dividerColor = "rgba(0,0,0,0.12)";
    return (
        <ZStack
            background={gradient("linear", {
                colors: ["rgba(255,255,255,1)", "rgba(120,175,220,1)"],
                startPoint: "top",
                endPoint: "bottom",
            })}>
            <VStack>
                <Spacer />
                <HStack>
                    <ArgView
                        icon="play"
                        title="运行"
                        body={Running.toString()}
                        color="systemGreen"
                    />
                    <ArgView
                        icon="stop"
                        title="停止"
                        body={Stopped.toString()}
                        color="systemRed"
                    />
                </HStack>
                <Spacer />
                <HStack>
                    <ArgView
                        icon="cpu"
                        title="CPU"
                        body={CPUs.toString()}
                        color="systemOrange"
                    />
                    <ArgView
                        icon="memorychip"
                        title="内存"
                        body={formatMemory(Memory)}
                        color="systemPurple"
                    />
                </HStack>
                <Spacer />
            </VStack>
            <Divider padding overlay={dividerColor} />
            <Divider padding rotationEffect={90} overlay={dividerColor} />
        </ZStack>
    );
}

function ArgView({
    icon,
    title,
    body,
    color,
}: {
    icon: string;
    title: string;
    body: string;
    color: Color;
}) {
    return (
        <VStack>
            <HStack foregroundStyle={"rgba(0,0,0,0.5)"} font={13}>
                <Spacer />
                <Image systemName={icon} />
                <Text>{title}</Text>
                <Spacer />
            </HStack>
            <Text
                bold
                foregroundStyle={color}
                padding={{ top: 2 }}
                lineLimit={1}
                allowsTightening={true}>
                {body}
            </Text>
        </VStack>
    );
}
