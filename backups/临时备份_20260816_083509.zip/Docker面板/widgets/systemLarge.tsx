import {
    Text,
    VStack,
    HStack,
    Image,
    Color,
    Divider,
    Spacer,
    Button,
    gradient,
} from "scripting";
import { DockerInfoData } from "./type";
import { reloadWidget } from "../app_intents";
import { formatMemory } from "../utils/format";

export function View({ data }: { data: DockerInfoData }) {
    const {
        Name,
        Version,
        CPUs,
        Memory,
        Containers,
        Running,
        Stopped,
        Images,
        OperatingSystem,
        OSType,
        Architecture,
    } = data;

    const dividerLength = 37;
    const dividerColor = "rgba(0,0,0,0.12)";

    return (
        <VStack
            padding
            background={gradient("linear", {
                colors: ["rgba(255,255,255,1)", "rgba(120,175,220,1)"],
                startPoint: "top",
                endPoint: "bottom",
            })}>
            <HStack padding={{ leading: true, trailing: true }}>
                <VStack alignment={"leading"}>
                    <Text bold font={32} foregroundStyle="black">
                        {Name}
                    </Text>
                    <Text foregroundStyle="rgba(0,0,0,0.55)">{Version}</Text>
                </VStack>

                <Spacer />

                <Button buttonStyle={"plain"} intent={reloadWidget(undefined)}>
                    <Image
                        font={24}
                        systemName={"arrow.clockwise"}
                        foregroundStyle={"systemBlue"}
                    />
                </Button>
            </HStack>

            <Divider overlay={dividerColor} />
            <Spacer />
            <HStack>
                <ArgView
                    icon="play"
                    title="运行"
                    body={Running.toString()}
                    color="systemGreen"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="stop"
                    title="停止"
                    body={Stopped.toString()}
                    color="systemRed"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="cube.box"
                    title="总计"
                    body={Containers.toString()}
                    color="black"
                />
            </HStack>
            <Spacer />
            <HStack>
                <ArgView
                    icon="cpu"
                    title="CPU"
                    body={CPUs.toString()}
                    color="systemOrange"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="memorychip"
                    title="内存"
                    body={formatMemory(Memory)}
                    color="systemPurple"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="cube"
                    title="镜像"
                    body={Images.toString()}
                    color="systemBlue"
                />
            </HStack>
            <Spacer />
            <HStack padding={{ bottom: true }}>
                <ArgView
                    icon="gearshape"
                    title="系统"
                    body={OperatingSystem}
                    color="rgba(30,30,40,1)"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="doc.plaintext"
                    title="类型"
                    body={OSType}
                    color="systemIndigo"
                />
                <Divider frame={{ height: dividerLength }} overlay={dividerColor} />
                <ArgView
                    icon="cube.transparent"
                    title="架构"
                    body={Architecture}
                    color="systemBrown"
                />
            </HStack>
        </VStack>
    );
}

function ArgView({
    icon,
    title,
    body,
    color,
}: {
    icon: string;
    title: string;
    body: string;
    color: Color;
}) {
    return (
        <VStack>
            <HStack foregroundStyle={"rgba(0,0,0,0.5)"}>
                <Spacer />
                <Image systemName={icon} />
                <Text>{title}</Text>
                <Spacer />
            </HStack>
            <Text
                bold
                foregroundStyle={color}
                padding={{ top: 4 }}
                lineLimit={1}
                allowsTightening={true}>
                {body}
            </Text>
        </VStack>
    );
}
