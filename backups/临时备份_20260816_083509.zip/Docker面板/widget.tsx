import { Widget, Text, Notification } from "scripting";
import { DockerInfoData } from "./widgets/type";

// 改成你 NAS 的 WireGuard 内网 IP + docker-socket-proxy 暴露的端口
// 例如："http://10.6.0.1:2375"
const PROXY_BASE_URL = "http://192.168.5.5:2375";

// import { View as accessoryRectangularView } from "./widgets/accessoryRectangular";
// import { View as accessoryCircularView } from "./widgets/accessoryCircular";
// import { View as accessoryInlineView } from "./widgets/accessoryInline";
import { View as SystemSmallView } from "./widgets/systemSmall";
import { View as SystemMediumView } from "./widgets/systemMedium";
import { View as SystemLargeView } from "./widgets/systemLarge";

(async () => {
  // docker-socket-proxy 直接转发 Docker Engine 原生 API，GET /info 返回的就是
  // dockerd 实时状态，字段名和原来 `docker info --format` 里用的一致
  const response = await fetch(`${PROXY_BASE_URL}/info`);
  if (!response.ok) throw new Error(`请求失败: ${response.status}`);

  const raw = await response.json();
  const data: DockerInfoData = {
    Name: raw.Name,
    Version: raw.ServerVersion,
    CPUs: raw.NCPU,
    Memory: raw.MemTotal,
    Containers: raw.Containers,
    Running: raw.ContainersRunning,
    Stopped: raw.ContainersStopped,
    Images: raw.Images,
    OperatingSystem: raw.OperatingSystem,
    OSType: raw.OSType,
    Architecture: raw.Architecture,
  };

  // if (Widget.parameter) data.Name = Widget.parameter;

  switch (Widget.family) {
    case "systemSmall":
      Widget.present(<SystemSmallView data={data} />);
      break;
    case "systemMedium":
      Widget.present(<SystemMediumView data={data} />);
      break;
    case "systemLarge":
      Widget.present(<SystemLargeView data={data} />);
      break;
    default:
      throw new Error("Unsupported widget size");
  }
})().catch(async (e) => {
  await Notification.schedule({
    title: "错误",
    body: String(e),
  });
  Widget.present(<Text>{String(e)}</Text>);
});
