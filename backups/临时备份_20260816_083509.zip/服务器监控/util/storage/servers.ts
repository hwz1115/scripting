// util/storage/servers.ts
// 存两样东西：
// 1. workerUrl —— 你的 Worker 地址，只填一次
// 2. activeServerId —— 小组件显示哪一台

const workerUrlKey = "workerUrl";
const activeServerIdKey = "activeServerId";

export function getWorkerUrl(): string {
  return Storage.get(workerUrlKey) || "";
}

export function setWorkerUrl(url: string) {
  Storage.set(workerUrlKey, String(url || "").trim());
}

export function getActiveServerId(): string {
  return Storage.get(activeServerIdKey) || "";
}

export function setActiveServerId(id: string) {
  Storage.set(activeServerIdKey, id);
}
