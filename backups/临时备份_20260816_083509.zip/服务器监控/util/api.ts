// util/api.ts
// 只请求一个接口：{WORKER_URL}/api/servers
// 这个接口默认是公开可读的（后台"全局设置"里 is_public 保持开启就行，默认就是开的）。

import { fetch } from "scripting";

export type ServerInfo = {
  id: string;
  name: string;
  region: string;
  os: string;
  cpu: number;
  ram_used: number;
  ram_total: number;
  disk_used: number;
  disk_total: number;
  load_avg: string;
  net_in_speed: number;
  net_out_speed: number;
  net_rx: number;
  net_tx: number;
  net_rx_monthly: number;
  net_tx_monthly: number;
  boot_time: number;
  last_updated: number;
  ping_ct: number;
  ping_cu: number;
  ping_cm: number;
  ping_bd: number;
  price: string;
  currency: string;
  expire_date: string;
};

function toNum(v: any): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function normalizeServer(raw: any): ServerInfo {
  return {
    id: String(raw?.id ?? ""),
    name: String(raw?.name ?? raw?.id ?? "未命名"),
    region: String(raw?.region ?? ""),
    os: String(raw?.os ?? ""),
    cpu: toNum(raw?.cpu),
    ram_used: toNum(raw?.ram_used),
    ram_total: toNum(raw?.ram_total),
    disk_used: toNum(raw?.disk_used),
    disk_total: toNum(raw?.disk_total),
    load_avg: String(raw?.load_avg ?? ""),
    net_in_speed: toNum(raw?.net_in_speed),
    net_out_speed: toNum(raw?.net_out_speed),
    net_rx: toNum(raw?.net_rx),
    net_tx: toNum(raw?.net_tx),
    net_rx_monthly: toNum(raw?.net_rx_monthly),
    net_tx_monthly: toNum(raw?.net_tx_monthly),
    boot_time: toNum(raw?.boot_time),
    last_updated: toNum(raw?.last_updated),
    ping_ct: toNum(raw?.ping_ct),
    ping_cu: toNum(raw?.ping_cu),
    ping_cm: toNum(raw?.ping_cm),
    ping_bd: toNum(raw?.ping_bd),
    price: String(raw?.price ?? ""),
    currency: String(raw?.currency ?? ""),
    expire_date: String(raw?.expire_date ?? ""),
  };
}

// 拉取全部服务器。workerUrl 由用户在设置页里填写，不写死在代码里。
export async function fetchAllServers(workerUrl: string): Promise<ServerInfo[]> {
  const base = String(workerUrl || "").trim().replace(/\/+$/, "");
  if (!base) throw new Error("还没有填 Worker 地址");

  const response = await fetch(`${base}/api/servers`, {
    method: "GET",
    headers: { Accept: "application/json" },
    timeout: 8000,
  } as any);

  if (!response.ok) {
    throw new Error(`接口返回错误状态：${response.status}`);
  }

  const data = await response.json();
  if (!data || !Array.isArray(data.servers)) {
    throw new Error("接口返回的数据格式不对，检查一下地址是不是填对了");
  }

  return data.servers.map(normalizeServer);
}
