// util/format.ts
// 各种数值转成人能看懂的文字，以及一些颜色/图标的小工具函数。

export function formatBytes(bytes: number): string {
  const n = Number(bytes) || 0;
  if (n <= 0) return "0";
  const gb = n / 1024 / 1024 / 1024;
  if (gb >= 1) return gb.toFixed(gb >= 10 ? 0 : 1) + " GB";
  const mb = n / 1024 / 1024;
  return mb.toFixed(0) + " MB";
}

export function formatSpeed(bytesPerSec: number): string {
  const n = Number(bytesPerSec) || 0;
  const kb = n / 1024;
  if (kb >= 1024) return (kb / 1024).toFixed(1) + " MB/s";
  return kb.toFixed(0) + " KB/s";
}

export function formatUptime(bootTimeMs: number): string {
  const boot = Number(bootTimeMs) || 0;
  if (boot <= 0) return "--";
  const seconds = Math.max(0, (Date.now() - boot) / 1000);
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  if (days > 0) return `${days}天${hours}时`;
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours}时${minutes}分`;
}

// 区域代码（如 US / JP / HK）转国旗 emoji，不是标准两位代码就给个地球图标
export function regionToFlag(region: string): string {
  const code = String(region || "").trim().toUpperCase();
  if (code.length !== 2) return "🌐";
  const base = 0x1f1e6;
  const chars = [...code].map((c) => base + (c.charCodeAt(0) - 65));
  if (chars.some((c) => c < base || c > base + 25)) return "🌐";
  return String.fromCodePoint(...chars);
}

// 负载字符串 "0.18 0.14 0.10" 原样展示，格式不对就给个占位
export function formatLoadAvg(loadAvg: string): string {
  const raw = String(loadAvg || "").trim();
  if (!raw) return "0.00 0.00 0.00";
  const parts = raw.split(/\s+/).slice(0, 3);
  while (parts.length < 3) parts.push("0.00");
  return parts.map((p) => (Number(p) || 0).toFixed(2)).join(" ");
}

export function isOnline(lastUpdatedMs: number): boolean {
  const last = Number(lastUpdatedMs) || 0;
  return Date.now() - last < 5 * 60 * 1000; // 5 分钟内有上报就算在线
}

export function percentColor(p: number): string {
  if (p >= 90) return "systemRed";
  if (p >= 70) return "systemOrange";
  return "systemGreen";
}

export function latencyColor(ms: number): string {
  const n = Number(ms) || 0;
  if (n <= 0) return "secondaryLabel";
  if (n >= 200) return "systemRed";
  if (n >= 100) return "systemOrange";
  return "systemGreen";
}

// 系统名字太长会在小组件里挤爆或者被截断得很难看，只取"名字+版本号"这种精简形式
// 例如 "Debian GNU/Linux 11 (bullseye)" -> "Debian 11"
export function formatOsShort(os: string): string {
  const raw = String(os || "").trim();
  if (!raw) return "";
  const firstWord = raw.split(/\s+/)[0] || raw;
  const versionMatch = raw.match(/\d+(\.\d+)?/);
  return versionMatch ? `${firstWord} ${versionMatch[0]}` : firstWord;
}

// 到期日期还剩几天的展示文字，价格/账期没配置就返回空字符串（外层负责决定是否显示这一行）
export function formatExpire(expireDate: string): string {
  const raw = String(expireDate || "").trim();
  if (!raw) return "";
  const date = new Date(raw);
  if (isNaN(date.getTime())) return raw;
  const days = Math.ceil((date.getTime() - Date.now()) / 86400000);
  if (days < 0) return `已到期 ${raw}`;
  if (days === 0) return `今天到期`;
  return `${days} 天后到期`;
}
