// index.tsx
// 在 App 里手动打开这个脚本时，直接进入设置页。

import { Script, Navigation } from "scripting";
import { View } from "./page";

(async () => {
  await Navigation.present({
    element: <View />,
  });
})()
  .catch(async (e) => {
    await Dialog.alert({
      title: "错误",
      message: String(e),
    });
  })
  .finally(Script.exit);
