// widget/card.tsx
// 服务器详情卡片（中尺寸）— v1.1.5 紧凑版 + 延迟三等分胶囊

import { VStack, HStack, Text, Image, Spacer, Gauge } from "scripting";
import { ServerInfo } from "../util/api";
import {
  formatBytes,
  formatSpeed,
  formatUptime,
  formatLoadAvg,
  formatExpire,
  formatOsShort,
  regionToFlag,
  isOnline,
  percentColor,
  latencyColor,
} from "../util/format";

function pct(used: number, total: number): number {
  if (total <= 0) return 0;
  return Math.min(100, Math.round((used / total) * 100));
}

function MetricBlock({
  systemName,
  label,
  value,
  percent,
  accentColor,
}: {
  systemName: string;
  label: string;
  value: string;
  percent: number;
  accentColor: string;
}) {
  return (
    <VStack spacing={2} frame={{ maxWidth: "infinity" }} alignment="leading">
      <HStack spacing={3}>
        <Image
          systemName={systemName}
          foregroundStyle={accentColor}
          imageScale="small"
        />
        <Text font={10} foregroundStyle="secondaryLabel">
          {label}
        </Text>
      </HStack>
      <Text font={18} bold={true} foregroundStyle="primary">
        {value}
      </Text>
      <Gauge
        gaugeStyle="accessoryLinear"
        label={<Text>{""}</Text>}
        value={percent}
        max={100}
        tint={{ color: percentColor(percent) }}
      />
    </VStack>
  );
}

export function ServerCard({ server }: { server: ServerInfo }) {
  const online = isOnline(server.last_updated);
  const ramPct = pct(server.ram_used, server.ram_total);
  const diskPct = pct(server.disk_used, server.disk_total);
  const cpuPct = Math.round(server.cpu);

  const monthlyTraffic = server.net_rx_monthly + server.net_tx_monthly;
  const totalTraffic = server.net_rx + server.net_tx;

  const expireText = formatExpire(server.expire_date);
  const priceText = server.price
    ? `${server.currency || ""}${server.price}`
    : "";
  const loadText = formatLoadAvg(server.load_avg);

  const hasPing =
    server.ping_ct > 0 || server.ping_cu > 0 || server.ping_cm > 0;

  return (
    <VStack
      spacing={7}
      padding={{ top: 10, leading: 12, bottom: 10, trailing: 12 }}
      background="secondarySystemBackground"
      cornerRadius={14}
    >
      {/* 第一行：状态 + 名称 ... 到期 + 国旗/系统 */}
      <HStack spacing={5} alignment="center">
        <Text font={11} foregroundStyle={online ? "systemGreen" : "systemRed"}>
          {"●"}
        </Text>
        <Text font={15} bold={true} foregroundStyle="primary" lineLimit={1}>
          {server.name}
        </Text>
        <Spacer />
        {expireText ? (
          <Text font={10} foregroundStyle="systemOrange" lineLimit={1}>
            {expireText}
          </Text>
        ) : null}
        <Text font={12}>{regionToFlag(server.region)}</Text>
        {server.os ? (
          <Text font={10} foregroundStyle="secondaryLabel" lineLimit={1}>
            {formatOsShort(server.os)}
          </Text>
        ) : null}
      </HStack>

      {!online ? (
        <Text font={12} foregroundStyle="systemRed">
          离线 · 最后上报过久
        </Text>
      ) : (
        <>
          {/* CPU / 内存 / 磁盘 */}
          <HStack spacing={10}>
            <MetricBlock
              systemName="cpu"
              label="CPU"
              value={`${cpuPct}%`}
              percent={cpuPct}
              accentColor="systemBlue"
            />
            <MetricBlock
              systemName="memorychip"
              label="内存"
              value={`${ramPct}%`}
              percent={ramPct}
              accentColor="systemPurple"
            />
            <MetricBlock
              systemName="internaldrive"
              label="磁盘"
              value={`${diskPct}%`}
              percent={diskPct}
              accentColor="systemOrange"
            />
          </HStack>

          {/* 负载 + 开机 + 价格 */}
          <HStack spacing={5} alignment="center">
            <Image
              systemName="chart.bar"
              foregroundStyle="secondaryLabel"
              imageScale="small"
            />
            <Text font={11} foregroundStyle="secondaryLabel">
              {loadText}
            </Text>
            <Text font={11} foregroundStyle="tertiaryLabel">
              ·
            </Text>
            <Image
              systemName="clock"
              foregroundStyle="secondaryLabel"
              imageScale="small"
            />
            <Text font={11} foregroundStyle="secondaryLabel">
              {formatUptime(server.boot_time)}
            </Text>
            {priceText ? (
              <>
                <Text font={11} foregroundStyle="tertiaryLabel">
                  ·
                </Text>
                <Text font={11} foregroundStyle="secondaryLabel" lineLimit={1}>
                  {priceText}
                </Text>
              </>
            ) : null}
          </HStack>

          {/* 速度 + 流量 */}
          <HStack spacing={10} alignment="center">
            <HStack spacing={2}>
              <Image
                systemName="arrow.up.circle.fill"
                foregroundStyle="systemGreen"
                imageScale="small"
              />
              <Text font={12} bold={true} foregroundStyle="primary">
                {formatSpeed(server.net_in_speed)}
              </Text>
            </HStack>
            <HStack spacing={2}>
              <Image
                systemName="arrow.down.circle.fill"
                foregroundStyle="systemBlue"
                imageScale="small"
              />
              <Text font={12} bold={true} foregroundStyle="primary">
                {formatSpeed(server.net_out_speed)}
              </Text>
            </HStack>
            <Spacer />
            <Text font={10} foregroundStyle="tertiaryLabel">
              本月 {formatBytes(monthlyTraffic)} · 累计 {formatBytes(totalTraffic)}
            </Text>
          </HStack>

          {/* 三网延迟：三等分圆角胶囊 */}
          {hasPing ? (
            <HStack spacing={6}>
              <HStack
                spacing={4}
                padding={{ top: 5, bottom: 5 }}
                background="tertiarySystemBackground"
                cornerRadius={8}
                frame={{ maxWidth: "infinity" }}
                alignment="center"
              >
                <Text font={10} foregroundStyle="secondaryLabel">
                  电信
                </Text>
                <Text
                  font={12}
                  bold={true}
                  foregroundStyle={latencyColor(server.ping_ct)}
                >
                  {server.ping_ct > 0
                    ? `${Math.round(server.ping_ct)}ms`
                    : "--"}
                </Text>
              </HStack>
              <HStack
                spacing={4}
                padding={{ top: 5, bottom: 5 }}
                background="tertiarySystemBackground"
                cornerRadius={8}
                frame={{ maxWidth: "infinity" }}
                alignment="center"
              >
                <Text font={10} foregroundStyle="secondaryLabel">
                  联通
                </Text>
                <Text
                  font={12}
                  bold={true}
                  foregroundStyle={latencyColor(server.ping_cu)}
                >
                  {server.ping_cu > 0
                    ? `${Math.round(server.ping_cu)}ms`
                    : "--"}
                </Text>
              </HStack>
              <HStack
                spacing={4}
                padding={{ top: 5, bottom: 5 }}
                background="tertiarySystemBackground"
                cornerRadius={8}
                frame={{ maxWidth: "infinity" }}
                alignment="center"
              >
                <Text font={10} foregroundStyle="secondaryLabel">
                  移动
                </Text>
                <Text
                  font={12}
                  bold={true}
                  foregroundStyle={latencyColor(server.ping_cm)}
                >
                  {server.ping_cm > 0
                    ? `${Math.round(server.ping_cm)}ms`
                    : "--"}
                </Text>
              </HStack>
            </HStack>
          ) : null}
        </>
      )}
    </VStack>
  );
}
