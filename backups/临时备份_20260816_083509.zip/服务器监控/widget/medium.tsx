// widget/medium.tsx
import { VStack, Text } from "scripting";
import { ServerInfo } from "../util/api";
import { ServerCard } from "./card";

export function View({
  server,
  error,
}: {
  server: ServerInfo | null;
  error?: string;
}) {
  if (error) {
    return (
      <VStack
        padding={12}
        spacing={6}
        background="secondarySystemBackground"
        cornerRadius={14}
      >
        <Text font={14} bold={true} foregroundStyle="systemRed">
          出错了
        </Text>
        <Text font={11} foregroundStyle="secondaryLabel">
          {error}
        </Text>
      </VStack>
    );
  }

  if (!server) {
    return (
      <VStack
        padding={12}
        spacing={6}
        background="secondarySystemBackground"
        cornerRadius={14}
      >
        <Text font={13} foregroundStyle="secondaryLabel">
          请先在 App 内的设置页选择要显示的服务器
        </Text>
      </VStack>
    );
  }

  return <ServerCard server={server} />;
}
