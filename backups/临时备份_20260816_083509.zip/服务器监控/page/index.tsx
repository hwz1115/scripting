// page/index.tsx
// App 内的设置页：填 Worker 地址 -> 拉取服务器列表 -> 选一台要显示的服务器。

import {
  Button,
  HStack,
  VStack,
  Image,
  List,
  TextField,
  Section,
  Spacer,
  Text,
  useState,
  Navigation,
  NavigationStack,
  Widget,
} from "scripting";
import { fetchAllServers, ServerInfo } from "../util/api";
import {
  getWorkerUrl,
  setWorkerUrl,
  getActiveServerId,
  setActiveServerId,
} from "../util/storage/servers";

export function View() {
  const dismiss = Navigation.useDismiss();

  const [workerUrlInput, setWorkerUrlInput] = useState<string>(() => getWorkerUrl());
  const [servers, setServers] = useState<ServerInfo[]>([]);
  const [activeId, setActiveIdState] = useState<string>(() => getActiveServerId());
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [loaded, setLoaded] = useState(false);

  function persistActive(id: string) {
    setActiveServerId(id);
    setActiveIdState(id);
  }

  async function loadServers() {
    const url = workerUrlInput.trim();
    if (!url) {
      await Dialog.alert({
        title: "还没填地址",
        message: "先填一下 Worker 地址再拉取列表。",
        buttonLabel: "好的",
      });
      return;
    }

    setLoading(true);
    setLoadError("");
    try {
      setWorkerUrl(url);
      const list = await fetchAllServers(url);
      setServers(list);
      setLoaded(true);

      // 第一次拉到列表、还没选过的话，默认选第一台，省得小组件空着
      if (!getActiveServerId() && list.length > 0) {
        persistActive(list[0].id);
      }
    } catch (e) {
      setLoadError(String((e as Error)?.message || e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <NavigationStack>
      <List
        navigationTitle={"服务器监控设置"}
        toolbar={{
          topBarLeading: [<Button title="完成" action={() => dismiss()} />],
          topBarTrailing: [
            <Button
              title="预览"
              action={async () => {
                await Widget.preview();
              }}
            />,
          ],
        }}>
        <Section
          title="Worker 地址"
          footer={
            <Text foregroundStyle="secondaryLabel">
              就是你部署 CF-Server-Monitor 后台那个网址，不要斜杠结尾。填完点下面"拉取服务器列表"。
            </Text>
          }>
          <TextField
            title="https://你的项目.你的子域.workers.dev"
            value={workerUrlInput}
            onChanged={(v) => setWorkerUrlInput(v ?? "")}
          />
          <Button
            disabled={loading || !workerUrlInput.trim()}
            title={loading ? "拉取中..." : "拉取服务器列表"}
            action={loadServers}
          />
          {loadError ? (
            <Text foregroundStyle="systemRed" font={12}>
              {loadError}
            </Text>
          ) : null}
        </Section>

        <Section
          title="选择要显示的服务器"
          footer={
            <Text foregroundStyle="secondaryLabel">
              点哪台就显示哪台，小组件会跟着变。
            </Text>
          }>
          {!loaded ? (
            <Text foregroundStyle="secondaryLabel">
              还没有拉取过列表，先在上面拉取一次
            </Text>
          ) : servers.length === 0 ? (
            <Text foregroundStyle="secondaryLabel">
              接口没有返回任何服务器，检查一下后台是否已经添加了服务器
            </Text>
          ) : (
            servers.map((server) => (
              <Button
                key={server.id}
                buttonStyle="plain"
                action={() => persistActive(server.id)}>
                <HStack>
                  <Image
                    systemName={
                      server.id === activeId ? "checkmark.circle.fill" : "circle"
                    }
                  />
                  <Text lineLimit={1}>{server.name}</Text>
                  <Spacer />
                  <Text font={11} foregroundStyle="secondaryLabel">
                    {Math.round(server.cpu)}% CPU
                  </Text>
                </HStack>
              </Button>
            ))
          )}
        </Section>
      </List>
    </NavigationStack>
  );
}
