// widget.tsx
// 小组件主入口：只支持中尺寸，显示在 App 设置页里选好的那台服务器。

import { Widget, Text, VStack } from "scripting";
import { View as MediumView } from "./widget/medium";
import { fetchAllServers, ServerInfo } from "./util/api";
import { getWorkerUrl, getActiveServerId } from "./util/storage/servers";

(async () => {
  const workerUrl = getWorkerUrl();

  if (!workerUrl) {
    Widget.present(
      <VStack padding spacing={6}>
        <Text font={13} foregroundStyle="secondaryLabel">
          请先在 App 内的设置页填写 Worker 地址
        </Text>
      </VStack>
    );
    return;
  }

  let allServers: ServerInfo[] = [];
  let fetchError = "";
  try {
    allServers = await fetchAllServers(workerUrl);
  } catch (e) {
    fetchError = String((e as Error)?.message || e);
  }

  const activeId = getActiveServerId();
  const server =
    allServers.find((s) => s.id === activeId) || allServers[0] || null;

  Widget.present(<MediumView server={server} error={fetchError} />);
})().catch((e) => {
  Widget.present(<Text>{String(e)}</Text>);
});
