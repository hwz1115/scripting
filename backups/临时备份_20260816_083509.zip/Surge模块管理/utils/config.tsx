export type AppConfig = {
  baseDir: string
  baseBookmarkName: string
  categories: string[]
  linkPatternsText: string
  downloadConcurrency: number
  iCloudMetadataSync: boolean
  remoteHost: string
  remotePort: string
  remotePassword: string
}

const KEY = "surge_modules_manager_cfg_v1"

const DEFAULT_CONFIG: AppConfig = {
  baseDir: "",
  baseBookmarkName: "",
  categories: [],
  linkPatternsText: "#!url=",
  downloadConcurrency: 3,
  iCloudMetadataSync: false,
  remoteHost: "http://127.0.0.1",
  remotePort: "6171",
  remotePassword: "",
}

function normalizeDownloadConcurrency(value: unknown): number {
  const num = Number(value)
  if (!Number.isFinite(num)) return DEFAULT_CONFIG.downloadConcurrency
  return Math.max(1, Math.min(10, Math.round(num)))
}

function normalizeCategories(list: string[]): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const raw of list ?? []) {
    const name = String(raw ?? "").trim()
    if (!name) continue
    if (seen.has(name)) continue
    seen.add(name)
    out.push(name)
  }
  return out
}

export function loadConfig(): AppConfig {
  const st: any = (globalThis as any).Storage
  try {
    const raw = st?.get?.(KEY) ?? st?.getString?.(KEY)
    if (!raw) return DEFAULT_CONFIG
    const obj = JSON.parse(raw)
    const categories = normalizeCategories(obj?.categories ?? [])
    const baseDir = String(obj?.baseDir ?? "").trim()
    const baseBookmarkName = String(obj?.baseBookmarkName ?? "").trim()
    const linkPatternsText = String(obj?.linkPatternsText ?? DEFAULT_CONFIG.linkPatternsText)
    const downloadConcurrency = normalizeDownloadConcurrency(obj?.downloadConcurrency)
    const iCloudMetadataSync = !!obj?.iCloudMetadataSync
    const remoteHost = String(obj?.remoteHost ?? DEFAULT_CONFIG.remoteHost).trim() || DEFAULT_CONFIG.remoteHost
    const remotePort = String(obj?.remotePort ?? DEFAULT_CONFIG.remotePort).trim() || DEFAULT_CONFIG.remotePort
    const remotePassword = String(obj?.remotePassword ?? "")
    return {
      ...DEFAULT_CONFIG,
      ...obj,
      categories,
      baseDir,
      baseBookmarkName,
      linkPatternsText,
      downloadConcurrency,
      iCloudMetadataSync,
      remoteHost,
      remotePort,
      remotePassword,
    }
  } catch {
    return DEFAULT_CONFIG
  }
}

export function saveConfig(cfg: AppConfig): void {
  const st: any = (globalThis as any).Storage
  const fixed: AppConfig = {
    baseDir: String(cfg.baseDir ?? "").trim(),
    baseBookmarkName: String(cfg.baseBookmarkName ?? "").trim(),
    categories: normalizeCategories(cfg.categories ?? []),
    linkPatternsText: String(cfg.linkPatternsText ?? DEFAULT_CONFIG.linkPatternsText),
    downloadConcurrency: normalizeDownloadConcurrency(cfg.downloadConcurrency),
    iCloudMetadataSync: !!cfg.iCloudMetadataSync,
    remoteHost: String(cfg.remoteHost ?? DEFAULT_CONFIG.remoteHost).trim() || DEFAULT_CONFIG.remoteHost,
    remotePort: String(cfg.remotePort ?? DEFAULT_CONFIG.remotePort).trim() || DEFAULT_CONFIG.remotePort,
    remotePassword: String(cfg.remotePassword ?? ""),
  }
  const raw = JSON.stringify(fixed)
  if (st?.set) st.set(KEY, raw)
  else if (st?.setString) st.setString(KEY, raw)
  else throw new Error("Storage API 不存在：请确认 Scripting 是否提供 Storage.set/get")
}

export function addCategory(cfg: AppConfig, name: string): AppConfig {
  const categories = normalizeCategories([...(cfg.categories ?? []), name])
  return { ...cfg, categories }
}
