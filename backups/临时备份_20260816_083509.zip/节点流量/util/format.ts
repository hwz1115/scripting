export function formatExpire(expire: number) {
  if (!expire) return "";
  return new Date(expire * 1000).toLocaleDateString("zh-CN", {
    dateStyle: "long",
  });
}

/** 紧凑流量：整数 + 短单位，适合小标签 */
export function formatBytesCompact(bytes: number): string {
  const units = ["B", "K", "M", "G", "T", "P"];
  let n = Math.max(0, bytes);
  let i = 0;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i++;
  }
  if (n >= 100) return Math.round(n) + units[i];
  if (n >= 10) return n.toFixed(1).replace(/\.0$/, "") + units[i];
  return n.toFixed(1).replace(/\.0$/, "") + units[i];
}

export function formatBytes(bytes: number): { value: number; unit: string } {
  const units = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
  let i = 0;
  let n = Math.max(0, bytes);
  for (; n >= 1024 && i < units.length - 1; i++) n /= 1024;
  if (n >= 1000 && i < units.length - 1) {
    n /= 1024;
    i++;
  }
  return {
    value: +n.toFixed(2),
    unit: units[i],
  };
}

export function formatHeader(data: string) {
  return Object.fromEntries(
    data.split("; ")?.map((item) => {
      return item.split("=");
    }) || []
  );
}
