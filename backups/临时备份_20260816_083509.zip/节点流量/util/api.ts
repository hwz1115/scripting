import { fetch } from "scripting";
import { formatHeader } from "./format";

const UA_LIST = [
  "clash",
  "ClashforWindows/0.20.39",
  "ClashMeta/1.16.0",
  "v2rayN/6.23",
  "Shadowrocket/1898",
];

export class API {
  constructor(private url: string) {}

  total: number = 0;
  expire: number = 0;
  upload: number = 0;
  download: number = 0;
  title: string = "Airport";
  error: string = "";

  async fetchData() {
    let lastError = "";

    // 先 HEAD，再 GET；并轮换常见客户端 UA（很多机场会拦不认识的 UA / 不支持 HEAD）
    for (const method of ["HEAD", "GET"] as const) {
      for (const ua of UA_LIST) {
        try {
          const response = await fetch(this.url, {
            method,
            headers: {
              "User-Agent": ua,
              Accept: "*/*",
            },
            timeout: 8000,
          });

          if (!response.ok) {
            lastError = String(response.status);
            // 403/405 换方式或 UA 再试
            if (response.status === 403 || response.status === 405) {
              continue;
            }
            // 其他错误也继续试，但记下状态码
            continue;
          }

          const content = response.headers.get("content-disposition");
          const parsedTitle = this.parseTitle(content);
          if (parsedTitle) this.title = parsedTitle;

          const data = response.headers.get("subscription-userinfo");
          if (!data) {
            lastError = "无流量信息";
            continue;
          }

          const info = formatHeader(data);
          this.total = Number(info.total) || 0;
          this.expire = Number(info.expire) || 0;
          this.upload = Number(info.upload) || 0;
          this.download = Number(info.download) || 0;
          this.error = "";
          return;
        } catch (e) {
          lastError = String(e);
        }
      }
    }

    this.error = lastError || "请求失败";
    throw new Error(this.error);
  }

  private parseTitle(content: string | null): string {
    if (!content) return "";

    const disposition = formatHeader(content);
    let raw =
      disposition.filename ||
      disposition["filename*"] ||
      disposition.Filename ||
      "";

    if (!raw || typeof raw !== "string") return "";

    if (raw.includes("''")) {
      raw = raw.split("''").slice(1).join("''");
    }

    try {
      raw = decodeURIComponent(raw.replace(/^"+|"+$/g, ""));
    } catch {
      raw = raw.replace(/^"+|"+$/g, "");
    }

    const name = raw.split(/[\\/]/).pop() || raw;
    const base = name.replace(/\.[^.]+$/, "").trim();
    return base || "";
  }
}
