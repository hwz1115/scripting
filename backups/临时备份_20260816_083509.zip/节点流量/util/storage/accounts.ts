export type Account = {
  id: string;
  title: string;
  url: string;
};

const listKey = "accounts";
const activeKey = "activeAccountId";

function normalizeAccount(raw: any): Account | null {
  if (!raw || typeof raw !== "object") return null;
  const id = typeof raw.id === "string" ? raw.id : "";
  const url = typeof raw.url === "string" ? raw.url : "";
  if (!id || !url) return null;
  const title =
    typeof raw.title === "string" && raw.title.trim()
      ? raw.title.trim()
      : "Airport";
  return { id, title, url };
}

export function getAccounts(): Account[] {
  const raw = Storage.get(listKey);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map(normalizeAccount)
      .filter((a): a is Account => a !== null);
  } catch {
    return [];
  }
}

export function setAccounts(accounts: Account[]) {
  const cleaned = accounts
    .map(normalizeAccount)
    .filter((a): a is Account => a !== null);
  Storage.set(listKey, JSON.stringify(cleaned));
}

export function getActiveAccountId(): string {
  return Storage.get(activeKey) || "";
}

export function setActiveAccountId(id: string) {
  Storage.set(activeKey, id);
}

export function getActiveAccount(): Account | null {
  const accounts = getAccounts();
  if (accounts.length === 0) return null;
  const id = getActiveAccountId();
  return accounts.find((a) => a.id === id) || accounts[0];
}

const mediumLeftKey = "mediumLeftId";
const mediumRightKey = "mediumRightId";

export function getMediumLeftId(): string {
  return Storage.get(mediumLeftKey) || "";
}

export function setMediumLeftId(id: string) {
  Storage.set(mediumLeftKey, id);
}

export function getMediumRightId(): string {
  return Storage.get(mediumRightKey) || "";
}

export function setMediumRightId(id: string) {
  Storage.set(mediumRightKey, id);
}

export function getMediumAccounts(): {
  left: Account | null;
  right: Account | null;
} {
  const accounts = getAccounts();
  const leftId = getMediumLeftId();
  const rightId = getMediumRightId();
  const left = accounts.find((a) => a.id === leftId) || accounts[0] || null;
  const right =
    accounts.find((a) => a.id === rightId) ||
    accounts.find((a) => a.id !== left?.id) ||
    null;
  return { left, right };
}

const largeKey = "largeAccountIds";

export function getLargeIds(): string[] {
  const raw = Storage.get(largeKey);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((x) => typeof x === "string");
  } catch {
    return [];
  }
}

export function setLargeIds(ids: string[]) {
  Storage.set(
    largeKey,
    JSON.stringify(ids.filter((x) => typeof x === "string"))
  );
}

export function getLargeAccounts(): Account[] {
  const ids = new Set(getLargeIds());
  return getAccounts().filter((a) => ids.has(a.id));
}
