import { HStack, VStack, Text, Spacer, Gauge, Divider } from "scripting";
import { formatBytes, formatBytesCompact, formatExpire } from "../util/format";

type SideData = { api: any; title?: string; error?: string } | null;

function Side({ data }: { data: SideData }) {
  if (!data) {
    return (
      <VStack padding spacing={4}>
        <Spacer />
        <Text font={12} foregroundStyle="secondaryLabel">
          未设置
        </Text>
        <Spacer />
      </VStack>
    );
  }

  const { api, title, error } = data;
  const widgetTitle = title || api.title || "Airport";

  if (error) {
    return (
      <VStack padding={{ horizontal: 10, vertical: 8 }} spacing={4}>
        <Text font={16} bold={true} foregroundStyle="primary" lineLimit={1}>
          {widgetTitle}
        </Text>
        <Spacer />
        <Text font={12} foregroundStyle="systemRed">
          {error === "403" ? "403 被拒绝" : error}
        </Text>
        <Spacer />
      </VStack>
    );
  }

  const leftData = formatBytes(api.total - api.upload - api.download);
  const used = api.upload + api.download;
  const percent =
    api.total > 0 ? Math.min(100, Math.round((used / api.total) * 100)) : 0;
  const remainColor =
    percent < 50 ? "systemGreen" : percent < 80 ? "systemOrange" : "systemRed";
  const expireText = api.expire
    ? formatExpire(api.expire) + " 到期"
    : "长期有效";

  return (
    <VStack padding={{ horizontal: 10, vertical: 8 }} spacing={3}>
      <Text font={16} bold={true} foregroundStyle="primary" lineLimit={1}>
        {widgetTitle}
      </Text>

      <Text font={10} foregroundStyle="secondaryLabel" lineLimit={1}>
        {expireText}
      </Text>

      <HStack alignment="bottom" spacing={2}>
        <Text font={10} foregroundStyle="secondaryLabel">
          剩余
        </Text>
        <Spacer />
        <Text font={20} bold={true} foregroundStyle={remainColor}>
          {leftData.value}
        </Text>
        <Text
          font={11}
          bold={true}
          foregroundStyle={remainColor}
          padding={{ bottom: 2 }}>
          {leftData.unit}
        </Text>
      </HStack>

      <Gauge
        gaugeStyle="accessoryLinear"
        label={<Text>{""}</Text>}
        value={used}
        max={Math.max(api.total, 1)}
        tint={{ color: remainColor }}
      />

      <HStack spacing={0}>
        <VStack spacing={1} frame={{ maxWidth: "infinity" }}>
          <Text font={9} foregroundStyle="secondaryLabel">
            总量
          </Text>
          <Text font={12} bold={true} foregroundStyle="systemBlue" lineLimit={1}>
            {formatBytesCompact(api.total)}
          </Text>
        </VStack>
        <VStack spacing={1} frame={{ maxWidth: "infinity" }}>
          <Text font={9} foregroundStyle="secondaryLabel">
            下行
          </Text>
          <Text font={12} bold={true} foregroundStyle="systemGreen" lineLimit={1}>
            {"↓" + formatBytesCompact(api.download)}
          </Text>
        </VStack>
        <VStack spacing={1} frame={{ maxWidth: "infinity" }}>
          <Text font={9} foregroundStyle="secondaryLabel">
            上行
          </Text>
          <Text font={12} bold={true} foregroundStyle="systemOrange" lineLimit={1}>
            {"↑" + formatBytesCompact(api.upload)}
          </Text>
        </VStack>
      </HStack>
    </VStack>
  );
}

export function View({
  left,
  right,
}: {
  left: SideData;
  right: SideData;
}) {
  return (
    <HStack spacing={0}>
      <Side data={left} />
      <Divider />
      <Side data={right} />
    </HStack>
  );
}
