import { VStack, HStack, Text, Image, Gauge, Spacer, Divider } from "scripting";
import { formatBytes, formatExpire } from "../util/format";

type AccountData = { api: any; title?: string; error?: string };

function Row({ data }: { data: AccountData }) {
  const { api, title, error } = data;
  const widgetTitle = title || api.title || "Airport";
  const font = 13;

  if (error) {
    return (
      <VStack padding={{ top: 6, bottom: 6 }}>
        <HStack>
          <Text font={16} bold={true}>
            {widgetTitle}
          </Text>
          <Spacer />
          <Text font={12} foregroundStyle="systemRed">
            {error === "403" ? "403 被拒绝" : error}
          </Text>
        </HStack>
      </VStack>
    );
  }

  const totalData = formatBytes(api.total);
  const leftData = formatBytes(api.total - api.upload - api.download);
  const uploadData = formatBytes(api.upload);
  const downloadData = formatBytes(api.download);

  return (
    <VStack padding={{ top: 6, bottom: 6 }}>
      <HStack>
        <Text font={16} bold={true}>
          {widgetTitle}
        </Text>
        <Spacer />
        <Text font={11} foregroundStyle="secondaryLabel">
          {api.expire ? formatExpire(api.expire) + " 到期" : ""}
        </Text>
      </HStack>
      <Gauge
        padding={{ top: 4, bottom: 2 }}
        gaugeStyle="accessoryLinear"
        label={<Text>{""}</Text>}
        value={api.upload + api.download}
        max={Math.max(api.total, 1)}
      />
      <HStack padding={{ top: 2 }}>
        <Text font={font}>{"剩余 " + leftData.value + leftData.unit}</Text>
        <Spacer />
        <Text font={font}>{"总量 " + totalData.value + totalData.unit}</Text>
      </HStack>
      <HStack padding={{ top: 2 }}>
        <Image systemName="arrow.down.circle.fill" imageScale="small" />
        <Text font={font} padding={{ leading: -4 }}>
          {downloadData.value + downloadData.unit}
        </Text>
        <Spacer />
        <Image systemName="arrow.up.circle.fill" imageScale="small" />
        <Text font={font} padding={{ leading: -4 }}>
          {uploadData.value + uploadData.unit}
        </Text>
      </HStack>
    </VStack>
  );
}

export function View({ items }: { items: AccountData[] }) {
  if (items.length === 0) {
    return (
      <VStack padding>
        <Spacer />
        <Text foregroundStyle="secondaryLabel">
          请在设置中勾选要在大尺寸小组件显示的机场
        </Text>
        <Spacer />
      </VStack>
    );
  }

  return (
    <VStack padding>
      {items.map((item, index) => (
        <VStack key={item.title || String(index)}>
          <Row data={item} />
          {index < items.length - 1 ? <Divider /> : null}
        </VStack>
      ))}
    </VStack>
  );
}
