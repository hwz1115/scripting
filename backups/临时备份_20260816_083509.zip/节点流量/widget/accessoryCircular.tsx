import { Text, Gauge, VStack } from "scripting";
import { formatBytes } from "../util/format";

export function View({ api, error }: { api: any; error?: string }) {
  if (error) {
    return (
      <VStack>
        <Text font={10} foregroundStyle="systemRed">
          {error === "403" ? "403" : "ERR"}
        </Text>
      </VStack>
    );
  }

  const remain = formatBytes(api.total - (api.upload + api.download));
  const value = remain.value;

  return (
    <Gauge
      gaugeStyle="accessoryCircular"
      min={0}
      max={Math.max(api.total, 1)}
      value={api.upload + api.download}
      tint={{ color: "tertiaryLabel", opacity: 1 }}
      currentValueLabel={
        <Text>{value < 10 ? value.toFixed(1) : Math.floor(value)}</Text>
      }
      label={<Text foregroundStyle="secondaryLabel">{remain.unit}</Text>}
    />
  );
}
