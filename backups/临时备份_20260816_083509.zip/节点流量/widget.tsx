import { Widget, Text } from "scripting";
import { View as CircularView } from "./widget/accessoryCircular";
import { View as SmallView } from "./widget/small";
import { View as MediumView } from "./widget/medium";
import { View as LargeView } from "./widget/large";
import { API } from "./util/api";
import {
  getAccounts,
  getActiveAccount,
  getMediumAccounts,
  getLargeAccounts,
  Account,
} from "./util/storage/accounts";

(async () => {
  if (getAccounts().length === 0) {
    Widget.present(<Text>请先在 App 内添加机场账号</Text>);
    return;
  }

  let view = null;
  switch (Widget.family) {
    case "accessoryCircular": {
      const account = getActiveAccount()!;
      const result = await safeFetch(account);
      view = <CircularView api={result.api} error={result.error} />;
      break;
    }
    case "systemSmall": {
      const account = getActiveAccount()!;
      const result = await safeFetch(account);
      view = (
        <SmallView
          api={result.api}
          title={account.title}
          error={result.error}
        />
      );
      break;
    }
    case "systemMedium": {
      const { left, right } = getMediumAccounts();
      const leftResult = left ? await safeFetch(left) : null;
      const rightResult = right ? await safeFetch(right) : null;
      view = (
        <MediumView
          left={
            left && leftResult
              ? {
                  api: leftResult.api,
                  title: left.title,
                  error: leftResult.error,
                }
              : null
          }
          right={
            right && rightResult
              ? {
                  api: rightResult.api,
                  title: right.title,
                  error: rightResult.error,
                }
              : null
          }
        />
      );
      break;
    }
    case "systemLarge": {
      const accounts = getLargeAccounts();
      const items = [];
      for (const acc of accounts) {
        const result = await safeFetch(acc);
        items.push({
          api: result.api,
          title: acc.title,
          error: result.error,
        });
      }
      view = <LargeView items={items} />;
      break;
    }
    default:
      throw new Error("未适配的 Widget 尺寸");
  }
  Widget.present(view);
})().catch((e) => {
  Widget.present(<Text>{String(e)}</Text>);
});

async function safeFetch(account: Account): Promise<{
  api: API;
  error: string;
}> {
  const api = new API(account.url);
  try {
    await api.fetchData();
    if (!api.title || api.title === "Airport") {
      api.title = account.title || "Airport";
    }
    return { api, error: "" };
  } catch (e) {
    api.title = account.title || "Airport";
    return { api, error: String(e) };
  }
}
